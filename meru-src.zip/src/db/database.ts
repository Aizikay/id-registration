/**
 * Local persistence layer (IndexedDB via Dexie).
 *
 * localStorage is never used as a primary datastore. This database survives
 * refreshes and connectivity loss and backs the offline mode of the system.
 *
 * Security posture:
 *  - Only records needed to operate offline are cached (recently accessed).
 *  - No credentials, tokens or passwords are stored here — Supabase auth
 *    manages its own storage; the offline session uses a signed capability
 *    record with expiry (see features/auth/offline-session.ts).
 */

import Dexie, { type Table } from "dexie";
import type { IdentificationRecord, IssuanceRecord, Person, PrintHistoryRecord } from "@/types";

export interface CachedPerson extends Person {
  /** true once the server has confirmed this row */
  synced: boolean;
}

export interface CachedIssuance extends IssuanceRecord {
  synced: boolean;
  person_name?: string;
  identification_number?: string;
}

/** Pending-change journal entry (client side). Mirrors sync_operations. */
export interface OutboxEntry {
  id?: number;
  operation_id: string;
  entity_type: "person" | "issuance" | "audit_log" | "printer_status";
  entity_id: string;
  operation_type:
    | "insert_person"
    | "update_person"
    | "insert_issuance"
    | "update_issuance_status"
    | "insert_audit_log";
  payload: Record<string, unknown>;
  status: "pending" | "in_flight" | "synchronized" | "failed" | "conflict";
  retry_count: number;
  next_attempt_at: number;
  error_message: string | null;
  created_at: string;
  processed_at: string | null;
}

/** Small key/value metadata table (device id, last sync cursor, etc.) */
export interface MetaEntry {
  key: string;
  value: unknown;
}

export interface CachedPrintHistory extends PrintHistoryRecord {
  synced: boolean;
}

export class MeruIdDatabase extends Dexie {
  persons!: Table<CachedPerson, string>;
  issuances!: Table<CachedIssuance, string>;
  identifications!: Table<IdentificationRecord, string>;
  printHistory!: Table<CachedPrintHistory, string>;
  outbox!: Table<OutboxEntry, number>;
  meta!: Table<MetaEntry, string>;

  constructor() {
    super("meru-id-registry");
    this.version(2).stores({
      // Index specifications — fields we search by offline.
      persons:
        "id, identification_number, full_name, phone, department, registration_status, created_at, synced",
      issuances:
        "id, person_id, issuance_reference, idempotency_key, status, issued_at, created_at, synced",
      identifications: "id, person_id, identification_number",
      printHistory:
        "id, document_name, printer_name, status, created_at, synced",
      outbox:
        "++id, operation_id, entity_type, entity_id, status, next_attempt_at",
      meta: "key"
    });
    this.version(3).stores({
      persons:
        "id, identification_number, full_name, phone, department, registration_status, created_at, synced",
      issuances:
        "id, person_id, issuance_reference, idempotency_key, status, issued_at, created_at, synced",
      identifications: "id, person_id, identification_number",
      printHistory:
        "id, document_name, printer_name, status, created_at, synced",
      outbox:
        "++id, operation_id, entity_type, entity_id, status, next_attempt_at",
      meta: "key"
    });
  }
}

export const db = new MeruIdDatabase();

export async function getMeta<T>(key: string): Promise<T | undefined> {
  const entry = await db.meta.get(key);
  return entry?.value as T | undefined;
}

export async function setMeta(key: string, value: unknown): Promise<void> {
  await db.meta.put({ key, value });
}

/**
 * Purge ALL locally stored data. Invoked on explicit secure logout,
 * or when an administrator revokes this device.
 */
export async function purgeLocalData(): Promise<void> {
  await Promise.all([
    db.persons.clear(),
    db.issuances.clear(),
    db.identifications.clear(),
    db.printHistory.clear(),
    db.outbox.clear(),
    db.meta.clear()
  ]);
}
