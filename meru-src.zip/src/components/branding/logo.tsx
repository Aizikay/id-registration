/**
 * Branding components for Meru District Council.
 *
 * Official government logos are loaded from /public/branding/.
 * If an asset is missing, a clearly-marked professional placeholder is rendered.
 */

import { useState } from "react";
import { BRANDING_ASSETS, ORGANIZATION } from "@/lib/constants";
import { cn } from "@/lib/cn";

function useImageAvailable(src: string): boolean {
  const [available, setAvailable] = useState<boolean | null>(null);
  if (available === null) {
    const img = new Image();
    img.onload = () => setAvailable(true);
    img.onerror = () => setAvailable(false);
    img.src = src;
  }
  return available === true;
}

/** Meru District Council logo */
export function CouncilLogo({
  className,
  size = 56,
}: {
  className?: string;
  size?: number;
}) {
  const available = useImageAvailable(BRANDING_ASSETS.councilLogo);
  if (available) {
    return (
      <div
        className={cn(
          "relative flex items-center justify-center rounded-full overflow-hidden",
          className
        )}
        style={{ width: size, height: size }}
      >
        <img
          src={BRANDING_ASSETS.councilLogo}
          alt={`${ORGANIZATION.nameEn} logo`}
          width={size}
          height={size}
          className="object-cover w-full h-full"
        />
        <div className="absolute inset-0 rounded-full ring-2 ring-white/30" />
      </div>
    );
  }

  return (
    <div
      aria-label="Meru District Council logo"
      title="Place authorized logo at public/branding/meru-logo.jpeg"
      style={{ width: size, height: size }}
      className={cn(
        "flex items-center justify-center rounded-full",
        "bg-gradient-to-br from-council-600 to-council-800",
        "text-white font-medium shadow-glow",
        className
      )}
    >
      <span style={{ fontSize: size * 0.35 }}>MDC</span>
    </div>
  );
}

/** Tanzania Coat of Arms */
export function TanzaniaCoatOfArms({
  size = 80,
  className,
}: {
  size?: number;
  className?: string;
}) {
  const available = useImageAvailable(BRANDING_ASSETS.coatOfArms);
  if (available) {
    return (
      <div
        className={cn("relative flex items-center justify-center", className)}
      >
        <img
          src={BRANDING_ASSETS.coatOfArms}
          alt="Tanzania Coat of Arms"
          width={size}
          height={size}
          className="object-contain drop-shadow-sm"
        />
      </div>
    );
  }

  return (
    <div
      role="img"
      aria-label="Tanzania Coat of Arms"
      title="Place authorized asset at public/branding/coat-of-arms.png"
      style={{ width: size, height: size * 0.75 }}
      className={cn(
        "flex flex-col items-center justify-center rounded-xl",
        "border-2 border-dashed border-council-200 bg-council-50/50",
        "px-3 text-center backdrop-blur-sm",
        className
      )}
    >
      <span className="text-[9px] font-medium uppercase tracking-[0.15em] text-council-400">
        Coat of Arms
      </span>
      <span className="mt-0.5 text-[7px] text-council-300">
        Add authorized asset
      </span>
    </div>
  );
}

/** Header icon — compact logo for the top navigation bar */
export function HeaderIcon({
  size = 32,
  className,
}: {
  size?: number;
  className?: string;
}) {
  const available = useImageAvailable(BRANDING_ASSETS.councilLogo);
  if (available) {
    return (
      <div
        className={cn(
          "relative flex items-center justify-center rounded-lg overflow-hidden",
          "ring-1 ring-council-700/20 shadow-sm",
          className
        )}
        style={{ width: size, height: size }}
      >
        <img
          src={BRANDING_ASSETS.councilLogo}
          alt=""
          width={size}
          height={size}
          className="object-cover w-full h-full"
        />
      </div>
    );
  }

  return (
    <div
      aria-hidden="true"
      style={{ width: size, height: size }}
      className={cn(
        "flex items-center justify-center rounded-lg",
        "bg-gradient-to-br from-council-600 to-council-800",
        "text-white font-medium text-[10px] shadow-sm",
        className
      )}
    >
      MDC
    </div>
  );
}

/** Full organization header with logo and text */
export function OrganizationHeader({
  compact,
  className,
  align = "center",
}: {
  compact?: boolean;
  className?: string;
  align?: "center" | "left";
}) {
  return (
    <div
      className={cn(
        "flex items-center gap-3",
        align === "center"
          ? "flex-col text-center sm:flex-row sm:text-left"
          : "text-left",
        className
      )}
    >
      <CouncilLogo size={compact ? 42 : 56} />
      <div>
        <h1
          className={cn(
            "font-display font-medium uppercase tracking-wide",
            compact ? "text-xs" : "text-sm sm:text-base"
          )}
        >
          {ORGANIZATION.nameSw}
        </h1>
        <p
          className={cn(
            "tracking-wide text-surface-400",
            compact ? "text-[10px]" : "text-[11px] sm:text-xs"
          )}
        >
          {ORGANIZATION.nameEn}
        </p>
      </div>
    </div>
  );
}
