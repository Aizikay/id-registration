from django.urls import path
from . import views

app_name = 'core'

urlpatterns = [
    # =====================================================
    # AUTHENTICATION
    # =====================================================
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('register/', views.register_view, name='register'),
    
    # =====================================================
    # DASHBOARD ROUTER & ROLE-SPECIFIC DASHBOARDS
    # =====================================================
    path('dashboard/', views.dashboard, name='dashboard'),
    path('user/dashboard/', views.user_dashboard_view, name='user_dashboard_view'),
    path('officer/dashboard/', views.officer_dashboard_view, name='officer_dashboard_view'),
    path('manager/dashboard/', views.manager_dashboard_view, name='manager_dashboard_view'),
    path('dashboard/admin/', views.admin_dashboard_view, name='admin_dashboard_view'),
    path('superadmin/dashboard/', views.superadmin_dashboard_view, name='superadmin_dashboard_view'),

    # =====================================================
    # USER MANAGEMENT - GENERAL
    # =====================================================
    path('users/', views.UserProfileListView.as_view(), name='userprofile_list'),
    path('users/<int:pk>/', views.UserProfileDetailView.as_view(), name='userprofile_detail'),
    path('users/create/', views.UserProfileCreateView.as_view(), name='userprofile_create'),
    path('users/<int:pk>/update/', views.UserProfileUpdateView.as_view(), name='userprofile_update'),
    
    
      path('api/check-alerts/', views.check_alerts_api, name='check_alerts_api'),
    
    
    # =====================================================
# HIERARCHICAL PROMOTION/DEMOTION WORKFLOW
# =====================================================

# 1. SUPERADMIN-ONLY PROMOTION VIEWS
path('superadmin/demote-from-admin/<int:user_id>/',
     views.demote_from_admin, name='demote_from_admin'),
path('superadmin/bulk-promote/',
     views.bulk_promote_users, name='bulk_promote_users'),
path('superadmin/promote-to-superadmin/<int:user_id>/',
     views.promote_to_superadmin, name='promote_to_superadmin'),

# 2. ADMIN PROMOTION VIEWS (Admin and SuperAdmin can access)
path('admin/demote-user/<int:user_id>/',
     views.admin_demote_user, name='admin_demote_user'),

# 3. UNIFIED PROMOTION/DEMOTION VIEW (for any role change)
path('users/<int:pk>/promote/',
     views.promote_user, name='promote_user'),

# 4. ROLE HISTORY & AUDIT
path('user-role-history/<int:user_id>/',
     views.user_role_history, name='user_role_history'),

# 5. API ENDPOINTS (if used)
path('api/validate-promotion/<int:user_id>/',
     views.validate_promotion_request, name='validate_promotion'),
path('api/user-role-info/<int:user_id>/',
     views.get_user_role_info, name='user_role_info'),
    
    
    # =====================================================
    # ASSET MANAGEMENT
    # =====================================================
    path('assets/', views.AssetListView.as_view(), name='asset_list'),
    path('assets/<int:pk>/', views.AssetDetailView.as_view(), name='asset_detail'),
    path('assets/create/', views.AssetCreateView.as_view(), name='asset_create'),
    path('assets/<int:pk>/update/', views.AssetUpdateView.as_view(), name='asset_update'),
    path('assets/<int:pk>/delete/', views.AssetDeleteView.as_view(), name='asset_delete'),
    path('assets/search/', views.asset_search, name='asset_search'),
    path('assets/<int:pk>/qr/', views.generate_asset_qr, name='generate_asset_qr'),
    path('assets/<int:pk>/barcode/', views.generate_asset_barcode, name='generate_asset_barcode'),
    path('assets/my/', views.MyAssetsView.as_view(), name='my_assets'),

    # =====================================================
    # ASSET REQUESTS & ASSIGNMENTS
    # =====================================================
    path('assetrequests/create/', views.AssetRequestCreateView.as_view(), name='assetrequest_create'),
    path('assetrequests/', views.AssetRequestListView.as_view(), name='assetrequest_list'),
    path('assets/assign/<int:request_id>/', views.asset_assignment_view, name='asset_assignment'),
    path('assets/assign/', views.asset_assignment_view, name='asset_assignment_no_request'),
    path('assetrequests/<int:pk>/reject/', views.reject_asset_request, name='reject_asset_request'),

    # =====================================================
    # ASSET MOVEMENT
    # =====================================================
    path('assetmovements/create/', views.AssetMovementCreateView.as_view(), name='assetmovement_create'),
    path('assetmovements/', views.AssetMovementListView.as_view(), name='assetmovement_list'),
    path('assets/<int:asset_pk>/movements/', views.asset_movement_history, name='asset_movement_history'),

    # =====================================================
    # USAGE TRACKING
    # =====================================================
    path('assetusagelogs/create/', views.AssetUsageLogCreateView.as_view(), name='assetusagelog_create'),
    path('assetusagelogs/', views.AssetUsageLogListView.as_view(), name='assetusage_list'),
    path('assets/<int:asset_pk>/usage/summary/', views.asset_usage_summary, name='asset_usage_summary'),

    # =====================================================
    # PREDICTIVE MAINTENANCE
    # =====================================================
    path('predictive/alerts/', views.PredictiveAlertView.as_view(), name='predictive_alert_view'),
    path('predictive/evaluate/', views.evaluate_predictive_maintenance, name='evaluate_predictive'),

    # =====================================================
    # MAINTENANCE LOGS
    # =====================================================
    path('maintenancelogs/create/', views.MaintenanceLogView.as_view(), name='maintenancelog_create'),
    path('maintenancelogs/', views.MaintenanceLogListView.as_view(), name='maintenancelog_list'),
    path('assets/<int:asset_pk>/maintenance/history/', views.maintenance_history, name='maintenance_history'),

    # =====================================================
    # TICKETING SYSTEM
    # =====================================================
    path('tickets/report/', views.IncidentReportView.as_view(), name='incident_report'),
    path('tickets/queue/', views.TicketQueueView.as_view(), name='ticket_queue_view'),
    path('tickets/<int:pk>/', views.TicketDetailView.as_view(), name='ticket_detail'),
    path('tickets/<int:pk>/update/', views.TicketUpdateView.as_view(), name='ticket_update'),
    path('tickets/<int:pk>/close/', views.close_ticket, name='close_ticket'),
    path('tickets/<int:ticket_id>/assign/', views.assign_ticket_to_officer, name='assign_ticket'),
    path('tickets/', views.UserTicketListView.as_view(), name='ticket_list'),

    # =====================================================
    # INVENTORY MANAGEMENT
    # =====================================================
    path('inventory/items/', views.InventoryItemListView.as_view(), name='inventoryitem_list'),
    path('inventory/items/create/', views.InventoryItemCreateView.as_view(), name='inventoryitem_create'),
    path('inventory/items/<int:pk>/update/', views.InventoryItemUpdateView.as_view(), name='inventoryitem_update'),
    path('inventory/management/', views.inventory_management_view, name='inventory_management_view'),

    # =====================================================
    # PROCUREMENT REQUESTS
    # =====================================================
    path('procurements/create/', views.ProcurementRequestCreateView.as_view(), name='procurementrequest_create'),
    path('procurements/', views.ProcurementRequestListView.as_view(), name='procurementrequest_list'),
    path('procurements/batch/approve/', views.batch_approve_requests, name='batch_approve_requests'),
    path('procurements/<int:pk>/approve/', views.approve_procurement, name='approve_procurement'),
    path('procurements/<int:pk>/reject/', views.reject_procurement, name='reject_procurement'),

    # =====================================================
    # REPORTS
    # =====================================================
    path('reports/asset/', views.asset_report, name='asset_report'),
path('reports/maintenance/', views.maintenance_report, name='maintenance_report'),
path('reports/usage/', views.usage_report, name='usage_report'),
path('reports/risk/', views.risk_report, name='risk_report'),
    # =====================================================
    
    # =====================================================
# CATEGORY MANAGEMENT (SuperAdmin only)
# =====================================================
path('categories/', views.CategoryListView.as_view(), name='category_list'),
path('categories/create/', views.CategoryCreateView.as_view(), name='category_create'),
path('categories/<int:pk>/update/', views.CategoryUpdateView.as_view(), name='category_update'),
path('categories/<int:pk>/delete/', views.CategoryDeleteView.as_view(), name='category_delete'),
    # AUDIT LOGS
    # =====================================================
    path('audits/', views.AuditLogListView.as_view(), name='auditlog_list'),
    path('audits/<int:pk>/', views.AuditLogDetailView.as_view(), name='auditlog_detail'),
    path('audits/export/', views.export_audit, name='export_audit'),

    # =====================================================
    # SYSTEM SETTINGS
    # =====================================================
    path('settings/', views.SystemSettingListView.as_view(), name='systemsetting_list'),
    path('settings/<int:pk>/', views.SystemSettingDetailView.as_view(), name='systemsetting_detail'),
    path('settings/<int:pk>/update/', views.update_system_setting, name='update_system_setting'),

    # =====================================================
    # ROLE PERMISSIONS
    # =====================================================
    path('roles/permissions/', views.RolePermissionListView.as_view(), name='rolepermission_list'),
    path('roles/permissions/<int:pk>/update/', views.RolePermissionUpdateView.as_view(), name='rolepermission_update'),

    # =====================================================
    # SECURITY & LOGIN ATTEMPTS
    # =====================================================
    path('logs/login_attempts/', views.login_attempt_logs, name='login_attempt_logs'),

    # =====================================================
    # NOTIFICATIONS
    # =====================================================
    path('notifications/', views.notifications_view, name='notifications_view'),
    path('officer/notifications/', views.officer_notifications_view, name='officer_notifications_view'),

    # =====================================================
    # POLICY ACKNOWLEDGEMENT
    # =====================================================
    path('assets/<int:asset_id>/acknowledge_policy/', views.acknowledge_policy_view, name='acknowledge_policy_view'),

    # =====================================================
    # ENTERPRISE FEATURES
    # =====================================================
    path('requests/temporary_access/create/', views.TemporaryAccessRequestCreateView.as_view(), name='temporaryaccessrequest_create'),
    path('assets/transfer/create/', views.AssetTransferRequestCreateView.as_view(), name='assettransferrequest_create'),
    path('assets/<int:pk>/return/', views.AssetReturnRequestView.as_view(), name='asset_return_request'),

    # =====================================================
    # SUPERADMIN OVERRIDES
    # =====================================================
    path('assets/<int:asset_id>/override_assignment/', views.override_assignment, name='override_assignment'),
    
    # =====================================================
    # API ENDPOINTS (For AJAX operations - NEW)
    # =====================================================
    path('api/validate-promotion/<int:user_id>/', views.validate_promotion_request, name='validate_promotion'),
    path('api/get-user-roles/<int:user_id>/', views.get_user_role_info, name='get_user_role_info'),
    
    
    
    
    
    
    # Department Management
    path('departments/', views.DepartmentListView.as_view(), name='department_list'),
    path('departments/create/', views.DepartmentCreateView.as_view(), name='department_create'),
    path('departments/<int:pk>/update/', views.DepartmentUpdateView.as_view(), name='department_update'),
    path('departments/<int:pk>/delete/', views.DepartmentDeleteView.as_view(), name='department_delete'),

    # User Department Assignment
    path('users/<int:user_id>/assign-department/', views.assign_user_department, name='assign_user_department'),
    path('users/bulk-assign-department/', views.bulk_assign_department, name='bulk_assign_department'),
]
    
    
    
  








