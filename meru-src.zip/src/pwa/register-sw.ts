/**
 * Service Worker registration.
 *
 * Registers the service worker for offline caching.
 * In development, it uses the dev server's built-in HMR.
 * In production, it caches all static assets.
 */

export function registerServiceWorker(): void {
  if (typeof window === "undefined") return;
  if (!("serviceWorker" in navigator)) {
    console.log("[PWA] Service Worker not supported");
    return;
  }

  window.addEventListener("load", async () => {
    try {
      const registration = await navigator.serviceWorker.register("/sw.js", {
        scope: "/",
      });

      console.log("[PWA] Service Worker registered:", registration.scope);

      // Check for updates periodically
      setInterval(() => {
        registration.update().catch(() => {
          // Silently ignore update check failures
        });
      }, 60 * 60 * 1000); // Check every hour

      // Listen for updates
      registration.addEventListener("updatefound", () => {
        const newWorker = registration.installing;
        if (!newWorker) return;

        newWorker.addEventListener("statechange", () => {
          if (newWorker.state === "activated") {
            console.log("[PWA] New Service Worker activated");
            // Optionally notify user of update
            if (document.visibilityState === "visible") {
              showUpdateNotification();
            }
          }
        });
      });
    } catch (error) {
      console.warn("[PWA] Service Worker registration failed:", error);
    }
  });
}

function showUpdateNotification(): void {
  // Create a subtle update notification
  const banner = document.createElement("div");
  banner.id = "pwa-update-banner";
  banner.style.cssText = `
    position: fixed;
    bottom: 20px;
    left: 50%;
    transform: translateX(-50%);
    background: #065f46;
    color: white;
    padding: 12px 24px;
    border-radius: 12px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.3);
    z-index: 10000;
    font-family: system-ui, -apple-system, sans-serif;
    font-size: 14px;
    display: flex;
    align-items: center;
    gap: 12px;
    animation: slideUp 0.3s ease-out;
  `;
  banner.innerHTML = `
    <span>App updated! Refresh for the latest version.</span>
    <button onclick="window.location.reload()" style="
      background: white;
      color: #065f46;
      border: none;
      padding: 6px 16px;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
      font-size: 13px;
    ">Refresh</button>
    <button onclick="this.parentElement.remove()" style="
      background: transparent;
      color: rgba(255,255,255,0.7);
      border: none;
      padding: 6px;
      cursor: pointer;
      font-size: 16px;
    ">×</button>
  `;

  // Add animation keyframes
  const style = document.createElement("style");
  style.textContent = `
    @keyframes slideUp {
      from { transform: translateX(-50%) translateY(100px); opacity: 0; }
      to { transform: translateX(-50%) translateY(0); opacity: 1; }
    }
  `;
  document.head.appendChild(style);
  document.body.appendChild(banner);

  // Auto-dismiss after 10 seconds
  setTimeout(() => {
    if (banner.parentElement) {
      banner.style.animation = "slideUp 0.3s ease-out reverse";
      setTimeout(() => banner.remove(), 300);
    }
  }, 10000);
}
