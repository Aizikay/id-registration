/**
 * TemplateEditPanel — Edit custom template fields, photo areas, and signatures.
 */

import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input, Select } from "@/components/ui/form";
import { Icon } from "@/components/icons/icon";
import type { CustomTemplate, CustomFieldConfig } from "../template-manager";
import { updateTemplate } from "../template-manager";
import { useState } from "react";
import { GlassCheckbox } from "@/components/GlassCheckbox";

interface Props {
  template: CustomTemplate;
  onUpdate: (template: CustomTemplate) => void;
  selectedField: string | null;
  onSelectField: (fieldId: string | null) => void;
}

export function TemplateEditPanel({
  template,
  onUpdate,
  selectedField,
  onSelectField,
}: Props) {
  const [editingTemplate, setEditingTemplate] = useState(template);

  const save = (updates: Partial<CustomTemplate>) => {
    const updated = { ...editingTemplate, ...updates };
    setEditingTemplate(updated);
    void updateTemplate(editingTemplate.id, updates);
    onUpdate(updated);
  };

  const updateField = (fieldId: string, patch: Partial<CustomFieldConfig>) => {
    const updatedFields = editingTemplate.fields.map((f) =>
      f.id === fieldId ? { ...f, ...patch } : f
    );
    save({ fields: updatedFields });
  };

  const addField = () => {
    const id = `field-${Date.now()}`;
    const newField: CustomFieldConfig = {
      id,
      label: "New Field",
      dataKey: null,
      staticText: "Text",
      position: { xPct: 10, yPct: 65, wPct: 30, hPct: 4 },
      style: {
        fontSizePt: 10,
        fontWeight: 500,
        fontFamily: "Arial, sans-serif",
        letterSpacingEm: 0,
        lineHeight: 1.2,
        textAlign: "left",
        color: "#333333",
      },
      visible: true,
    };
    save({ fields: [...editingTemplate.fields, newField] });
    onSelectField(id);
  };

  const removeField = (fieldId: string) => {
    save({ fields: editingTemplate.fields.filter((f) => f.id !== fieldId) });
    if (selectedField === fieldId) onSelectField(null);
  };

  const selectedFieldObj = editingTemplate.fields.find((f) => f.id === selectedField);

  return (
    <div className="space-y-4">
      {/* Template info */}
      <Card>
        <CardHeader
          title={editingTemplate.name}
          subtitle={`${editingTemplate.sourceType.toUpperCase()} · ${editingTemplate.width}×${editingTemplate.height}px`}
          icon={<Icon name="settings" className="h-4 w-4" />}
        />
        <CardBody className="space-y-3">
          <Input
            label="Template Name"
            value={editingTemplate.name}
            onChange={(e) => save({ name: e.target.value })}
          />
          <div className="grid grid-cols-2 gap-3">
            <Input
              label="Width (px)"
              type="number"
              value={String(editingTemplate.width)}
              onChange={(e) => {
                const w = Number(e.target.value);
                save({ width: w, aspectRatio: w / editingTemplate.height });
              }}
            />
            <Input
              label="Height (px)"
              type="number"
              value={String(editingTemplate.height)}
              onChange={(e) => {
                const h = Number(e.target.value);
                save({ height: h, aspectRatio: editingTemplate.width / h });
              }}
            />
          </div>
        </CardBody>
      </Card>

      {/* Fields */}
      <Card>
        <CardHeader
          title="Text Fields"
          subtitle={`${editingTemplate.fields.length} field(s)`}
          icon={<Icon name="pencil" className="h-4 w-4" />}
          actions={
            <Button
              size="sm"
              variant="ghost"
              onClick={addField}
              icon={<Icon name="plus" className="h-3.5 w-3.5" />}
            >
              Add
            </Button>
          }
        />
        <CardBody className="space-y-2">
          {editingTemplate.fields.map((field) => (
            <div
              key={field.id}
              onClick={() => onSelectField(field.id)}
              className={`flex cursor-pointer items-center justify-between rounded-xl px-3 py-2 transition-colors ${
                selectedField === field.id
                  ? "bg-council-50 border border-council-200"
                  : "hover:bg-surface-50 border border-transparent"
              }`}
            >
              <div className="min-w-0">
                <span className="text-sm font-medium text-surface-700">
                  {field.label}
                </span>
                <span className="ml-2 text-xs text-surface-400">
                  {field.dataKey || "static"}
                </span>
              </div>
              <div className="flex items-center gap-1">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    updateField(field.id, { visible: !field.visible });
                  }}
                  className={`rounded p-1 ${field.visible ? "text-council-600" : "text-surface-300"}`}
                >
                  <Icon name={field.visible ? "eye" : "eye-off"} className="h-3.5 w-3.5" />
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    removeField(field.id);
                  }}
                  className="rounded p-1 text-surface-300 hover:text-red-500"
                >
                  <Icon name="trash" className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          ))}
          {editingTemplate.fields.length === 0 && (
            <p className="text-center text-sm text-surface-400 py-4">
              No fields yet. Click "Add" to create one.
            </p>
          )}
        </CardBody>
      </Card>

      {/* Selected field editor */}
      {selectedFieldObj && (
        <Card>
          <CardHeader
            title={`Edit: ${selectedFieldObj.label}`}
            icon={<Icon name="sliders" className="h-4 w-4" />}
          />
          <CardBody className="space-y-3">
            <Input
              label="Label"
              value={selectedFieldObj.label}
              onChange={(e) => updateField(selectedFieldObj.id, { label: e.target.value })}
            />
            <Input
              label="Static Text"
              value={selectedFieldObj.staticText || ""}
              onChange={(e) => updateField(selectedFieldObj.id, { staticText: e.target.value })}
              hint="Used when no data is bound"
            />
            <div className="grid grid-cols-2 gap-3">
              <Input
                label="X (%)"
                type="number"
                step={0.5}
                value={String(selectedFieldObj.position.xPct)}
                onChange={(e) =>
                  updateField(selectedFieldObj.id, {
                    position: { ...selectedFieldObj.position, xPct: Number(e.target.value) },
                  })
                }
              />
              <Input
                label="Y (%)"
                type="number"
                step={0.5}
                value={String(selectedFieldObj.position.yPct)}
                onChange={(e) =>
                  updateField(selectedFieldObj.id, {
                    position: { ...selectedFieldObj.position, yPct: Number(e.target.value) },
                  })
                }
              />
              <Input
                label="Width (%)"
                type="number"
                step={0.5}
                value={String(selectedFieldObj.position.wPct)}
                onChange={(e) =>
                  updateField(selectedFieldObj.id, {
                    position: { ...selectedFieldObj.position, wPct: Number(e.target.value) },
                  })
                }
              />
              <Input
                label="Height (%)"
                type="number"
                step={0.5}
                value={String(selectedFieldObj.position.hPct)}
                onChange={(e) =>
                  updateField(selectedFieldObj.id, {
                    position: { ...selectedFieldObj.position, hPct: Number(e.target.value) },
                  })
                }
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Input
                label="Font Size (pt)"
                type="number"
                step={0.5}
                value={String(selectedFieldObj.style.fontSizePt)}
                onChange={(e) =>
                  updateField(selectedFieldObj.id, {
                    style: { ...selectedFieldObj.style, fontSizePt: Number(e.target.value) },
                  })
                }
              />
              <Select
                label="Font Weight"
                value={String(selectedFieldObj.style.fontWeight)}
                onChange={(e) =>
                  updateField(selectedFieldObj.id, {
                    style: { ...selectedFieldObj.style, fontWeight: Number(e.target.value) },
                  })
                }
                options={[
                  { value: "400", label: "Regular" },
                  { value: "500", label: "Medium" },
                  { value: "600", label: "Semibold" },
                  { value: "700", label: "Bold" },
                  { value: "800", label: "Extra Bold" },
                ]}
              />
            </div>
            <Input
              label="Text Color"
              type="color"
              value={selectedFieldObj.style.color}
              onChange={(e) =>
                updateField(selectedFieldObj.id, {
                  style: { ...selectedFieldObj.style, color: e.target.value },
                })
              }
            />
            <div className="flex gap-2">
              {(["left", "center", "right"] as const).map((align) => (
                <Button
                  key={align}
                  size="sm"
                  variant={selectedFieldObj.style.textAlign === align ? "primary" : "outline"}
                  onClick={() =>
                    updateField(selectedFieldObj.id, {
                      style: { ...selectedFieldObj.style, textAlign: align },
                    })
                  }
                >
                  {align}
                </Button>
              ))}
            </div>
            <Select
              label="Text Transform"
              value={selectedFieldObj.style.textTransform || "none"}
              onChange={(e) =>
                updateField(selectedFieldObj.id, {
                  style: { ...selectedFieldObj.style, textTransform: e.target.value as "uppercase" | "none" },
                })
              }
              options={[
                { value: "none", label: "None" },
                { value: "uppercase", label: "UPPERCASE" },
              ]}
            />
          </CardBody>
        </Card>
      )}

      {/* Photo area settings */}
      <Card>
        <CardHeader
          title="Photo Area"
          icon={<Icon name="image" className="h-4 w-4" />}
        />
        <CardBody className="space-y-3">
          <div className="flex items-center gap-2">
            <GlassCheckbox
              checked={editingTemplate.photo.enabled}
              onChange={(e) => save({ photo: { ...editingTemplate.photo, enabled: e.target.checked } })}
            />
            <span className="text-sm text-surface-700">Enable photo area</span>
          </div>
          {editingTemplate.photo.enabled && (
            <>
              <div className="grid grid-cols-2 gap-3">
                <Input
                  label="X (%)"
                  type="number"
                  step={0.5}
                  value={String(editingTemplate.photo.position.xPct)}
                  onChange={(e) =>
                    save({
                      photo: {
                        ...editingTemplate.photo,
                        position: { ...editingTemplate.photo.position, xPct: Number(e.target.value) },
                      },
                    })
                  }
                />
                <Input
                  label="Y (%)"
                  type="number"
                  step={0.5}
                  value={String(editingTemplate.photo.position.yPct)}
                  onChange={(e) =>
                    save({
                      photo: {
                        ...editingTemplate.photo,
                        position: { ...editingTemplate.photo.position, yPct: Number(e.target.value) },
                      },
                    })
                  }
                />
                <Input
                  label="Width (%)"
                  type="number"
                  step={0.5}
                  value={String(editingTemplate.photo.position.wPct)}
                  onChange={(e) =>
                    save({
                      photo: {
                        ...editingTemplate.photo,
                        position: { ...editingTemplate.photo.position, wPct: Number(e.target.value) },
                      },
                    })
                  }
                />
                <Input
                  label="Height (%)"
                  type="number"
                  step={0.5}
                  value={String(editingTemplate.photo.position.hPct)}
                  onChange={(e) =>
                    save({
                      photo: {
                        ...editingTemplate.photo,
                        position: { ...editingTemplate.photo.position, hPct: Number(e.target.value) },
                      },
                    })
                  }
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Input
                  label="Border Radius"
                  type="number"
                  step={1}
                  value={String(editingTemplate.photo.borderRadius)}
                  onChange={(e) =>
                    save({ photo: { ...editingTemplate.photo, borderRadius: Number(e.target.value) } })
                  }
                />
                <Input
                  label="Border Color"
                  type="color"
                  value={editingTemplate.photo.borderColor}
                  onChange={(e) =>
                    save({ photo: { ...editingTemplate.photo, borderColor: e.target.value } })
                  }
                />
              </div>
              <Select
                label="Object Fit"
                value={editingTemplate.photo.objectFit}
                onChange={(e) =>
                  save({ photo: { ...editingTemplate.photo, objectFit: e.target.value as "cover" | "contain" | "fill" } })
                }
                options={[
                  { value: "cover", label: "Cover" },
                  { value: "contain", label: "Contain" },
                  { value: "fill", label: "Fill" },
                ]}
              />
            </>
          )}
        </CardBody>
      </Card>
    </div>
  );
}
