import { execFile } from "node:child_process";
import { promisify } from "node:util";

const execFileAsync = promisify(execFile);

export interface AgentPrinterInfo {
  id: string;
  name: string;
  is_default: boolean;
  status: "online" | "offline" | "unknown" | "error";
  location?: string;
}

interface RawPrinter {
  Name?: string;
  PrinterStatus?: number;
  PrinterState?: number;
  Location?: string;
  Shared?: boolean;
  Default?: boolean;
}

/**
 * Discover printers on this Windows workstation.
 * Tries PowerShell Get-Printer; falls back to wmic; falls back to a mock list
 * when neither is available (e.g. CI / non-Windows dev).
 */
export async function discoverPrinters(): Promise<AgentPrinterInfo[]> {
  // PowerShell is the most reliable on modern Windows.
  const ps = await tryPowerShell();
  if (ps.length > 0) return ps;

  const wmic = await tryWmic();
  if (wmic.length > 0) return wmic;

  return mockPrinters();
}

async function tryPowerShell(): Promise<AgentPrinterInfo[]> {
  // Get-Printer exists on Windows 8+ / Server 2012+.
  const script =
    "Get-Printer | Select-Object Name, PrinterStatus, PrinterState, Location, Shared | ConvertTo-Json -Compress";
  try {
    const { stdout } = await execFileAsync("powershell.exe", ["-NoProfile", "-Command", script], {
      timeout: 8000,
      windowsHide: true
    });
    const raw = stdout.trim();
    if (!raw) return [];
    const parsed: RawPrinter | RawPrinter[] = JSON.parse(raw);
    const list = Array.isArray(parsed) ? parsed : [parsed];
    return list
      .filter((p) => typeof p.Name === "string" && p.Name.trim() !== "")
      .map((p, idx) => ({
        id: slug(p.Name!.trim()),
        name: p.Name!.trim(),
        is_default: idx === 0,
        status: mapPsStatus(p.PrinterStatus),
        location: p.Location?.trim() || undefined
      }));
  } catch {
    return [];
  }
}

async function tryWmic(): Promise<AgentPrinterInfo[]> {
  // wmic is deprecated but still present on many Windows 10/11 installs.
  try {
    const { stdout } = await execFileAsync("wmic", ["printer", "get", "name,default,location,workoffline", "/format:csv"], {
      timeout: 6000,
      windowsHide: true
    });
    const lines = stdout
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter((l) => l && !l.startsWith("Node"));
    // CSV header: Node,Default,Location,Name,WorkOffline
    const rows = lines.slice(1);
    const printers: AgentPrinterInfo[] = [];
    for (const row of rows) {
      const cols = row.split(",").map((c) => c.trim());
      // wmic csv order may vary; last column is usually Name.
      const name = cols[cols.length - 2] ?? cols[cols.length - 1] ?? "";
      if (!name) continue;
      printers.push({
        id: slug(name),
        name,
        is_default: cols[1]?.toLowerCase() === "true",
        status: cols[cols.length - 1]?.toLowerCase() === "true" ? "offline" : "online",
        location: cols[2] || undefined
      });
    }
    return printers;
  } catch {
    return [];
  }
}

function mockPrinters(): AgentPrinterInfo[] {
  return [
    {
      id: "mock-council-printer-1",
      name: "Meru Council — Main Hall Printer (Mock)",
      is_default: true,
      status: "online",
      location: "Main Hall"
    },
    {
      id: "mock-council-printer-2",
      name: "Meru Council — Registry Office Printer (Mock)",
      is_default: false,
      status: "online",
      location: "Registry Office"
    }
  ];
}

function mapPsStatus(code: number | undefined): AgentPrinterInfo["status"] {
  // PrinterStatus WMI values: https://learn.microsoft.com/en-us/windows/win32/printdocs/printerstatus
  // 3=Idle, 4=Printing, 5=Warming up -> online; 0=Other, 1=Unknown -> unknown; 2=Error-like
  if (code === undefined) return "unknown";
  if (code === 3 || code === 4 || code === 5) return "online";
  if (code === 2 || code === 6 || code === 7) return "error";
  return "unknown";
}

function slug(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 64);
}
