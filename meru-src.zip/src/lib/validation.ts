import {
  IDENTIFICATION_NUMBER_PATTERN,
  TANZANIA_PHONE_PATTERN
} from "./constants";

export interface ValidationResult {
  valid: boolean;
  message?: string;
}

export function validateFullName(name: string): ValidationResult {
  const trimmed = name.trim();
  if (!trimmed) return { valid: false, message: "Jina kamili linahitajika / Full name is required" };
  if (trimmed.length < 3) return { valid: false, message: "Name must be at least 3 characters" };
  if (trimmed.length > 120) return { valid: false, message: "Name must not exceed 120 characters" };
  // Letters, spaces, apostrophes, hyphens — covers Swahili/English names.
  if (!/^[\p{L}][\p{L}\s'’-]*$/u.test(trimmed)) {
    return { valid: false, message: "Name may only contain letters, spaces, apostrophes and hyphens" };
  }
  return { valid: true };
}

export function validateIdentificationNumber(value: string): ValidationResult {
  const trimmed = value.trim().toUpperCase();
  if (!trimmed) return { valid: false, message: "Identification number is required" };
  if (!IDENTIFICATION_NUMBER_PATTERN.test(trimmed)) {
    return {
      valid: false,
      message:
        "Identification number must be 1–30 characters (A–Z, 0–9, -, /)"
    };
  }
  return { valid: true };
}

export function validateDateOfBirth(dob: string): ValidationResult {
  if (!dob) return { valid: false, message: "Date of birth is required" };
  const d = new Date(dob + "T00:00:00");
  if (Number.isNaN(d.getTime())) return { valid: false, message: "Invalid date" };

  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  if (d > today) return { valid: false, message: "Date of birth cannot be in the future" };

  let age = today.getFullYear() - d.getFullYear();
  const m = today.getMonth() - d.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < d.getDate())) age--;
  if (age < 18) {
    return { valid: false, message: "Applicant must be at least 18 years old" };
  }
  if (age > 130) return { valid: false, message: "Date of birth is implausible" };
  return { valid: true };
}

export function validateGender(gender: string): ValidationResult {
  if (gender !== "male" && gender !== "female") {
    return { valid: false, message: "Select gender" };
  }
  return { valid: true };
}

export function validateNationality(nationality: string): ValidationResult {
  const trimmed = nationality.trim();
  if (!trimmed) return { valid: true }; // defaults to Tanzanian upstream
  if (trimmed.length > 60) return { valid: false, message: "Nationality too long" };
  if (!/^[\p{L}\s-]+$/u.test(trimmed)) {
    return { valid: false, message: "Nationality may only contain letters" };
  }
  return { valid: true };
}

export function validateAddress(address: string): ValidationResult {
  const trimmed = address.trim();
  if (!trimmed) return { valid: false, message: "Address is required" };
  if (trimmed.length < 5) return { valid: false, message: "Address is too short" };
  if (trimmed.length > 300) return { valid: false, message: "Address must not exceed 300 characters" };
  return { valid: true };
}

export function validatePhone(phone: string): ValidationResult {
  const trimmed = phone.trim();
  if (!trimmed) return { valid: true }; // optional
  if (!TANZANIA_PHONE_PATTERN.test(trimmed)) {
    return {
      valid: false,
      message: "Phone must be a Tanzanian number e.g. 0712345678 or +255712345678"
    };
  }
  return { valid: true };
}
