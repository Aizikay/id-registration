import { app, dialog, shell } from "electron";
import { createLogger } from "./logger";
import { spawn } from "node:child_process";
import { mkdirSync, existsSync, readdirSync, statSync, createReadStream, createWriteStream, unlinkSync, rmdirSync } from "node:fs";
import { join, dirname } from "node:path";

const log = createLogger("local-store");

/**
 * Local storage layout (per Windows user):
 *
 *   %APPDATA%/Meru DC ID Registry/
 *     logs/main.log           — main process log
 *     backups/                — (reserved)
 *     Partitions/...          — Chromium profile: IndexedDB (Dexie), localStorage
 *
 * Everything the app persists offline (people, print history, outbox, prefs)
 * lives inside this folder, so snapshotting it is a complete portable backup.
 *
 * Backup format (.mbackup): MERUBK01 | headerLen(4 LE) | header JSON
 *   header JSON: [{p: "relative/path", s: size}, ...] followed by the raw
 *   concatenated file bytes in header order. Restored via a detached
 *   PowerShell helper that swaps the folder after the app exits.
 */

const BACKUP_MAGIC = "MERUBK01";
const SKIP_DIRS = new Set(["logs", "Cache", "Code Cache", "GPUCache", "Crashpad", "Temp", "backups"]);

export function userDataDir(): string {
  return app.getPath("userData");
}

export async function openDataFolder(): Promise<void> {
  const dir = userDataDir();
  log.info(`Opening data folder: ${dir}`);
  await shell.openPath(dir);
}

export async function getDataFolderPath(): Promise<string> {
  return userDataDir();
}

export async function getAppPaths(): Promise<{ userData: string; temp: string; exe: string }> {
  return {
    userData: app.getPath("userData"),
    temp: app.getPath("temp"),
    exe: app.getPath("exe"),
  };
}

function copyTree(src: string, dest: string): void {
  if (!existsSync(src)) return;
  mkdirSync(dest, { recursive: true });
  for (const entry of readdirSync(src, { withFileTypes: true })) {
    const s = join(src, entry.name);
    const d = join(dest, entry.name);
    if (entry.isDirectory()) copyTree(s, d);
    else if (entry.isFile()) {
      try {
        statSync(s);
        const { copyFileSync } = require("node:fs") as typeof import("node:fs");
        copyFileSync(s, d);
      } catch {
        // skip locked files — backup is best-effort
      }
    }
  }
}

function rmDirRecursive(dir: string): void {
  try {
    for (const e of readdirSync(dir, { withFileTypes: true })) {
      const full = join(dir, e.name);
      if (e.isDirectory()) rmDirRecursive(full);
      else {
        try {
          unlinkSync(full);
        } catch {
          // ignore locked
        }
      }
    }
    rmdirSync(dir);
  } catch {
    // ignore
  }
}

interface BackupEntry {
  p: string;
  s: number;
}

export async function backupNow(): Promise<{ ok: boolean; path?: string; error?: string }> {
  let tmpRoot: string | null = null;
  try {
    const dir = userDataDir();
    const stamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
    const defaultPath = join(app.getPath("documents"), `MeruDC-IDRegistry-backup-${stamp}.mbackup`);
    const { canceled, filePath } = await dialog.showSaveDialog({
      title: "Save Backup",
      defaultPath,
      filters: [{ name: "Meru DC Backup", extensions: ["mbackup"] }],
    });
    if (canceled || !filePath) return { ok: false, error: "cancelled" };
    mkdirSync(dirname(filePath), { recursive: true });

    // 1. Stage a clean copy (skip caches/logs).
    tmpRoot = join(app.getPath("temp"), `meru-backup-${stamp}`);
    rmDirRecursive(tmpRoot);
    const tmpData = join(tmpRoot, "data");
    mkdirSync(tmpData, { recursive: true });
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      if (SKIP_DIRS.has(entry.name)) continue;
      const s = join(dir, entry.name);
      const d = join(tmpData, entry.name);
      if (entry.isDirectory()) copyTree(s, d);
      else {
        try {
          const { copyFileSync } = require("node:fs") as typeof import("node:fs");
          copyFileSync(s, d);
        } catch {
          // skip locked
        }
      }
    }

    // 2. Collect files and write the container.
    const files: BackupEntry[] = [];
    const abs: string[] = [];
    const walk = (d: string): void => {
      for (const e of readdirSync(d, { withFileTypes: true })) {
        const full = join(d, e.name);
        if (e.isDirectory()) walk(full);
        else if (e.isFile()) {
          try {
            const size = statSync(full).size;
            files.push({ p: full.slice(tmpData.length).split("\\").join("/"), s: size });
            abs.push(full);
          } catch {
            // skip
          }
        }
      }
    };
    walk(tmpData);

    const headerBuf = Buffer.from(JSON.stringify(files), "utf8");
    const out = createWriteStream(filePath);
    await new Promise<void>((resolve, reject) => {
      out.on("error", reject);
      out.write(Buffer.from(BACKUP_MAGIC, "ascii"));
      const hl = Buffer.alloc(4);
      hl.writeUInt32LE(headerBuf.length);
      out.write(hl);
      out.write(headerBuf, () => {
        (async () => {
          for (const f of abs) {
            await new Promise<void>((res, rej) => {
              const rs = createReadStream(f);
              rs.on("error", rej);
              rs.on("end", () => res());
              rs.pipe(out, { end: false });
            });
          }
          out.end(() => resolve());
        })().catch(reject);
      });
    });

    log.info(`Backup written: ${filePath} (${files.length} files)`);
    return { ok: true, path: filePath };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    log.error(`Backup failed: ${msg}`);
    return { ok: false, error: msg };
  } finally {
    if (tmpRoot) rmDirRecursive(tmpRoot);
  }
}

export async function restoreBackup(): Promise<{ ok: boolean; path?: string; error?: string }> {
  try {
    const { canceled, filePaths } = await dialog.showOpenDialog({
      title: "Restore Backup",
      properties: ["openFile"],
      filters: [{ name: "Meru DC Backup", extensions: ["mbackup"] }],
    });
    if (canceled || filePaths.length === 0) return { ok: false, error: "cancelled" };
    const filePath = filePaths[0]!;

    const confirm = await dialog.showMessageBox({
      type: "warning",
      buttons: ["Restore && Restart", "Cancel"],
      defaultId: 0,
      cancelId: 1,
      message: "Restore backup?",
      detail:
        "This replaces all local data (records, history, preferences) with the backup contents and restarts the app.",
    });
    if (confirm.response !== 0) return { ok: false, error: "cancelled" };

    await writeRestoreHelperAndRelaunch(filePath);
    return { ok: true, path: filePath };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    log.error(`Restore failed: ${msg}`);
    return { ok: false, error: msg };
  }
}

/** Write a PowerShell helper that swaps the userData dir after exit, then relaunch. */
async function writeRestoreHelperAndRelaunch(backupPath: string): Promise<void> {
  const helperPath = join(app.getPath("temp"), "meru-restore.ps1");
  const dataDir = userDataDir();
  const exePath = app.getPath("exe");
  const ps = `
$ErrorActionPreference = 'Stop'
$backup = '${backupPath.replace(/'/g, "''")}'
$data   = '${dataDir.replace(/'/g, "''")}'
$exe    = '${exePath.replace(/'/g, "''")}'
Start-Sleep -Seconds 2
for ($i = 0; $i -lt 30; $i++) {
  $proc = Get-Process | Where-Object { $_.Path -eq $exe } | Select-Object -First 1
  if (-not $proc) { break }
  Start-Sleep -Seconds 1
}
$fs = [System.IO.File]::OpenRead($backup)
$br = New-Object System.IO.BinaryReader($fs)
$null = $br.ReadBytes(8)
$hlen = $br.ReadInt32()
$headerJson = [System.Text.Encoding]::UTF8.GetString($br.ReadBytes($hlen))
$header = $headerJson | ConvertFrom-Json
$tmp = Join-Path $env:TEMP ('meru-restore-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $tmp | Out-Null
foreach ($item in $header) {
  $target = Join-Path $tmp ($item.p -replace '/', '\\')
  $dir = Split-Path $target -Parent
  if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
  $fs2 = [System.IO.File]::Create($target)
  $remaining = [int64]$item.s
  $buf = New-Object byte[] (1048576)
  while ($remaining -gt 0) {
    $chunk = $br.Read([int][Math]::Min($remaining, $buf.Length))
    if ($chunk -le 0) { break }
    $fs2.Write($buf, 0, $chunk)
    $remaining -= $chunk
  }
  $fs2.Close()
}
$br.Close(); $fs.Close()
$old = $data + '.old-' + [guid]::NewGuid().ToString('N').Substring(0, 8)
Rename-Item -Path $data -NewName (Split-Path $old -Leaf)
Move-Item -Path (Join-Path $tmp 'data') -Destination $data
Remove-Item -Path $tmp -Recurse -Force -ErrorAction SilentlyContinue
Start-Process -FilePath $exe
`;
  const { writeFile } = await import("node:fs/promises");
  await writeFile(helperPath, ps, "utf8");
  const child = spawn(
    "powershell.exe",
    ["-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden", helperPath],
    { detached: true, stdio: "ignore", windowsHide: true }
  );
  child.unref();
  app.quit();
}
