/**
 * Printers Page — Auto-detected printers, real print workflow, print history.
 *
 * Architecture:
 *   Web App → Print Agent (localhost:8377) → OS Print Spooler → USB/Wi-Fi Printer
 *
 * Printers are detected automatically via the Print Agent which uses
 * PowerShell Get-Printer / WMIC to enumerate system printers.
 * No manual registration — all printers come from the actual OS.
 */

import { useCallback, useEffect, useRef, useState } from "react";
import { Card, PageHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  EmptyState,
  ErrorState,
  TBody,
  TD,
  TH,
  THead,
  TR,
  Table,
} from "@/components/ui/data-table";
import { Modal } from "@/components/ui/modal";
import { Icon } from "@/components/icons/icon";
import { useToast } from "@/components/ui/toast";
import { mapSupabaseError } from "@/services/errors";
import { printAgentClient, type AgentPrinterInfo } from "@/printing/agent-client";
import { desktop } from "@/lib/desktop";
import {
  createPrintHistory,
  listPrintHistory,
  getPrintHistoryStatsSafe,
  type CreatePrintHistoryInput,
} from "@/services/print-history-service";
import { authProfileCache } from "@/services/audit-service";
import { formatRelative } from "@/lib/format";
import type { PrintHistoryRecord } from "@/types";
import Loader from "@/components/Loader";

/* ── Connection type helpers ──────────────────────────────────────────────── */

interface DetectedPrinter extends AgentPrinterInfo {
  connection_type: "usb" | "network" | "wireless" | "unknown";
}

const CONNECTION_META: Record<
  DetectedPrinter["connection_type"],
  { label: string; icon: string; color: string; bgColor: string }
> = {
  usb: {
    label: "USB",
    icon: "🔌",
    color: "text-blue-600 dark:text-blue-400",
    bgColor: "bg-blue-50 dark:bg-blue-950/50",
  },
  network: {
    label: "Network",
    icon: "🌐",
    color: "text-purple-600 dark:text-purple-400",
    bgColor: "bg-purple-50 dark:bg-purple-950/50",
  },
  wireless: {
    label: "Wireless",
    icon: "📡",
    color: "text-emerald-600 dark:text-emerald-400",
    bgColor: "bg-emerald-50 dark:bg-emerald-950/50",
  },
  unknown: {
    label: "Connected",
    icon: "🖨️",
    color: "text-slate-500 dark:text-slate-400",
    bgColor: "bg-slate-50 dark:bg-slate-800",
  },
};

const STATUS_CONFIG: Record<
  string,
  { dot: string; label: string; textColor: string }
> = {
  online: {
    dot: "bg-emerald-500",
    label: "Online",
    textColor: "text-emerald-700 dark:text-emerald-400",
  },
  offline: {
    dot: "bg-slate-400",
    label: "Offline",
    textColor: "text-slate-500 dark:text-slate-400",
  },
  error: {
    dot: "bg-red-500",
    label: "Error",
    textColor: "text-red-600 dark:text-red-400",
  },
  unknown: {
    dot: "bg-amber-400",
    label: "Unknown",
    textColor: "text-amber-600 dark:text-amber-400",
  },
};

function classifyConnection(p: AgentPrinterInfo): DetectedPrinter["connection_type"] {
  const name = p.name.toLowerCase();
  if (name.includes("usb")) return "usb";
  if (name.includes("network") || /\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/.test(name)) return "network";
  if (name.includes("wireless") || name.includes("wifi") || name.includes("airprint")) return "wireless";
  if (name.includes("shared") || name.includes("\\\\")) return "network";
  return "unknown";
}

/* ── Main Page ────────────────────────────────────────────────────────────── */

export function PrintersPage() {
  const toast = useToast();

  /* ── Agent / printer state ── */
  const [agentOnline, setAgentOnline] = useState(false);
  const [discovered, setDiscovered] = useState<DetectedPrinter[]>([]);
  const [discoveryLoading, setDiscoveryLoading] = useState(true);
  const [discoveryError, setDiscoveryError] = useState<string | null>(null);
  const [testing, setTesting] = useState<string | null>(null);
  const mountedRef = useRef(true);

  /* ── Print workflow state ── */
  const [selectedPrinter, setSelectedPrinter] = useState<DetectedPrinter | null>(null);
  const [printModalOpen, setPrintModalOpen] = useState(false);
  const [documentName, setDocumentName] = useState("ID Card");
  const [copies, setCopies] = useState(1);
  const [paperSize, setPaperSize] = useState("86x54");
  const [printing, setPrinting] = useState(false);

  /* ── Print history state ── */
  const [history, setHistory] = useState<PrintHistoryRecord[]>([]);
  const [historyLoading, setHistoryLoading] = useState(true);
  const [historyError, setHistoryError] = useState<string | null>(null);
  const [historyPage, setHistoryPage] = useState(0);
  const [historyTotal, setHistoryTotal] = useState(0);
  const [historyFilter, setHistoryFilter] = useState<"all" | "completed" | "failed">("all");
  const [stats, setStats] = useState({ total: 0, completed: 0, failed: 0, today: 0 });

  /* ── Polling ── */
  const fetchPrinters = useCallback(async () => {
    try {
      setDiscoveryError(null);

      // Desktop app: enumerate printers natively via the main process.
      const native = desktop();
      if (native) {
        const printers = await native.listPrinters();
        if (!mountedRef.current) return;
        setAgentOnline(true);
        setDiscovered(
          printers.map((p) => ({
            id: p.id,
            name: p.name,
            is_default: p.is_default,
            status: p.status,
            location: p.location ?? undefined,
            connection_type: p.connection_type,
          }))
        );
        setDiscoveryLoading(false);
        return;
      }

      const status = await printAgentClient.status();
      if (!mountedRef.current) return;
      setAgentOnline(true);
      const printers: DetectedPrinter[] = status.printers.map((p) => ({
        ...p,
        connection_type: classifyConnection(p),
      }));
      setDiscovered(printers);
    } catch (err) {
      if (!mountedRef.current) return;
      const msg = err instanceof Error ? err.message : String(err);
      setAgentOnline(false);
      if (msg.includes("fetch") || msg.includes("agent_unreachable") || msg.includes("not reachable") || msg.includes("network")) {
        setDiscoveryError("Print Agent not reachable — start the agent on this workstation to detect printers.");
      } else {
        setDiscoveryError("Printer detection error — please try refreshing.");
      }
    } finally {
      if (mountedRef.current) setDiscoveryLoading(false);
    }
  }, []);

  const fetchHistory = useCallback(async () => {
    try {
      setHistoryError(null);
      const [result, statsResult] = await Promise.all([
        listPrintHistory({ pageSize: 20, page: historyPage, status: historyFilter }),
        getPrintHistoryStatsSafe(),
      ]);
      if (!mountedRef.current) return;
      setHistory(result.rows);
      setHistoryTotal(result.total);
      setStats(statsResult);
    } catch (err) {
      if (!mountedRef.current) return;
      const mapped = mapSupabaseError(err);
      // If the print_history table doesn't exist yet, show a helpful message
      const msg = String(err instanceof Error ? err.message : err ?? "").toLowerCase();
      if (msg.includes("relation \"public.print_history\"") || msg.includes("does not exist") || mapped.code === "not_found") {
        setHistoryError("Print history table not found. Run the SQL migration in Supabase to enable print history.");
      } else {
        setHistoryError(mapped.userMessage);
      }
    } finally {
      if (mountedRef.current) setHistoryLoading(false);
    }
  }, [historyPage, historyFilter]);

  useEffect(() => {
    mountedRef.current = true;
    void fetchPrinters();
    void fetchHistory();

    const interval = setInterval(() => void fetchPrinters(), 20_000);
    return () => {
      mountedRef.current = false;
      clearInterval(interval);
    };
  }, [fetchPrinters, fetchHistory]);

  /* ── Handlers ── */

  const handleTest = async (printer: DetectedPrinter) => {
    setTesting(printer.id);
    try {
      const result = await printAgentClient.testPrinter(printer.id);
      if (result.ok) toast.success("Test page sent", `Sent to ${printer.name}`);
      else toast.error("Test failed", result.message);
    } catch {
      toast.error("Test failed", "Could not reach Print Agent");
    } finally {
      setTesting(null);
    }
  };

  const handleSelectPrinter = (printer: DetectedPrinter) => {
    setSelectedPrinter(printer);
    setPrintModalOpen(true);
  };

  const handlePrint = async () => {
    if (!selectedPrinter) return;
    setPrinting(true);
    try {
      // Create a pending print history record
      const historyRecord = await createPrintHistory({
        document_name: documentName,
        printer_name: selectedPrinter.name,
        printer_connection_type: selectedPrinter.connection_type,
        copies,
        paper_size: paperSize,
        status: "printing",
      });

      // Desktop app → native printing via the main process.
      const native = desktop();
      if (native) {
        const result = await native.print({
          job_ref: historyRecord.id,
          printer_name: selectedPrinter.name,
          front_image_src: "/branding/frontpageeditable.jpeg",
          back_image_src: "/branding/backpageid.jpeg",
          copies,
          duplex: true,
          orientation: "landscape",
        });
        if (result.ok) {
          await createPrintHistory({
            document_name: documentName,
            printer_name: selectedPrinter.name,
            printer_connection_type: selectedPrinter.connection_type,
            copies,
            paper_size: paperSize,
            status: "completed",
            agent_job_id: result.job_id,
          } as CreatePrintHistoryInput);
          toast.success("Print sent", `${documentName} sent to ${selectedPrinter.name}`);
          setPrintModalOpen(false);
          setSelectedPrinter(null);
        } else {
          const { updatePrintHistoryStatus } = await import("@/services/print-history-service");
          await updatePrintHistoryStatus(historyRecord.id, "failed", result.error_message);
          toast.error("Print failed", result.error_message ?? "The printer returned an error");
        }
        void fetchHistory();
        return;
      }

      // Generate front and back page images for dual-page printing
      const frontImageSrc = "/branding/frontpageeditable.jpeg";
      const backImageSrc = "/branding/backpageid.jpeg";

      // Send to Print Agent with dual-page support
      const idempotencyKey = `PRINT-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 8)}`;
      const result = await printAgentClient.submitPrintJob({
        document_reference: historyRecord.id,
        issuance_reference: `PH-${historyRecord.id.slice(0, 8)}`,
        idempotency_key: idempotencyKey,
        printer_id: selectedPrinter.id,
        person_name: documentName,
        identification_number: "DIRECT-PRINT",
        issued_by_staff_number: authProfileCache.staffNumber ?? null,
        issued_at_iso: new Date().toISOString(),
        council_name_sw: "HALMASHAURI YA WILAYA YA MERU",
        council_name_en: "MERU DISTRICT COUNCIL",
        front_image_src: frontImageSrc,
        back_image_src: backImageSrc,
      });

      if (result.ok) {
        await createPrintHistory({
          ...({
            document_name: documentName,
            printer_name: selectedPrinter.name,
            printer_connection_type: selectedPrinter.connection_type,
            copies,
            paper_size: paperSize,
            status: "completed",
            agent_job_id: result.job_id,
          } as CreatePrintHistoryInput),
        });
        toast.success("Print sent", `${documentName} sent to ${selectedPrinter.name}`);
        setPrintModalOpen(false);
        setSelectedPrinter(null);
      } else {
        // Update the history record to failed
        const { updatePrintHistoryStatus } = await import("@/services/print-history-service");
        await updatePrintHistoryStatus(historyRecord.id, "failed", result.error_message);
        toast.error("Print failed", result.error_message ?? "The printer returned an error");
      }

      void fetchHistory();
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      toast.error("Print failed", msg.slice(0, 200));
    } finally {
      setPrinting(false);
    }
  };

  const handleRefresh = () => {
    setDiscoveryLoading(true);
    void fetchPrinters();
    void fetchHistory();
  };

  const onlineCount = discovered.filter((p) => p.status === "online").length;
  const defaultPrinter = discovered.find((p) => p.is_default);

  return (
    <div className="animate-fade-in space-y-6">
      <PageHeader
        title="Printers"
        subtitle="Auto-detected printers connected to this workstation"
        actions={
          <Button
            variant="outline"
            size="sm"
            icon={<Icon name="refresh" className={`h-4 w-4 ${discoveryLoading ? "animate-spin" : ""}`} />}
            onClick={handleRefresh}
          >
            Refresh printers
          </Button>
        }
      />

      {/* ─── Agent Status Banner ─── */}
      <div
        className={`flex items-center gap-3 rounded-xl border px-4 py-3 text-sm transition-all ${
          agentOnline
            ? "border-emerald-200 bg-emerald-50 text-emerald-800 dark:border-emerald-800 dark:bg-emerald-950 dark:text-emerald-300"
            : "border-amber-200 bg-amber-50 text-amber-800 dark:border-amber-800 dark:bg-amber-950 dark:text-amber-300"
        }`}
      >
        <span className="relative flex h-2.5 w-2.5 flex-shrink-0">
          {agentOnline && (
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
          )}
          <span
            className={`relative inline-flex h-2.5 w-2.5 rounded-full ${
              agentOnline ? "bg-emerald-500" : "bg-amber-500"
            }`}
          />
        </span>
        <span className="font-medium">
          {agentOnline
            ? `Print Agent connected — ${discovered.length} printer${discovered.length !== 1 ? "s" : ""} detected (${onlineCount} online)`
            : discoveryError || "Print Agent offline — start the agent to detect printers"}
        </span>
      </div>

      {/* ─── Stats Row ─── */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        {[
          { label: "Detected", value: discovered.length, color: "text-slate-900 dark:text-white" },
          { label: "Online", value: onlineCount, color: "text-emerald-600 dark:text-emerald-400" },
          { label: "Print Jobs", value: stats.total, color: "text-blue-600 dark:text-blue-400" },
          { label: "Today", value: stats.today, color: "text-purple-600 dark:text-purple-400" },
        ].map((s) => (
          <div
            key={s.label}
            className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-700 dark:bg-slate-900"
          >
            <p className="text-xs font-medium uppercase tracking-wide text-slate-500 dark:text-slate-400">
              {s.label}
            </p>
            <p className={`mt-1 text-2xl font-bold tabular-nums ${s.color}`}>{s.value}</p>
          </div>
        ))}
      </div>

      {/* ─── Detected Printers ─── */}
      <Card className="overflow-hidden">
        <div className="flex items-center justify-between border-b border-slate-200 px-5 py-3 dark:border-slate-700">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-100 dark:bg-emerald-900/50">
              <Icon name="printer" className="h-4 w-4 text-emerald-600" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                Detected Printers
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Auto-discovered from the operating system via Print Agent
              </p>
            </div>
          </div>
          {defaultPrinter && (
            <span className="rounded-full bg-emerald-100 px-2.5 py-1 text-xs font-medium text-emerald-700 dark:bg-emerald-900/50 dark:text-emerald-400">
              Default: {defaultPrinter.name}
            </span>
          )}
        </div>

        {discoveryLoading && discovered.length === 0 ? (
          <div className="flex items-center justify-center py-12">
            <Loader />
          </div>
        ) : !agentOnline ? (
          <div className="px-5 py-10 text-center">
            <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-amber-100 dark:bg-amber-900/50">
              <span className="text-xl">⚠️</span>
            </div>
            <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
              Print Agent is not running
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Start the Print Agent on this workstation to detect connected printers.
            </p>
            <Button
              size="sm"
              variant="outline"
              className="mt-3"
              onClick={handleRefresh}
              icon={<Icon name="refresh" className="h-3.5 w-3.5" />}
            >
              Retry
            </Button>
          </div>
        ) : discovered.length === 0 ? (
          <EmptyState
            icon="printer"
            title="No printers detected"
            message="No printers were found on this workstation. Connect a printer via USB or ensure network printers are on the same network."
            action={
              <Button size="sm" variant="outline" onClick={handleRefresh} icon={<Icon name="refresh" className="h-3.5 w-3.5" />}>
                Scan again
              </Button>
            }
          />
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {discovered.map((printer) => {
              const connMeta = CONNECTION_META[printer.connection_type];
              const statusCfg = (STATUS_CONFIG[printer.status] ?? STATUS_CONFIG.unknown) as { dot: string; label: string; textColor: string };

              return (
                <div
                  key={printer.id}
                  className="flex items-center gap-4 px-5 py-4 transition-colors hover:bg-slate-50 dark:hover:bg-slate-800/50"
                >
                  {/* Status dot */}
                  <div className="relative">
                    <span className={`block h-3 w-3 rounded-full ${statusCfg.dot}`} />
                    {printer.status === "online" && (
                      <span className="absolute inset-0 h-3 w-3 animate-ping rounded-full bg-emerald-400 opacity-50" />
                    )}
                  </div>

                  {/* Printer info */}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-lg">{connMeta.icon}</span>
                      <p className="truncate text-sm font-semibold text-slate-900 dark:text-slate-100">
                        {printer.name}
                      </p>
                      {printer.is_default && (
                        <span className="rounded bg-emerald-100 px-1.5 py-0.5 text-[10px] font-bold uppercase text-emerald-700 dark:bg-emerald-900/50 dark:text-emerald-400">
                          Default
                        </span>
                      )}
                    </div>
                    <div className="mt-1 flex flex-wrap items-center gap-3 text-xs text-slate-500 dark:text-slate-400">
                      <span className={`inline-flex items-center gap-1 font-medium ${connMeta.color}`}>
                        <span className={`inline-block h-1.5 w-1.5 rounded-full ${connMeta.bgColor.replace("bg-", "bg-")}`} />
                        {connMeta.label}
                      </span>
                      <span className={`font-medium ${statusCfg.textColor}`}>
                        {statusCfg.label}
                      </span>
                      <span className="font-mono text-[10px] text-slate-400">{printer.id}</span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      loading={testing === printer.id}
                      onClick={() => void handleTest(printer)}
                      disabled={printer.status !== "online"}
                    >
                      Test
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => handleSelectPrinter(printer)}
                      disabled={printer.status !== "online"}
                      icon={<Icon name="printer" className="h-3.5 w-3.5" />}
                    >
                      Print
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Card>

      {/* ─── Print History ─── */}
      <Card className="overflow-hidden">
        <div className="flex items-center justify-between border-b border-slate-200 px-5 py-3 dark:border-slate-700">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-100 dark:bg-blue-900/50">
              <Icon name="clock" className="h-4 w-4 text-blue-600" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                Print History
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {historyTotal} record{historyTotal !== 1 ? "s" : ""}
              </p>
            </div>
          </div>
          <div className="flex gap-1">
            {(["all", "completed", "failed"] as const).map((f) => (
              <button
                key={f}
                onClick={() => { setHistoryFilter(f); setHistoryPage(0); }}
                className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-colors ${
                  historyFilter === f
                    ? "bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900"
                    : "text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
                }`}
              >
                {f === "all" ? "All" : f === "completed" ? "Completed" : "Failed"}
              </button>
            ))}
          </div>
        </div>

        {historyError ? (
          <ErrorState message={historyError} onRetry={() => void fetchHistory()} />
        ) : historyLoading && history.length === 0 ? (
          <div className="flex items-center justify-center py-8">
            <Loader />
          </div>
        ) : history.length === 0 ? (
          <EmptyState
            icon="clock"
            title="No print history"
            message="Print jobs will appear here once you print an ID card."
          />
        ) : (
          <>
            <Table>
              <THead>
                <TR>
                  <TH>Document</TH>
                  <TH>Printer</TH>
                  <TH>Copies</TH>
                  <TH>Status</TH>
                  <TH>Date</TH>
                </TR>
              </THead>
              <TBody>
                {history.map((h) => (
                  <TR key={h.id}>
                    <TD>
                      <div>
                        <p className="text-sm font-medium text-slate-800 dark:text-slate-200">
                          {h.document_name}
                        </p>
                        {h.person_name && (
                          <p className="text-xs text-slate-500 dark:text-slate-400">
                            {h.person_name}
                          </p>
                        )}
                      </div>
                    </TD>
                    <TD>
                      <div className="flex items-center gap-1.5">
                        <span className="text-sm text-slate-700 dark:text-slate-300">
                          {h.printer_name}
                        </span>
                        {h.printer_connection_type && (
                          <span className="rounded bg-slate-100 px-1.5 py-0.5 text-[10px] font-medium text-slate-600 dark:bg-slate-800 dark:text-slate-400">
                            {h.printer_connection_type.toUpperCase()}
                          </span>
                        )}
                      </div>
                    </TD>
                    <TD className="text-sm tabular-nums text-slate-600 dark:text-slate-400">
                      {h.copies}
                    </TD>
                    <TD>
                      <PrintStatusBadge status={h.status} errorMessage={h.error_message} />
                    </TD>
                    <TD className="text-xs text-slate-500 dark:text-slate-400">
                      {formatRelative(h.created_at)}
                    </TD>
                  </TR>
                ))}
              </TBody>
            </Table>

            {/* Pagination */}
            {historyTotal > 20 && (
              <div className="flex items-center justify-between border-t border-slate-200 px-5 py-3 dark:border-slate-700">
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Showing {historyPage * 20 + 1}–{Math.min((historyPage + 1) * 20, historyTotal)} of{" "}
                  {historyTotal}
                </p>
                <div className="flex gap-1">
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={historyPage === 0}
                    onClick={() => setHistoryPage((p) => p - 1)}
                  >
                    Previous
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={(historyPage + 1) * 20 >= historyTotal}
                    onClick={() => setHistoryPage((p) => p + 1)}
                  >
                    Next
                  </Button>
                </div>
              </div>
            )}
          </>
        )}
      </Card>

      {/* ─── How It Works ─── */}
      <Card>
        <div className="px-5 py-4">
          <h3 className="mb-2 text-sm font-semibold text-slate-900 dark:text-slate-100">
            How Printer Detection Works
          </h3>
          <div className="grid gap-3 text-xs text-slate-600 dark:text-slate-400 sm:grid-cols-3">
            <div className="rounded-lg bg-slate-50 p-3 dark:bg-slate-800">
              <p className="mb-1 font-medium text-slate-700 dark:text-slate-300">🔌 USB Printers</p>
              <p>Detected automatically when plugged in via USB cable. The Print Agent uses Windows PowerShell to scan connected devices.</p>
            </div>
            <div className="rounded-lg bg-slate-50 p-3 dark:bg-slate-800">
              <p className="mb-1 font-medium text-slate-700 dark:text-slate-300">📡 Wireless Printers</p>
              <p>Wi-Fi and network printers are detected when they are on the same network as the workstation.</p>
            </div>
            <div className="rounded-lg bg-slate-50 p-3 dark:bg-slate-800">
              <p className="mb-1 font-medium text-slate-700 dark:text-slate-300">🌐 Network Printers</p>
              <p>Shared printers and IP-based printers are discovered through the Windows print spooler.</p>
            </div>
          </div>
        </div>
      </Card>

      {/* ─── Print Modal ─── */}
      {printModalOpen && selectedPrinter && (
        <PrintModal
          printer={selectedPrinter}
          defaultDocumentName={documentName}
          onClose={() => { setPrintModalOpen(false); setSelectedPrinter(null); }}
          onPrint={async (docName, numCopies, paper, _orient) => {
            setDocumentName(docName);
            setCopies(numCopies);
            setPaperSize(paper);
            // Small delay to let state update, then print
            await new Promise((r) => setTimeout(r, 50));
            await handlePrint();
          }}
          printing={printing}
        />
      )}
    </div>
  );
}

/* ── Print Modal ──────────────────────────────────────────────────────────── */

function PrintModal({
  printer,
  defaultDocumentName,
  onClose,
  onPrint,
  printing,
}: {
  printer: DetectedPrinter;
  defaultDocumentName: string;
  onClose: () => void;
  onPrint: (docName: string, copies: number, paperSize: string, orientation: string) => Promise<void>;
  printing: boolean;
}) {
  const [docName, setDocName] = useState(defaultDocumentName);
  const [copies, setCopies] = useState(1);
  const [paperSize, setPaperSize] = useState("86x54");
  const [orientation, setOrientation] = useState("landscape");

  const connMeta = CONNECTION_META[printer.connection_type];

  return (
    <Modal open onClose={onClose} title="Print Document" size="md">
      <div className="space-y-5">
        {/* Printer info */}
        <div className="flex items-center gap-3 rounded-xl bg-slate-50 p-4 dark:bg-slate-800">
          <span className="text-2xl">{connMeta.icon}</span>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold text-slate-900 dark:text-slate-100">
              {printer.name}
            </p>
            <p className={`text-xs font-medium ${connMeta.color}`}>
              {connMeta.label} • {printer.status === "online" ? "Ready" : "Offline"}
            </p>
          </div>
          {printer.is_default && (
            <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-700 dark:bg-emerald-900/50 dark:text-emerald-400">
              DEFAULT
            </span>
          )}
        </div>

        {/* Document name */}
        <div>
          <label className="mb-1.5 block text-xs font-medium uppercase tracking-wide text-slate-500 dark:text-slate-400">
            Document Name
          </label>
          <input
            type="text"
            value={docName}
            onChange={(e) => setDocName(e.target.value)}
            className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-900 focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
            placeholder="e.g. ID Card, Test Page"
          />
        </div>

        {/* Options grid */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="mb-1.5 block text-xs font-medium uppercase tracking-wide text-slate-500 dark:text-slate-400">
              Copies
            </label>
            <input
              type="number"
              min={1}
              max={10}
              value={copies}
              onChange={(e) => setCopies(Math.max(1, Math.min(10, Number(e.target.value))))}
              className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-900 focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
            />
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-medium uppercase tracking-wide text-slate-500 dark:text-slate-400">
              Paper Size
            </label>
            <select
              value={paperSize}
              onChange={(e) => setPaperSize(e.target.value)}
              className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-900 focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
            >
              <option value="86x54">86 × 54 mm (Standard ID)</option>
              <option value="iso">85.6 × 53.98 mm (ISO/IEC 7810)</option>
              <option value="a4">A4 (210 × 297 mm)</option>
              <option value="letter">Letter (8.5 × 11 in)</option>
            </select>
          </div>
        </div>

        <div>
          <label className="mb-1.5 block text-xs font-medium uppercase tracking-wide text-slate-500 dark:text-slate-400">
            Orientation
          </label>
          <div className="flex gap-2">
            {[
              { value: "landscape", label: "Landscape", icon: "⬜" },
              { value: "portrait", label: "Portrait", icon: "📋" },
            ].map((o) => (
              <button
                key={o.value}
                onClick={() => setOrientation(o.value)}
                className={`flex flex-1 items-center justify-center gap-2 rounded-lg border-2 px-4 py-3 text-sm font-medium transition-all ${
                  orientation === o.value
                    ? "border-emerald-500 bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-400"
                    : "border-slate-200 bg-white text-slate-600 hover:border-slate-300 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-400"
                }`}
              >
                <span>{o.icon}</span>
                {o.label}
              </button>
            ))}
          </div>
        </div>

        {/* Dual-page preview */}
        <div>
          <label className="mb-1.5 block text-xs font-medium uppercase tracking-wide text-slate-500 dark:text-slate-400">
            Card Preview (Front + Back)
          </label>
          <div className="flex gap-3">
            <div className="flex-1 rounded-lg border border-slate-200 bg-slate-50 p-2 dark:border-slate-700 dark:bg-slate-800">
              <p className="mb-1 text-center text-[10px] font-medium text-slate-500 dark:text-slate-400">FRONT</p>
              <img
                src="/branding/frontpageeditable.jpeg"
                alt="ID Card Front"
                className="w-full rounded border border-slate-200 dark:border-slate-600"
                style={{ aspectRatio: "86/54" }}
              />
            </div>
            <div className="flex-1 rounded-lg border border-slate-200 bg-slate-50 p-2 dark:border-slate-700 dark:bg-slate-800">
              <p className="mb-1 text-center text-[10px] font-medium text-slate-500 dark:text-slate-400">BACK</p>
              <img
                src="/branding/backpageid.jpeg"
                alt="ID Card Back"
                className="w-full rounded border border-slate-200 dark:border-slate-600"
                style={{ aspectRatio: "86/54" }}
              />
            </div>
          </div>
          <p className="mt-1.5 text-center text-[10px] text-slate-400 dark:text-slate-500">
            Both pages printed on the same card (front + back)
          </p>
        </div>

        {/* Print button */}
        <Button
          className="w-full"
          size="lg"
          loading={printing}
          onClick={() => void onPrint(docName, copies, paperSize, orientation)}
          icon={<Icon name="printer" className="h-5 w-5" />}
        >
          {printing ? "Sending to printer..." : `Print ${copies > 1 ? `(${copies} copies)` : ""}`}
        </Button>

        <p className="text-center text-xs text-slate-500 dark:text-slate-400">
          The print job will be sent to the selected printer via the Print Agent.
        </p>
      </div>
    </Modal>
  );
}

/* ── Print Status Badge ───────────────────────────────────────────────────── */

function PrintStatusBadge({
  status,
  errorMessage,
}: {
  status: PrintHistoryRecord["status"];
  errorMessage?: string | null;
}) {
  const config: Record<string, { bg: string; text: string; dot: string }> = {
    completed: {
      bg: "bg-emerald-50 dark:bg-emerald-950/50",
      text: "text-emerald-700 dark:text-emerald-400",
      dot: "bg-emerald-500",
    },
    failed: {
      bg: "bg-red-50 dark:bg-red-950/50",
      text: "text-red-600 dark:text-red-400",
      dot: "bg-red-500",
    },
    printing: {
      bg: "bg-blue-50 dark:bg-blue-950/50",
      text: "text-blue-600 dark:text-blue-400",
      dot: "bg-blue-500",
    },
    queued: {
      bg: "bg-amber-50 dark:bg-amber-950/50",
      text: "text-amber-600 dark:text-amber-400",
      dot: "bg-amber-400",
    },
    cancelled: {
      bg: "bg-slate-100 dark:bg-slate-800",
      text: "text-slate-500 dark:text-slate-400",
      dot: "bg-slate-400",
    },
  };    const c = (config[status] ?? config.queued) as { bg: string; text: string; dot: string };
  const labels: Record<string, string> = {
    completed: "Completed",
    failed: "Failed",
    printing: "Printing",
    queued: "Queued",
    cancelled: "Cancelled",
  };

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ${c.bg} ${c.text}`}
      title={errorMessage ?? undefined}
    >
      <span className={`h-1.5 w-1.5 rounded-full ${c.dot} ${status === "printing" ? "animate-pulse" : ""}`} />
      {labels[status] ?? status}
    </span>
  );
}
