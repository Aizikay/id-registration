#!/usr/bin/env node
/**
 * Generates build/icon.ico from the council crest for the Windows builds.
 *
 * - If the source branding image is a JPEG (as here), it is first converted
 *   to a 256x256 PNG via PowerShell System.Drawing (built into Windows —
 *   no extra dependencies), resized on a white background.
 * - png-to-ico then packs the PNG into build/icon.ico.
 */
import pngToIco from "png-to-ico";
import { mkdirSync, writeFileSync, existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const root = dirname(fileURLToPath(import.meta.url)) + "/..";

const candidates = [
  "public/branding/app-icon-512.png",
  "public/branding/meru-logo.jpeg",
];
const src = candidates.map((p) => join(root, p)).find((p) => existsSync(p));
if (!src) {
  console.error("[icons] no source branding image found");
  process.exit(1);
}

mkdirSync(join(root, "build"), { recursive: true });

let pngSource = src;
if (!src.toLowerCase().endsWith(".png")) {
  const outPng = join(root, "build", "icon-256.png");
  const ps = `
Add-Type -AssemblyName System.Drawing
$src  = [System.Drawing.Image]::FromFile('${src.replace(/'/g, "''")}')
$size = 256
$bmp = New-Object System.Drawing.Bitmap($size, $size)
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.Clear([System.Drawing.Color]::White)
$g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
$side = [Math]::Min($src.Width, $src.Height)
$sx = [int](($src.Width - $side) / 2)
$sy = [int](($src.Height - $side) / 2)
$destRect = New-Object System.Drawing.Rectangle(0, 0, $size, $size)
$srcRect = New-Object System.Drawing.Rectangle($sx, $sy, $side, $side)
$g.DrawImage($src, $destRect, $srcRect, [System.Drawing.GraphicsUnit]::Pixel)
$bmp.Save('${outPng.replace(/'/g, "''")}', [System.Drawing.Imaging.ImageFormat]::Png)
$g.Dispose(); $bmp.Dispose(); $src.Dispose()
`;
  execFileSync("powershell.exe", [
    "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", ps,
  ], { stdio: "inherit" });
  pngSource = outPng;
  console.log("[icons] converted crest →", outPng);
}

const buf = await pngToIco([pngSource]);
writeFileSync(join(root, "build/icon.ico"), buf);
console.log("[icons] wrote build/icon.ico from", pngSource);
