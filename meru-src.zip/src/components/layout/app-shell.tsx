import { useEffect, useState } from "react";
import { NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import { cn } from "@/lib/cn";
import { Icon, type IconName } from "@/components/icons/icon";
import { AppFooter } from "@/components/branding/footer";
import { ConnectionBadge } from "@/features/sync/connection-indicator";
import { useAuth } from "@/features/auth/auth-context";
import { useIdleLock } from "@/features/auth/use-idle-lock";
import { ORGANIZATION, ROLE_LABELS, ROLE_COLORS } from "@/lib/constants";
import type { Permission } from "@/lib/permissions";
import { ThemeToggle } from "@/components/ThemeToggle";
import { useTheme } from "@/contexts/ThemeContext";

interface NavItem {
  to: string;
  label: string;
  icon: IconName;
  permission?: Permission;
}

const NAV_SECTIONS: { heading: string; items: NavItem[] }[] = [
  {
    heading: "Operations",
    items: [
      { to: "/app", label: "Dashboard", icon: "grid" },
      {
        to: "/app/people",
        label: "People Registry",
        icon: "users",
        permission: "people.view",
      },
      {
        to: "/app/issuance",
        label: "ID Issuance",
        icon: "id-card",
        permission: "issuance.view",
      },
      {
        to: "/app/id-card",
        label: "ID Card Designer",
        icon: "credit-card",
        permission: "issuance.view",
      },
      {
        to: "/app/departments",
        label: "Departments",
        icon: "landmark",
        permission: "departments.view",
      },
    ],
  },
  {
    heading: "Oversight",
    items: [
      {
        to: "/app/reports",
        label: "Reports",
        icon: "file-text",
        permission: "reports.view",
      },
      {
        to: "/app/sync",
        label: "Sync & Conflicts",
        icon: "refresh",
        permission: "sync.view",
      },
    ],
  },
  {
    heading: "Administration",
    items: [
      {
        to: "/app/printers",
        label: "Printers",
        icon: "printer",
        permission: "printers.view",
      },
      {
        to: "/app/settings",
        label: "Settings",
        icon: "settings",
      },
    ],
  },
];

export function AppShell() {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const { signOut, can } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const { isDark, toggleTheme } = useTheme();

  useIdleLock(() => {
    void signOut().then(() => navigate("/login?reason=idle"));
  });

  useEffect(() => {
    setDrawerOpen(false);
  }, [location.pathname]);

  const handleSignOut = (): void => {
    void signOut().then(() => navigate("/login"));
  };

  return (
    <div className="flex min-h-screen">
      {/* Desktop sidebar */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-30 hidden w-[260px] flex-col lg:flex no-print",
          "glass-panel text-white",
          "border-r border-white/10"
        )}
      >
        <SidebarBrand />
        <NavList can={can} />
        <div className="border-t border-white/10 p-4">
          <UserBlock onSignOut={handleSignOut} />
        </div>
      </aside>

      {/* Mobile drawer */}
      {drawerOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <button
            aria-label="Close navigation"
            className="absolute inset-0 bg-surface-900/60 backdrop-blur-sm animate-fade-in"
            onClick={() => setDrawerOpen(false)}
          />
          <aside
            className={cn(
              "absolute inset-y-0 left-0 flex w-72 max-w-[85vw] flex-col",
              "glass-panel text-white shadow-2xl",
              "animate-slide-left"
            )}
          >
            <SidebarBrand onClose={() => setDrawerOpen(false)} />
            <NavList can={can} />
            <div className="border-t border-white/10 p-4">
              <UserBlock onSignOut={handleSignOut} />
            </div>
          </aside>
        </div>
      )}

      {/* Main column */}
      <div className="flex min-h-screen w-full flex-col lg:pl-[260px]">
        {/* Glassmorphic header */}
        <header
          className={cn(
            "sticky top-0 z-20 no-print",
            "border-b border-surface-200/60 dark:border-slate-700/60",
            "bg-white/70 dark:bg-slate-900/80 backdrop-blur-xl",
            "supports-[backdrop-filter]:bg-white/60 dark:supports-[backdrop-filter]:bg-slate-900/70"
          )}
        >
          <div className="flex h-14 items-center justify-between gap-3 px-4 sm:px-6">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setDrawerOpen(true)}
                aria-label="Open navigation menu"
                className={cn(
                  "rounded-xl p-2 text-surface-500 dark:text-slate-400 lg:hidden",
                  "transition-all duration-200",
                  "hover:bg-surface-100 dark:hover:bg-slate-700 hover:text-surface-700 dark:hover:text-slate-200",
                  "active:scale-95"
                )}
              >
                <Icon name="menu" />
              </button>
              <div className="w-10 h-10 rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 shadow-sm flex items-center justify-center p-0.5 hidden sm:flex">
                <img src="/branding/meru-logo.jpeg" alt="Meru District Council Crest" className="object-contain w-full h-full" />
              </div>
              <div className="hidden flex-col sm:flex">
                <span className="text-xs font-medium text-surface-700 dark:text-slate-200 leading-tight">
                  {ORGANIZATION.nameSw}
                </span>
                <span className="text-[10px] text-surface-400 dark:text-slate-500 leading-tight">
                  {ORGANIZATION.nameEn}
                </span>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <ThemeToggle isDark={isDark} onToggle={toggleTheme} />
              <ConnectionBadge />
            </div>
          </div>
        </header>

        <main
          id="main-content"
          className="flex-1 px-4 py-6 sm:px-6 lg:px-8"
        >
          <Outlet />
        </main>

        <AppFooter className="no-print" />
      </div>
    </div>
  );
}

function SidebarBrand({ onClose }: { onClose?: () => void }) {
  return (
    <div className="relative flex items-center gap-3 border-b border-white/10 px-5 py-5">
      {onClose && (
        <button
          onClick={onClose}
          aria-label="Close menu"
          className={cn(
            "absolute right-3 top-3 rounded-lg p-1.5",
            "text-white/50 transition-all duration-200",
            "hover:bg-white/10 hover:text-white"
          )}
        >
          <Icon name="x" className="h-4 w-4" />
        </button>
      )}
      <div className="flex items-center gap-3">
        <img
          src="/branding/meru-logo.jpeg"
          alt="Meru District Council"
          className="h-11 w-11 rounded-xl object-cover ring-2 ring-white/20 shadow-glow"
        />
        <div>
          <h1 className="text-sm font-medium text-white/90 tracking-wide uppercase leading-tight">
            {ORGANIZATION.nameSw}
          </h1>
          <p className="text-[10px] text-white/40 tracking-wider">
            {ORGANIZATION.nameEn}
          </p>
        </div>
      </div>
    </div>
  );
}

function NavList({ can }: { can: (p: Permission) => boolean }) {
  return (
    <nav className="flex-1 overflow-y-auto px-3 py-4" aria-label="Primary">
      {NAV_SECTIONS.map((section, sectionIdx) => {
        const items = section.items.filter(
          (i) => !i.permission || can(i.permission)
        );
        if (items.length === 0) return null;
        return (
          <div
            key={section.heading}
            className={cn("mb-5", sectionIdx > 0 && "mt-2")}
          >
            <p className="mb-2 px-3 text-[10px] font-medium uppercase tracking-[0.12em] text-white/30">
              {section.heading}
            </p>
            <ul className="space-y-0.5">
              {items.map((item, idx) => (
                <li key={item.to}>
                  <NavLink
                    to={item.to}
                    end={item.to === "/app"}
                    className={({ isActive }) =>
                      cn(
                        "group flex items-center gap-3 rounded-xl px-3 py-2.5",
                        "text-[13px] transition-all duration-200",
                        isActive
                          ? "bg-white/15 text-white font-medium shadow-lg shadow-black/10 backdrop-blur-sm"
                          : "text-white/60 font-normal hover:bg-white/[0.07] hover:text-white/90",
                        `animate-fade-in stagger-${idx + 1}`
                      )
                    }
                  >
                    <Icon
                      name={item.icon}
                      className="h-[18px] w-[18px] opacity-80 transition-transform duration-200 group-hover:scale-110"
                      strokeWidth={1.75}
                    />
                    {item.label}
                  </NavLink>
                </li>
              ))}
            </ul>
          </div>
        );
      })}
    </nav>
  );
}

function UserBlock({ onSignOut }: { onSignOut: () => void }) {
  const { profile } = useAuth();
  if (!profile) return null;

  const roleColor = ROLE_COLORS[profile.role];

  return (
    <div className="flex items-center gap-3">
      <div
        className={cn(
          "w-9 h-9 rounded-full overflow-hidden border border-emerald-600/40 bg-emerald-950 flex-shrink-0 shadow-sm",
          "transition-transform duration-200 hover:scale-105"
        )}
      >
        <img
          src="/branding/admin-avatar.jpeg"
          alt="Meru Admin Avatar"
          className="w-full h-full object-cover object-center"
        />
      </div>
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium text-white/90">
          {profile.full_name}
        </p>
        <div className="flex items-center gap-1.5">
          <span
            className={cn(
              "inline-block h-1.5 w-1.5 rounded-full",
              roleColor.dot
            )}
          />
          <p className="truncate text-[10px] uppercase tracking-wider text-white/40">
            {ROLE_LABELS[profile.role]} · {profile.staff_number}
          </p>
        </div>
      </div>
      <button
        onClick={onSignOut}
        aria-label="Sign out"
        title="Sign out"
        className={cn(
          "rounded-xl p-2 text-white/50 transition-all duration-200",
          "hover:bg-white/10 hover:text-white active:scale-90"
        )}
      >
        <Icon name="log-out" className="h-[18px] w-[18px]" />
      </button>
    </div>
  );
}


