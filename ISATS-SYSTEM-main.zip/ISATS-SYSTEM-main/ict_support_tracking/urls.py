# ict_support_tracking/urls.py
from django.contrib import admin
from django.urls import path, include
from django.views.generic import RedirectView

urlpatterns = [
    path('admin/', admin.site.urls),

    # Include all URLs from core app
    path('', include('core.urls')),  # root-level URLs handled by core

    # Optional: redirect root '/' to login page
    path('', RedirectView.as_view(pattern_name='core:login', permanent=False)),
]
