# Meru DC ID Registry — Desktop Application (Windows .exe)

The same React application, packaged as a native Windows desktop app with
**native printer integration**, **full local storage**, and the existing
**offline-first sync** to Supabase.

## Architecture

```
┌──────────────────────────────────────────────────────────────┐
│  Electron main process (electron/ → bundled to dist-electron)│
│   • Window + tray + single-instance lock + state persistence │
│   • Native printer discovery (PowerShell Get-Printer)        │
│   • Native print pipeline (printToPDF → spooler)             │
│   • Local data folder, backup/restore                        │
│   • Minimal validated IPC surface (meru:*)                   │
├──────────────────────────────────────────────────────────────┤
│  Preload (sandboxed bridge) → window.meru (typed API)        │
├──────────────────────────────────────────────────────────────┤
│  Renderer — the existing React app, unchanged                │
│   • Dexie/IndexedDB local database (lives in userData dir)   │
│   • Outbox sync engine → Supabase when online                │
│   • HashRouter (file:// compatible)                          │
└──────────────────────────────────────────────────────────────┘
```

Security: `contextIsolation: true`, `nodeIntegration: false`, no remote
content, every IPC argument validated in the main process.

## Where data lives

All local data is inside the per-user data folder:

```
%APPDATA%\Meru DC ID Registry\
  logs\main.log       — main process log
  window-state.json   — window size/position
  Partitions\...      — Chromium profile: IndexedDB (Dexie), localStorage
```

Everything offline (people, print history, outbox queue, preferences) is in
that folder. Settings → System Info → **Local Data & Backups** exposes:
*Open Data Folder*, *Backup Now* (single `.mbackup` file), *Restore*.

## Development

```powershell
# Desktop app in dev mode (Vite dev server + Electron window):
npm run desktop:dev

# Web app only (unchanged):
npm run dev
```

`desktop:dev` bundles `electron/` with esbuild, starts Vite on port 5174,
and opens the Electron window pointed at it.

## Build the installer

```powershell
# One-time: generate build/icon.ico from the council crest
npm run desktop:icons

# Full build (renderer + main + NSIS installer + portable exe)
npm run desktop:build

# Portable exe only
npm run desktop:build:portable
```

Output lands in `dist-desktop/`:
- `MeruDC-IDRegistry-Setup-<version>.exe` — NSIS installer (per-user)
- `MeruDC-IDRegistry-Portable-<version>.exe` — portable, no install

Optional: drop `SumatraPDF.exe` into `build/` before building to enable
advanced silent-print control (explicit duplex + copies flags). Without it,
printing uses the Windows `printto` shell verb via the default PDF handler.

## Printing (native, replaces the external Print Agent)

- Printers are auto-discovered from Windows (USB / network / Wi-Fi) — no
  manual registration. The Printers page works identically in the browser
  (via the Print Agent) and the desktop (via the main process).
- ID printing renders front + back at full resolution, builds a two-page
  PDF in a hidden window, and spools it to the selected printer. With
  SumatraPDF present, `duplex` prints front and back on one sheet.
- Failures are real: a disconnected printer returns an error which is shown
  as a toast and recorded in print history.

## Update checking

Settings → Check for Updates uses `electron-updater` when the app is
packaged and an update feed is configured in `electron-builder.yml`
(`publish:` block — placeholder commented out). In dev it reports that
updates are unavailable.

## Acceptance checklist (clean Windows PC)

1. [ ] Run `MeruDC-IDRegistry-Setup-<version>.exe` → app installs and starts.
2. [ ] App icon shows the Meru crest; dark theme matches the web app.
3. [ ] Log in once **online** (Supabase credentials valid).
4. [ ] Disconnect internet (Wi-Fi off / cable out) → header shows OFFLINE.
5. [ ] Register a new person offline (ID Card Designer → Register) → saved.
6. [ ] Restart the app while offline → session still valid, data present.
7. [ ] Print an ID to a real USB printer offline → prints (or shows a real
       error if the printer is off).
8. [ ] Reconnect internet → header flips to ONLINE/SYNCING; outbox drains;
       the new person appears in Supabase.
9. [ ] Settings → Backup Now → `.mbackup` file created.
10. [ ] Settings → Restore (choose that file) → app restarts with restored
        data.

## Troubleshooting

- **Electron window does not open in dev** — ensure the Electron binary is
  installed: `node node_modules/electron/install.js` (some npm setups block
  its postinstall script).
- **Print dialog never appears / nothing prints** — check
  `%APPDATA%\Meru DC ID Registry\logs\main.log`; install SumatraPDF in
  `build/` and rebuild for the most reliable silent printing.
- **Backup restore hangs** — restore runs after the app exits (PowerShell
  helper); wait ~5 seconds for automatic relaunch.
