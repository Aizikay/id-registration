/**
 * Printer & workstation device administration.
 */

import { supabase } from "./supabase-client";
import { mapSupabaseError } from "./errors";
import type { Printer, WorkstationDevice } from "@/types";

export async function listPrinters(): Promise<Printer[]> {
  const { data, error } = await supabase
    .from("printers")
    .select("*")
    .order("printer_name");
  if (error) throw mapSupabaseError(error);
  return data as Printer[];
}

export interface RegisterPrinterInput {
  printerName: string;
  printerIdentifier: string;
  location?: string;
}

export async function registerPrinter(
  input: RegisterPrinterInput
): Promise<Printer> {
  const { data, error } = await supabase
    .from("printers")
    .insert({
      printer_name: input.printerName,
      printer_identifier: input.printerIdentifier,
      location: input.location ?? null
    })
    .select("*")
    .single();
  if (error) throw mapSupabaseError(error);
  const printer = data as Printer;
  return printer;
}

export async function setPrinterEnabled(
  id: string,
  enabled: boolean
): Promise<void> {
  const { error } = await supabase
    .from("printers")
    .update({ enabled })
    .eq("id", id);
  if (error) throw mapSupabaseError(error);

}

export async function testPrinter(printerId: string): Promise<{ ok: boolean; message: string }> {
  // Delegates to the local print agent via the printing service.
  const { printAgentClient } = await import("@/printing/agent-client");
  return printAgentClient.testPrinter(printerId);
}

export async function listDevices(): Promise<WorkstationDevice[]> {
  const { data, error } = await supabase
    .from("workstation_devices")
    .select("*")
    .order("device_name");
  if (error) throw mapSupabaseError(error);
  return data as WorkstationDevice[];
}

/** Called once per session per device: registers or refreshes this device. */
export async function registerThisDevice(device: {
  deviceId: string;
  deviceName: string;
  location?: string;
}): Promise<WorkstationDevice | null> {
  if (!navigator.onLine) return null;
  try {
    const { data, error } = await supabase
      .from("workstation_devices")
      .upsert(
        {
          device_id: device.deviceId,
          device_name: device.deviceName,
          location: device.location ?? null,
          status: "active",
          last_online_at: new Date().toISOString()
        },
        { onConflict: "device_id" }
      )
      .select("*")
      .maybeSingle();
    if (error) {
      // A revoked device will fail the upsert due to RLS — surface clearly.
      throw mapSupabaseError(error);
    }
    return (data as WorkstationDevice | null) ?? null;
  } catch (err) {
    const mapped = mapSupabaseError(err);
    if (
      mapped.code === "permission_denied" ||
      mapped.code === "conflict_detected"
    ) {
      const revoked = new Error("device_revoked");
      throw mapSupabaseError(revoked);
    }
    return null;
  }
}
