import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState
} from "react";
import { createPortal } from "react-dom";
import { cn } from "@/lib/cn";
import { Icon, type IconName } from "@/components/icons/icon";

export type ToastTone = "success" | "error" | "warning" | "info";

export interface Toast {
  id: number;
  tone: ToastTone;
  title: string;
  message?: string;
}

interface ToastContextValue {
  toast: (tone: ToastTone, title: string, message?: string) => void;
  success: (title: string, message?: string) => void;
  error: (title: string, message?: string) => void;
  warning: (title: string, message?: string) => void;
  info: (title: string, message?: string) => void;
}

const ToastContext = createContext<ToastContextValue | null>(null);

const TONE_STYLES: Record<ToastTone, { icon: IconName; classes: string }> = {
  success: {
    icon: "check-circle",
    classes: "border-emerald-200 bg-emerald-50 text-emerald-800"
  },
  error: {
    icon: "alert-circle",
    classes: "border-red-200 bg-red-50 text-red-800"
  },
  warning: {
    icon: "alert-triangle",
    classes: "border-amber-200 bg-amber-50 text-amber-800"
  },
  info: {
    icon: "info",
    classes: "border-sky-200 bg-sky-50 text-sky-800"
  }
};

let nextId = 1;

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const remove = useCallback((id: number) => {
    setToasts((t) => t.filter((x) => x.id !== id));
  }, []);

  const push = useCallback(
    (tone: ToastTone, title: string, message?: string) => {
      const id = nextId++;
      setToasts((t) => [...t.slice(-4), { id, tone, title, message }]);
      window.setTimeout(() => remove(id), 6000);
    },
    [remove]
  );

  const value = useMemo<ToastContextValue>(
    () => ({
      toast: push,
      success: (title, msg) => push("success", title, msg),
      error: (title, msg) => push("error", title, msg),
      warning: (title, msg) => push("warning", title, msg),
      info: (title, msg) => push("info", title, msg)
    }),
    [push]
  );

  return (
    <ToastContext.Provider value={value}>
      {children}
      {createPortal(
        <div
          aria-live="polite"
          className="pointer-events-none fixed bottom-4 right-4 z-[60] flex w-full max-w-sm flex-col gap-2 px-4 sm:px-0"
        >
          {toasts.map((t) => (
            <div
              key={t.id}
              role="status"
              className={cn(
                "pointer-events-auto flex animate-slide-up items-start gap-3 rounded-xl border p-3.5 shadow-popover backdrop-blur-sm",
                TONE_STYLES[t.tone].classes
              )}
            >
              <Icon name={TONE_STYLES[t.tone].icon} className="mt-0.5 h-5 w-5 shrink-0" />
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold">{t.title}</p>
                {t.message && (
                  <p className="mt-0.5 text-xs opacity-80">{t.message}</p>
                )}
              </div>
              <button
                onClick={() => remove(t.id)}
                aria-label="Dismiss"
                className="rounded-md p-1 opacity-60 hover:bg-black/5 hover:opacity-100"
              >
                <Icon name="x" className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>,
        document.body
      )}
    </ToastContext.Provider>
  );
}

export function useToast(): ToastContextValue {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error("useToast must be used within <ToastProvider>");
  return ctx;
}
