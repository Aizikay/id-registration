$ids = @(26628, 22724)
foreach ($procId in $ids) {
  $p = Get-Process -Id $procId -ErrorAction SilentlyContinue
  if ($p) {
    Write-Output "PID $($procId) : $($p.ProcessName)"
  } else {
    Write-Output "PID $($procId) : NOT FOUND"
  }
}
