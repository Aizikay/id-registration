/**
 * Template Manager — Custom Template CRUD with IndexedDB storage.
 */

import Dexie, { type Table } from "dexie";

// ============================================================
// Types
// ============================================================

export type TemplateSourceType = "pdf" | "image" | "ai";

export interface CustomFieldConfig {
  id: string;
  label: string;
  dataKey: string | null;
  staticText?: string;
  position: {
    xPct: number;
    yPct: number;
    wPct: number;
    hPct: number;
  };
  style: {
    fontSizePt: number;
    fontWeight: number;
    fontFamily: string;
    letterSpacingEm: number;
    lineHeight: number;
    textAlign: "left" | "center" | "right";
    color: string;
    textTransform?: "uppercase" | "none";
  };
  visible: boolean;
  maskColor?: string;
}

export interface CustomPhotoArea {
  enabled: boolean;
  position: {
    xPct: number;
    yPct: number;
    wPct: number;
    hPct: number;
  };
  borderRadius: number;
  borderColor: string;
  background: string;
  objectFit: "cover" | "contain" | "fill";
}

export interface CustomSignatureArea {
  enabled: boolean;
  label: string;
  position: {
    xPct: number;
    yPct: number;
    wPct: number;
    hPct: number;
  };
  borderColor: string;
}

export interface CustomTemplate {
  id: string;
  name: string;
  description: string;
  sourceType: TemplateSourceType;
  fileName: string;
  mimeType: string;
  fileDataUrl: string;
  width: number;
  height: number;
  aspectRatio: number;
  createdAt: string;
  updatedAt: string;
  createdBy: string;
  isActive: boolean;
  fields: CustomFieldConfig[];
  photo: CustomPhotoArea;
  signatures: CustomSignatureArea[];
  masks: Array<{ id: string; position: { xPct: number; yPct: number; wPct: number; hPct: number }; color: string }>;
}

export interface UploadedFile {
  file: File;
  name: string;
  type: TemplateSourceType;
  mimeType: string;
}

// ============================================================
// Database
// ============================================================

class TemplateDatabase extends Dexie {
  templates!: Table<CustomTemplate, string>;

  constructor() {
    super("meru-id-templates");
    this.version(1).stores({
      templates: "id, name, isActive, createdAt, createdBy",
    });
  }
}

const templateDb = new TemplateDatabase();

// ============================================================
// Format Detection
// ============================================================

const IMAGE_TYPES = new Set([
  "image/jpeg", "image/jpg", "image/png", "image/webp",
  "image/gif", "image/bmp", "image/svg+xml",
]);

const PDF_MIMES = new Set(["application/pdf"]);

const AI_EXTENSIONS = new Set([".ai", ".ait"]);

export function detectFileType(file: File): TemplateSourceType {
  const ext = "." + file.name.split(".").pop()?.toLowerCase();

  if (PDF_MIMES.has(file.type) || ext === ".pdf") {
    return "pdf";
  }

  if (AI_EXTENSIONS.has(ext)) {
    return "ai";
  }

  if (IMAGE_TYPES.has(file.type)) {
    return "image";
  }

  if (file.name.toLowerCase().endsWith(".ai")) {
    return "ai";
  }

  throw new Error(
    `Unsupported file type: ${file.type || ext}\n` +
    `Supported formats:\n` +
    `• PDF (.pdf)\n` +
    `• Adobe Illustrator (.ai)\n` +
    `• Images (.jpg, .jpeg, .png, .webp, .gif, .bmp, .svg)`
  );
}

export function validateFile(file: File): { valid: boolean; error?: string } {
  const maxSize = 50 * 1024 * 1024;
  if (file.size > maxSize) {
    return { valid: false, error: `File too large. Maximum size is 50MB. (Your file: ${(file.size / 1024 / 1024).toFixed(1)}MB)` };
  }

  if (file.size === 0) {
    return { valid: false, error: "File is empty." };
  }

  try {
    detectFileType(file);
    return { valid: true };
  } catch (e) {
    return { valid: false, error: e instanceof Error ? e.message : "Unknown file type" };
  }
}

export const ACCEPT_MIME = "application/pdf,image/*,.ai,.ait";

// ============================================================
// File Reading
// ============================================================

export function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error("Failed to read file"));
    reader.readAsDataURL(file);
  });
}

export async function getImageDimensions(dataUrl: string): Promise<{ width: number; height: number }> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve({ width: img.naturalWidth, height: img.naturalHeight });
    img.onerror = () => reject(new Error("Failed to load image"));
    img.src = dataUrl;
  });
}

// ============================================================
// CRUD Operations
// ============================================================

export async function createCustomTemplate(
  file: File,
  creatorName: string
): Promise<CustomTemplate> {
  const fileType = detectFileType(file);
  const dataUrl = await readFileAsDataUrl(file);

  let width = 595;
  let height = 842;

  if (fileType === "image") {
    const dims = await getImageDimensions(dataUrl);
    width = dims.width;
    height = dims.height;
  } else if (fileType === "pdf" || fileType === "ai") {
    try {
      const { default: pdfjsLib } = await import("pdfjs-dist");
      const pdfWorkerSrc = (await import("pdfjs-dist/build/pdf.worker.mjs?url")).default;
      if (!pdfjsLib.GlobalWorkerOptions.workerSrc) {
        pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorkerSrc;
      }
      const loadingTask = pdfjsLib.getDocument(dataUrl);
      const pdf = await loadingTask.promise;
      const page = await pdf.getPage(1);
      const viewport = page.getViewport({ scale: 1 });
      width = viewport.width;
      height = viewport.height;
    } catch {
      // Use defaults
    }
  }

  const now = new Date().toISOString();
  const id = `custom-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

  const template: CustomTemplate = {
    id,
    name: file.name.replace(/\.[^/.]+$/, "").replace(/[-_]/g, " "),
    description: `Uploaded ${fileType.toUpperCase()} template`,
    sourceType: fileType,
    fileName: file.name,
    mimeType: file.type || (fileType === "ai" ? "application/illustrator" : "application/octet-stream"),
    fileDataUrl: dataUrl,
    width,
    height,
    aspectRatio: width / height,
    createdAt: now,
    updatedAt: now,
    createdBy: creatorName,
    isActive: false,
    fields: createDefaultFields(),
    photo: {
      enabled: fileType === "pdf" || fileType === "ai",
      position: { xPct: 60, yPct: 30, wPct: 30, hPct: 30 },
      borderRadius: 4,
      borderColor: "#333333",
      background: "#ffffff",
      objectFit: "cover",
    },
    signatures: [
      {
        enabled: false,
        label: "Sahihi ya Mtumishi",
        position: { xPct: 5, yPct: 75, wPct: 35, hPct: 12 },
        borderColor: "#999999",
      },
      {
        enabled: false,
        label: "Sahihi ya Mwajiri",
        position: { xPct: 55, yPct: 75, wPct: 35, hPct: 12 },
        borderColor: "#999999",
      },
    ],
    masks: [],
  };

  await templateDb.templates.add(template);
  return template;
}

function createDefaultFields(): CustomFieldConfig[] {
  return [
    {
      id: "fullName",
      label: "Full Name (Jina)",
      dataKey: "fullName",
      position: { xPct: 5, yPct: 40, wPct: 45, hPct: 5 },
      style: {
        fontSizePt: 12,
        fontWeight: 700,
        fontFamily: "Arial, sans-serif",
        letterSpacingEm: 0,
        lineHeight: 1.2,
        textAlign: "left",
        color: "#1a1a1a",
        textTransform: "uppercase",
      },
      visible: true,
    },
    {
      id: "checkNumber",
      label: "Cheki Namba",
      dataKey: "checkNumber",
      position: { xPct: 5, yPct: 46, wPct: 45, hPct: 4 },
      style: {
        fontSizePt: 10,
        fontWeight: 600,
        fontFamily: "Arial, sans-serif",
        letterSpacingEm: 0,
        lineHeight: 1.2,
        textAlign: "left",
        color: "#333333",
      },
      visible: true,
    },
    {
      id: "position",
      label: "Position (Cheo)",
      dataKey: "position",
      position: { xPct: 5, yPct: 52, wPct: 45, hPct: 4 },
      style: {
        fontSizePt: 10,
        fontWeight: 600,
        fontFamily: "Arial, sans-serif",
        letterSpacingEm: 0,
        lineHeight: 1.2,
        textAlign: "left",
        color: "#333333",
        textTransform: "uppercase",
      },
      visible: true,
    },
    {
      id: "fileNumber",
      label: "File Number (Namba)",
      dataKey: "fileNumber",
      position: { xPct: 5, yPct: 58, wPct: 45, hPct: 4 },
      style: {
        fontSizePt: 9,
        fontWeight: 500,
        fontFamily: "Arial, sans-serif",
        letterSpacingEm: 0,
        lineHeight: 1.2,
        textAlign: "left",
        color: "#555555",
      },
      visible: true,
    },
  ];
}

export async function getAllTemplates(): Promise<CustomTemplate[]> {
  return templateDb.templates.orderBy("createdAt").reverse().toArray();
}

export async function getActiveTemplate(): Promise<CustomTemplate | undefined> {
  return templateDb.templates.where("isActive").equals(1).first()
    ?? templateDb.templates.orderBy("createdAt").last();
}

export async function getTemplateById(id: string): Promise<CustomTemplate | undefined> {
  return templateDb.templates.get(id);
}

export async function updateTemplate(id: string, updates: Partial<CustomTemplate>): Promise<void> {
  await templateDb.templates.update(id, {
    ...updates,
    updatedAt: new Date().toISOString(),
  });
}

export async function deleteTemplate(id: string): Promise<void> {
  await templateDb.templates.delete(id);
}

export async function setActiveTemplate(id: string): Promise<void> {
  await templateDb.templates.toCollection().modify({ isActive: false });
  await templateDb.templates.update(id, { isActive: true });
}

export async function duplicateTemplate(id: string, newName: string): Promise<CustomTemplate | null> {
  const source = await templateDb.templates.get(id);
  if (!source) return null;

  const newId = `custom-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const now = new Date().toISOString();

  const duplicate: CustomTemplate = {
    ...source,
    id: newId,
    name: newName,
    isActive: false,
    createdAt: now,
    updatedAt: now,
  };

  await templateDb.templates.add(duplicate);
  return duplicate;
}

export function normalizeTemplateName(fileName: string): string {
  return fileName
    .replace(/\.[^/.]+$/, "")
    .replace(/[-_]+/g, " ")
    .replace(/\s+/g, " ")
    .replace(/\b\w/g, (c) => c.toUpperCase())
    .trim();
}
