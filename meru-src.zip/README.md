# Meru District Council — ID Registration & Issuance Management System

Identification Registration & Issuance Management System for **Halmashauri ya Wilaya ya Meru** (Meru District Council, Arusha, Tanzania). Bilingual (Swahili/English), offline-capable, audited, and duplicate-proof.

> **Made by Aizikay.dev Enterprises**

---

## Features

- **People registry** — bilingual validation, 18+ age gate, TZ phone checks, search/filter by name/ID, offline queue.
- **One-ID-per-person enforcement** — partial unique index + atomic `issue_id()` RPC; duplicate attempts are blocked with a full audit trail (who, when, printer, reference).
- **Issuance lifecycle** — `pending → printing → issued` (terminal), `failed ↔ pending/reprint_requested`, `cancelled`/`reprint_requested` transitions, idempotency keys, supervisor/Admin reprint authorization.
- **Offline-first** — Dexie (IndexedDB) local store, outbox with exponential backoff (cap 10 min) → conflict after 8 retries, sync engine drains on `online` + 30 s timer, re-keys local UUIDs to server UUIDs.
- **Local printing** — browser talks to a localhost-only Node print agent (`http://127.0.0.1:8377`) that drives Windows printers; Origin allowlist, idempotency, job polling (`/print`, `/test`, `/jobs/:id`, `/status`).
- **Administration** — staff accounts via Edge Function (service role never in browser), role matrix (admin/officer/supervisor/viewer), printers, workstation devices, system settings.
- **Audit & reports** — append-only `audit_logs` (no UPDATE/DELETE RLS), staff activity, issuance/failed/duplicate report tabs, CSV export from `queryIssuancesOnline`.
- **PWA** — `vite-plugin-pwa` precaches shell assets only (never API/personal data), `offline.html` fallback.
- **Branding** — official council logos are never fabricated; placeholders render when `/public/branding/*.png` assets are absent.

## Tech Stack

| Layer | Choice |
|-------|--------|
| Frontend | React 18 + Vite + TypeScript (strict) + React Router 6 + Tailwind CSS |
| Backend | Supabase (Postgres + Auth + RLS + RPC + Realtime + Edge Functions) |
| Offline | Dexie 4 + `fake-indexeddb` for tests |
| PWA | `vite-plugin-pwa` (Workbox GenerateSW) |
| Print agent | Node 20+ HTTP (no external deps), PowerShell/wmic printer discovery |
| Tests | Vitest + Testing Library + jsdom |
| Deploy | Vercel (SPA rewrites + security headers + CSP in `vercel.json`) |

## Architecture

```
Browser (React/Vite)
  ├── IndexedDB (Dexie: persons, issuances, identifications, outbox, meta)
  ├── Outbox → SyncEngine (online event + 30 s tick, backoff, conflict marking)
  ├── Supabase Auth (JWT) + RLS (per-role policies) + RPCs (issue_id, update_issuance_status)
  ├── Supabase Edge Function create-user (service role, admin-only)
  └── Print Agent Client → http://127.0.0.1:8377 (Origin allowlist, idempotency)
         └── Windows spooler (PowerShell Start-Process / rundll32 / print)
```

**Duplicate prevention:** `issuance_one_active_per_person_idx` partial unique index on `(person_id) WHERE status IN (pending,printing,issued,reprint_requested)` + `issue_id()` SECURITY DEFINER RPC that checks auth, idempotency replay, duplicate block, and inserts the issuance + audit row atomically.

**Auth & offline capability:** Supabase Auth only. Offline capability is an HMAC-SHA256 signed record (base in localStorage + sig in sessionStorage, keyed to device `WS-<16 hex>` in IndexedDB meta) that expires per `VITE_MAX_OFFLINE_HOURS`; idle lock via `VITE_IDLE_LOCK_MINUTES`.

## Prerequisites

- Node.js 20+ · npm 11+
- Supabase CLI 2.115+ (`npx supabase --version`) — for migrations & edge functions
- A Supabase project (cloud or self-hosted)
- Windows 10/11 workstation for the print agent (macOS/Linux runs in mock/dry-run mode)

## Quick Start

1. **Clone & install**

   ```powershell
   git clone <repo-url>
   cd "ID Registration & Issuance Management System.(MERU DC)"
   npm install
   npm --prefix print-agent install
   ```

2. **Environment**

   ```powershell
   Copy-Item .env.example .env.local
   # then edit .env.local:
   # VITE_SUPABASE_URL=https://<project-ref>.supabase.co
   # VITE_SUPABASE_ANON_KEY=<anon-key>
   # VITE_PRINT_AGENT_URL=http://localhost:8377   # optional
   # VITE_MAX_OFFLINE_HOURS=24                    # optional
   # VITE_IDLE_LOCK_MINUTES=30                    # optional
   ```

3. **Supabase**

   ```powershell
   npx supabase link --project-ref <project-ref>
   npx supabase db push
   npx supabase functions deploy create-user --no-verify-jwt
   # Ensure Auth → Settings → Enable signup = OFF (service-role provisioning only)
   ```

4. **Run**

   ```powershell
   npm run dev          # frontend at http://localhost:5173
   npm --prefix print-agent run build
   npm run agent        # print agent at http://127.0.0.1:8377 (keep this terminal open)
   ```

5. **First admin** — create one user via the Edge Function (or Supabase Dashboard → Auth → Users → Invite, then set `profiles.role = 'admin'`), sign in, then manage staff at **Staff Accounts**.

## Branding

Place **authorized, official** files in `public/branding/` (see `public/branding/README.md`):

- `meru-district-council-logo.png` (512×512)
- `tanzania-coat-of-arms.png`
- `tanzania-flag.png`
- `app-icon-192.png`, `app-icon-512.png`, `app-icon-maskable-512.png`

SVG placeholders ship so the app is usable before assets are provisioned. Never commit fabricated council logos.

## Print Agent

See `print-agent/README.md` for full docs. Summary:

```powershell
npm --prefix print-agent run build
npm --prefix print-agent start          # binds 127.0.0.1:8377 only
# verify
curl http://127.0.0.1:8377/status
```

- **Endpoints:** `GET /status`, `GET /printers`, `POST /test`, `POST /print`, `GET /jobs/:id`, `GET /health`.
- **Origin allowlist:** `localhost`/`127.0.0.1` (any port) + `*.vercel.app` + `ALLOWED_ORIGINS` env.
- **Idempotency:** same `idempotency_key` → same `job_id`, no re-print.
- **Discovery:** `Get-Printer | ConvertTo-Json` → `wmic` → mock fallback.
- **Dry run:** `PRINT_AGENT_DRY_RUN=true` simulates success without spooler.

Deploy to workstations via `nssm` or Task Scheduler (logon trigger).

## Roles & Permissions

Defined in `src/lib/permissions.ts` and enforced again by RLS:

| Permission | admin | officer | supervisor | viewer |
|------------|-------|---------|------------|--------|
| people.view | ✓ | ✓ | ✓ | ✓ |
| people.create/update | ✓ | ✓ | — | — |
| issuance.view | ✓ | ✓ | ✓ | ✓ |
| issuance.create/cancel | ✓ | ✓/— | — | — |
| print.request | ✓ | ✓ | — | — |
| print.reprint | ✓ | — | ✓ | — |
| users.view/manage | ✓ | — | view | — |
| audit.view | ✓ | — | ✓ | — |
| reports.view/export | ✓ | view | ✓ | — |
| printers/devices/settings | ✓ | — | view | — |
| sync.view/retry, conflicts.resolve | ✓ | — | view/resolve | — |

Status transitions in `src/lib/issuance-rules.ts` mirror the DB trigger: `pending → printing/issued/failed/cancelled`, `printing → issued/failed/cancelled`, `issued` terminal (reprints are new rows), `failed → pending/reprint_requested/cancelled`, `reprint_requested → printing/failed/cancelled`.

## Scripts

| Command | Description |
|---------|-------------|
| `npm run dev` | Vite dev server |
| `npm run build` | `tsc -b && vite build` (PWA + chunked) |
| `npm run typecheck` | `tsc -b --noEmit` (use `node node_modules/typescript/bin/tsc -b` if path contains spaces/&`) |
| `npm run lint` | ESLint (max-warnings 0) |
| `npm test` | Vitest run (jsdom, fake-indexeddb) |
| `npm run agent` | Run compiled print agent |
| `npm --prefix print-agent run build` | Compile print agent |

## Testing

```powershell
node node_modules/vitest/vitest.mjs run
node node_modules/vitest/vitest.mjs run --coverage
```

Suites: `src/lib/validation.test.ts` · `identifiers.test.ts` · `issuance-rules.test.ts` · `permissions.test.ts` · `format.test.ts` · `src/offline/outbox.test.ts` (backoff, conflict escalation, retry reset).

## Deployment (Vercel)

- `vercel.json` — SPA rewrites, `X-Frame-Options`, `X-Content-Type-Options`, `Referrer-Policy`, `Permissions-Policy`, CSP.
- Environment variables in Vercel Dashboard must match `.env.example` (`VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`, optional `VITE_PRINT_AGENT_URL`, `VITE_MAX_OFFLINE_HOURS`, `VITE_IDLE_LOCK_MINUTES`).
- Print agent is **not** deployed to Vercel — it runs on each Windows workstation.

## Security

- CSP + `X-Frame-Options: DENY` + `X-Content-Type-Options: nosniff` in `vercel.json`.
- RLS on every table; audit logs are INSERT/SELECT only; service role stays server-side (Edge Function).
- Offline capability is HMAC-signed and bound to device id; workstation auto-registers and can be revoked (`workstation_devices.status = 'revoked'`).
- Path with spaces/`&` breaks npm `.cmd` shims on Windows — invoke binaries directly (`node node_modules/<bin>`).

## Troubleshooting

- **npm scripts fail with “Cannot find module”** — your checkout path contains a space/`&`. Use direct invocations shown above or move the project to a path without spaces.
- **Agent unreachable** — start `npm run agent` and check `curl http://127.0.0.1:8377/status`; allow loopback in Windows Firewall.
- **Origin not allowed** — add the frontend origin to `ALLOWED_ORIGINS` in the agent env.
- **Printer not found** — confirm `GET /status` lists the printer; mock printers are always available for testing.
- **Supabase Auth “signup disabled”** — expected; create users via **Staff Accounts** (Edge Function).

## License

Private — Halmashauri ya Wilaya ya Meru. All rights reserved.
