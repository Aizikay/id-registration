import { describe, it, expect } from "vitest";
import { canTransition, allowedNextStatuses } from "./issuance-rules";
import type { IssuanceStatus } from "@/types";

describe("canTransition", () => {
  it("allows pending -> printing/issued/failed/cancelled", () => {
    expect(canTransition("pending", "printing")).toBe(true);
    expect(canTransition("pending", "issued")).toBe(true);
    expect(canTransition("pending", "failed")).toBe(true);
    expect(canTransition("pending", "cancelled")).toBe(true);
    expect(canTransition("pending", "reprint_requested")).toBe(false);
  });

  it("allows printing -> issued/failed/cancelled only", () => {
    expect(canTransition("printing", "issued")).toBe(true);
    expect(canTransition("printing", "failed")).toBe(true);
    expect(canTransition("printing", "pending")).toBe(false);
  });

  it("treats issued as terminal", () => {
    const all: IssuanceStatus[] = ["pending", "printing", "issued", "failed", "cancelled", "reprint_requested"];
    for (const s of all) expect(canTransition("issued", s)).toBe(false);
  });

  it("allows failed -> pending/reprint_requested/cancelled", () => {
    expect(canTransition("failed", "pending")).toBe(true);
    expect(canTransition("failed", "reprint_requested")).toBe(true);
    expect(canTransition("failed", "cancelled")).toBe(true);
    expect(canTransition("failed", "issued")).toBe(false);
  });

  it("allows reprint_requested -> printing/failed/cancelled", () => {
    expect(canTransition("reprint_requested", "printing")).toBe(true);
    expect(canTransition("reprint_requested", "failed")).toBe(true);
    expect(canTransition("reprint_requested", "cancelled")).toBe(true);
    expect(canTransition("reprint_requested", "issued")).toBe(false);
  });

  it("treats cancelled as terminal", () => {
    expect(canTransition("cancelled", "pending")).toBe(false);
    expect(canTransition("cancelled", "failed")).toBe(false);
  });
});

describe("allowedNextStatuses", () => {
  it("returns correct sets", () => {
    expect(allowedNextStatuses("pending")).toEqual(["printing", "issued", "failed", "cancelled"]);
    expect(allowedNextStatuses("issued")).toEqual([]);
    expect(allowedNextStatuses("cancelled")).toEqual([]);
  });
});
