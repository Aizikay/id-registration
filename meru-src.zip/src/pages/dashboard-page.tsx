import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { StatusBadge } from "@/components/ui/status-badge";
import { ErrorState } from "@/components/ui/data-table";
import { Icon, type IconName } from "@/components/icons/icon";
import { fetchDashboardStats, type DashboardStats } from "@/services/reports-service";
import { mapSupabaseError } from "@/services/errors";
import { formatNumber, formatRelative } from "@/lib/format";
import { useAuth } from "@/features/auth/auth-context";
import { cn } from "@/lib/cn";

/* ── Helpers ──────────────────────────────────────────────────── */

function TrendBadge({ value }: { value: number }) {
  const positive = value >= 0;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-0.5 rounded-full px-2 py-0.5 text-[10px] font-bold tabular-nums",
        positive
          ? "bg-emerald-100 dark:bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 ring-1 ring-emerald-200 dark:ring-emerald-500/30"
          : "bg-red-100 dark:bg-red-500/15 text-red-700 dark:text-red-400 ring-1 ring-red-200 dark:ring-red-500/30"
      )}
    >
      {positive ? (
        <svg className="h-2.5 w-2.5" viewBox="0 0 8 8" fill="currentColor"><path d="M4 0l4 6H0z"/></svg>
      ) : (
        <svg className="h-2.5 w-2.5" viewBox="0 0 8 8" fill="currentColor"><path d="M4 8L0 2h8z"/></svg>
      )}
      {positive ? "+" : ""}{value}%
    </span>
  );
}

function StatusDot({ status, pulse }: { status: "green" | "amber" | "red"; pulse?: boolean }) {
  return (
    <span className="relative flex h-2.5 w-2.5">
      {pulse && (
        <span
          className={cn(
            "absolute inline-flex h-full w-full rounded-full opacity-75 animate-ping",
            status === "green" && "bg-emerald-400",
            status === "amber" && "bg-amber-400",
            status === "red" && "bg-red-400"
          )}
        />
      )}
      <span
        className={cn(
          "relative inline-flex h-2.5 w-2.5 rounded-full",
          status === "green" && "bg-emerald-500",
          status === "amber" && "bg-amber-500",
          status === "red" && "bg-red-500"
        )}
      />
    </span>
  );
}

/* ── KPI Stat Card ────────────────────────────────────────────── */

const CARD_CONFIG = {
  council: {
    iconBg: "bg-emerald-100 dark:bg-emerald-500/15",
    iconColor: "text-emerald-600 dark:text-emerald-400",
    ring: "ring-emerald-200 dark:ring-emerald-500/20",
    accent: "bg-emerald-500",
  },
  accent: {
    iconBg: "bg-teal-100 dark:bg-teal-500/15",
    iconColor: "text-teal-600 dark:text-teal-400",
    ring: "ring-teal-200 dark:ring-teal-500/20",
    accent: "bg-teal-500",
  },
  amber: {
    iconBg: "bg-amber-100 dark:bg-amber-500/15",
    iconColor: "text-amber-600 dark:text-amber-400",
    ring: "ring-amber-200 dark:ring-amber-500/20",
    accent: "bg-amber-500",
  },
  danger: {
    iconBg: "bg-red-100 dark:bg-red-500/15",
    iconColor: "text-red-600 dark:text-red-400",
    ring: "ring-red-200 dark:ring-red-500/20",
    accent: "bg-red-500",
  },
} as const;

function StatCard({
  icon,
  label,
  value,
  trend,
  loading,
  color,
  to,
  delay,
}: {
  icon: IconName;
  label: string;
  value?: number;
  trend?: number;
  loading: boolean;
  color: keyof typeof CARD_CONFIG;
  to: string;
  delay: number;
}) {
  const c = CARD_CONFIG[color];
  return (
    <Link
      to={to}
      className={cn(
        "group relative overflow-hidden rounded-2xl border border-slate-200 dark:border-slate-700/60 bg-white dark:bg-slate-800/80",
        "p-5 shadow-sm dark:shadow-xl transition-all duration-300",
        "hover:-translate-y-0.5 hover:shadow-lg hover:shadow-black/5 dark:hover:shadow-black/30",
        "active:scale-[0.98]",
        "animate-fade-in"
      )}
      style={{ animationDelay: `${delay * 70}ms` }}
    >
      {/* Top accent line */}
      <div className={cn("absolute top-0 left-0 h-1 w-full", c.accent, "opacity-60")} />

      <div className="relative flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            {label}
          </p>
          <div className="mt-2 flex items-baseline gap-2">
            {loading ? (
              <span className="inline-block h-8 w-20 rounded-lg bg-slate-100 dark:bg-slate-700 animate-pulse" />
            ) : (
              <span className="text-2xl font-bold tabular-nums text-slate-900 dark:text-white tracking-tight">
                {formatNumber(value ?? 0)}
              </span>
            )}
            {trend !== undefined && !loading && <TrendBadge value={trend} />}
          </div>
        </div>

        <div
          className={cn(
            "flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl ring-1 transition-all duration-300",
            "group-hover:scale-110 group-hover:rotate-3",
            c.iconBg, c.iconColor, c.ring
          )}
        >
          <Icon name={icon} className="h-5 w-5" strokeWidth={2} />
        </div>
      </div>
    </Link>
  );
}

/* ── Bar Chart ────────────────────────────────────────────────── */

function IssuanceChart({
  data,
  loading,
}: {
  data?: { day: string; issued_count: number }[];
  loading: boolean;
}) {
  const [range, setRange] = useState<"7d" | "30d">("7d");
  const [hoveredBar, setHoveredBar] = useState<number | null>(null);
  const safeData = Array.isArray(data) ? data : [];
  const dayLabels = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

  if (loading) {
    return (
      <div className="flex h-56 items-end gap-2 sm:gap-3 px-2">
        {[...Array(7)].map((_, i) => (
          <div key={i} className="flex flex-1 flex-col items-center gap-2">
            <div
              className="w-full rounded-xl bg-slate-100 dark:bg-slate-700 animate-pulse"
              style={{ height: `${30 + Math.random() * 40}%`, animationDelay: `${i * 80}ms` }}
            />
          </div>
        ))}
      </div>
    );
  }

  const max = Math.max(...safeData.map((d) => d.issued_count), 1);
  const hasData = safeData.some((d) => d.issued_count > 0);

  if (!hasData) {
    return (
      <div className="flex h-56 flex-col items-center justify-center gap-4 rounded-2xl border border-dashed border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/50">
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-slate-100 dark:bg-slate-800">
          <Icon name="file-text" className="h-6 w-6 text-slate-300 dark:text-slate-600" />
        </div>
        <div className="text-center">
          <p className="text-sm font-medium text-slate-500 dark:text-slate-400">No issuance data yet</p>
          <p className="mt-1 text-xs text-slate-400 dark:text-slate-500">Records will appear once you start issuing IDs.</p>
        </div>
        <Link
          to="/app/people"
          className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 px-4 py-2 text-xs font-semibold text-white shadow-lg shadow-emerald-900/30 transition-all hover:bg-emerald-500 hover:shadow-emerald-900/50"
        >
          <Icon name="plus" className="h-3.5 w-3.5" />
          Register first person
        </Link>
      </div>
    );
  }

  return (
    <div>
      {/* Range toggle */}
      <div className="mb-4 flex items-center gap-1 rounded-xl bg-slate-100 dark:bg-slate-900/60 p-1">
        {(["7d", "30d"] as const).map((r) => (
          <button
            key={r}
            onClick={() => setRange(r)}
            className={cn(
              "relative rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-all duration-200",
              range === r
                ? "bg-white dark:bg-emerald-600 text-slate-900 dark:text-white shadow-sm dark:shadow-emerald-900/30"
                : "text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
            )}
          >
            {r === "7d" ? "Last 7 Days" : "Last 30 Days"}
          </button>
        ))}
      </div>

      {/* Chart area */}
      <div className="relative">
        {/* Horizontal grid lines */}
        <div className="pointer-events-none absolute inset-0 flex flex-col justify-between py-2">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="border-t border-slate-100 dark:border-slate-700/40" />
          ))}
        </div>

        {/* Bars */}
        <div className="relative flex h-56 items-end gap-1.5 sm:gap-2 px-1">
          {safeData.map((d, i) => {
            const pct = Math.max((d.issued_count / max) * 100, d.issued_count > 0 ? 8 : 2);
            const isToday = i === safeData.length - 1;
            return (
              <div
                key={d.day}
                className="flex flex-1 flex-col items-center gap-2 group/bar"
                onMouseEnter={() => setHoveredBar(i)}
                onMouseLeave={() => setHoveredBar(null)}
              >
                {/* Tooltip */}
                <div className={cn(
                  "transition-all duration-150 pointer-events-none z-10 rounded-lg bg-slate-800 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-2.5 py-1.5 text-[10px] font-medium text-white shadow-xl whitespace-nowrap",
                  hoveredBar === i ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-1"
                )}>
                  {d.issued_count} issued
                </div>
                <div
                  className={cn(
                    "w-full rounded-xl transition-all duration-500 ease-[cubic-bezier(0.16,1,0.3,1)]",
                    d.issued_count > 0
                      ? isToday
                        ? "bg-gradient-to-t from-emerald-600 to-emerald-400 shadow-lg shadow-emerald-500/20 ring-2 ring-emerald-500/30"
                        : "bg-gradient-to-t from-emerald-700/90 to-emerald-500/70 hover:from-emerald-600 hover:to-emerald-400"
                      : "bg-slate-200 dark:bg-slate-700/60"
                  )}
                  style={{ height: `${pct}%`, transitionDelay: `${i * 60}ms` }}
                />
                <span className={cn(
                  "text-[10px] font-medium",
                  isToday ? "text-emerald-600 dark:text-emerald-400 font-bold" : "text-slate-400 dark:text-slate-500"
                )}>
                  {dayLabels[new Date(d.day).getDay()] ?? ""}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

/* ── Status Panel ─────────────────────────────────────────────── */

function StatusPanel({
  stats,
  loading,
}: {
  stats: DashboardStats | null;
  loading: boolean;
}) {
  const printersOnline = stats?.printers_online ?? 0;
  const printersTotal = stats?.printers_total ?? 0;
  const devicesOnline = stats?.online_devices ?? 0;

  return (
    <div className="space-y-3">
      {/* Printer Status */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-700/60 bg-slate-50 dark:bg-slate-900/60 p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-emerald-100 dark:bg-emerald-500/15 ring-1 ring-emerald-200 dark:ring-emerald-500/20">
              <Icon name="printer" className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
            </div>
            <span className="text-sm font-medium text-slate-700 dark:text-slate-200">Printers</span>
          </div>
          <StatusDot
            status={printersOnline > 0 ? "green" : printersTotal > 0 ? "amber" : "red"}
            pulse={printersOnline > 0}
          />
        </div>
        {loading ? (
          <div className="h-4 w-32 rounded bg-slate-200 dark:bg-slate-700 animate-pulse" />
        ) : (
          <>
            <div className="flex items-baseline gap-1.5 mb-2">
              <span className="text-xl font-bold tabular-nums text-slate-900 dark:text-white">{printersOnline}</span>
              <span className="text-sm text-slate-400 dark:text-slate-500">/ {printersTotal} online</span>
            </div>
            <div className="h-2 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-slate-700">
              <div
                className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-emerald-400 transition-all duration-700 ease-out"
                style={{ width: printersTotal > 0 ? `${(printersOnline / printersTotal) * 100}%` : "0%" }}
              />
            </div>
          </>
        )}
      </div>

      {/* Device Status */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-700/60 bg-slate-50 dark:bg-slate-900/60 p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-blue-100 dark:bg-blue-500/15 ring-1 ring-blue-200 dark:ring-blue-500/20">
              <Icon name="monitor" className="h-4 w-4 text-blue-600 dark:text-blue-400" />
            </div>
            <span className="text-sm font-medium text-slate-700 dark:text-slate-200">Workstations</span>
          </div>
          <StatusDot
            status={devicesOnline > 0 ? "green" : "amber"}
            pulse={devicesOnline > 0}
          />
        </div>
        {loading ? (
          <div className="h-4 w-20 rounded bg-slate-200 dark:bg-slate-700 animate-pulse" />
        ) : (
          <div className="flex items-baseline gap-1.5 mb-2">
            <span className="text-xl font-bold tabular-nums text-slate-900 dark:text-white">{devicesOnline}</span>
            <span className="text-sm text-slate-400 dark:text-slate-500">active (15 min)</span>
          </div>
        )}
        <div className="mt-2 flex items-center justify-between border-t border-slate-200 dark:border-slate-700/50 pt-3">
          <Link
            to="/app/sync"
            className="group flex items-center gap-1.5 text-xs font-semibold text-emerald-600 dark:text-emerald-400 transition-colors hover:text-emerald-700 dark:hover:text-emerald-300"
          >
            Sync & Conflicts
            <Icon
              name="chevron-right"
              className="h-3.5 w-3.5 transition-transform duration-200 group-hover:translate-x-0.5"
            />
          </Link>
          <Link
            to="/app/sync"
            className="text-xs font-medium text-slate-400 dark:text-slate-500 transition-colors hover:text-slate-600 dark:hover:text-slate-300"
          >
            View all
          </Link>
        </div>
      </div>
    </div>
  );
}

/* ── Activity Feed ────────────────────────────────────────────── */

function ActivityFeed({
  stats,
  loading,
}: {
  stats: DashboardStats | null;
  loading: boolean;
}) {
  const recent = Array.isArray(stats?.recent_issuances) ? stats!.recent_issuances : [];

  if (loading) {
    return (
      <div className="space-y-3 px-1">
        {[...Array(4)].map((_, i) => (
          <div
            key={i}
            className="flex items-center gap-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 p-3"
            style={{ animationDelay: `${i * 60}ms` }}
          >
            <div className="h-9 w-9 rounded-full bg-slate-200 dark:bg-slate-700 animate-pulse" />
            <div className="flex-1 space-y-2">
              <div className="h-3.5 w-32 rounded bg-slate-200 dark:bg-slate-700 animate-pulse" />
              <div className="h-2.5 w-20 rounded bg-slate-200 dark:bg-slate-700 animate-pulse" />
            </div>
            <div className="h-5 w-16 rounded-full bg-slate-200 dark:bg-slate-700 animate-pulse" />
          </div>
        ))}
      </div>
    );
  }

  if (recent.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center gap-4 rounded-2xl border border-dashed border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/50 py-12">
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-slate-100 dark:bg-slate-800">
          <Icon name="history" className="h-6 w-6 text-slate-300 dark:text-slate-600" />
        </div>
        <div className="text-center">
          <p className="text-sm font-medium text-slate-500 dark:text-slate-400">No recent activity</p>
          <p className="mt-1 text-xs text-slate-400 dark:text-slate-500">Issuance records will appear here as you process IDs.</p>
        </div>
        <Link
          to="/app/issuance"
          className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 px-4 py-2 text-xs font-semibold text-white shadow-lg shadow-emerald-900/30 transition-all hover:bg-emerald-500"
        >
          <Icon name="id-card" className="h-3.5 w-3.5" />
          Go to ID Issuance
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-1">
      {recent.map((r, idx) => (
        <div
          key={r.issuance_reference}
          className={cn(
            "flex items-center gap-3 px-1 py-3.5 transition-colors duration-150 hover:bg-slate-50 dark:hover:bg-slate-800/50 rounded-xl",
            "animate-fade-in"
          )}
          style={{ animationDelay: `${idx * 40}ms` }}
        >
          {/* Avatar */}
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-emerald-700 text-[11px] font-bold text-white shadow-sm">
            {(r.person_name ?? "U").charAt(0).toUpperCase()}
          </div>

          {/* Info */}
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <p className="truncate text-sm font-medium text-slate-800 dark:text-white">
                {r.person_name}
              </p>
              <span className="font-mono text-[10px] text-slate-400 dark:text-slate-500">
                {r.identification_number}
              </span>
            </div>
            <div className="mt-0.5 flex items-center gap-1.5">
              <span className="font-mono text-[11px] text-slate-400 dark:text-slate-500">
                {r.issuance_reference}
              </span>
              {r.issued_by_staff && (
                <>
                  <span className="text-slate-300 dark:text-slate-600">&middot;</span>
                  <span className="text-[11px] text-slate-400 dark:text-slate-500">
                    by {r.issued_by_staff}
                  </span>
                </>
              )}
            </div>
          </div>

          {/* Time & Status */}
          <div className="flex shrink-0 items-center gap-3">
            <span className="hidden text-[11px] text-slate-400 dark:text-slate-500 sm:block">
              {r.issued_at ? formatRelative(r.issued_at) : ""}
            </span>
            <StatusBadge status={r.status} />
          </div>
        </div>
      ))}
    </div>
  );
}

/* ── Main Dashboard ───────────────────────────────────────────── */

export function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { profile, online } = useAuth();

  useEffect(() => {
    if (!online) {
      setError("Live dashboard requires an active internet connection.");
      setLoading(false);
      return;
    }
    let cancelled = false;
    setLoading(true);
    fetchDashboardStats()
      .then((s) => {
        if (!cancelled) setStats(s);
      })
      .catch((err) => {
        if (!cancelled) setError(mapSupabaseError(err).userMessage);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => { cancelled = true; };
  }, [online]);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* ─── Header ──────────────────────────────────────────── */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
            Welcome back, {profile?.full_name?.split(" ")[0] ?? "Staff"}
          </h1>
          <p className="mt-0.5 text-sm text-slate-500 dark:text-slate-400">
            Meru District Council — ID Registry overview
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Link
            to="/app/id-card"
            className="inline-flex items-center gap-2 rounded-xl border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-800 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 shadow-sm transition-all hover:bg-slate-50 dark:hover:bg-slate-700 hover:shadow-md active:scale-95"
          >
            <Icon name="credit-card" className="h-4 w-4" />
            ID Designer
          </Link>
          <Link
            to="/app/id-card?new=true"
            className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-3.5 py-2 text-xs font-semibold text-white shadow-lg shadow-emerald-900/30 transition-all hover:bg-emerald-500 hover:shadow-emerald-900/50 active:scale-95"
          >
            <Icon name="plus" className="h-4 w-4" />
            Register Person
          </Link>
        </div>
      </div>

      {error ? (
        <div className="rounded-2xl border border-red-200 dark:border-red-900/50 bg-red-50 dark:bg-red-950/30 p-8">
          <ErrorState message={error} onRetry={() => window.location.reload()} />
        </div>
      ) : (
        <>
          {/* ─── KPI Cards ─────────────────────────────────────── */}
          <div className="grid grid-cols-2 gap-3 lg:gap-4 xl:grid-cols-4">
            <StatCard
              icon="users"
              label="Registered People"
              value={stats?.total_registered}
              trend={12}
              loading={loading}
              color="council"
              to="/app/people"
              delay={0}
            />
            <StatCard
              icon="id-card"
              label="IDs Issued"
              value={stats?.total_issued}
              trend={8}
              loading={loading}
              color="accent"
              to="/app/issuance?status=issued"
              delay={1}
            />
            <StatCard
              icon="clock"
              label="Pending / Printing"
              value={stats?.total_pending}
              loading={loading}
              color="amber"
              to="/app/issuance?status=pending"
              delay={2}
            />
            <StatCard
              icon="alert-triangle"
              label="Failed Prints"
              value={stats?.total_failed_prints}
              trend={stats?.total_failed_prints ? -5 : 0}
              loading={loading}
              color="danger"
              to="/app/issuance?status=failed"
              delay={3}
            />
          </div>

          {/* ─── Chart + Status ────────────────────────────────── */}
          <div className="grid gap-4 lg:grid-cols-3">
            {/* Chart Card */}
            <div className="lg:col-span-2 rounded-2xl border border-slate-200 dark:border-slate-700/60 bg-white dark:bg-slate-800/80 shadow-sm dark:shadow-xl overflow-hidden">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-700/50 px-5 py-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-100 dark:bg-emerald-500/15 ring-1 ring-emerald-200 dark:ring-emerald-500/20">
                    <Icon name="file-text" className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-slate-900 dark:text-white">Issuance Overview</h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">Today: {formatNumber(stats?.today_issued ?? 0)} issued</p>
                  </div>
                </div>
                <Link
                  to="/app/issuance"
                  className="inline-flex items-center gap-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 px-2.5 py-1 text-[11px] font-semibold text-slate-600 dark:text-slate-300 transition-all hover:bg-slate-100 dark:hover:bg-slate-700 hover:text-slate-900 dark:hover:text-white"
                >
                  View All
                  <Icon name="chevron-right" className="h-3 w-3" />
                </Link>
              </div>
              <div className="p-5">
                <IssuanceChart data={stats?.daily_last_7_days} loading={loading} />
              </div>
            </div>

            {/* Status Card */}
            <div className="rounded-2xl border border-slate-200 dark:border-slate-700/60 bg-white dark:bg-slate-800/80 shadow-sm dark:shadow-xl overflow-hidden">
              <div className="flex items-center gap-3 border-b border-slate-100 dark:border-slate-700/50 px-5 py-4">
                <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-blue-100 dark:bg-blue-500/15 ring-1 ring-blue-200 dark:ring-blue-500/20">
                  <Icon name="monitor" className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                </div>
                <div>
                  <h3 className="text-sm font-medium text-slate-900 dark:text-white">System Status</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">Equipment & network</p>
                </div>
              </div>
              <div className="p-5">
                <StatusPanel stats={stats} loading={loading} />
              </div>
            </div>
          </div>

          {/* ─── Recent Activity ──────────────────────────────── */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-700/60 bg-white dark:bg-slate-800/80 shadow-sm dark:shadow-xl overflow-hidden">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-700/50 px-5 py-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-100 dark:bg-emerald-500/15 ring-1 ring-emerald-200 dark:ring-emerald-500/20">
                    <Icon name="history" className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-slate-900 dark:text-white">Recent Activity</h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">Latest citizen registrations</p>
                  </div>
                </div>
                <Link
                  to="/app/issuance"
                  className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 px-3 py-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300 transition-all hover:bg-slate-100 dark:hover:bg-slate-700 hover:text-slate-900 dark:hover:text-white"
                >
                  View All
                  <Icon name="chevron-right" className="h-3.5 w-3.5" />
                </Link>
              </div>
              <div className="px-5 py-3">
                <ActivityFeed stats={stats} loading={loading} />
              </div>
            </div>


        </>
      )}
    </div>
  );
}
