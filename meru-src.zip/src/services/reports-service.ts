/**
 * Reports service — aggregates for authorized roles.
 * Uses the get_dashboard_stats RPC for dashboard and dedicated queries
 * for report pages (all paginated and filtered server-side).
 */

import { supabase } from "./supabase-client";
import { mapSupabaseError } from "./errors";
import type { IssuanceStatus } from "@/types";

export interface DashboardStats {
  total_registered: number;
  total_issued: number;
  total_pending: number;
  total_failed_prints: number;
  today_issued: number;
  online_devices: number;
  printers_online: number;
  printers_total: number;
  recent_issuances: {
    issuance_reference: string;
    issued_at: string | null;
    status: IssuanceStatus;
    person_name: string;
    identification_number: string;
    issued_by_staff: string | null;
  }[];
  daily_last_7_days: { day: string; issued_count: number }[];
}

export async function fetchDashboardStats(): Promise<DashboardStats> {
  const { data, error } = await supabase.rpc("get_dashboard_stats");
  if (error) throw mapSupabaseError(error);
  const raw = data as unknown as Record<string, unknown>;
  const toNum = (v: unknown): number => {
    const n = Number(v ?? 0);
    return Number.isFinite(n) ? n : 0;
  };
  // Normalize: the hosted function historically returned `issued` (not
  // `issued_count`) for the daily series, and cloud AI may return
  // numbers/scalars for array fields. Accept both spellings.
  const daily = Array.isArray(raw.daily_last_7_days)
    ? (raw.daily_last_7_days as Record<string, unknown>[])
        .filter((d): d is Record<string, unknown> => d !== null && typeof d === "object" && !Array.isArray(d))
        .map((d) => ({
          day: typeof d.day === "string" ? d.day : "",
          issued_count: toNum(d.issued_count ?? d.issued)
        }))
    : [];
  return {
    total_registered: toNum(raw.total_registered),
    total_issued: toNum(raw.total_issued),
    total_pending: toNum(raw.total_pending),
    total_failed_prints: toNum(raw.total_failed_prints),
    today_issued: toNum(raw.today_issued),
    online_devices: toNum(raw.online_devices),
    printers_online: toNum(raw.printers_online),
    printers_total: toNum(raw.printers_total),
    recent_issuances: Array.isArray(raw.recent_issuances) ? (raw.recent_issuances as DashboardStats["recent_issuances"]) : [],
    daily_last_7_days: daily
  };
}

export interface StaffActivityRow {
  staff_number: string;
  full_name: string;
  role: string;
  issuances: number;
}

export async function fetchStaffActivity(
  from: string,
  to: string
): Promise<StaffActivityRow[]> {
  const { data, error } = await supabase
    .from("issuance_records")
    .select("issued_by_staff_number, profiles:issued_by(full_name, role)")
    .gte("created_at", from)
    .lte("created_at", to)
    .not("issued_by_staff_number", "is", null);

  if (error) throw mapSupabaseError(error);

  const grouped = new Map<string, StaffActivityRow>();
  for (const row of (data ?? []) as unknown as {
    issued_by_staff_number: string;
    profiles: { full_name: string; role: string } | null;
  }[]) {
    const key = row.issued_by_staff_number;
    const existing = grouped.get(key);
    if (existing) {
      existing.issuances++;
    } else {
      grouped.set(key, {
        staff_number: key,
        full_name: row.profiles?.full_name ?? "Unknown",
        role: row.profiles?.role ?? "—",
        issuances: 1
      });
    }
  }
  return Array.from(grouped.values()).sort((a, b) => b.issuances - a.issuances);
}

