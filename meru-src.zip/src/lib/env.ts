/**
 * Environment configuration with strict validation.
 * Only PUBLIC variables intended for the browser are read here.
 * Server-only secrets must NEVER be placed in VITE_* variables.
 */

function requireEnv(name: string): string {
  const value = import.meta.env[name];
  if (typeof value !== "string" || value.trim() === "") {
    throw new Error(
      `Missing required environment variable: ${name}. ` +
        `Copy .env.example to .env.local and configure it.`
    );
  }
  return value.trim();
}

function optionalEnv(name: string, fallback: string): string {
  const value = import.meta.env[name];
  return typeof value === "string" && value.trim() !== ""
    ? value.trim()
    : fallback;
}

const rawUrl = requireEnv("VITE_SUPABASE_URL");
const rawAnonKey = requireEnv("VITE_SUPABASE_ANON_KEY");

let parsedUrl: URL;
try {
  parsedUrl = new URL(rawUrl);
} catch {
  throw new Error(
    `VITE_SUPABASE_URL is not a valid absolute URL: "${rawUrl}". ` +
      `It should look like https://<project-ref>.supabase.co`
  );
}

if (!/^https?:$/.test(parsedUrl.protocol)) {
  throw new Error(
    `VITE_SUPABASE_URL must use http(s). Received protocol: ${parsedUrl.protocol}`
  );
}

/** True when .env.local still contains placeholder values — Supabase is not configured. */
export const isSupabasePlaceholder =
  rawUrl.includes("placeholder") ||
  rawUrl.includes("YOUR-PROJECT-REF") ||
  rawAnonKey.includes("placeholder") ||
  rawAnonKey.includes("your-anon") ||
  rawAnonKey.length < 20;

export const env = {
  supabaseUrl: rawUrl,
  supabaseAnonKey: rawAnonKey,
  appName: optionalEnv("VITE_APP_NAME", "Meru District Council — ID Registry"),
  /** Maximum offline session duration in hours before forced re-auth. */
  maxOfflineHours: Number(optionalEnv("VITE_MAX_OFFLINE_HOURS", "24")),
  /** Local print agent base URL. */
  printAgentUrl: optionalEnv("VITE_PRINT_AGENT_URL", "http://localhost:8377"),
  /** Inactivity auto-lock timeout in minutes (0 = disabled). */
  idleLockMinutes: Number(optionalEnv("VITE_IDLE_LOCK_MINUTES", "30"))
} as const;

export type Env = typeof env;
