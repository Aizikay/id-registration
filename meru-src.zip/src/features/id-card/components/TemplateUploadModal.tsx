/**
 * Template Upload Modal — Drag-and-drop file upload for ID card templates.
 */

import { useState, useRef, useCallback } from "react";
import { Modal } from "@/components/ui/modal";
import { Button } from "@/components/ui/button";
import { Icon } from "@/components/icons/icon";
import {
  ACCEPT_MIME,
  detectFileType,
  validateFile,
  createCustomTemplate,
  type CustomTemplate,
} from "../template-manager";

interface Props {
  open: boolean;
  onClose: () => void;
  onCreated: (template: CustomTemplate) => void;
  creatorName: string;
}

export function TemplateUploadModal({
  open,
  onClose,
  onCreated,
  creatorName,
}: Props) {
  const [dragOver, setDragOver] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [templateName, setTemplateName] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const reset = () => {
    setSelectedFile(null);
    setPreviewUrl(null);
    setTemplateName("");
    setError(null);
    setLoading(false);
  };

  const handleClose = () => {
    reset();
    onClose();
  };

  const handleFile = useCallback(async (file: File) => {
    setError(null);

    const validation = validateFile(file);
    if (!validation.valid) {
      setError(validation.error || "Invalid file");
      return;
    }

    setSelectedFile(file);
    setTemplateName(
      file.name.replace(/\.[^/.]+$/, "").replace(/[-_]/g, " ")
    );

    try {
      const fileType = detectFileType(file);
      if (fileType === "image") {
        const url = URL.createObjectURL(file);
        setPreviewUrl(url);
      } else {
        setPreviewUrl(null);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Invalid file");
      setSelectedFile(null);
    }
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDragOver(false);
      const file = e.dataTransfer.files[0];
      if (file) void handleFile(file);
    },
    [handleFile]
  );

  const handleFileInput = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) void handleFile(file);
      e.target.value = "";
    },
    [handleFile]
  );

  const handleUpload = async () => {
    if (!selectedFile || !templateName.trim()) return;
    setLoading(true);
    setError(null);

    try {
      const template = await createCustomTemplate(selectedFile, creatorName);
      template.name = templateName.trim();
      const { updateTemplate } = await import("../template-manager");
      await updateTemplate(template.id, { name: templateName.trim() });

      onCreated(template);
      handleClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to create template");
    } finally {
      setLoading(false);
    }
  };

  const fileType = selectedFile ? detectFileType(selectedFile) : null;
  const fileTypeLabel =
    fileType === "pdf"
      ? "PDF Document"
      : fileType === "ai"
        ? "Adobe Illustrator"
        : fileType === "image"
          ? "Image"
          : "Unknown";

  return (
    <Modal open={open} onClose={handleClose} title="Upload Template" size="lg">
      <div className="space-y-5">
        {!selectedFile && (
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`
              flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed p-10
              transition-all duration-200
              ${
                dragOver
                  ? "border-council-500 bg-council-50/50 scale-[1.02]"
                  : "border-surface-300 bg-surface-50/50 hover:border-council-400 hover:bg-council-50/30"
              }
            `}
          >
            <div className="mb-4 rounded-2xl bg-council-100/80 p-4">
              <Icon name="upload" className="h-8 w-8 text-council-600" />
            </div>
            <p className="text-base font-medium text-surface-700">
              Drop your template file here
            </p>
            <p className="mt-1 text-sm text-surface-400">or click to browse</p>
            <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
              {["PDF", "AI", "JPG", "PNG", "WebP"].map((fmt) => (
                <span
                  key={fmt}
                  className="rounded-full border border-surface-200 bg-white px-2.5 py-1 text-[11px] font-medium text-surface-500"
                >
                  {fmt}
                </span>
              ))}
            </div>
          </div>
        )}

        <input
          ref={fileInputRef}
          type="file"
          accept={ACCEPT_MIME}
          className="hidden"
          onChange={handleFileInput}
        />

        {selectedFile && (
          <div className="space-y-4">
            <div className="flex items-start gap-4 rounded-xl border border-surface-200/60 bg-surface-50/80 p-4 backdrop-blur-sm">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-council-100 text-council-600">
                <Icon
                  name={fileType === "image" ? "image" : "file-text"}
                  className="h-6 w-6"
                />
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-surface-800">
                  {selectedFile.name}
                </p>
                <p className="text-xs text-surface-400">
                  {fileTypeLabel} ·{" "}
                  {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                </p>
              </div>
              <button
                onClick={() => {
                  setSelectedFile(null);
                  setPreviewUrl(null);
                  setTemplateName("");
                  setError(null);
                }}
                className="rounded-lg p-1.5 text-surface-400 hover:bg-surface-100 hover:text-surface-600"
              >
                <Icon name="x" className="h-4 w-4" />
              </button>
            </div>

            {previewUrl && (
              <div className="flex justify-center rounded-xl border border-surface-200/60 bg-white p-4">
                <img
                  src={previewUrl}
                  alt="Template preview"
                  className="max-h-64 rounded-lg object-contain shadow-sm"
                />
              </div>
            )}

            <div>
              <label className="mb-1.5 block text-[13px] font-medium text-surface-600">
                Template Name
              </label>
              <input
                type="text"
                value={templateName}
                onChange={(e) => setTemplateName(e.target.value)}
                placeholder="e.g., Employee ID Card"
                className="w-full rounded-xl border border-surface-200 bg-white px-4 py-2.5 text-sm text-surface-800 outline-none transition-colors focus:border-council-500 focus:ring-2 focus:ring-council-500/20"
              />
            </div>

            <div className="rounded-xl border border-council-100/60 bg-council-50/50 px-4 py-3 text-xs text-council-700">
              <p className="font-medium">What happens next?</p>
              <ul className="mt-1 space-y-1 text-council-600">
                <li>• The uploaded file becomes your template background</li>
                <li>• You can add editable text fields (name, position, etc.)</li>
                <li>• Add photo and signature areas</li>
                <li>• Position and style each element on the template</li>
                {fileType === "ai" && (
                  <li className="font-medium">
                    • AI files are treated as PDF — modern Illustrator files are
                    compatible
                  </li>
                )}
              </ul>
            </div>

            {error && (
              <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-xs text-red-700">
                {error}
              </div>
            )}
          </div>
        )}
      </div>

      <div className="mt-6 flex justify-end gap-2.5">
        <Button variant="outline" onClick={handleClose}>
          Cancel
        </Button>
        <Button
          onClick={handleUpload}
          disabled={!selectedFile || !templateName.trim() || loading}
          loading={loading}
          icon={<Icon name="upload" className="h-4 w-4" />}
        >
          Upload Template
        </Button>
      </div>
    </Modal>
  );
}
