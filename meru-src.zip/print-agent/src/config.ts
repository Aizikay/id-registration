import { randomUUID } from "node:crypto";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// When compiled, __dirname === print-agent/dist; in dev (esm loader) it's print-agent/src.
// State lives at print-agent/state.json in both cases.
export const STATE_PATH = path.resolve(__dirname, "..", "state.json");
export const LOG_DIR = path.resolve(__dirname, "..", "logs");

export const AGENT_VERSION = "1.0.0";
export const HOST = process.env.PRINT_AGENT_HOST?.trim() || "127.0.0.1";
export const PORT = Number(process.env.PRINT_AGENT_PORT?.trim() || "8377");
export const DRY_RUN =
  (process.env.PRINT_AGENT_DRY_RUN?.trim().toLowerCase() ?? "") === "true" ||
  (process.env.PRINT_DRY_RUN?.trim().toLowerCase() ?? "") === "true";

/**
 * Allowed request Origins. The agent refuses requests whose Origin header is
 * present but not on this allowlist — preventing arbitrary websites from
 * driving the printer.
 *
 * Defaults allow:
 *  - Any localhost / 127.0.0.1 origin (any port) for local development
 *  - Any *.vercel.app deployment (covers production)
 * Additional origins may be supplied via ALLOWED_ORIGINS env (comma-separated,
 * exact match). Example: ALLOWED_ORIGINS="https://meru-id.example.go.tz,https://id.meru.go.tz"
 */
const extraAllowedOrigins = (process.env.ALLOWED_ORIGINS ?? "")
  .split(",")
  .map((s) => s.trim())
  .filter(Boolean);

export function isOriginAllowed(origin: string): boolean {
  if (extraAllowedOrigins.includes(origin)) return true;
  let url: URL;
  try {
    url = new URL(origin);
  } catch {
    return false;
  }
  const host = url.hostname.toLowerCase();
  if (host === "localhost" || host === "127.0.0.1" || host === "::1") return true;
  if (host.endsWith(".vercel.app")) return true;
  if (host.endsWith(".netlify.app")) return true;
  // Allow any origin that was explicitly listed via env.
  return false;
}

export function getPersistedDeviceId(): string {
  // Try to reuse a device id from state.json; otherwise generate WS-… and persist.
  try {
    if (existsSync(STATE_PATH)) {
      const raw = readFileSync(STATE_PATH, "utf-8");
      const parsed = JSON.parse(raw) as { deviceId?: string };
      if (typeof parsed.deviceId === "string" && /^WS-[0-9a-f]{16}$/.test(parsed.deviceId)) {
        return parsed.deviceId;
      }
    }
  } catch {
    // fall through to generation
  }
  const fresh = `WS-${randomUUID().replace(/-/g, "").slice(0, 16)}`;
  try {
    let existing: Record<string, unknown> = {};
    if (existsSync(STATE_PATH)) {
      try {
        existing = JSON.parse(readFileSync(STATE_PATH, "utf-8")) as Record<string, unknown>;
      } catch {
        existing = {};
      }
    }
    writeFileSync(STATE_PATH, JSON.stringify({ ...existing, deviceId: fresh }, null, 2), "utf-8");
  } catch {
    // best-effort only
  }
  return fresh;
}

export const DEVICE_ID = getPersistedDeviceId();
