import http from "node:http";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { mkdtempSync, writeFileSync, unlinkSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { AGENT_VERSION, DEVICE_ID, DRY_RUN, HOST, PORT, isOriginAllowed } from "./config.js";
import { discoverPrinters } from "./printers.js";
import { JobStore } from "./jobs.js";
import { logger } from "./logger.js";
import { renderIdCardHtml, renderDualPageIdCardHtml, renderTestPageHtml } from "./templates.js";

const execFileAsync = promisify(execFile);
const store = new JobStore(DEVICE_ID);

function json(res: http.ServerResponse, status: number, body: unknown, origin?: string): void {
  const headers: Record<string, string> = {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store"
  };
  if (origin && isOriginAllowed(origin)) {
    headers["Access-Control-Allow-Origin"] = origin;
    headers["Vary"] = "Origin";
    headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS";
    headers["Access-Control-Allow-Headers"] = "Content-Type";
  }
  res.writeHead(status, headers);
  res.end(JSON.stringify(body));
}

function corsPreflight(req: http.IncomingMessage, res: http.ServerResponse): boolean {
  if (req.method !== "OPTIONS") return false;
  const origin = req.headers.origin as string | undefined;
  const headers: Record<string, string> = {
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Max-Age": "86400"
  };
  if (origin && isOriginAllowed(origin)) {
    headers["Access-Control-Allow-Origin"] = origin;
    headers["Vary"] = "Origin";
  } else if (!origin) {
    // Non-browser clients (curl) — allow.
    headers["Access-Control-Allow-Origin"] = "*";
  }
  res.writeHead(204, headers);
  res.end();
  return true;
}

function requireAllowedOrigin(req: http.IncomingMessage, res: http.ServerResponse): boolean {
  const origin = req.headers.origin as string | undefined;
  if (!origin) return true; // curl / same-origin without Origin header — allow (agent is localhost-only anyway)
  if (isOriginAllowed(origin)) return true;
  logger.warn("Blocked request with disallowed Origin", { origin, url: req.url });
  json(res, 403, { error: "origin_not_allowed", detail: `Origin ${origin} is not on the allowlist` }, origin);
  return false;
}

async function readJson(req: http.IncomingMessage): Promise<Record<string, unknown>> {
  const chunks: Buffer[] = [];
  for await (const chunk of req) chunks.push(chunk as Buffer);
  const raw = Buffer.concat(chunks).toString("utf-8").trim();
  if (!raw) return {};
  try {
    return JSON.parse(raw) as Record<string, unknown>;
  } catch {
    throw Object.assign(new Error("invalid_json"), { statusCode: 400 });
  }
}

async function attemptWindowsPrint(html: string, printerName?: string): Promise<{ ok: boolean; error?: string }> {
  if (DRY_RUN) {
    logger.info("[DRY_RUN] Skipping real print", { printerName });
    await new Promise((r) => setTimeout(r, 400));
    return { ok: true };
  }

  const dir = mkdtempSync(path.join(os.tmpdir(), "meru-print-"));
  const file = path.join(dir, `meru-${Date.now()}.html`);
  writeFileSync(file, html, "utf-8");

  try {
    // Strategy 1: PowerShell Start-Process -Verb Print (works for HTML when a handler exists).
    // We try with the specific printer name if provided via -ArgumentList pattern.
    // Fallback: rundll32.
    const psScript = printerName
      ? `Start-Process -FilePath '${file.replace(/'/g, "''")}' -Verb Print -WindowStyle Hidden; Start-Sleep -Seconds 2`
      : `Start-Process -FilePath '${file.replace(/'/g, "''")}' -Verb Print -WindowStyle Hidden; Start-Sleep -Seconds 2`;

    try {
      await execFileAsync("powershell.exe", ["-NoProfile", "-Command", psScript], {
        timeout: 15000,
        windowsHide: true
      });
      logger.info("Print dispatched via PowerShell Start-Process", { file, printerName });
      return { ok: true };
    } catch (psErr) {
      logger.warn("PowerShell print failed, trying rundll32 fallback", { error: String(psErr) });
      // Fallback: mshtml print
      try {
        await execFileAsync("rundll32.exe", ["mshtml.dll,PrintHTML", file], {
          timeout: 15000,
          windowsHide: true
        });
        logger.info("Print dispatched via rundll32 mshtml", { file });
        return { ok: true };
      } catch (fallbackErr) {
        // Last resort: 'print' command (raw) — may not work for HTML but we try.
        try {
          const target = printerName ? `\\\\.\\${printerName}` : file;
          await execFileAsync("cmd.exe", ["/c", `print /D:"${target}" "${file}"`], {
            timeout: 10000,
            windowsHide: true
          });
          return { ok: true };
        } catch {
          throw fallbackErr;
        }
      }
    }
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    logger.error("Windows print invocation failed", { message, printerName });
    // For demo/offline resilience, we still mark the job as completed in dry conditions.
    // In strict mode, this would be a failure. We treat it as a soft failure: the
    // issuance record is already committed server-side; printing can be retried.
    return { ok: false, error: message.slice(0, 500) };
  } finally {
    try {
      unlinkSync(file);
    } catch {
      // ignore
    }
    try {
      // rmdir temp dir if empty
      const { rmdirSync } = await import("node:fs");
      rmdirSync(dir);
    } catch {
      // ignore
    }
  }
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url ?? "/", `http://${HOST}:${PORT}`);
  const pathname = url.pathname;
  const method = (req.method ?? "GET").toUpperCase();
  const origin = req.headers.origin as string | undefined;

  // CORS preflight
  if (corsPreflight(req, res)) return;

  // Enforce Origin allowlist for state-changing and sensitive reads
  const needsOriginCheck =
    pathname === "/print" || pathname === "/test" || pathname.startsWith("/jobs/") || pathname === "/status";
  if (needsOriginCheck && !requireAllowedOrigin(req, res)) return;

  try {
    // Health / root
    if ((pathname === "/" || pathname === "/health") && method === "GET") {
      json(res, 200, { ok: true, service: "meru-print-agent", version: AGENT_VERSION, device_id: DEVICE_ID }, origin);
      return;
    }

    // Status — printer discovery
    if (pathname === "/status" && method === "GET") {
      const printers = await discoverPrinters();
      json(
        res,
        200,
        { ok: true, agent_version: AGENT_VERSION, device_id: DEVICE_ID, printers },
        origin
      );
      return;
    }

    if (pathname === "/printers" && method === "GET") {
      const printers = await discoverPrinters();
      json(res, 200, { ok: true, printers }, origin);
      return;
    }

    // Test print
    if (pathname === "/test" && method === "POST") {
      const body = await readJson(req);
      const printerId = typeof body.printer_id === "string" ? body.printer_id.trim() : "";
      if (!printerId) {
        json(res, 400, { error: "missing_printer_id" }, origin);
        return;
      }
      const requestedBy = typeof body.requested_by === "string" ? body.requested_by : null;
      const printers = await discoverPrinters();
      const printer = printers.find((p) => p.id === printerId || p.name === printerId);
      if (!printer) {
        json(res, 404, { error: "printer_not_found", detail: `No printer matches id ${printerId}` }, origin);
        return;
      }
      const job = store.createTestJob(printer.id, requestedBy);
      store.update(job.job_id, { status: "printing" });
      const html = renderTestPageHtml(printer.name);
      const result = await attemptWindowsPrint(html, printer.name);
      const final = store.update(job.job_id, {
        status: result.ok ? "completed" : "failed",
        error_message: result.error,
        pages_printed: result.ok ? 1 : 0
      })!;
      json(
        res,
        200,
        {
          ok: result.ok,
          job_id: final.job_id,
          status: final.status,
          error_message: final.error_message
        },
        origin
      );
      return;
    }

    // Main print endpoint
    if (pathname === "/print" && method === "POST") {
      const body = await readJson(req);
      const required = [
        "document_reference",
        "issuance_reference",
        "idempotency_key",
        "printer_id",
        "person_name",
        "identification_number"
      ] as const;
      for (const key of required) {
        const v = body[key];
        if (typeof v !== "string" || v.trim() === "") {
          json(res, 400, { error: "missing_field", detail: `Field ${key} is required` }, origin);
          return;
        }
      }
      const docRef = (body.document_reference as string).trim();
      const issuanceRef = (body.issuance_reference as string).trim();
      const idemKey = (body.idempotency_key as string).trim();
      const printerId = (body.printer_id as string).trim();
      const personName = (body.person_name as string).trim();
      const idNumber = (body.identification_number as string).trim();
      const issuedBy = typeof body.issued_by_staff_number === "string" ? body.issued_by_staff_number : null;
      const issuedAt = typeof body.issued_at_iso === "string" ? body.issued_at_iso : new Date().toISOString();
      const councilSw =
        typeof body.council_name_sw === "string" ? body.council_name_sw : "HALMASHAURI YA WILAYA YA MERU";
      const councilEn =
        typeof body.council_name_en === "string" ? body.council_name_en : "MERU DISTRICT COUNCIL";
      const requestedBy = typeof body.requested_by === "string" ? body.requested_by : null;

      // Idempotent replay — return existing job without re-printing.
      const existing = store.getByIdempotency(idemKey);
      if (existing) {
        logger.info("Idempotent replay — returning existing job", { idemKey, job_id: existing.job_id });
        json(
          res,
          200,
          {
            ok: existing.status === "completed",
            job_id: existing.job_id,
            status: existing.status,
            error_message: existing.error_message,
            pages_printed: existing.pages_printed
          },
          origin
        );
        return;
      }

      const printers = await discoverPrinters();
      const printer = printers.find((p) => p.id === printerId || p.name === printerId);
      if (!printer) {
        json(res, 404, { error: "printer_not_found", detail: `No printer matches id ${printerId}` }, origin);
        return;
      }

      const { job } = store.createOrReplay({
        idempotency_key: idemKey,
        document_reference: docRef,
        issuance_reference: issuanceRef,
        printer_id: printer.id,
        requested_by: requestedBy,
        person_name: personName,
        identification_number: idNumber
      });

      store.update(job.job_id, { status: "printing" });
      logger.info("Dispatching print job", {
        job_id: job.job_id,
        issuanceRef,
        printer: printer.name,
        person: personName
      });

      // Support dual-page (front + back) or single-page (front only)
      const frontImageSrc = typeof body.front_image_src === "string" ? body.front_image_src : null;
      const backImageSrc = typeof body.back_image_src === "string" ? body.back_image_src : null;
      const frontOverlays = typeof body.front_overlays === "object" && body.front_overlays !== null
        ? body.front_overlays as Record<string, string>
        : undefined;

      const html = (frontImageSrc && backImageSrc)
        ? renderDualPageIdCardHtml({
            personName,
            identificationNumber: idNumber,
            issuedByStaffNumber: issuedBy,
            issuedAtIso: issuedAt,
            issuanceReference: issuanceRef,
            documentReference: docRef,
            councilNameSw: councilSw,
            councilNameEn: councilEn,
            frontImageSrc,
            backImageSrc,
            frontOverlays: frontOverlays ? {
              chekiNamba: frontOverlays.chekiNamba,
              jina: frontOverlays.jina,
              cheo: frontOverlays.cheo,
              photoSrc: frontOverlays.photoSrc,
              signatureSrc: frontOverlays.signatureSrc,
            } : undefined,
          })
        : renderIdCardHtml({
            personName,
            identificationNumber: idNumber,
            issuedByStaffNumber: issuedBy,
            issuedAtIso: issuedAt,
            issuanceReference: issuanceRef,
            documentReference: docRef,
            councilNameSw: councilSw,
            councilNameEn: councilEn
          });

      const printed = await attemptWindowsPrint(html, printer.name);
      const final = store.update(job.job_id, {
        status: printed.ok ? "completed" : "failed",
        error_message: printed.error,
        pages_printed: printed.ok ? 1 : 0
      })!;

      json(
        res,
        printed.ok ? 200 : 502,
        {
          ok: printed.ok,
          job_id: final.job_id,
          status: final.status,
          error_message: final.error_message,
          pages_printed: final.pages_printed
        },
        origin
      );
      return;
    }

    // Job status polling
    if (pathname.startsWith("/jobs/") && method === "GET") {
      const jobId = decodeURIComponent(pathname.slice("/jobs/".length));
      if (!jobId) {
        json(res, 400, { error: "missing_job_id" }, origin);
        return;
      }
      const job = store.getById(jobId);
      if (!job) {
        json(res, 404, { error: "job_not_found" }, origin);
        return;
      }
      json(
        res,
        200,
        {
          ok: job.status === "completed",
          job_id: job.job_id,
          status: job.status,
          error_message: job.error_message,
          pages_printed: job.pages_printed
        },
        origin
      );
      return;
    }

    json(res, 404, { error: "not_found", detail: `${method} ${pathname} not found` }, origin);
  } catch (err) {
    const e = err as Error & { statusCode?: number };
    const status = e.statusCode ?? 500;
    const code = e.message === "invalid_json" ? "invalid_json" : "internal_error";
    logger.error("Request failed", { url: req.url, error: e.message });
    json(res, status, { error: code, detail: e.message }, origin);
  }
});

server.on("error", (err) => {
  logger.error("Server error", { error: String(err) });
  process.exit(1);
});

server.listen(PORT, HOST, () => {
  logger.info(`Meru Print Agent v${AGENT_VERSION} listening on http://${HOST}:${PORT}`);
  logger.info(`Device ${DEVICE_ID} — dryRun=${String(DRY_RUN)}`);
  logger.info("Allowed origins: localhost/127.0.0.1 + *.vercel.app" + (process.env.ALLOWED_ORIGINS ? ` + ${process.env.ALLOWED_ORIGINS}` : ""));
  logger.info("Endpoints: GET /status, GET /printers, POST /test, POST /print, GET /jobs/:id");
});

// Graceful shutdown
for (const sig of ["SIGINT", "SIGTERM"] as const) {
  process.on(sig, () => {
    logger.info(`Received ${sig} — shutting down`);
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(0), 3000).unref();
  });
}
