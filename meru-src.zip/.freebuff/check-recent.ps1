$log = 'C:\Users\hp\Pictures\ID Registration & Issuance Management System.(MERU DC) - Copy\.freebuff\preview-185ab75d-b7ac-4e90-8d29-bbede45499ca.log'
$lines = Get-Content $log -ErrorAction SilentlyContinue
$recent = $lines | Select-Object -Last 10
$recent | ForEach-Object { Write-Output $_ }
