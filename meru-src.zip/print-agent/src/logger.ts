export type LogLevel = "info" | "warn" | "error" | "debug";

function ts(): string {
  return new Date().toISOString();
}

function line(level: LogLevel, msg: string, extra?: unknown): void {
  const prefix = `[${ts()}] [${level.toUpperCase()}]`;
  if (extra !== undefined) {
    // Avoid noisy circular output — stringify once.
    let detail = "";
    try {
      detail = typeof extra === "string" ? extra : JSON.stringify(extra);
    } catch {
      detail = String(extra);
    }
    // eslint-disable-next-line no-console
    console.log(`${prefix} ${msg} ${detail}`);
  } else {
    // eslint-disable-next-line no-console
    console.log(`${prefix} ${msg}`);
  }
}

export const logger = {
  info: (msg: string, extra?: unknown) => line("info", msg, extra),
  warn: (msg: string, extra?: unknown) => line("warn", msg, extra),
  error: (msg: string, extra?: unknown) => line("error", msg, extra),
  debug: (msg: string, extra?: unknown) => line("debug", msg, extra)
};
