Set-Location 'C:\Users\hp\Pictures\ID Registration & Issuance Management System.(MERU DC) - Copy'
& "C:\node.exe" "node_modules\vite\bin\vite.js" --port 5174 --host
