import { useCallback, useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Icon } from "@/components/icons/icon";
import { Modal, ConfirmDialog } from "@/components/ui/modal";
import { useToast } from "@/components/ui/toast";
import { useAuth } from "@/features/auth/auth-context";
import { cn } from "@/lib/cn";
import { mapSupabaseError } from "@/services/errors";
import {
  listDepartments,
  getPeopleInDepartment,
  createDepartment,
  deleteDepartment,
  assignPersonToDepartment,
  type DepartmentWithCount,
} from "@/services/departments-service";

/* ─── Types ──────────────────────────────────────────────────── */

type PageTab = "all" | "unassigned" | "recent";

interface PersonRow {
  id: string;
  identification_number: string;
  full_name: string;
  position: string | null;
  department: string | null;
  created_at: string;
  synced?: boolean;
}

/* ─── Helpers ────────────────────────────────────────────────── */

const CARD_COLORS = [
  "from-emerald-500 to-teal-600",
  "from-blue-500 to-indigo-600",
  "from-purple-500 to-fuchsia-600",
  "from-amber-500 to-orange-600",
  "from-rose-500 to-pink-600",
  "from-cyan-500 to-sky-600",
  "from-lime-500 to-green-600",
  "from-violet-500 to-purple-600",
];

function departmentColor(id: string): string {
  let hash = 0;
  for (let i = 0; i < id.length; i++) {
    hash = id.charCodeAt(i) + ((hash << 5) - hash);
  }
  return CARD_COLORS[Math.abs(hash) % CARD_COLORS.length]!;
}

function initials(name: string): string {
  return name
    .split(/\s+/)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase() ?? "")
    .join("");
}

function initialsColor(name: string): string {
  const colors = [
    "from-emerald-500 to-emerald-700",
    "from-teal-500 to-teal-700",
    "from-blue-500 to-blue-700",
    "from-purple-500 to-purple-700",
    "from-amber-500 to-amber-700",
    "from-rose-500 to-rose-700",
  ];
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }
  return colors[Math.abs(hash) % colors.length]!;
}

function departmentLabel(
  deptId: string | null,
  departments: { id: string; name_sw: string }[] = []
): string {
  if (!deptId) return "Unassigned";
  return departments.find((d) => d.id === deptId)?.name_sw ?? deptId;
}

/* ─── Main Component ─────────────────────────────────────────── */

export function DepartmentsPage() {
  const { online, can, profile } = useAuth();
  const toast = useToast();

  const isAdmin = profile?.role === "admin";

  // Departments list
  const [departments, setDepartments] = useState<DepartmentWithCount[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [refreshNonce, setRefreshNonce] = useState(0);

  // Register department modal
  const [registerOpen, setRegisterOpen] = useState(false);
  const [newNameSw, setNewNameSw] = useState("");
  const [newNameEn, setNewNameEn] = useState("");
  const [creating, setCreating] = useState(false);

  // Selected department → member registry
  const [selectedDept, setSelectedDept] = useState<string | null>(null);
  const [members, setMembers] = useState<PersonRow[]>([]);
  const [membersLoading, setMembersLoading] = useState(false);
  const [membersError, setMembersError] = useState<string | null>(null);

  // Swap / remove modals
  const [swapTarget, setSwapTarget] = useState<PersonRow | null>(null);
  const [swapTo, setSwapTo] = useState("");
  const [swapping, setSwapping] = useState(false);
  const [removeTarget, setRemoveTarget] = useState<PersonRow | null>(null);
  const [removing, setRemoving] = useState(false);
  const [confirmDeleteDept, setConfirmDeleteDept] =
    useState<DepartmentWithCount | null>(null);
  const [deletingDept, setDeletingDept] = useState(false);

  // Search & filters
  const [search, setSearch] = useState("");
  const [activeTab, setActiveTab] = useState<PageTab>("all");

  const canManage = isAdmin && online;

  /* ─── Load departments ─────────────────────────────────────── */

  const loadDepartments = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const rows = await listDepartments();
      setDepartments(rows);
    } catch (err) {
      setError(mapSupabaseError(err).userMessage);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadDepartments();
  }, [loadDepartments, refreshNonce]);

  /* ─── Load members of selected department ──────────────────── */

  useEffect(() => {
    if (!selectedDept) {
      setMembers([]);
      return;
    }
    let cancelled = false;
    setMembersLoading(true);
    setMembersError(null);
    (async () => {
      try {
        const result = await getPeopleInDepartment(selectedDept, 0, 100);
        if (!cancelled) {
          setMembers(result.rows as unknown as PersonRow[]);
        }
      } catch (err) {
        if (!cancelled) setMembersError(mapSupabaseError(err).userMessage);
      } finally {
        if (!cancelled) setMembersLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [selectedDept, refreshNonce]);

  /* ─── Derived ──────────────────────────────────────────────── */

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    let rows = departments;
    if (term) {
      rows = rows.filter(
        (d) =>
          d.name_sw.toLowerCase().includes(term) ||
          d.name_en.toLowerCase().includes(term)
      );
    }
    return rows;
  }, [departments, search]);

  /* ─── Actions ──────────────────────────────────────────────── */

  const handleCreate = async () => {
    if (!newNameSw.trim()) {
      toast.warning("Required", "Enter at least the department name (Kiswahili).");
      return;
    }
    const slug =
      newNameSw
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-+|-+$/g, "")
        .slice(0, 60) || "dept";
    setCreating(true);
    try {
      await createDepartment({
        id: slug,
        name_sw: newNameSw,
        name_en: newNameEn.trim() || newNameSw.trim(),
      });
      toast.success(
        "Department registered",
        `${newNameSw.trim()} is now available for ID allocation.`
      );
      setNewNameSw("");
      setNewNameEn("");
      setRegisterOpen(false);
      setRefreshNonce((n) => n + 1);
    } catch (err) {
      toast.error("Could not register department", mapSupabaseError(err).userMessage);
    } finally {
      setCreating(false);
    }
  };

  const handleSwap = async () => {
    if (!swapTarget || !swapTo) return;
    setSwapping(true);
    try {
      await assignPersonToDepartment(swapTarget.id, swapTo || null);
      toast.success(
        "Department updated",
        `${swapTarget.full_name} moved to ${departmentLabel(swapTo || null, departments)}.`
      );
      setSwapTarget(null);
      setSwapTo("");
      setRefreshNonce((n) => n + 1);
    } catch (err) {
      toast.error("Could not move person", mapSupabaseError(err).userMessage);
    } finally {
      setSwapping(false);
    }
  };

  const handleRemove = async () => {
    if (!removeTarget) return;
    setRemoving(true);
    try {
      await assignPersonToDepartment(removeTarget.id, null);
      toast.success(
        "Removed from department",
        `${removeTarget.full_name} is now unassigned. The record was kept.`
      );
      setRemoveTarget(null);
      setRefreshNonce((n) => n + 1);
    } catch (err) {
      toast.error("Could not remove person", mapSupabaseError(err).userMessage);
    } finally {
      setRemoving(false);
    }
  };

  const handleDeleteDept = async () => {
    if (!confirmDeleteDept) return;
    setDeletingDept(true);
    try {
      await deleteDepartment(confirmDeleteDept.id);
      toast.success(
        "Department removed",
        `${confirmDeleteDept.name_sw} was removed. Its registered IDs are kept and shown as Unassigned.`
      );
      setConfirmDeleteDept(null);
      if (selectedDept === confirmDeleteDept.id) setSelectedDept(null);
      setRefreshNonce((n) => n + 1);
    } catch (err) {
      toast.error("Could not remove department", mapSupabaseError(err).userMessage);
    } finally {
      setDeletingDept(false);
    }
  };

  /* ─── Member list filtering (client-side tabs) ─────────────── */

  const memberRows = useMemo(() => {
    const term = search.trim().toLowerCase();
    let rows = members;
    if (term) {
      rows = rows.filter(
        (m) =>
          m.full_name.toLowerCase().includes(term) ||
          m.identification_number.toLowerCase().includes(term)
      );
    }
    if (activeTab === "recent") {
      const now = Date.now();
      rows = rows.filter(
        (m) => now - new Date(m.created_at).getTime() < 7 * 24 * 60 * 60 * 1000
      );
    }
    return rows;
  }, [members, search, activeTab]);

  /* ─── Render ───────────────────────────────────────────────── */

  return (
    <div className="space-y-4 animate-fade-in">
      {/* ─── Page Header ─────────────────────────────────────── */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-900 dark:text-slate-100">
            Departments
          </h1>
          <p className="mt-0.5 text-sm text-gray-500 dark:text-slate-400">
            {online
              ? "Register departments and file registered IDs under the right office"
              : "OFFLINE — department management requires a connection"}
          </p>
        </div>
        {canManage && (
          <Button
            size="sm"
            onClick={() => setRegisterOpen(true)}
            icon={<Icon name="plus" className="h-4 w-4" />}
          >
            Register Department
          </Button>
        )}
      </div>

      {/* ─── Error banner ────────────────────────────────────── */}
      {error && (
        <div className="flex items-start justify-between gap-4 rounded-2xl border border-red-200 dark:border-red-900/50 bg-red-50 dark:bg-red-950/30 px-4 py-3">
          <div className="flex items-start gap-3">
            <Icon name="alert-circle" className="mt-0.5 h-5 w-5 shrink-0 text-red-500" />
            <div>
              <p className="text-sm font-semibold text-red-700 dark:text-red-400">
                Could not load departments
              </p>
              <p className="mt-0.5 text-xs text-red-600/90 dark:text-red-400/80">{error}</p>
            </div>
          </div>
          <Button
            size="sm"
            variant="outline"
            onClick={() => {
              setRefreshNonce((n) => n + 1);
              setError(null);
            }}
            icon={<Icon name="refresh" className="h-3.5 w-3.5" />}
          >
            Retry
          </Button>
        </div>
      )}

      {/* ─── Search ──────────────────────────────────────────── */}
      <div className="relative">
        <Icon
          name="search"
          className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400 dark:text-slate-500"
        />
        <input
          type="text"
          placeholder="Search departments..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className={cn(
            "w-full rounded-xl border border-gray-200 dark:border-slate-600 bg-gray-50/50 dark:bg-slate-900/50 py-2.5 pl-10 pr-10",
            "text-sm text-gray-900 dark:text-slate-100 placeholder-gray-400 dark:placeholder-slate-500",
            "outline-none transition-all duration-200",
            "focus:border-emerald-400 focus:bg-white dark:focus:bg-slate-800 focus:ring-2 focus:ring-emerald-500/10"
          )}
        />
        {search && (
          <button
            onClick={() => setSearch("")}
            className="absolute right-2 top-1/2 -translate-y-1/2 rounded-md p-1 text-gray-400 transition-colors hover:bg-gray-100 hover:text-gray-600"
          >
            <Icon name="x" className="h-3.5 w-3.5" />
          </button>
        )}
      </div>

      {/* ─── Department grid ─────────────────────────────────── */}
      {loading ? (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {[...Array(6)].map((_, i) => (
            <div
              key={i}
              className="h-32 rounded-2xl border border-gray-200/80 dark:border-slate-700/80 bg-white dark:bg-slate-800 shadow-sm animate-pulse"
            />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center gap-4 rounded-2xl border border-gray-200/80 dark:border-slate-700/80 bg-white dark:bg-slate-800 shadow-sm py-16">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gray-100 dark:bg-slate-700">
            <Icon name="landmark" className="h-7 w-7 text-gray-300 dark:text-slate-500" />
          </div>
          <div className="text-center">
            <p className="text-sm font-medium text-gray-600 dark:text-slate-300">
              {search ? "No matching departments" : "No departments yet"}
            </p>
            <p className="mt-1 text-xs text-gray-400 dark:text-slate-500">
              {search
                ? `No results for "${search}".`
                : "Register the first department to start filing IDs."}
            </p>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {filtered.map((dept) => {
            const active = selectedDept === dept.id;
            return (
              <div
                key={dept.id}
                role="button"
                tabIndex={0}
                onClick={() => setSelectedDept(active ? null : dept.id)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    e.preventDefault();
                    setSelectedDept(active ? null : dept.id);
                  }
                }}
                className={cn(
                  "group relative cursor-pointer overflow-hidden rounded-2xl border bg-white dark:bg-slate-800 shadow-sm transition-all duration-200",
                  "hover:shadow-md hover:-translate-y-0.5",
                  active
                    ? "border-emerald-400 dark:border-emerald-500 ring-2 ring-emerald-500/20"
                    : "border-gray-200/80 dark:border-slate-700/80"
                )}
              >
                <div
                  className={cn(
                    "absolute inset-x-0 top-0 h-1 bg-gradient-to-r",
                    departmentColor(dept.id)
                  )}
                />
                <div className="p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div
                      className={cn(
                        "flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br text-white shadow-sm",
                        departmentColor(dept.id)
                      )}
                    >
                      <Icon name="landmark" className="h-5 w-5" />
                    </div>
                    <span
                      className={cn(
                        "inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wide ring-1",
                        dept.person_count > 0
                          ? "bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 ring-emerald-200 dark:ring-emerald-800"
                          : "bg-gray-50 dark:bg-slate-900/60 text-gray-500 dark:text-slate-400 ring-gray-200 dark:ring-slate-700"
                      )}
                    >
                      {dept.person_count} ID{dept.person_count === 1 ? "" : "s"}
                    </span>
                  </div>
                  <h3 className="mt-3 truncate text-sm font-bold text-gray-900 dark:text-white">
                    {dept.name_sw}
                  </h3>
                  <p className="truncate text-xs text-gray-500 dark:text-slate-400">
                    {dept.name_en}
                  </p>

                  {canManage && (
                    <div className="mt-4 flex items-center gap-1.5 opacity-0 transition-opacity duration-200 group-hover:opacity-100 focus-within:opacity-100">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setConfirmDeleteDept(dept);
                        }}
                        className="inline-flex items-center gap-1 rounded-lg px-2 py-1 text-[11px] font-medium text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-500/10"
                      >
                        <Icon name="trash" className="h-3.5 w-3.5" />
                        Remove
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ─── Selected department member registry ─────────────── */}
      {selectedDept && (
        <div className="rounded-2xl border border-gray-200/80 dark:border-slate-700/80 bg-white dark:bg-slate-800 shadow-sm">
          <div className="flex flex-col gap-3 border-b border-gray-100 dark:border-slate-700 p-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h2 className="text-base font-bold text-gray-900 dark:text-white">
                {departmentLabel(selectedDept, departments)}
              </h2>
              <p className="text-xs text-gray-500 dark:text-slate-400">
                Registered IDs filed under this department
              </p>
            </div>
            <div className="flex items-center gap-2">
              {/* Tabs */}
              <div className="flex items-center gap-1">
                {(
                  [
                    { id: "all", label: "All" },
                    { id: "recent", label: "Recent" },
                  ] as { id: PageTab; label: string }[]
                ).map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={cn(
                      "inline-flex items-center rounded-lg px-3 py-1.5 text-xs font-medium transition-all duration-200",
                      activeTab === tab.id
                        ? "bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 ring-1 ring-emerald-200 dark:ring-emerald-800"
                        : "text-gray-500 dark:text-slate-400 hover:bg-gray-100 dark:hover:bg-slate-700"
                    )}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
              <button
                onClick={() => setSelectedDept(null)}
                className="rounded-lg p-1.5 text-gray-400 transition-colors hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-600 dark:hover:text-slate-300"
                aria-label="Close panel"
              >
                <Icon name="x" className="h-4 w-4" />
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100 dark:border-slate-700 bg-gray-50/80 dark:bg-slate-900/50">
                  <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:text-slate-400">
                    Cheki Namba
                  </th>
                  <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:text-slate-400">
                    Jina
                  </th>
                  <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:text-slate-400">
                    Cheo
                  </th>
                  <th className="px-4 py-3 text-right text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:text-slate-400">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100/80 dark:divide-slate-700/50">
                {membersLoading ? (
                  [...Array(3)].map((_, i) => (
                    <tr key={i} className="animate-pulse">
                      <td className="px-4 py-3">
                        <div className="h-3.5 w-24 rounded bg-gray-100 dark:bg-slate-700" />
                      </td>
                      <td className="px-4 py-3">
                        <div className="h-3.5 w-32 rounded bg-gray-100 dark:bg-slate-700" />
                      </td>
                      <td className="px-4 py-3">
                        <div className="h-3.5 w-20 rounded bg-gray-100 dark:bg-slate-700" />
                      </td>
                      <td className="px-4 py-3">
                        <div className="ml-auto h-3.5 w-10 rounded bg-gray-100 dark:bg-slate-700" />
                      </td>
                    </tr>
                  ))
                ) : membersError ? (
                  <tr>
                    <td colSpan={4} className="px-4 py-8 text-center">
                      <p className="text-sm font-medium text-red-600 dark:text-red-400">
                        {membersError}
                      </p>
                      <p className="mt-1 text-xs text-gray-400 dark:text-slate-500">
                        Run the SQL migration (20260914_departments.sql) to enable the
                        department column.
                      </p>
                    </td>
                  </tr>
                ) : memberRows.length === 0 ? (
                  <tr>
                    <td colSpan={4}>
                      <div className="flex flex-col items-center justify-center gap-3 py-12">
                        <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gray-100 dark:bg-slate-700">
                          <Icon name="users" className="h-5 w-5 text-gray-300 dark:text-slate-500" />
                        </div>
                        <p className="text-sm font-medium text-gray-600 dark:text-slate-300">
                          No IDs filed under this department yet
                        </p>
                        <p className="text-xs text-gray-400 dark:text-slate-500">
                          Pick a department when registering a person, or swap one
                          in from another department.
                        </p>
                      </div>
                    </td>
                  </tr>
                ) : (
                  memberRows.map((p) => (
                    <tr
                      key={p.id}
                      className="transition-colors hover:bg-emerald-50/30 dark:hover:bg-slate-700/40"
                    >
                      <td className="px-4 py-3">
                        <span className="font-mono text-xs font-semibold tracking-wide text-gray-900 dark:text-white">
                          {p.identification_number}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <div
                            className={cn(
                              "flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br text-[11px] font-bold text-white shadow-sm",
                              initialsColor(p.full_name)
                            )}
                          >
                            {initials(p.full_name)}
                          </div>
                          <span className="truncate font-semibold text-gray-900 dark:text-white">
                            {p.full_name}
                          </span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className="text-sm font-medium text-gray-700 dark:text-slate-200">
                          {p.position || "-"}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        {can("people.update") ? (
                          <div className="inline-flex items-center gap-1.5">
                            <button
                              onClick={() => {
                                setSwapTarget(p);
                                setSwapTo("");
                              }}
                              className="inline-flex items-center gap-1 rounded-lg px-2 py-1 text-[11px] font-medium text-emerald-700 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-500/10"
                            >
                              <Icon name="refresh" className="h-3.5 w-3.5" />
                              Swap
                            </button>
                            <button
                              onClick={() => setRemoveTarget(p)}
                              className="inline-flex items-center gap-1 rounded-lg px-2 py-1 text-[11px] font-medium text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-500/10"
                            >
                              <Icon name="x" className="h-3.5 w-3.5" />
                              Remove
                            </button>
                          </div>
                        ) : (
                          <span className="text-xs text-gray-400 dark:text-slate-500">
                            View only
                          </span>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ─── Register department modal ───────────────────────── */}
      <Modal
        open={registerOpen}
        onClose={() => setRegisterOpen(false)}
        title="Register Department"
        description="New departments become available when registering a person."
      >
        <div className="space-y-4">
          <div>
            <label
              htmlFor="dept-name-sw"
              className="mb-1.5 block text-[13px] font-medium text-surface-600 dark:text-slate-300"
            >
              Name (Kiswahili) <span className="text-danger-500">*</span>
            </label>
            <input
              id="dept-name-sw"
              type="text"
              value={newNameSw}
              onChange={(e) => setNewNameSw(e.target.value)}
              placeholder="e.g. Idara ya Usimamizi"
              className="input-base"
            />
          </div>
          <div>
            <label
              htmlFor="dept-name-en"
              className="mb-1.5 block text-[13px] font-medium text-surface-600 dark:text-slate-300"
            >
              Name (English)
            </label>
            <input
              id="dept-name-en"
              type="text"
              value={newNameEn}
              onChange={(e) => setNewNameEn(e.target.value)}
              placeholder="e.g. Management Department"
              className="input-base"
            />
          </div>
          <p className="text-xs text-gray-400 dark:text-slate-500">
            Registered IDs keep their department even if it is later removed —
            they will show as unassigned rather than being deleted.
          </p>
        </div>
        <div className="mt-6 flex justify-end gap-2.5">
          <Button variant="outline" onClick={() => setRegisterOpen(false)}>
            Cancel
          </Button>
          <Button loading={creating} onClick={() => void handleCreate()}>
            Register Department
          </Button>
        </div>
      </Modal>

      {/* ─── Swap department modal ───────────────────────────── */}
      <Modal
        open={swapTarget !== null}
        onClose={() => {
          setSwapTarget(null);
          setSwapTo("");
        }}
        title="Swap Department"
        description={
          swapTarget
            ? `Move ${swapTarget.full_name} (${swapTarget.identification_number}) to another department.`
            : undefined
        }
      >
        <div>
          <label
            htmlFor="swap-dept-select"
            className="mb-1.5 block text-[13px] font-medium text-surface-600 dark:text-slate-300"
          >
            New department
          </label>
          <select
            id="swap-dept-select"
            value={swapTo}
            onChange={(e) => setSwapTo(e.target.value)}
            className="input-base"
          >
            <option value="">— Unassigned (no department) —</option>
            {departments
              .filter((d) => d.id !== swapTarget?.department)
              .map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name_sw} ({d.name_en})
                </option>
              ))}
          </select>
        </div>
        <div className="mt-6 flex justify-end gap-2.5">
          <Button
            variant="outline"
            onClick={() => {
              setSwapTarget(null);
              setSwapTo("");
            }}
          >
            Cancel
          </Button>
          <Button loading={swapping} disabled={!swapTo} onClick={() => void handleSwap()}>
            Move Person
          </Button>
        </div>
      </Modal>

      {/* ─── Confirmations ───────────────────────────────────── */}
      <ConfirmDialog
        open={removeTarget !== null}
        onCancel={() => setRemoveTarget(null)}
        options={{
          title: "Remove from department?",
          message: (
            <>
              <strong>{removeTarget?.full_name}</strong> will be detached from{" "}
              {departmentLabel(removeTarget?.department ?? null, departments)}. The person
              record is kept and can be assigned to another department later.
            </>
          ),
          confirmLabel: "Yes, remove",
          cancelLabel: "Cancel",
          danger: true,
          loading: removing,
          onConfirm: () => {
            void handleRemove();
          },
        }}
      />
      <ConfirmDialog
        open={confirmDeleteDept !== null}
        onCancel={() => setConfirmDeleteDept(null)}
        options={{
          title: "Remove this department?",
          message: (
            <>
              <strong>{confirmDeleteDept?.name_sw}</strong> will be removed from
              the department list. Registered IDs filed under it are{" "}
              <strong>not deleted</strong> — they will show as unassigned.
            </>
          ),
          confirmLabel: "Yes, remove",
          cancelLabel: "Cancel",
          danger: true,
          loading: deletingDept,
          onConfirm: () => {
            void handleDeleteDept();
          },
        }}
      />
    </div>
  );
}
