import { useEffect, useState } from "react";
import { Card, CardBody, CardHeader, PageHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/ui/status-badge";
import { EmptyState, TBody, TD, TH, THead, TR, Table } from "@/components/ui/data-table";
import { Icon } from "@/components/icons/icon";
import { useToast } from "@/components/ui/toast";
import { useSyncEngineState } from "@/features/sync/connection-indicator";
import { SyncEngine } from "@/sync/engine";
import { listOutbox, retryEntry } from "@/offline/outbox";
import { getMeta, setMeta } from "@/db/database";
import { getDeviceId } from "@/offline/device";
import type { OutboxEntry } from "@/db/database";
import { formatDateTime, formatRelative, humanize } from "@/lib/format";

export function SyncPage() {
  const { online, running, lastSyncAt, lastError, pending, conflicts } = useSyncEngineState();
  const [entries, setEntries] = useState<OutboxEntry[]>([]);
  const toast = useToast();

  const refresh = (): void => {
    void listOutbox().then(setEntries);
  };

  useEffect(() => {
    refresh();
    const t = window.setInterval(refresh, 5000);
    return () => window.clearInterval(t);
  }, []);

  const manualSync = async (): Promise<void> => {
    if (!online) {
      toast.warning("You are offline", "Connect to the internet to synchronize.");
      return;
    }
    const result = await SyncEngine.sync();
    refresh();
    if (result.conflicts > 0) {
      toast.warning(
        `Synchronized with ${result.conflicts} conflict${result.conflicts === 1 ? "" : "s"}`,
        "Review conflicts below — supervisor attention required."
      );
    } else if (result.failures > 0) {
      toast.error("Sync incomplete", `${result.failures} operation(s) failed and will retry automatically.`);
    } else {
      toast.success("Synchronization complete", `${result.processed} change(s) uploaded.`);
    }
  };

  const handleRetry = async (id?: number): Promise<void> => {
    if (!id) return;
    await retryEntry(id);
    refresh();
    toast.info("Queued for retry");
  };

  return (
    <div className="animate-fade-in">
      <PageHeader
        title="Synchronization"
        subtitle="Offline operations queue — nothing is ever silently lost or overwritten"
        actions={
          <>
            <Button
              variant="outline"
              icon={<Icon name="refresh" className={`h-4 w-4 ${running ? "animate-spin" : ""}`} />}
              onClick={() => void manualSync()}
              disabled={running}
            >
              Sync now
            </Button>
            <Button
              variant="ghost"
              onClick={async () => {
                await setMeta("last_sync_at", new Date().toISOString());
                refresh();
              }}
              title="Refresh view"
              aria-label="Refresh"
            >
              <Icon name="history" className="h-4 w-4" />
            </Button>
          </>
        }
      />

      {/* Status cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatusTile label="Connection" value={<StatusBadge status={online ? "online" : "offline"} />} />
        <StatusTile label="Pending changes" value={
          <span className={`text-2xl font-bold tabular-nums ${pending > 0 ? "text-amber-600" : "text-slate-700 dark:text-slate-300"}`}>
            {pending}
          </span>
        } />
        <StatusTile label="Conflicts" value={
          <span className={`text-2xl font-bold tabular-nums ${conflicts > 0 ? "text-violet-600" : "text-slate-700 dark:text-slate-300"}`}>
            {conflicts}
          </span>
        } />
        <StatusTile label="Last sync" value={
          <span className="text-sm font-medium text-slate-700 dark:text-slate-300">
            {formatDateTime(lastSyncAt)}
          </span>
        } />
      </div>

      {lastError && (
        <div role="alert" className="mt-4 rounded-xl border border-red-200 dark:border-red-900 bg-red-50 dark:bg-red-950/60 px-4 py-3 text-sm text-red-800 dark:text-red-300">
          <p className="flex items-center gap-2 font-semibold">
            <Icon name="alert-circle" className="h-4 w-4" /> Last sync error
          </p>
          <p className="mt-1 text-xs">{lastError}</p>
        </div>
      )}

      <Card className="mt-4 overflow-hidden">
        <CardHeader
          title="Operation journal"
          subtitle={`${entries.length} entr${entries.length === 1 ? "y" : "ies"} on this device`}
          icon={<Icon name="refresh" className="h-4 w-4" />}
        />
        {entries.length === 0 ? (
          <EmptyState
            icon="check-circle"
            title="Queue is empty"
            message="All local changes are synchronized. Offline work will appear here until it is uploaded."
          />
        ) : (
          <Table>
            <THead>
              <TR>
                <TH>Created</TH>
                <TH>Operation</TH>
                <TH>Status</TH>
                <TH>Retries</TH>
                <TH>Error</TH>
                <TH />
              </TR>
            </THead>
            <TBody>
              {entries.map((e) => (
                <TR key={e.id}>
                  <TD className="whitespace-nowrap text-xs text-slate-500">
                    {formatRelative(e.created_at)}
                  </TD>
                  <TD>
                    <span className="font-mono text-xs font-semibold">{humanize(e.operation_type)}</span>
                    <span className="ml-2 font-mono text-[10px] text-slate-400">
                      {e.entity_id.slice(0, 8)}
                    </span>
                  </TD>
                  <TD>
                    <StatusBadge status={e.status} pulse={e.status === "in_flight"} />
                  </TD>
                  <TD className="tabular-nums">{e.retry_count}</TD>
                  <TD className="max-w-[220px] truncate text-[11px] text-red-600" title={e.error_message ?? ""}>
                    {e.error_message ?? "—"}
                  </TD>
                  <TD>
                    {(e.status === "failed" || e.status === "conflict") && (
                      <Button size="sm" variant="outline" onClick={() => void handleRetry(e.id)}>
                        Retry
                      </Button>
                    )}
                  </TD>
                </TR>
              ))}
            </TBody>
          </Table>
        )}
      </Card>

      <Card className="mt-4">
        <CardHeader
          title="This workstation"
          icon={<Icon name="monitor" className="h-4 w-4" />}
        />
        <CardBody className="space-y-2 text-sm text-slate-600 dark:text-slate-400">
          <DeviceInfo />
        </CardBody>
      </Card>
    </div>
  );
}

function DeviceInfo() {
  const [deviceId, setDeviceId] = useState("");
  const [lastSync, setLastSync] = useState<string | null>(null);

  useEffect(() => {
    void getDeviceId().then((d) =>
      setDeviceId(`${d.slice(0, 6)}…${d.slice(-4)}`)
    );
    void getMeta<string>("last_sync_at").then((v: string | undefined | null) =>
      setLastSync(v ?? null)
    );
  }, []);

  return (
    <>
      <p className="flex flex-wrap items-baseline justify-between gap-2 border-b border-slate-100 dark:border-slate-700 pb-2">
        <span className="text-xs uppercase tracking-wide text-slate-400">Device ID</span>
        <span className="font-mono text-xs">{deviceId}</span>
      </p>
      <p className="flex flex-wrap items-baseline justify-between gap-2">
        <span className="text-xs uppercase tracking-wide text-slate-400">Registered</span>
        <span className="font-medium">Automatically on first sign-in</span>
      </p>
      <p className="flex flex-wrap items-baseline justify-between gap-2">
        <span className="text-xs uppercase tracking-wide text-slate-400">Last sync</span>
        <span className="font-medium">{lastSync ? formatDateTime(lastSync) : "—"}</span>
      </p>
    </>
  );
}

function StatusTile({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <Card className="p-4">
      <p className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">{label}</p>
      <div className="mt-2">{value}</div>
    </Card>
  );
}
