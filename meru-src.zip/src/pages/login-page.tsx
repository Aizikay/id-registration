import { useEffect, useState } from "react";
import Loader from "@/components/Loader";
import { Link, Navigate, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "@/features/auth/auth-context";
import { AppFooter } from "@/components/branding/footer";
import { OrganizationHeader, TanzaniaCoatOfArms, CouncilLogo } from "@/components/branding/logo";
import { Icon } from "@/components/icons/icon";
import { ORGANIZATION } from "@/lib/constants";
import { isSupabasePlaceholder } from "@/lib/env";
import { mapSupabaseError } from "@/services/errors";
import { ThemeToggle } from "@/components/ThemeToggle";
import { useTheme } from "@/contexts/ThemeContext";

const REASON_MESSAGES: Record<string, string> = {
  idle: "You were signed out automatically after a period of inactivity.",
  revoked: "Your device access was revoked. Contact an administrator.",
  expired: "Your session expired. Please sign in again.",
};

export function LoginPage() {
  const { signIn, profile, loading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { isDark, toggleTheme } = useTheme();
  const params = new URLSearchParams(location.search);
  const reason = params.get("reason");
  const from = (location.state as { from?: { pathname: string } })?.from?.pathname;

  useEffect(() => {
    document.title = `Ingia — ${ORGANIZATION.nameEn}`;
    return () => { document.title = `Usajili wa Kitambulisho | ${ORGANIZATION.nameEn}`; };
  }, []);

  if (!loading && profile) {
    return <Navigate to={from ?? "/app"} replace />;
  }

  const handleSubmit = async (e: React.FormEvent): Promise<void> => {
    e.preventDefault();
    if (!email.trim() || !password) return;
    setError(null);
    setSubmitting(true);
    try {
      await signIn(email.trim(), password);
      navigate(from ?? "/app", { replace: true });
    } catch (err) {
      const mapped = mapSupabaseError(err);
      setError(
        mapped.code === "auth_failed"
          ? "Invalid email or password. Please check your credentials."
          : !navigator.onLine
            ? "No internet connection. Sign-in requires connectivity."
            : mapped.userMessage
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen w-full relative flex items-center justify-center overflow-hidden bg-slate-100 dark:bg-slate-950 transition-colors duration-300 p-4">

      {/* ─── Animated Ambient Glow Background ────────────────── */}
      <div className="absolute -top-20 -left-20 w-96 h-96 bg-emerald-500/20 rounded-full blur-[120px] animate-pulse" aria-hidden="true" />
      <div className="absolute -bottom-20 -right-20 w-96 h-96 bg-teal-400/20 rounded-full blur-[120px] animate-pulse" style={{ animationDelay: "1s" }} aria-hidden="true" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-emerald-600/10 rounded-full blur-[150px] animate-pulse" style={{ animationDelay: "2s" }} aria-hidden="true" />

      {/* Theme Toggle */}
      <div className="fixed top-6 right-6 z-50">
        <ThemeToggle isDark={isDark} onToggle={toggleTheme} />
      </div>

      {/* Tanzanian flag ribbon */}
      <div className="absolute top-0 left-0 right-0 flex h-1 z-20" aria-hidden="true">
        <div className="h-full w-1/3 bg-gradient-to-r from-[#1eb53a] to-[#16a34a]" />
        <div className="h-full flex-1 bg-gradient-to-r from-[#fcd116] to-[#eab308]" />
        <div className="h-full w-1/3 bg-gradient-to-r from-[#00a3dd] to-[#0ea5e9]" />
      </div>

      {/* ─── Main Modal Card ────────────────────────────────── */}
      <div className="w-full max-w-4xl grid grid-cols-1 lg:grid-cols-2 rounded-3xl overflow-hidden shadow-[0_25px_60px_-15px_rgba(0,0,0,0.5)] border border-slate-800/80 backdrop-blur-xl bg-white dark:bg-slate-900/90 relative z-10 transition-all duration-300">

        {/* ─── Left Hero Panel ────────────────────────────────── */}
        <section
          className="relative overflow-hidden p-8 flex flex-col justify-between text-white min-h-[400px] lg:min-h-0"
          aria-label="Organization information"
          style={{
            background: "linear-gradient(160deg, #022c22 0%, #064e3b 35%, #065f46 55%, #1e293b 100%)",
          }}
        >
          {/* Radial gradient flare */}
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-emerald-400/10 via-transparent to-transparent pointer-events-none" />

          {/* Geometric grid pattern */}
          <div
            className="absolute inset-0 opacity-[0.04] pointer-events-none"
            style={{
              backgroundImage: "radial-gradient(circle, rgba(255,255,255,0.15) 1px, transparent 1px)",
              backgroundSize: "16px 16px",
            }}
          />

          {/* Internal glow accents */}
          <div className="absolute -top-10 -right-10 w-48 h-48 bg-emerald-500/15 rounded-full blur-[80px] animate-pulse" />
          <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-emerald-400/10 rounded-full blur-[80px] animate-pulse" style={{ animationDelay: "1.5s" }} />

          <div className="relative z-10 space-y-8">
            <div className="flex items-center gap-4">
              <CouncilLogo size={64} className="ring-2 ring-white/20 shadow-lg" />
              <div>
                <h1 className="text-lg font-medium text-white/95 tracking-wide uppercase leading-tight">
                  {ORGANIZATION.nameSw}
                </h1>
                <p className="text-xs text-white/45 tracking-wider">
                  {ORGANIZATION.nameEn}
                </p>
              </div>
            </div>

            <div className="space-y-2">
              <h2 className="text-2xl font-semibold text-white leading-snug">
                Mfumo wa Usajili na Utoaji wa Kitambulisho
              </h2>
              <p className="text-sm text-emerald-300/70 font-medium">
                ID Registration & Issuance Portal
              </p>
            </div>
          </div>

          <div className="relative z-10 flex items-end justify-between gap-6 mt-8">
            <div className="relative z-10 p-3 bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 shadow-xl transform transition-transform duration-300 hover:scale-105 hover:bg-white/15">
              <TanzaniaCoatOfArms size={80} />
            </div>
            <p className="text-right text-[11px] text-white/30 leading-relaxed">
              {ORGANIZATION.region}
            </p>
          </div>
        </section>

        {/* ─── Right Form Panel ─────────────────────────────── */}
        <section className="flex flex-col p-6 sm:p-10 bg-white dark:bg-slate-900/95 backdrop-blur-xl">
          <div className="mb-6 flex justify-center lg:hidden">
            <OrganizationHeader compact />
          </div>

          <header className="mb-6 text-center">
            {/* Login icon with glow pulse */}
            <div className="mx-auto mb-4 w-16 h-16 rounded-2xl overflow-hidden border border-emerald-500/30 shadow-[0_0_30px_rgba(16,185,129,0.25)] transition-all duration-300 hover:scale-105 hover:shadow-[0_0_40px_rgba(16,185,129,0.35)]">
              <img
                src="https://sufktrtlhfpyqcdikywa.supabase.co/storage/v1/object/public/Logo/3d%20User%20login%20or%20verification%20icon,%20human%20symbol_Mobile%20ui%20ux%20app%20icons_.jpeg"
                alt="Login icon"
                className="h-full w-full object-cover"
              />
            </div>
            <h2 className="font-display text-xl font-semibold text-slate-900 dark:text-white">
              LOGIN
            </h2>
            <p className="mt-1.5 text-sm text-slate-500 dark:text-slate-400">
              Ingia kuingia kwenye mfumo
            </p>
          </header>

          {isSupabasePlaceholder && (
            <div
              role="alert"
              className="mb-5 rounded-xl border border-red-800/50 bg-red-950/30 px-4 py-3 text-xs text-red-400 backdrop-blur-sm"
            >
              <strong>Supabase haijaunganishwa.</strong>{" "}
              Weka <code className="rounded bg-red-900/50 px-1.5 py-0.5 font-mono text-[11px]">VITE_SUPABASE_URL</code> na{" "}
              <code className="rounded bg-red-900/50 px-1.5 py-0.5 font-mono text-[11px]">VITE_SUPABASE_ANON_KEY</code> katika{" "}
              <code className="rounded bg-red-900/50 px-1.5 py-0.5 font-mono text-[11px]">.env.local</code> na anzisha upya server.
            </div>
          )}

          {reason && REASON_MESSAGES[reason] && (
            <div
              role="status"
              className="mb-5 flex items-start gap-3 rounded-xl border border-amber-800/50 bg-amber-950/30 px-4 py-3 text-xs text-amber-400 backdrop-blur-sm"
            >
              <Icon name="info" className="mt-0.5 h-4 w-4 shrink-0 text-amber-500" />
              <span className="leading-relaxed">{REASON_MESSAGES[reason]}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} noValidate className="space-y-4">
            {/* Email Input */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Email address <span className="text-red-500">*</span>
              </label>
              <input
                type="email"
                name="email"
                autoComplete="username"
                placeholder="j.mwanaisha@council.go.tz"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                disabled={submitting}
                className="w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700/80 text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all duration-200"
              />
            </div>

            {/* Password Input with eye toggle */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Password <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  name="password"
                  autoComplete="current-password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  disabled={submitting}
                  className="w-full px-4 py-3 pr-11 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700/80 text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all duration-200"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  aria-label={showPassword ? "Hide password" : "Show password"}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 rounded-lg p-1.5 text-slate-500 transition-colors hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300"
                >
                  <Icon name={showPassword ? "eye-off" : "eye"} className="h-4 w-4" />
                </button>
              </div>
              {error && (
                <p className="mt-1.5 text-xs text-red-400">{error}</p>
              )}
            </div>

            {/* Submit Button with hover elevation */}
            <div>
              <button
                type="submit"
                disabled={!email.trim() || !password || submitting}
                className="w-full py-3.5 px-6 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold shadow-[0_10px_25px_-5px_rgba(16,185,129,0.4)] hover:shadow-[0_15px_30px_-5px_rgba(16,185,129,0.6)] transform active:scale-[0.98] transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-emerald-600 disabled:active:scale-100 disabled:hover:shadow-[0_10px_25px_-5px_rgba(16,185,129,0.4)]"
              >
                {submitting ? (
                  <span className="flex items-center justify-center gap-2">
                    <Loader />
                    Signing in...
                  </span>
                ) : (
                  <span className="flex items-center justify-center gap-2">
                    Sign in
                    <Icon name="chevron-right" className="h-4 w-4" />
                  </span>
                )}
              </button>
            </div>
          </form>

          <div className="mt-4 text-center">
            <Link
              to="/forgot-password"
              className="text-xs font-medium text-emerald-400 transition-colors duration-200 hover:text-emerald-300 hover:underline underline-offset-2"
            >
              Forgot your password?
            </Link>
          </div>

          <div className="mt-auto pt-8">
            <ConnectionHint />
          </div>
        </section>
      </div>

      <div className="absolute bottom-4 left-0 right-0 z-20">
        <AppFooter />
      </div>
    </div>
  );
}

function ConnectionHint() {
  const [online, setOnline] = useState(navigator.onLine);
  useEffect(() => {
    const on = (): void => setOnline(true);
    const off = (): void => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
    };
  }, []);
  return (
    <div className="flex items-center justify-center gap-2 text-xs text-emerald-400 font-medium tracking-wide">
      <span className="relative flex h-2.5 w-2.5">
        {online && (
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
        )}
        <span className={`relative inline-flex rounded-full h-2.5 w-2.5 ${online ? "bg-emerald-500" : "bg-slate-600"}`} />
      </span>
      <span>{online ? "SYSTEM ONLINE" : "OFFLINE"}</span>
    </div>
  );
}
