import { useCallback, useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Icon } from "@/components/icons/icon";

interface Props {
  src: string;
  onCropped: (dataUrl: string) => void;
  onCancel: () => void;
  aspectRatio?: number;
}

export function PhotoCropper({ src, onCropped, onCancel, aspectRatio = 22 / 26 }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imgRef = useRef<HTMLImageElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [rotation, setRotation] = useState(0);
  const [dragging, setDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [loaded, setLoaded] = useState(false);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    const img = imgRef.current;
    if (!canvas || !img || !loaded) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const cw = canvas.width;
    const ch = canvas.height;
    ctx.clearRect(0, 0, cw, ch);
    ctx.save();
    ctx.translate(cw / 2 + pan.x, ch / 2 + pan.y);
    ctx.rotate((rotation * Math.PI) / 180);
    ctx.scale(zoom, zoom);
    const iw = img.naturalWidth;
    const ih = img.naturalHeight;
    // Fit image to cover the crop box
    const scale = Math.max(cw / iw, ch / ih);
    const dw = iw * scale;
    const dh = ih * scale;
    ctx.drawImage(img, -dw / 2, -dh / 2, dw, dh);
    ctx.restore();
  }, [zoom, pan, rotation, loaded]);

  useEffect(() => {
    draw();
  }, [draw]);

  const handlePointerDown = (e: React.PointerEvent) => {
    setDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!dragging) return;
    setPan({ x: e.clientX - dragStart.x, y: e.clientY - dragStart.y });
  };

  const handlePointerUp = () => setDragging(false);

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? -0.05 : 0.05;
    setZoom((z) => Math.min(3, Math.max(0.5, z + delta)));
  };

  const handleCrop = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    // Export at 300dpi equivalent ( (~3x) for print quality)
    const exportCanvas = document.createElement("canvas");
    const dpr = 3;
    exportCanvas.width = canvas.width * dpr;
    exportCanvas.height = canvas.height * dpr;
    const ctx = exportCanvas.getContext("2d");
    if (!ctx) return;
    // Redraw at higher res
    const img = imgRef.current!;
    ctx.scale(dpr, dpr);
    ctx.save();
    ctx.translate(canvas.width / 2 + pan.x, canvas.height / 2 + pan.y);
    ctx.rotate((rotation * Math.PI) / 180);
    ctx.scale(zoom, zoom);
    const scale = Math.max(canvas.width / img.naturalWidth, canvas.height / img.naturalHeight);
    const dw = img.naturalWidth * scale;
    const dh = img.naturalHeight * scale;
    ctx.drawImage(img, -dw / 2, -dh / 2, dw, dh);
    ctx.restore();
    const dataUrl = exportCanvas.toDataURL("image/jpeg", 0.92);
    onCropped(dataUrl);
  };

  const handleReset = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
    setRotation(0);
  };

  return (
    <div className="space-y-4">
      {/* Hidden source image */}
      <img ref={imgRef} src={src} alt="Source" className="hidden" onLoad={() => setLoaded(true)} crossOrigin="anonymous" />

      {/* Crop viewport */}
      <div
        ref={containerRef}
        className="relative mx-auto overflow-hidden rounded-xl border-2 border-slate-200 bg-slate-900"
        style={{ width: 320, height: 320 / aspectRatio, maxWidth: "100%" }}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerUp}
        onWheel={handleWheel}
      >
        <canvas
          ref={canvasRef}
          width={320}
          height={320 / aspectRatio}
          className="h-full w-full cursor-move touch-none"
          style={{ touchAction: "none" }}
        />
        {/* Grid overlay */}
        <div className="pointer-events-none absolute inset-0 grid grid-cols-3 grid-rows-3 opacity-20">
          {Array.from({ length: 9 }).map((_, i) => (
            <div key={i} className="border border-white/30" />
          ))}
        </div>
        <div className="pointer-events-none absolute inset-0 rounded-xl border-2 border-white/60" />
        {!loaded && (
          <div className="absolute inset-0 flex items-center justify-center bg-slate-800 text-sm text-white/60">Loading…</div>
        )}
      </div>

      {/* Controls */}
      <div className="space-y-3">
        <div className="flex items-center gap-3">
          <Icon name="zoom-out" className="h-4 w-4 text-slate-500" />
          <input
            type="range"
            min={0.5}
            max={3}
            step={0.05}
            value={zoom}
            onChange={(e) => setZoom(Number(e.target.value))}
            className="h-1 flex-1 appearance-none rounded-full bg-slate-200 accent-council-800"
          />
          <Icon name="zoom-in" className="h-4 w-4 text-slate-500" />
          <span className="w-10 text-right font-mono text-xs text-slate-600">{Math.round(zoom * 100)}%</span>
        </div>

        <div className="flex items-center gap-2">
          <Button size="sm" variant="ghost" onClick={() => setRotation((r) => (r - 90) % 360)} title="Rotate left">
            <Icon name="rotate-ccw" className="h-4 w-4" /> -90°
          </Button>
          <Button size="sm" variant="ghost" onClick={() => setRotation((r) => (r + 90) % 360)} title="Rotate right">
            <Icon name="rotate-cw" className="h-4 w-4" /> +90°
          </Button>
          <Button size="sm" variant="ghost" onClick={handleReset}>
            <Icon name="refresh" className="h-4 w-4" /> Reset
          </Button>
          <span className="ml-auto font-mono text-xs text-slate-500">{rotation}°</span>
        </div>

        <p className="text-center text-xs text-slate-500">Drag to pan · Scroll to zoom · Buttons to rotate</p>
      </div>

      <div className="flex justify-end gap-2 border-t border-slate-100 pt-3">
        <Button variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button onClick={handleCrop} icon={<Icon name="crop" className="h-4 w-4" />}>
          Apply crop
        </Button>
      </div>
    </div>
  );
}
