import { createClient } from "@supabase/supabase-js";
import { env } from "@/lib/env";
import type { Database } from "@/types/database";

/**
 * Singleton Supabase client.
 *
 * Uses ONLY the anon key — Row Level Security policies on the server
 * restrict every table to what the authenticated user is allowed to see.
 * The service-role key must never appear in frontend code.
 */
export const supabase = createClient<Database>(
  env.supabaseUrl,
  env.supabaseAnonKey,
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
      storageKey: "meru-id-auth"
    },
    global: {
      headers: { "x-client-info": "meru-id-registry/1.0" }
    }
  }
);
