import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Icon } from "@/components/icons/icon";
import {
  loadTemplate,
  createDefaultTemplate,
  resetTemplate,
  saveTemplate,
} from "../template";
import type { TemplateVersionStatus } from "../template";
import { useAuth } from "@/features/auth/auth-context";
import { useToast } from "@/components/ui/toast";
import { cn } from "@/lib/cn";

/* ─── Types ──────────────────────────────────────────────────── */

interface TemplateCard {
  id: string;
  name: string;
  shortName: string;
  desc: string;
  status: TemplateVersionStatus;
  version: string;
  color: string;
  accent: string;
  previewFields: { label: string; value: string; x: string; y: string }[];
  previewPhoto: boolean;
}

/* ─── Status Styles ──────────────────────────────────────────── */

const STATUS_STYLES: Record<
  TemplateVersionStatus,
  { bg: string; text: string; ring: string; dot: string; label: string }
> = {
  active: {
    bg: "bg-emerald-50",
    text: "text-emerald-700",
    ring: "ring-emerald-200",
    dot: "bg-emerald-500",
    label: "Active",
  },
  draft: {
    bg: "bg-amber-50",
    text: "text-amber-700",
    ring: "ring-amber-200",
    dot: "bg-amber-500",
    label: "Draft",
  },
  archived: {
    bg: "bg-gray-100",
    text: "text-gray-600",
    ring: "ring-gray-200",
    dot: "bg-gray-400",
    label: "Archived",
  },
};

/* ─── Catalog ────────────────────────────────────────────────── */

const CATALOG: TemplateCard[] = [
  {
    id: "employee-id-v1",
    name: "Employee ID",
    shortName: "KITAMBULISHO CHA MTUMISHI",
    desc: "Official employee identification card with council branding and government emblem",
    status: "active",
    version: "1.0.0",
    color: "from-yellow-300 via-amber-400 to-yellow-500",
    accent: "ring-amber-300",
    previewFields: [
      { label: "Cheki Namba", value: "8973229", x: "6%", y: "40%" },
      { label: "Jina", value: "ELIZABETH R.", x: "6%", y: "50%" },
      { label: "Cheo", value: "AFISA ELIMU", x: "6%", y: "60%" },
    ],
    previewPhoto: true,
  },
  {
    id: "contractor-id",
    name: "Contractor ID",
    shortName: "KITAMBULISHO CHA MKANDA",
    desc: "Temporary contractor identification for project-based personnel",
    status: "draft",
    version: "0.1.0",
    color: "from-blue-400 via-blue-500 to-blue-600",
    accent: "ring-blue-300",
    previewFields: [
      { label: "Contractor No.", value: "CTR-001", x: "6%", y: "45%" },
      { label: "Name", value: "CONTRACTOR", x: "6%", y: "55%" },
    ],
    previewPhoto: true,
  },
  {
    id: "visitor-id",
    name: "Visitor Pass",
    shortName: "KIBALI CHA MTALII",
    desc: "Temporary visitor identification for facility access",
    status: "archived",
    version: "0.1.0",
    color: "from-purple-400 via-purple-500 to-purple-600",
    accent: "ring-purple-300",
    previewFields: [
      { label: "Pass No.", value: "VIS-001", x: "6%", y: "45%" },
      { label: "Name", value: "VISITOR", x: "6%", y: "55%" },
    ],
    previewPhoto: false,
  },
  {
    id: "temporary-id",
    name: "Provisional ID",
    shortName: "KITAMBULISHO YA MUDA",
    desc: "Short-term provisional identification pending full registration",
    status: "archived",
    version: "0.1.0",
    color: "from-gray-400 via-gray-500 to-gray-600",
    accent: "ring-gray-300",
    previewFields: [
      { label: "Ref No.", value: "TMP-001", x: "6%", y: "45%" },
      { label: "Name", value: "PROVISIONAL", x: "6%", y: "55%" },
    ],
    previewPhoto: false,
  },
];

const VERSION_HISTORY = [
  {
    version: "v1.0.0",
    status: "active" as TemplateVersionStatus,
    author: "System Admin",
    staffId: "STAFF-001",
    notes: "Initial release with council logo, signature font, and official layout",
    date: "2026-01-15",
  },
  {
    version: "v0.9.0",
    status: "archived" as TemplateVersionStatus,
    author: "System Admin",
    staffId: "STAFF-001",
    notes: "Updated coat of arms positioning and corrected field alignment",
    date: "2025-12-20",
  },
  {
    version: "v0.5.0",
    status: "archived" as TemplateVersionStatus,
    author: "Developer",
    staffId: "STAFF-003",
    notes: "Initial draft with placeholder layout and sample data",
    date: "2025-10-05",
  },
];

/* ─── Mini Card Preview ──────────────────────────────────────── */

function CardPreview({
  template,
  isCurrent,
}: {
  template: TemplateCard;
  isCurrent: boolean;
}) {
  return (
    <div
      className={cn(
        "relative aspect-[85/54] w-full overflow-hidden rounded-xl border bg-white shadow-inner",
        isCurrent ? "ring-2 ring-emerald-400 border-emerald-300" : "border-gray-200"
      )}
    >
      {/* Yellow gradient background simulating the official card */}
      <div
        className={cn(
          "absolute inset-0 bg-gradient-to-br opacity-20",
          template.color
        )}
      />

      {/* Header stripe */}
      <div className="absolute top-0 left-0 right-0 h-[18%] bg-gradient-to-r from-emerald-800 to-emerald-600 flex items-center px-3">
        <div className="h-4 w-4 rounded-full bg-white/30 mr-2 flex items-center justify-center">
          <span className="text-[6px] font-bold text-white">M</span>
        </div>
        <div>
          <div className="text-[5px] font-bold text-white/90 tracking-wide uppercase leading-none">
            HALMASHAURI
          </div>
          <div className="text-[4px] text-white/60 leading-none mt-px">
            YA WILAYA YA MERU
          </div>
        </div>
      </div>

      {/* Fields */}
      {template.previewFields.map((field, i) => (
        <div
          key={i}
          className="absolute"
          style={{ left: field.x, top: field.y }}
        >
          <div className="text-[4px] font-medium text-gray-500 uppercase tracking-wider leading-none">
            {field.label}
          </div>
          <div className="text-[6px] font-bold text-gray-900 mt-px leading-tight">
            {field.value}
          </div>
        </div>
      ))}

      {/* Photo placeholder */}
      {template.previewPhoto && (
        <div className="absolute right-[6%] top-[35%] h-[30%] w-[28%] rounded-sm border border-gray-300 bg-gray-100 flex items-center justify-center">
          <div className="h-[40%] w-[40%] rounded-full bg-gray-200 flex items-center justify-center">
            <svg className="h-[60%] w-[60%] text-gray-300" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
            </svg>
          </div>
        </div>
      )}

      {/* Bottom bar */}
      <div className="absolute bottom-0 left-0 right-0 h-[12%] bg-gradient-to-r from-yellow-300/40 to-amber-200/40 flex items-center px-3">
        <div className="text-[4px] font-semibold text-gray-600 uppercase tracking-wider">
          MKURUGENZI
        </div>
      </div>

      {/* Active indicator */}
      {isCurrent && (
        <div className="absolute top-2 right-2 flex h-4 w-4 items-center justify-center rounded-full bg-emerald-500 shadow-sm">
          <svg className="h-2.5 w-2.5 text-white" fill="none" viewBox="0 0 24 24" strokeWidth={3} stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
          </svg>
        </div>
      )}
    </div>
  );
}

/* ─── Status Badge ───────────────────────────────────────────── */

function StatusBadge({ status }: { status: TemplateVersionStatus }) {
  const s = STATUS_STYLES[status];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wide",
        s.bg,
        s.text,
        s.ring
      )}
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", s.dot)} />
      {s.label}
    </span>
  );
}

/* ─── Template Card ──────────────────────────────────────────── */

function TemplateCardComponent({
  template,
  isCurrent,
  activeVersion,
  onEdit,
  onPreview,
  onDuplicate,
  onReset,
}: {
  template: TemplateCard;
  isCurrent: boolean;
  activeVersion: string;
  onEdit: () => void;
  onPreview: () => void;
  onDuplicate: () => void;
  onReset: () => void;
}) {
  const [showMenu, setShowMenu] = useState(false);
  const version =
    template.id === "employee-id-v1" ? activeVersion : template.version;

  return (
    <div
      className={cn(
        "group relative flex flex-col overflow-hidden rounded-2xl border bg-white transition-all duration-300",
        "shadow-sm hover:shadow-lg hover:shadow-black/5 hover:-translate-y-0.5",
        isCurrent ? "ring-2 ring-emerald-400 border-emerald-200" : "border-gray-200",
        template.status === "archived" && "opacity-75 hover:opacity-100"
      )}
    >
      {/* Visual Preview */}
      <div className="p-4 pb-0">
        <CardPreview template={template} isCurrent={isCurrent} />
      </div>

      {/* Card Body */}
      <div className="flex flex-1 flex-col p-4 pt-3">
        {/* Title + Status */}
        <div className="flex items-start justify-between gap-2 mb-1">
          <div className="min-w-0">
            <h3 className="text-sm font-bold text-gray-900 truncate">
              {template.name}
            </h3>
            <p className="text-[11px] font-medium text-gray-500 truncate mt-0.5">
              {template.shortName}
            </p>
          </div>
          <StatusBadge status={template.status} />
        </div>

        {/* Description */}
        <p className="text-xs text-gray-500 mt-2 line-clamp-2 leading-relaxed">
          {template.desc}
        </p>

        {/* Meta */}
        <div className="mt-3 flex items-center gap-3 text-[10px] text-gray-400">
          <span className="inline-flex items-center gap-1">
            <Icon name="history" className="h-3 w-3" />
            v{version}
          </span>
          <span className="inline-flex items-center gap-1">
            <Icon name="id-card" className="h-3 w-3" />
            85 × 54 mm
          </span>
          <span className="inline-flex items-center gap-1">
            <Icon name="file-text" className="h-3 w-3" />
            PDF
          </span>
        </div>

        {/* Actions */}
        <div className="mt-4 flex items-center gap-2">
          <button
            onClick={onEdit}
            className={cn(
              "flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl px-3 py-2 text-xs font-semibold transition-all duration-200",
              template.status === "archived"
                ? "bg-gray-100 text-gray-500 cursor-not-allowed"
                : "bg-emerald-600 text-white shadow-sm shadow-emerald-500/20 hover:bg-emerald-700 hover:shadow-md active:scale-95"
            )}
            disabled={template.status === "archived"}
          >
            <Icon name="pencil" className="h-3.5 w-3.5" />
            Edit in Designer
          </button>

          <button
            onClick={onPreview}
            className="inline-flex items-center justify-center gap-1 rounded-xl border border-gray-200 bg-white px-3 py-2 text-xs font-semibold text-gray-700 shadow-sm transition-all duration-200 hover:bg-gray-50 hover:text-gray-900 hover:shadow-md active:scale-95"
          >
            <Icon name="eye" className="h-3.5 w-3.5" />
            Preview
          </button>

          {/* More menu */}
          <div className="relative">
            <button
              onClick={() => setShowMenu(!showMenu)}
              className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-gray-200 bg-white text-gray-400 shadow-sm transition-all duration-200 hover:bg-gray-50 hover:text-gray-600"
            >
              <svg
                className="h-4 w-4"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={2}
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M6.75 12a.75.75 0 11-1.5 0 .75.75 0 011.5 0zM12.75 12a.75.75 0 11-1.5 0 .75.75 0 011.5 0zM18.75 12a.75.75 0 11-1.5 0 .75.75 0 011.5 0z"
                />
              </svg>
            </button>

            {showMenu && (
              <div className="absolute right-0 top-full z-50 mt-1 w-48 rounded-xl border border-gray-200 bg-white py-1 shadow-lg animate-scale-in">
                <button
                  onClick={() => {
                    setShowMenu(false);
                    onDuplicate();
                  }}
                  className="flex w-full items-center gap-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-50"
                >
                  <Icon name="credit-card" className="h-4 w-4 text-gray-400" />
                  Duplicate
                </button>
                <button
                  onClick={() => {
                    setShowMenu(false);
                  }}
                  className="flex w-full items-center gap-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-50"
                >
                  <Icon name="download" className="h-4 w-4 text-gray-400" />
                  Export Schema
                </button>
                {template.status === "draft" && (
                  <>
                    <div className="my-1 border-t border-gray-100" />
                    <button
                      onClick={() => {
                        setShowMenu(false);
                        onReset();
                      }}
                      className="flex w-full items-center gap-2 px-3 py-2 text-sm text-amber-600 hover:bg-amber-50"
                    >
                      <Icon name="alert-triangle" className="h-4 w-4" />
                      Archive Template
                    </button>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ─── Version History ────────────────────────────────────────── */

function VersionHistory({ template }: { template: { version: string; updatedAt: string } }) {
  return (
    <div className="rounded-2xl border border-gray-200 bg-white shadow-sm overflow-hidden">
      <div className="flex items-center justify-between border-b border-gray-100 px-6 py-4">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gray-100">
            <Icon name="history" className="h-4 w-4 text-gray-500" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Template Version History</h3>
            <p className="text-xs text-gray-500">
              Every issued ID records the template version used. All changes are tracked.
            </p>
          </div>
        </div>
      </div>

      {/* Timeline */}
      <div className="relative">
        {/* Vertical line */}
        <div className="absolute left-8 top-0 bottom-0 w-px bg-gray-200" />

        <div className="divide-y divide-gray-50">
          {/* Current version */}
          <div className="relative flex items-start gap-4 px-6 py-4 bg-emerald-50/30">
            <div className="relative z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-emerald-500 text-xs font-bold text-white shadow-md shadow-emerald-500/20 ring-4 ring-white">
              <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
              </svg>
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-sm font-bold text-gray-900">
                  v{template.version}
                </span>
                <StatusBadge status="active" />
              </div>
              <p className="text-xs text-gray-600 leading-relaxed">
                Official release with council logo, government emblem, and calibrated field positions.
              </p>
              <div className="mt-2 flex items-center gap-3 text-[11px] text-gray-400">
                <span className="font-medium text-gray-500">System Admin</span>
                <span className="font-mono">STAFF-001</span>
                <span>{new Date(template.updatedAt).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })}</span>
              </div>
            </div>
            <span className="shrink-0 rounded-full bg-emerald-100 px-2.5 py-1 text-[10px] font-bold text-emerald-700">
              CURRENT
            </span>
          </div>

          {/* Historical versions */}
          {VERSION_HISTORY.map((v, i) => (
            <div key={v.version} className="relative flex items-start gap-4 px-6 py-4 hover:bg-gray-50/50 transition-colors">
              <div className="relative z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white text-xs font-bold text-gray-500 ring-2 ring-gray-200">
                {i + 1}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-sm font-semibold text-gray-700">
                    v{v.version}
                  </span>
                  <StatusBadge status={v.status} />
                </div>
                <p className="text-xs text-gray-500 leading-relaxed">{v.notes}</p>
                <div className="mt-2 flex items-center gap-3 text-[11px] text-gray-400">
                  <span className="font-medium text-gray-500">{v.author}</span>
                  <span className="font-mono">{v.staffId}</span>
                  <span>{new Date(v.date).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })}</span>
                </div>
              </div>
              <button className="shrink-0 inline-flex items-center gap-1 rounded-lg border border-gray-200 bg-white px-2.5 py-1 text-[10px] font-semibold text-gray-600 transition-all hover:bg-gray-50 hover:text-gray-900">
                <Icon name="refresh" className="h-3 w-3" />
                Restore
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ─── Main Page ──────────────────────────────────────────────── */

export function TemplateListPage() {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const toast = useToast();
  const [template] = useState(() => loadTemplate());
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const handleReset = () => {
    const t = createDefaultTemplate();
    saveTemplate(t, true);
    resetTemplate();
    saveTemplate(createDefaultTemplate(), true);
    toast.success("Template Reset", "Restored to official system default");
    setShowResetConfirm(false);
    navigate("/app/id-card/designer");
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* ─── Page Header ─────────────────────────────────── */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-900">
            ID Card Designer &amp; Templates
          </h1>
          <p className="mt-0.5 text-sm text-gray-500">
            Manage, design, and version your organization's identification card templates
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              toast.info("Import", "Import from Adobe Illustrator, SVG, or PDF templates");
            }}
            icon={<Icon name="upload" className="h-4 w-4" />}
          >
            Import Template
          </Button>
          {profile?.role === "admin" && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowResetConfirm(true)}
              icon={<Icon name="refresh" className="h-4 w-4" />}
            >
              Reset Default
            </Button>
          )}
          <Button
            size="sm"
            onClick={() => setShowCreateModal(true)}
            icon={<Icon name="plus" className="h-4 w-4" />}
          >
            Create Template
          </Button>
        </div>
      </div>

      {/* ─── Template Grid ───────────────────────────────── */}
      <div className="grid gap-4 md:grid-cols-2">
        {CATALOG.map((t) => (
          <TemplateCardComponent
            key={t.id}
            template={t}
            isCurrent={t.id === template.id}
            activeVersion={template.version}
            onEdit={() => navigate("/app/id-card/designer")}
            onPreview={() => navigate("/app/id-card/preview")}
            onDuplicate={() => {
              toast.success(
                "Template Duplicated",
                `${t.name} copy created as new draft`
              );
            }}
            onReset={() => setShowResetConfirm(true)}
          />
        ))}
      </div>

      {/* ─── Version History ─────────────────────────────── */}
      <VersionHistory template={template} />

      {/* ─── Create Template Modal ───────────────────────── */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm animate-fade-in">
          <div className="mx-4 w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl animate-slide-up">
            <div className="flex items-center gap-3 mb-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-100">
                <Icon name="plus" className="h-5 w-5 text-emerald-600" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-gray-900">Create New Template</h3>
                <p className="text-sm text-gray-500">Design a new identification card template</p>
              </div>
            </div>

            <div className="space-y-4 mt-6">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                  Template Name
                </label>
                <input
                  type="text"
                  placeholder="e.g., Guest Pass, Student ID..."
                  className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none transition-all focus:border-emerald-400 focus:ring-2 focus:ring-emerald-500/10"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                  Start From
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button className="rounded-xl border-2 border-emerald-200 bg-emerald-50 p-3 text-left transition-all hover:border-emerald-400">
                    <div className="flex items-center gap-2 mb-1">
                      <Icon name="credit-card" className="h-4 w-4 text-emerald-600" />
                      <span className="text-xs font-semibold text-emerald-800">Blank Canvas</span>
                    </div>
                    <p className="text-[11px] text-emerald-600">Start from scratch</p>
                  </button>
                  <button className="rounded-xl border-2 border-gray-200 bg-white p-3 text-left transition-all hover:border-emerald-400 hover:bg-emerald-50/50">
                    <div className="flex items-center gap-2 mb-1">
                      <Icon name="credit-card" className="h-4 w-4 text-gray-400" />
                      <span className="text-xs font-semibold text-gray-700">Duplicate Active</span>
                    </div>
                    <p className="text-[11px] text-gray-500">Clone current template</p>
                  </button>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 mt-6 pt-4 border-t border-gray-100">
              <button
                onClick={() => setShowCreateModal(false)}
                className="rounded-xl px-4 py-2 text-sm font-semibold text-gray-600 hover:bg-gray-100 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setShowCreateModal(false);
                  navigate("/app/id-card/designer");
                }}
                className="rounded-xl bg-emerald-600 px-4 py-2 text-sm font-semibold text-white shadow-sm shadow-emerald-500/20 hover:bg-emerald-700 hover:shadow-md transition-all active:scale-95"
              >
                Create Template
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ─── Reset Confirmation ──────────────────────────── */}
      {showResetConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm animate-fade-in">
          <div className="mx-4 w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl animate-slide-up">
            <div className="flex items-center gap-3 mb-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-100">
                <Icon name="alert-triangle" className="h-5 w-5 text-amber-600" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-gray-900">Reset to Default?</h3>
                <p className="text-sm text-gray-500">
                  This will restore the official system template. All customizations will be lost.
                </p>
              </div>
            </div>

            <div className="flex justify-end gap-2 mt-6 pt-4 border-t border-gray-100">
              <button
                onClick={() => setShowResetConfirm(false)}
                className="rounded-xl px-4 py-2 text-sm font-semibold text-gray-600 hover:bg-gray-100 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleReset}
                className="rounded-xl bg-amber-500 px-4 py-2 text-sm font-semibold text-white shadow-sm shadow-amber-500/20 hover:bg-amber-600 hover:shadow-md transition-all active:scale-95"
              >
                Reset to Default
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
