import Loader from "@/components/Loader";

export function Spinner({
  className,
  label,
}: {
  size?: string;
  className?: string;
  label?: string;
}) {
  return (
    <span role="status" aria-label={label ?? "Loading"} className={className ?? ""}>
      <Loader />
    </span>
  );
}
