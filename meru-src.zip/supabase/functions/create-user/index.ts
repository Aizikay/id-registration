// =============================================================================
// Edge Function: create-user
//
// Staff account provisioning requires the Supabase Admin API, which needs the
// service-role key. That key must NEVER live in the frontend — so user
// creation is executed here, server-side, and gated to administrators only.
//
// Deploy:
//   supabase functions deploy create-user --no-verify-jwt=false
// =============================================================================

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const VALID_ROLES = new Set(["admin", "officer", "supervisor", "viewer"]);

interface CreateUserPayload {
  email: string;
  password: string;
  full_name: string;
  staff_number: string;
  role: string;
  department?: string;
  phone?: string;
}

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" }
  });

Deno.serve(async (req: Request) => {
  if (req.method !== "POST") {
    return json({ error: "Method not allowed" }, 405);
  }

  // The Authorization header carries the caller's JWT (anon key session).
  const authHeader = req.headers.get("Authorization");
  if (!authHeader) {
    return json({ error: "Missing authorization header" }, 401);
  }

  const adminClient = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
    { auth: { autoRefreshToken: false, persistSession: false } }
  );

  // 1. Verify caller identity via their JWT.
  {
    const verifyClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      { global: { headers: { Authorization: authHeader } } }
    );
    const { data, error } = await verifyClient.auth.getUser();
    if (error || !data.user) {
      return json({ error: "Unauthorized" }, 401);
    }

    // 2. Caller must be an ACTIVE ADMIN.
    const { data: profile, error: profileError } = await adminClient
      .from("profiles")
      .select("role, status")
      .eq("user_id", data.user.id)
      .single();

    if (profileError || !profile || profile.role !== "admin" || profile.status !== "active") {
      return json({ error: "Forbidden — administrator access required" }, 403);
    }
  }

  // 3. Validate payload.
  let payload: CreateUserPayload;
  try {
    payload = await req.json();
  } catch {
    return json({ error: "Invalid JSON body" }, 400);
  }

  const { email, password, full_name, staff_number, role } = payload;
  if (!email || !password || !full_name || !staff_number || !role) {
    return json({ error: "email, password, full_name, staff_number and role are required" }, 400);
  }
  if (password.length < 10) {
    return json({ error: "Password must be at least 10 characters" }, 400);
  }
  if (!VALID_ROLES.has(role)) {
    return json({ error: `role must be one of: ${[...VALID_ROLES].join(", ")}` }, 400);
  }
  if (!/^STAFF-[0-9]{3,6}$/.test(staff_number)) {
    return json({ error: "staff_number must match STAFF-<3..6 digits>" }, 400);
  }

  // 4. Create the auth user with metadata consumed by handle_new_user().
  const { data: created, error: createError } = await adminClient.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
    phone: payload.phone || undefined,
    user_metadata: {
      full_name,
      staff_number,
      role,
      department: payload.department ?? null
    }
  });

  if (createError || !created.user) {
    const msg =
      createError?.message.includes("already registered")
        ? "A user with this email already exists"
        : createError?.message ?? "User creation failed";
    return json({ error: msg }, 409);
  }

  return json({
    user: { id: created.user.id, email: created.user.email },
    message: `Staff account created for ${full_name} (${staff_number})`
  });
});
