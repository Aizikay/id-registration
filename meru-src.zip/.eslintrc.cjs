module.exports = {
  root: true,
  env: { browser: true, es2022: true },
  extends: [
    "eslint:recommended",
    "plugin:@typescript-eslint/recommended",
    "plugin:react-hooks/recommended"
  ],
  ignorePatterns: ["dist", "print-agent", "coverage", "node_modules", "supabase/functions"],
  parser: "@typescript-eslint/parser",
  parserOptions: {
    ecmaVersion: "latest",
    sourceType: "module",
    project: ["./tsconfig.json", "./tsconfig.node.json"]
  },
  plugins: ["react-refresh"],
  rules: {
    "@typescript-eslint/no-unused-vars": [
      "error",
      { argsIgnorePattern: "^_", varsIgnorePattern: "^_" }
    ],
    "@typescript-eslint/consistent-type-imports": ["warn", { prefer: "type-imports" }],
    "react-refresh/only-export-components": [
      "warn",
      { allowConstantExport: true }
    ],
    "no-console": ["warn", { allow: ["warn", "error"] }]
  },
  overrides: [
    {
      files: ["src/test/**/*", "**/*.test.ts", "**/*.test.tsx", "**/*.spec.ts"],
      env: { node: true },
      rules: {
        "@typescript-eslint/no-non-null-assertion": "off",
        "@typescript-eslint/no-explicit-any": "off"
      }
    },
    {
      files: [
        "src/components/ui/toast.tsx",
        "src/contexts/ThemeContext.tsx",
        "src/features/auth/auth-context.tsx",
        "src/features/id-card/editor/IdCanvas.tsx",
        "src/features/sync/connection-indicator.tsx"
      ],
      rules: { "react-refresh/only-export-components": "off" }
    },
    {
      files: ["src/types/database.ts"],
      rules: { "@typescript-eslint/consistent-type-imports": "off" }
    }
  ]
};
