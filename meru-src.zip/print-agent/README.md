# Meru Print Agent

Localhost-only HTTP service that drives Windows printers for the Meru District Council ID Registry. It runs on each officer's Windows workstation and is the only component allowed to talk to the physical printer; the web app never accesses printers directly.

## Architecture

```
Browser (meru-id-registry)  ──fetch──>  http://127.0.0.1:8377  (this agent)  ──Windows spooler──>  Printer
                               Origin allowlist enforced here
                               Idempotency by idempotency_key
```

## Security

- Binds to `127.0.0.1` only — never exposed to the LAN.
- Validates `Origin` against an allowlist:
  - `localhost` / `127.0.0.1` on any port (dev)
  - `*.vercel.app` / `*.netlify.app` (deployed frontends)
  - Extra origins via `ALLOWED_ORIGINS` env (comma-separated exact matches)
- Rejects any request missing required fields (`document_reference`, `issuance_reference`, `idempotency_key`, `printer_id`, `person_name`, `identification_number`) with `400`.
- Persists jobs and idempotency keys to `print-agent/state.json` so a replay of the same `idempotency_key` returns the original `job_id` without re-printing.

## Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/` , `/health` | Liveness probe — `{ok, service, version, device_id}` |
| GET | `/status` | Agent version, device id, discovered printers |
| GET | `/printers` | Printer list alias |
| POST | `/test` | Test page — body `{printer_id, requested_by?}` |
| POST | `/print` | ID card — body `PrintJobRequest & {requested_by?}` |
| GET | `/jobs/:id` | Poll job `{ok, job_id, status, error_message, pages_printed}` |

`GET /status` response shape matches `src/printing/agent-client.ts#AgentStatus`:
```json
{ "ok": true, "agent_version": "1.0.0", "device_id": "WS-…", "printers": [{ "id": "…", "name": "…", "is_default": true, "status": "online" }] }
```

## Installation (Windows 10/11)

1. Install Node.js 20+ (https://nodejs.org).
2. From the project root:
   ```powershell
   npm --prefix print-agent install
   npm --prefix print-agent run build
   ```
3. (Optional) Set environment overrides in `print-agent/.env` or system env:
   ```ini
   PRINT_AGENT_PORT=8377
   PRINT_AGENT_HOST=127.0.0.1
   ALLOWED_ORIGINS=https://your-production-domain.go.tz
   PRINT_AGENT_DRY_RUN=false
   ```
4. Start the agent:
   ```powershell
   npm --prefix print-agent start
   # or: node print-agent/dist/index.js
   ```
   Keep this window open while using the registry. For production, register it as a Windows Service (e.g. via `nssm` or Task Scheduler on logon).

5. Verify:
   ```powershell
   curl http://127.0.0.1:8377/status
   curl -X POST http://127.0.0.1:8377/test -H "Content-Type: application/json" -d "{\"printer_id\":\"mock-council-printer-1\"}"
   ```

## Printer discovery

On startup each `/status` call discovers printers via:
1. `powershell Get-Printer | ConvertTo-Json` (preferred)
2. `wmic printer get … /format:csv` (fallback)
3. Two mock printers (when neither is available — CI/non-Windows)

The UI lists these printers in the issuance flow and the Printers admin page. The agent resolves `printer_id` by slug or exact name.

## Printing

`POST /print` renders a self-contained ID card HTML (inline styles, no external assets, `window.print()` on load) to a temp file and dispatches it via:
1. `powershell Start-Process -Verb Print`
2. fallback `rundll32 mshtml.dll,PrintHTML`
3. fallback `print /D:`

Set `PRINT_AGENT_DRY_RUN=true` to simulate success without touching the spooler (useful in CI).

All jobs are persisted to `state.json` (`deviceId`, `jobs`, `idempotency` map) so a browser retry with the same `idempotency_key` is idempotent.

## Device identity

The agent reuses the browser's workstation `device_id` (`WS-<16 hex>`) when present, and otherwise generates its own `WS-…` stored in `state.json`. This id is surfaced in `/status` and attached to print jobs for audit traceability.

## Troubleshooting

- **Agent unreachable** from the browser: ensure the agent is running and Windows Firewall allows loopback on port 8377.
- **Blocked by Origin**: add the frontend origin to `ALLOWED_ORIGINS`.
- **Printer not found**: check `GET /status` — the printer name/id must match exactly; mock printers are available even without hardware for testing.
- **Print dispatched but nothing prints**: verify the printer is online in Windows Settings → Printers, set it as Default, and try the Test Page first.

## Logs & state

- State: `print-agent/state.json` (gitignored)
- Logs: stdout with ISO timestamps; redirect to `print-agent/logs/agent.log` if running as a service.
