$tcp = Get-NetTCPConnection -LocalPort 5174 -ErrorAction SilentlyContinue
if ($tcp) {
  $pid = $tcp.OwningProcess
  Write-Output "Killing PID $pid on port 5174"
  Stop-Process -Id $pid -Force -ErrorAction SilentlyContinue
  Write-Output "Killed"
} else {
  Write-Output "Port 5174 is free"
}
