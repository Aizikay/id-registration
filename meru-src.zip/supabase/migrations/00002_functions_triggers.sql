-- ============================================================================
-- Migration 00002: Helper functions, triggers, issuance RPC
-- ============================================================================

-- ---------------------------------------------------------------------------
-- Role lookup usable inside RLS policies (avoids recursive policy scans)
-- ---------------------------------------------------------------------------
create or replace function public.auth_profile_role()
returns public.user_role
language sql
stable
security definer
set search_path = public
as $$
  select p.role from public.profiles p
  where p.user_id = auth.uid() and p.status = 'active'
  limit 1;
$$;

create or replace function public.auth_profile_id()
returns uuid
language sql
stable
security definer
set search_path = public
as $$
  select p.id from public.profiles p
  where p.user_id = auth.uid() and p.status = 'active'
  limit 1;
$$;

create or replace function public.auth_staff_number()
returns text
language sql
stable
security definer
set search_path = public
as $$
  select p.staff_number from public.profiles p
  where p.user_id = auth.uid() and p.status = 'active'
  limit 1;
$$;

grant execute on function public.auth_profile_role() to authenticated;
grant execute on function public.auth_profile_id() to authenticated;
grant execute on function public.auth_staff_number() to authenticated;

-- ---------------------------------------------------------------------------
-- Auto-create a profile when an auth user is created.
-- Role/staff_number are taken from user metadata set during account
-- provisioning (admin flow). Default role: viewer (least privilege).
-- ---------------------------------------------------------------------------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (user_id, staff_number, full_name, phone, role, department)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'staff_number', 'STAFF-' || lpad((floor(random()*900)+100)::text, 3, '0')),
    coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)),
    new.phone,
    coalesce((new.raw_user_meta_data->>'role')::public.user_role, 'viewer'),
    new.raw_user_meta_data->>'department'
  )
  on conflict (user_id) do nothing;
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------------------
-- Auto-create an active identification record when a person is registered.
-- ---------------------------------------------------------------------------
create or replace function public.create_initial_identification_record()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.identification_records (person_id, identification_number, status)
  values (new.id, new.identification_number, 'active');
  return new;
end;
$$;

create trigger trg_person_created_identification
  after insert on public.persons
  for each row execute function public.create_initial_identification_record();

-- ---------------------------------------------------------------------------
-- ISSUANCE TRANSACTION (RPC)
--
-- Called by the web app (online) and by the sync engine (offline-originated).
-- Enforces in one atomic transaction:
--   1. Caller is an active officer/admin.
--   2. Person exists.
--   3. No already-issued ID exists  -> duplicate blocked.
--   4. Idempotency: same idempotency_key returns the original record.
--   5. Race safety via the partial unique index (one occupying record).
--   6. Writes an audit log row in the same transaction.
-- ---------------------------------------------------------------------------
create or replace function public.issue_id(
  p_person_id uuid,
  p_identification_record_id uuid,
  p_issuance_reference text,
  p_idempotency_key text,
  p_printer_id uuid default null,
  p_workstation_device_id uuid default null,
  p_print_job_reference text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_profile       public.profiles%rowtype;
  v_existing      public.issuance_records%rowtype;
  v_created       public.issuance_records%rowtype;
  v_person        public.persons%rowtype;
  v_now           timestamptz := now();
begin
  -- 1. Authorization ------------------------------------------------------
  select * into v_profile from public.profiles
    where user_id = auth.uid() and status = 'active' limit 1;
  if not found then
    raise exception 'unauthorized: no active profile for this session'
      using errcode = '42501';
  end if;
  if v_profile.role not in ('officer','admin') then
    raise exception 'forbidden: role % may not issue IDs', v_profile.role
      using errcode = '42501';
  end if;

  -- 2. Idempotent replay ---------------------------------------------------
  select * into v_existing from public.issuance_records
    where idempotency_key = p_idempotency_key limit 1;
  if found then
    return jsonb_build_object(
      'status', 'idempotent_replay',
      'record', to_jsonb(v_existing),
      'message', 'This issuance was already processed.'
    );
  end if;

  -- 3. Person must exist ---------------------------------------------------
  select * into v_person from public.persons where id = p_person_id limit 1;
  if not found then
    raise exception 'person_not_found: %', p_person_id using errcode = 'P0002';
  end if;

  -- 4. Duplicate check -----------------------------------------------------
  select * into v_existing from public.issuance_records
    where person_id = p_person_id
      and status in ('pending','printing','issued','reprint_requested')
    order by created_at desc limit 1;
  if found then
    if v_existing.status = 'issued' then
      -- audit the blocked attempt
      insert into public.audit_logs (actor_user_id, actor_staff_number, action, entity_type, entity_id, metadata, workstation_id)
      values (v_profile.id, v_profile.staff_number, 'issuance.duplicate_blocked',
              'person', p_person_id::text,
              jsonb_build_object('existing_reference', v_existing.issuance_reference),
              p_workstation_device_id::text);
      raise exception 'already_issued: identification number % was issued at % (ref %)',
        v_person.identification_number, coalesce(v_existing.issued_at::text,'unknown'),
        v_existing.issuance_reference using errcode = 'P0001';
    else
      raise exception 'issuance_in_progress: person has an active issuance (ref %)',
        v_existing.issuance_reference using errcode = 'P0001';
    end if;
  end if;

  -- 5. Create the issuance -------------------------------------------------
  -- The partial unique index makes concurrent attempts serialize here:
  -- exactly one transaction wins; others receive a unique-violation.
  insert into public.issuance_records (
    person_id, identification_record_id, issuance_reference,
    issued_by, issued_by_staff_number, issued_at,
    printer_id, workstation_id, print_job_id,
    status, idempotency_key
  ) values (
    p_person_id, p_identification_record_id, p_issuance_reference,
    v_profile.id, v_profile.staff_number, v_now,
    p_printer_id, p_workstation_device_id, p_print_job_reference,
    'issued', p_idempotency_key
  )
  returning * into v_created;

  -- 6. Audit within the same transaction ------------------------------------
  insert into public.audit_logs (actor_user_id, actor_staff_number, action, entity_type, entity_id, metadata, workstation_id)
  values (
    v_profile.id, v_profile.staff_number,
    case when p_print_job_reference is null then 'issuance.requested' else 'issuance.issued' end,
    'issuance_record', v_created.id::text,
    jsonb_build_object(
      'reference', v_created.issuance_reference,
      'identification_number', v_person.identification_number,
      'printer_id', p_printer_id,
      'print_job_reference', p_print_job_reference
    ),
    p_workstation_device_id::text
  );

  return jsonb_build_object(
    'status', 'created',
    'record', to_jsonb(v_created)
  );
end;
$$;

grant execute on function public.issue_id(
  uuid, uuid, text, text, uuid, uuid, text
) to authenticated;

-- ---------------------------------------------------------------------------
-- Update issuance status (print pipeline callbacks) with transition rules.
-- Allowed transitions mirror src/lib/issuance-rules.ts.
-- Only the actor who owns the pending/printing record, admins, or supervisors
-- may move it. issued requires timestamp + actor.
-- ---------------------------------------------------------------------------
create or replace function public.update_issuance_status(
  p_issuance_id uuid,
  p_new_status text,
  p_failure_reason text default null,
  p_print_job_id text default null,
  p_printer_id uuid default null
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_profile     public.profiles%rowtype;
  v_current     public.issuance_records%rowtype;
  v_allowed     constant text[] := array[
    'pending|printing','pending|issued','pending|failed','pending|cancelled',
    'printing|issued','printing|failed','printing|cancelled',
    'failed|pending','failed|reprint_requested','failed|cancelled',
    'reprint_requested|printing','reprint_requested|failed','reprint_requested|cancelled'
  ];
begin
  select * into v_profile from public.profiles
    where user_id = auth.uid() and status = 'active' limit 1;
  if not found then
    raise exception 'unauthorized' using errcode = '42501';
  end if;
  if v_profile.role not in ('officer','supervisor','admin') then
    raise exception 'forbidden' using errcode = '42501';
  end if;

  select * into v_current from public.issuance_records where id = p_issuance_id limit 1;
  if not found then
    raise exception 'issuance_not_found: %', p_issuance_id using errcode = 'P0002';
  end if;

  if not (v_current.status || '|' || p_new_status) = any(v_allowed) then
    raise exception 'invalid_transition: % -> %', v_current.status, p_new_status
      using errcode = '23514';
  end if;

  update public.issuance_records set
    status = p_new_status::public.issuance_status,
    failure_reason = case when p_new_status = 'failed' then coalesce(p_failure_reason, 'unspecified') else failure_reason end,
    print_job_id = coalesce(p_print_job_id, print_job_id),
    printer_id = coalesce(p_printer_id, printer_id),
    issued_at = case when p_new_status = 'issued' then now() else issued_at end
  where id = p_issuance_id
  returning * into v_current;

  insert into public.audit_logs (actor_user_id, actor_staff_number, action, entity_type, entity_id, metadata)
  values (
    v_profile.id, v_profile.staff_number,
    case
      when p_new_status = 'issued' then 'issuance.issued'
      when p_new_status = 'failed' then 'print.failed'
      when p_new_status = 'reprint_requested' then 'print.reprint_requested'
      when p_new_status = 'cancelled' then 'issuance.cancelled'
      else 'print.completed'
    end,
    'issuance_record', v_current.id::text,
    jsonb_build_object(
      'from', v_current.status, 'to', p_new_status,
      'failure_reason', p_failure_reason,
      'reference', v_current.issuance_reference
    )
  );

  return jsonb_build_object('status', 'updated', 'record', to_jsonb(v_current));
end;
$$;

grant execute on function public.update_issuance_status(
  uuid, text, text, text, uuid
) to authenticated;

-- ---------------------------------------------------------------------------
-- Dashboard statistics aggregate (single round-trip)
-- ---------------------------------------------------------------------------
create or replace function public.get_dashboard_stats()
returns jsonb
language sql
stable
security definer
set search_path = public
as $$
  select jsonb_build_object(
    'total_registered', (select count(*) from public.persons),
    'total_issued', (select count(*) from public.issuance_records where status = 'issued'),
    'total_pending', (select count(*) from public.issuance_records where status in ('pending','printing','reprint_requested')),
    'total_failed_prints', (select count(*) from public.issuance_records where status = 'failed'),
    'today_issued', (select count(*) from public.issuance_records where status='issued' and issued_at >= date_trunc('day', now())),
    'online_devices', (select count(*) from public.workstation_devices where status='active' and last_online_at > now() - interval '15 minutes'),
    'printers_online', (select count(*) from public.printers where status='online' and enabled),
    'printers_total', (select count(*) from public.printers where enabled),
    'recent_issuances', (
      select coalesce(jsonb_agg(x), '[]'::jsonb) from (
        select i.issuance_reference, i.issued_at, i.status, pr.full_name as person_name,
               pr.identification_number, pf.staff_number as issued_by_staff
        from public.issuance_records i
        join public.persons pr on pr.id = i.person_id
        left join public.profiles pf on pf.id = i.issued_by
        order by coalesce(i.issued_at, i.created_at) desc
        limit 10
      ) x
    ),
    'daily_last_7_days', (
      select coalesce(jsonb_agg(x order by x.day), '[]'::jsonb) from (
        select d::date as day,
               (select count(*) from public.issuance_records
                 where status='issued' and issued_at >= d and issued_at < d + interval '1 day') as issued_count
        from generate_series(date_trunc('day', now()) - interval '6 days', date_trunc('day', now()), interval '1 day') d
      ) x
    )
  );
$$;

grant execute on function public.get_dashboard_stats() to authenticated;
