try {
  $r = Invoke-WebRequest -Uri 'http://localhost:5174/' -UseBasicParsing -TimeoutSec 5
  Write-Output "HTTP $($r.StatusCode)"
} catch {
  Write-Output "DOWN"
}
