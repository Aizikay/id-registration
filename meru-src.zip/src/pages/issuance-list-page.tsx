import { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { queryIssuancesOnline } from "@/services/issuance-service";
import { mapSupabaseError } from "@/services/errors";
import type { CachedIssuance } from "@/db/database";
import type { IssuanceStatus } from "@/types";
import { formatDate, formatTime, formatRelative } from "@/lib/format";
import { useAuth } from "@/features/auth/auth-context";
import { useToast } from "@/components/ui/toast";
import { cn } from "@/lib/cn";

/* ─── Types ──────────────────────────────────────────────────── */

type IssuanceRow = CachedIssuance & { persons?: { full_name: string } };

type DateFilter = "all" | "today" | "7d" | "30d" | "custom";

/* ─── Constants ──────────────────────────────────────────────── */

const PAGE_SIZES = [10, 25, 50] as const;

const STATUS_TABS: { id: string; label: string; color: string; count?: number }[] = [
  { id: "", label: "All", color: "gray" },
  { id: "issued", label: "Issued", color: "emerald" },
  { id: "pending", label: "Pending", color: "amber" },
  { id: "printing", label: "Printing", color: "blue" },
  { id: "failed", label: "Failed", color: "red" },
  { id: "cancelled", label: "Cancelled", color: "slate" },
  { id: "reprint_requested", label: "Reprint", color: "purple" },
];

const STATUS_STYLES: Record<string, { bg: string; text: string; ring: string; dot: string }> = {
  issued: { bg: "bg-emerald-50", text: "text-emerald-700", ring: "ring-emerald-200", dot: "bg-emerald-500" },
  pending: { bg: "bg-amber-50", text: "text-amber-700", ring: "ring-amber-200", dot: "bg-amber-500 animate-pulse" },
  printing: { bg: "bg-blue-50", text: "text-blue-700", ring: "ring-blue-200", dot: "bg-blue-500 animate-pulse" },
  failed: { bg: "bg-rose-50", text: "text-rose-700", ring: "ring-rose-200", dot: "bg-rose-500" },
  cancelled: { bg: "bg-gray-100", text: "text-gray-600", ring: "ring-gray-200", dot: "bg-gray-400" },
  reprint_requested: { bg: "bg-purple-50", text: "text-purple-700", ring: "ring-purple-200", dot: "bg-purple-500 animate-pulse" },
};

/* ─── Helpers ────────────────────────────────────────────────── */

function staffInitials(staffId: string | null): string {
  if (!staffId) return "?";
  const match = staffId.match(/(\d+)$/);
  return match?.[1]?.slice(-2).padStart(2, "0") ?? staffId.slice(-2);
}

function staffAvatarColor(staffId: string | null): string {
  const colors = ["from-slate-500 to-slate-700", "from-sky-500 to-sky-700", "from-indigo-500 to-indigo-700", "from-violet-500 to-violet-700"];
  if (!staffId) return colors[0]!;
  let h = 0;
  for (let i = 0; i < staffId.length; i++) h = staffId.charCodeAt(i) + ((h << 5) - h);
  return colors[Math.abs(h) % colors.length]!;
}

function formatTimestamp(iso: string | null): { date: string; time: string; relative: string } {
  if (!iso) return { date: "-", time: "-", relative: "-" };
  return {
    date: formatDate(iso),
    time: formatTime(iso),
    relative: formatRelative(iso),
  };
}

/* ─── Main Component ─────────────────────────────────────────── */

export function IssuanceListPage() {
  const navigate = useNavigate();
  const { online } = useAuth();
  const toast = useToast();
  const searchRef = useRef<HTMLInputElement>(null);

  // URL params
  const [params, setParams] = useSearchParams();
  const statusFromUrl = params.get("status") ?? "";

  // State
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [status, setStatus] = useState(statusFromUrl);
  const [dateFilter, setDateFilter] = useState<DateFilter>("all");
  const [customFrom] = useState("");
  const [customTo] = useState("");
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(25);
  const [rows, setRows] = useState<IssuanceRow[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [refreshNonce, setRefreshNonce] = useState(0);
  const [openMenu, setOpenMenu] = useState<string | null>(null);

  // Status counts (approximated from total and filtered)
  const [statusCounts, setStatusCounts] = useState<Record<string, number>>({});

  // Keyboard shortcut
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "/" && document.activeElement?.tagName !== "INPUT") {
        e.preventDefault();
        searchRef.current?.focus();
      }
      if (e.key === "Escape") setOpenMenu(null);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  // Debounce search
  useEffect(() => {
    const t = window.setTimeout(() => {
      setDebouncedSearch(search.trim());
      setPage(0);
    }, 300);
    return () => window.clearTimeout(t);
  }, [search]);

  // Status filter from URL
  useEffect(() => {
    setStatus(statusFromUrl);
    setPage(0);
  }, [statusFromUrl]);

  // Reset page on filter change
  useEffect(() => { setPage(0); }, [dateFilter, customFrom, customTo]);

  // Build date range
  const getDateRange = useCallback((): { from?: string; to?: string } => {
    const now = new Date();
    if (dateFilter === "today") {
      const start = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      return { from: start.toISOString(), to: now.toISOString() };
    }
    if (dateFilter === "7d") {
      const start = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      return { from: start.toISOString(), to: now.toISOString() };
    }
    if (dateFilter === "30d") {
      const start = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      return { from: start.toISOString(), to: now.toISOString() };
    }
    if (dateFilter === "custom" && customFrom) {
      return {
        from: new Date(customFrom).toISOString(),
        to: customTo ? new Date(`${customTo}T23:59:59`).toISOString() : undefined,
      };
    }
    return {};
  }, [dateFilter, customFrom, customTo]);

  // Fetch data
  useEffect(() => {
    if (!online) {
      setError("The issuance register requires connectivity. Offline records are available on each person's profile.");
      setLoading(false);
      setRows([]);
      return;
    }

    let cancelled = false;
    setLoading(true);
    setError(null);
    const { from, to } = getDateRange();

    queryIssuancesOnline({
      page,
      pageSize,
      status: (status || undefined) as IssuanceStatus | undefined,
      from,
      to,
      search: debouncedSearch || undefined,
    })
      .then((r) => {
        if (cancelled) return;
        setRows(r.rows);
        setTotal(r.total);

        // Build status counts from first page (approximate)
        const counts: Record<string, number> = {};
        for (const row of r.rows) {
          counts[row.status] = (counts[row.status] || 0) + 1;
        }
        setStatusCounts(counts);
      })
      .catch((err) => {
        if (!cancelled) setError(mapSupabaseError(err).userMessage);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => { cancelled = true; };
  }, [page, pageSize, status, debouncedSearch, online, getDateRange, refreshNonce]);

  // Export CSV
  const exportCSV = () => {
    const header = "Reference,Person,ID Number,Status,Issued By,Issued At,Created\n";
    const body = rows.map((r) => {
      const name = r.persons?.full_name ?? r.person_name ?? "";
      const idNum = r.identification_number ?? "";
      return `"${r.issuance_reference}","${name}","${idNum}","${r.status}","${r.issued_by_staff_number ?? ""}","${r.issued_at ?? ""}","${r.created_at}"`;
    }).join("\n");
    const blob = new Blob([header + body], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `issuance-register-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Exported", `${rows.length} records exported`);
  };

  // Copy reference
  const copyRef = (ref: string, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(ref).then(() => {
      toast.success("Copied", `${ref} copied to clipboard`);
    });
  };

  const setFilter = (value: string) => {
    if (value) params.set("status", value);
    else params.delete("status");
    setParams(params, { replace: true });
  };

  const totalPages = Math.max(Math.ceil(total / pageSize), 1);
  const startItem = total === 0 ? 0 : page * pageSize + 1;
  const endItem = Math.min((page + 1) * pageSize, total);

  return (
    <div className="space-y-4 animate-fade-in">
      {/* ─── Page Header ─────────────────────────────────── */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-900 dark:text-slate-100">
            ID Issuance Register
          </h1>
          <p className="mt-0.5 text-sm text-gray-500 dark:text-slate-400">
            {online
              ? "Immutable audit log with staff and device attribution"
              : "Offline — showing local records only"}
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={exportCSV}
          disabled={loading || rows.length === 0}
          icon={<svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3" /></svg>}
        >
          Export Log
        </Button>
      </div>

      {/* ─── Metric Pills ────────────────────────────────── */}
      <div className="flex flex-wrap gap-2">
        {STATUS_TABS.map((tab) => {
          const isActive = status === tab.id;
          const count = tab.id === "" ? total : (statusCounts[tab.id] || 0);
          return (
            <button
              key={tab.id}
              onClick={() => setFilter(tab.id)}
              className={cn(
                "inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-semibold transition-all duration-200",
                isActive
                  ? `bg-${tab.color}-50 text-${tab.color}-700 border-${tab.color}-200 shadow-sm`
                  : "bg-white text-gray-500 border-gray-200 hover:bg-gray-50 hover:text-gray-700"
              )}
            >
              {isActive && (
                <span className={cn(
                  "h-1.5 w-1.5 rounded-full",
                  (STATUS_STYLES[tab.id] ?? { dot: 'bg-gray-400' }).dot
                )} />
              )}
              {tab.label}
              <span className={cn(
                "ml-0.5 rounded-full px-1.5 py-0.5 text-[10px] font-bold tabular-nums",
                isActive
                  ? `bg-${tab.color}-100/80 text-${tab.color}-600`
                  : "bg-gray-100 text-gray-500"
              )}>
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* ─── Filter Bar ──────────────────────────────────── */}
      <div className="rounded-2xl border border-gray-200/80 dark:border-slate-700/80 bg-white dark:bg-slate-800 shadow-sm">
        <div className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
          {/* Search */}
          <div className="relative flex-1">
            <svg className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
            </svg>
            <input
              ref={searchRef}
              type="text"
              placeholder="Search reference, name, or staff ID..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className={cn(
                "w-full rounded-xl border border-gray-200 dark:border-slate-600 bg-gray-50/50 dark:bg-slate-900/50 py-2.5 pl-10 pr-10",
                "text-sm text-gray-900 dark:text-slate-100 placeholder-gray-400 dark:placeholder-slate-500",
                "outline-none transition-all duration-200",
                "focus:border-emerald-400 focus:bg-white dark:focus:bg-slate-800 focus:ring-2 focus:ring-emerald-500/10"
              )}
            />
            {search && (
              <button
                onClick={() => setSearch("")}
                className="absolute right-2 top-1/2 -translate-y-1/2 rounded-md p-1 text-gray-400 transition-colors hover:bg-gray-100 hover:text-gray-600"
              >
                <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            )}
          </div>

          {/* Keyboard hint */}
          {!search && (
            <kbd className="hidden lg:inline-flex h-5 items-center rounded border border-gray-200 dark:border-slate-600 bg-gray-50 dark:bg-slate-900 px-1.5 font-mono text-[10px] text-gray-400 dark:text-slate-500">
              /
            </kbd>
          )}

          {/* Date filter */}
          <div className="flex items-center gap-1">
            {(["all", "today", "7d", "30d"] as DateFilter[]).map((d) => (
              <button
                key={d}
                onClick={() => setDateFilter(d)}
                className={cn(
                  "rounded-lg px-2.5 py-1.5 text-xs font-medium transition-all duration-200",
                  dateFilter === d
                    ? "bg-gray-900 dark:bg-slate-100 text-white dark:text-slate-900 shadow-sm"
                    : "text-gray-500 dark:text-slate-400 hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-700 dark:hover:text-slate-200"
                )}
              >
                {d === "all" ? "All" : d === "today" ? "Today" : d === "7d" ? "7 Days" : "30 Days"}
              </button>
            ))}
          </div>

          {/* Page size */}
          <select
            value={pageSize}
            onChange={(e) => { setPageSize(Number(e.target.value)); setPage(0); }}
            className="rounded-lg border border-gray-200 dark:border-slate-600 bg-white dark:bg-slate-800 px-3 py-2 text-xs font-medium text-gray-600 dark:text-slate-300 outline-none focus:border-emerald-400"
          >
            {PAGE_SIZES.map((s) => (
              <option key={s} value={s}>{s} / page</option>
            ))}
          </select>
        </div>
      </div>

      {/* ─── Data Table ──────────────────────────────────── */}
      {error && (
        <div className="flex items-start justify-between gap-4 rounded-2xl border border-red-200 dark:border-red-900/50 bg-red-50 dark:bg-red-950/30 px-4 py-3">
          <div className="flex items-start gap-3">
            <svg className="mt-0.5 h-5 w-5 shrink-0 text-red-500" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />
            </svg>
            <div>
              <p className="text-sm font-semibold text-red-700 dark:text-red-400">
                Could not load the issuance register
              </p>
              <p className="mt-0.5 text-xs text-red-600/90 dark:text-red-400/80">{error}</p>
            </div>
          </div>
          <button
            onClick={() => { setRefreshNonce((n) => n + 1); setError(null); }}
            className="inline-flex items-center rounded-lg border border-red-200 dark:border-red-900/50 bg-white dark:bg-slate-800 px-2.5 py-1.5 text-xs font-semibold text-red-600 dark:text-red-400 transition-colors hover:bg-red-50 dark:hover:bg-red-950/40"
          >
            Retry
          </button>
        </div>
      )}
      <div className="rounded-2xl border border-gray-200/80 dark:border-slate-700/80 bg-white dark:bg-slate-800 shadow-sm overflow-visible">
        <div className="overflow-x-auto overflow-y-visible">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-100 dark:border-slate-700 bg-gray-50/80 dark:bg-slate-900/50">
                <th className="px-5 py-3 text-left text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:text-slate-400">
                  Reference
                </th>
                <th className="px-5 py-3 text-left text-[11px] font-semibold uppercase tracking-wider text-gray-500">
                  Recipient
                </th>
                <th className="px-5 py-3 text-left text-[11px] font-semibold uppercase tracking-wider text-gray-500">
                  Status
                </th>
                <th className="px-5 py-3 text-left text-[11px] font-semibold uppercase tracking-wider text-gray-500">
                  Issued By
                </th>
                <th className="px-5 py-3 text-left text-[11px] font-semibold uppercase tracking-wider text-gray-500">
                  Date &amp; Time
                </th>
                <th className="w-16 px-5 py-3 text-right text-[11px] font-semibold uppercase tracking-wider text-gray-500">
                  Actions
                </th>
              </tr>
            </thead>

            <tbody className="divide-y divide-gray-100/80 dark:divide-slate-700/50">
              {loading ? (
                [...Array(pageSize < 10 ? pageSize : 10)].map((_, i) => (
                  <tr key={i} className="border-b border-gray-50">
                    {[120, 140, 80, 100, 130, 50].map((w, c) => (
                      <td key={c} className="px-5 py-3.5">
                        <div className="h-4 rounded bg-gray-100 dark:bg-slate-700 animate-pulse" style={{ width: w }} />
                      </td>
                    ))}
                  </tr>
                ))
              ) : rows.length === 0 ? (
                <tr>
                  <td colSpan={6}>
                    <div className="flex flex-col items-center justify-center gap-4 py-16">
                      {error ? (
                        <>
                          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-red-50 dark:bg-red-950/40">
                            <svg className="h-7 w-7 text-red-400" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />
                            </svg>
                          </div>
                          <div className="text-center">
                            <p className="text-sm font-medium text-red-600 dark:text-red-400">
                              Register query failed
                            </p>
                            <p className="mt-1 max-w-md text-xs text-gray-400 dark:text-slate-500">
                              {error}
                            </p>
                          </div>
                        </>
                      ) : (
                        <>
                          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gray-100 dark:bg-slate-700">
                            <svg className="h-7 w-7 text-gray-300" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
                            </svg>
                          </div>
                          <div className="text-center">
                            <p className="text-sm font-medium text-gray-600 dark:text-slate-300">
                              {status || debouncedSearch ? "No matching records" : "No issuance records yet"}
                            </p>
                            <p className="mt-1 text-xs text-gray-400 dark:text-slate-500">
                              {status || debouncedSearch
                                ? "Try adjusting your filters or search terms."
                                : "Issue an ID from a person's profile to populate this register."}
                            </p>
                          </div>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ) : (
                rows.map((r, idx) => {
                  const st = STATUS_STYLES[r.status] || STATUS_STYLES.pending!;
                  const ts = formatTimestamp(r.issued_at ?? r.created_at);
                  const personName = r.persons?.full_name ?? r.person_name ?? "Unknown";
                  const isFailed = r.status === "failed";
                  const isPending = r.status === "pending";
                  const isPrinting = r.status === "printing";

                  return (
                    <tr
                      key={r.id}
                      className={cn(
                        "group relative z-0 transition-colors duration-100",
                        idx % 2 === 1 && "bg-gray-50/40 dark:bg-slate-800/40",
                        "hover:bg-emerald-50/30 dark:hover:bg-slate-700/40"
                      )}
                    >
                      {/* Reference — crisp monospace with copy */}
                      <td className="px-5 py-3.5">
                        <div className="group/ref flex items-center gap-1.5">
                          <span className="font-mono text-[13px] font-semibold tracking-wide text-gray-900 dark:text-slate-100">
                            {r.issuance_reference}
                          </span>
                          <button
                            onClick={(e) => copyRef(r.issuance_reference, e)}
                            className="opacity-0 group-hover/ref:opacity-100 rounded p-0.5 text-gray-400 dark:text-slate-500 transition-all hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-600 dark:hover:text-slate-300"
                            title="Copy reference"
                          >
                            <svg className="h-3 w-3" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" d="M15.666 3.888A2.25 2.25 0 0013.5 2.25h-3c-1.03 0-1.9.693-2.166 1.638m7.332 0c.055.194.084.4.084.612v0a.75.75 0 01-.75.75H9.75a.75.75 0 01-.75-.75v0c0-.212.03-.418.084-.612m7.332 0c.646.049 1.288.11 1.927.184 1.1.128 1.907 1.077 1.907 2.185V19.5a2.25 2.25 0 01-2.25 2.25H6.75A2.25 2.25 0 014.5 19.5V6.257c0-1.108.806-2.057 1.907-2.185a48.208 48.208 0 011.927-.184" />
                            </svg>
                          </button>
                        </div>
                      </td>

                      {/* Recipient */}
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-3">
                          <div className={cn(
                            "flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br text-[11px] font-bold text-white shadow-sm",
                            staffAvatarColor(personName)
                          )}>
                            {personName.charAt(0).toUpperCase()}
                          </div>
                          <div className="min-w-0">
                            <p className="truncate font-medium text-gray-900 dark:text-slate-100">{personName}</p>
                            {r.identification_number && (
                              <p className="font-mono text-[11px] text-gray-400 dark:text-slate-500">{r.identification_number}</p>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Status badge */}
                      <td className="px-5 py-3.5">
                        <span className={cn(
                          "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wide",
                          st.bg, st.text, st.ring
                        )}>
                          <span className={cn("h-1.5 w-1.5 rounded-full", st.dot)} />
                          {r.status.replace("_", " ")}
                        </span>
                        {r.failure_reason && (
                          <p className="mt-1 max-w-[200px] truncate text-[11px] text-rose-500" title={r.failure_reason}>
                            {r.failure_reason}
                          </p>
                        )}
                      </td>

                      {/* Issued by — avatar + staff ID */}
                      <td className="px-5 py-3.5">
                        {r.issued_by_staff_number ? (
                          <div className="flex items-center gap-2">
                            <div className={cn(
                              "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-gradient-to-br text-[9px] font-bold text-white",
                              staffAvatarColor(r.issued_by_staff_number)
                            )}>
                              {staffInitials(r.issued_by_staff_number)}
                            </div>
                            <span className="font-mono text-xs text-gray-600 dark:text-slate-400">
                              {r.issued_by_staff_number}
                            </span>
                          </div>
                        ) : (
                          <span className="text-xs text-gray-400 dark:text-slate-500">-</span>
                        )}
                      </td>

                      {/* Timestamp */}
                      <td className="px-5 py-3.5">
                        <div>
                          <p className="text-sm text-gray-700 dark:text-slate-300">{ts.date}</p>
                          <p className="text-[11px] text-gray-400 dark:text-slate-500">{ts.time}</p>
                        </div>
                      </td>

                      {/* Actions */}
                      <td className="relative z-10 px-5 py-3.5 text-right">
                        <div className="relative inline-block">
                          {isPending || isPrinting ? (
                            <button
                              onClick={() => navigate(`/app/id-card?person=${r.person_id}`)}
                              className="inline-flex items-center gap-1 rounded-lg bg-emerald-600 px-2.5 py-1.5 text-[11px] font-semibold text-white shadow-sm transition-all hover:bg-emerald-700 hover:shadow-md active:scale-95"
                            >
                              <svg className="h-3 w-3" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M6.72 13.829c-.24.03-.48.062-.72.096m.72-.096a42.415 42.415 0 0110.56 0m-10.56 0L6.34 18m10.94-4.171c.24.03.48.062.72.096m-.72-.096L17.66 18m0 0l.229 2.523a1.125 1.125 0 01-1.12 1.227H7.231c-.662 0-1.18-.568-1.12-1.227L6.34 18m11.318 0h1.091A2.25 2.25 0 0021 15.75V9.456c0-1.081-.768-2.015-1.837-2.175a48.055 48.055 0 00-1.913-.247M6.34 18H5.25A2.25 2.25 0 013 15.75V9.456c0-1.081.768-2.015 1.837-2.175a48.041 48.041 0 011.913-.247m0 0a48.337 48.337 0 0110.5 0m-10.5 0V5.625a2.25 2.25 0 012.25-2.25h5.25a2.25 2.25 0 012.25 2.25v2.154" />
                              </svg>
                              Print
                            </button>
                          ) : r.status === "issued" ? (
                            <button
                              onClick={() => navigate(`/app/id-card?person=${r.person_id}`)}
                              className="inline-flex items-center gap-1 rounded-lg border border-gray-200 dark:border-slate-600 bg-white dark:bg-slate-700 px-2.5 py-1.5 text-[11px] font-semibold text-gray-700 dark:text-slate-200 shadow-sm transition-all hover:bg-gray-50 dark:hover:bg-slate-600 hover:text-gray-900 dark:hover:text-slate-100 active:scale-95"
                            >
                              Reprint
                            </button>
                          ) : null}

                          {/* More actions */}
                          <button
                            onClick={() => setOpenMenu(openMenu === r.id ? null : r.id)}
                            className="ml-1 inline-flex h-7 w-7 items-center justify-center rounded-lg text-gray-400 dark:text-slate-500 transition-all duration-200 hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-600 dark:hover:text-slate-300"
                          >
                            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" d="M6.75 12a.75.75 0 11-1.5 0 .75.75 0 011.5 0zM12.75 12a.75.75 0 11-1.5 0 .75.75 0 011.5 0zM18.75 12a.75.75 0 11-1.5 0 .75.75 0 011.5 0z" />
                            </svg>
                          </button>

                          {/* Dropdown */}
                          {openMenu === r.id && (
                            <>
                              {/* Click-away backdrop */}
                              <div
                                className="fixed inset-0 z-40"
                                onClick={() => setOpenMenu(null)}
                              />
                              <div className="absolute right-0 top-full z-50 mt-1 w-56 rounded-xl border border-gray-200/80 dark:border-slate-600/80 bg-white/95 dark:bg-slate-800/95 backdrop-blur-md py-1.5 shadow-xl dark:shadow-2xl dark:shadow-black/40 animate-scale-in">
                                <button
                                  onClick={() => { setOpenMenu(null); navigate(`/app/id-card?person=${r.person_id}`); }}
                                  className="flex w-full items-center gap-2.5 px-3.5 py-2.5 text-sm text-gray-700 dark:text-slate-200 hover:bg-gray-100 dark:hover:bg-slate-700/60 transition-colors rounded-md mx-1 w-[calc(100%-8px)]"
                                >
                                  <svg className="h-4 w-4 text-gray-400 dark:text-slate-400" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
                                  </svg>
                                  View Full Record
                                </button>
                                {r.status === "issued" && (
                                  <button
                                    onClick={() => {
                                      setOpenMenu(null);
                                      navigator.clipboard.writeText(r.issuance_reference);
                                      toast.success("Copied", "Reference copied to clipboard");
                                    }}
                                    className="flex w-full items-center gap-2.5 px-3.5 py-2.5 text-sm text-gray-700 dark:text-slate-200 hover:bg-gray-100 dark:hover:bg-slate-700/60 transition-colors rounded-md mx-1 w-[calc(100%-8px)]"
                                  >
                                    <svg className="h-4 w-4 text-gray-400 dark:text-slate-400" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
                                      <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3" />
                                    </svg>
                                    Download Reference
                                  </button>
                                )}
                                {isFailed && (
                                  <>
                                    <div className="my-1.5 mx-3 border-t border-gray-200/60 dark:border-slate-600/60" />
                                    <button
                                      onClick={() => {
                                        setOpenMenu(null);
                                        navigate(`/app/id-card?person=${r.person_id}`);
                                      }}
                                      className="flex w-full items-center gap-2.5 px-3.5 py-2.5 text-sm text-amber-600 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-500/10 transition-colors rounded-md mx-1 w-[calc(100%-8px)]"
                                    >
                                      <svg className="h-4 w-4 text-amber-500 dark:text-amber-400" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z" />
                                      </svg>
                                      Flag Issue
                                    </button>
                                  </>
                                )}
                              </div>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* ─── Pagination Footer ──────────────────────────── */}
        {!loading && rows.length > 0 && (
          <div className="flex items-center justify-between border-t border-gray-100 dark:border-slate-700 bg-gray-50/50 dark:bg-slate-900/50 px-5 py-3">
            <p className="text-xs text-gray-500 dark:text-slate-400">
              Showing <span className="font-semibold text-gray-700 dark:text-slate-200">{startItem}</span>
              {" - "}
              <span className="font-semibold text-gray-700 dark:text-slate-200">{endItem}</span>
              {" of "}
              <span className="font-semibold text-gray-700 dark:text-slate-200">{total.toLocaleString()}</span>
              {" entries"}
            </p>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setPage(Math.max(0, page - 1))}
                disabled={page === 0}
                className="flex h-8 w-8 items-center justify-center rounded-lg border border-gray-200 dark:border-slate-600 text-gray-600 dark:text-slate-400 transition-all hover:bg-white dark:hover:bg-slate-700 hover:shadow-sm disabled:opacity-40 disabled:hover:bg-transparent"
              >
                <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5" />
                </svg>
              </button>
              {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => {
                const pageNum = totalPages <= 5 ? i : Math.max(0, Math.min(page - 2, totalPages - 5)) + i;
                return (
                  <button
                    key={pageNum}
                    onClick={() => setPage(pageNum)}
                    className={cn(
                      "flex h-8 w-8 items-center justify-center rounded-lg text-xs font-medium transition-all duration-200",
                      page === pageNum
                        ? "bg-emerald-600 text-white shadow-sm shadow-emerald-500/25"
                        : "text-gray-600 dark:text-slate-400 hover:bg-white dark:hover:bg-slate-700 hover:text-gray-900 dark:hover:text-slate-100"
                    )}
                  >
                    {pageNum + 1}
                  </button>
                );
              })}
              <button
                onClick={() => setPage(Math.min(totalPages - 1, page + 1))}
                disabled={page >= totalPages - 1}
                className="flex h-8 w-8 items-center justify-center rounded-lg border border-gray-200 dark:border-slate-600 text-gray-600 dark:text-slate-400 transition-all hover:bg-white dark:hover:bg-slate-700 hover:shadow-sm disabled:opacity-40 disabled:hover:bg-transparent"
              >
                <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
                </svg>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
