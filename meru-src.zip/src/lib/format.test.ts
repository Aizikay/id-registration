import { describe, it, expect } from "vitest";
import { formatDate, formatDateTime, formatRelative, humanize, calculateAge, formatNumber } from "./format";

describe("formatDate", () => {
  it("returns — for null/undefined/invalid", () => {
    expect(formatDate(null)).toBe("—");
    expect(formatDate(undefined)).toBe("—");
    expect(formatDate("not-a-date")).toBe("—");
  });
  it("formats ISO date in en-GB long form", () => {
    // 23 August 2026 spans months without locale ambiguity
    const out = formatDate("2026-08-23T00:00:00.000Z");
    expect(out).toMatch(/23.*August.*2026/);
  });
});

describe("formatDateTime", () => {
  it("combines date and time", () => {
    const out = formatDateTime("2026-08-23T14:30:00.000Z");
    expect(out).toMatch(/23.*August.*2026/);
    expect(out).toMatch(/\d{2}:\d{2}/);
  });
});

describe("formatRelative", () => {
  it("returns just now for very recent", () => {
    expect(formatRelative(new Date().toISOString())).toBe("just now");
  });
  it("returns min ago", () => {
    const fiveMinAgo = new Date(Date.now() - 5 * 60_000).toISOString();
    expect(formatRelative(fiveMinAgo)).toMatch(/5 min ago/);
  });
  it("returns — for null", () => expect(formatRelative(null)).toBe("—"));
});

describe("humanize", () => {
  it("converts snake_case to Title Case", () => {
    expect(humanize("print_failed")).toBe("Print Failed");
    expect(humanize("already_issued")).toBe("Already Issued");
    expect(humanize("REPRINT_REQUESTED")).toBe("Reprint Requested");
  });
});

describe("calculateAge", () => {
  it("returns null for invalid", () => expect(calculateAge("bad")).toBeNull());
  it("calculates age for a known DOB", () => {
    const dob = new Date();
    dob.setFullYear(dob.getFullYear() - 25);
    dob.setMonth(0);
    dob.setDate(1);
    const age = calculateAge(dob.toISOString().slice(0, 10));
    expect(age).toBeGreaterThanOrEqual(24);
    expect(age).toBeLessThanOrEqual(26);
  });
});

describe("formatNumber", () => {
  it("formats with commas", () => expect(formatNumber(1234567)).toBe("1,234,567"));
});
