/**
 * Cached identity of the signed-in staff member.
 *
 * Populated by AuthProvider on sign-in / token refresh and consumed by
 * services that need to stamp actor identity onto records (issuance,
 * people, devices, print agent).
 */

export const authProfileCache: {
  profileId: string | null;
  staffNumber: string | null;
} = {
  profileId: null,
  staffNumber: null
};
