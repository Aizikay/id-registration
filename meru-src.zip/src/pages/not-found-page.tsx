import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { AppFooter } from "@/components/branding/footer";
import { OrganizationHeader } from "@/components/branding/logo";
import { Icon } from "@/components/icons/icon";

export function NotFoundPage() {
  return (
    <div className="flex min-h-screen flex-col bg-slate-100">
      <div className="flex flex-1 flex-col items-center justify-center gap-6 px-4 text-center">
        <OrganizationHeader compact />
        <div className="rounded-2xl bg-white p-8 shadow-card">
          <div className="mx-auto mb-3 w-fit rounded-xl bg-amber-50 p-3 text-amber-600">
            <Icon name="alert-triangle" className="h-7 w-7" />
          </div>
          <h1 className="text-xl font-bold text-slate-900">404 — Page not found</h1>
          <p className="mt-1 text-sm text-slate-500">
            The page you requested does not exist in this system.
          </p>
          <Link to="/app" className="mt-5 inline-block">
            <Button>Go to dashboard</Button>
          </Link>
        </div>
        <AppFooter />
      </div>
    </div>
  );
}
