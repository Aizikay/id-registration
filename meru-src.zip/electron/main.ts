import { app, BrowserWindow, ipcMain, Menu, Tray, nativeImage, shell } from "electron";
import { createLogger } from "./logger";
import { listPrinters } from "./printer-discovery";
import { printJob, printPdf, renderPdfFromHtml } from "./print-service";
import { openDataFolder, backupNow, restoreBackup, getDataFolderPath, getAppPaths } from "./local-store";
import { resolveRendererRoot, isPackagedRuntime } from "./package";
import { checkForUpdates } from "./updater";
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { join } from "node:path";

const log = createLogger("main");

/**
 * Meru DC ID Registry — Electron desktop shell.
 *
 * - Production: loads the built renderer from dist/ (built with base:"./" so
 *   plain file:// URLs work — no custom protocol needed).
 * - Development (desktop:dev): loads the Vite dev server URL.
 * - Minimal typed IPC surface exposed through preload (contextIsolation on).
 */

let mainWindow: BrowserWindow | null = null;
let tray: Tray | null = null;
let quitting = false;

const DEV_SERVER_URL = process.env.VITE_DEV_SERVER_URL || "http://localhost:5174";

/* ─── Window state persistence (simple JSON in userData) ─────── */

interface WindowState {
  width?: number;
  height?: number;
  x?: number;
  y?: number;
  maximized?: boolean;
}

function stateFile(): string {
  return join(app.getPath("userData"), "window-state.json");
}

function loadWindowState(): WindowState {
  try {
    if (existsSync(stateFile())) {
      return JSON.parse(readFileSync(stateFile(), "utf8")) as WindowState;
    }
  } catch {
    // fall through
  }
  return {};
}

let saveStateTimer: NodeJS.Timeout | null = null;
function saveWindowState(): void {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  if (saveStateTimer) clearTimeout(saveStateTimer);
  saveStateTimer = setTimeout(() => {
    if (!mainWindow || mainWindow.isDestroyed()) return;
    try {
      const state: WindowState = {
        width: mainWindow.getBounds().width,
        height: mainWindow.getBounds().height,
        x: mainWindow.getBounds().x,
        y: mainWindow.getBounds().y,
        maximized: mainWindow.isMaximized(),
      };
      writeFileSync(stateFile(), JSON.stringify(state), "utf8");
    } catch {
      // ignore
    }
  }, 400);
}

/* ─── Renderer entry ─────────────────────────────────────────── */

function rendererUrl(): string {
  if (!isPackagedRuntime()) return DEV_SERVER_URL;
  // file:// of the built renderer (assets are relative — see vite base config)
  const indexHtml = join(resolveRendererRoot(), "index.html");
  return indexHtml;
}

function createMainWindow(): void {
  const state = loadWindowState();

  const win = new BrowserWindow({
    width: state.width ?? 1280,
    height: state.height ?? 800,
    minWidth: 1024,
    minHeight: 680,
    x: state.x,
    y: state.y,
    show: false,
    backgroundColor: "#0f172a",
    title: "Meru DC ID Registry — Halmashauri ya Wilaya ya Meru",
    autoHideMenuBar: true,
    webPreferences: {
      preload: join(__dirname, "preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      spellcheck: false,
    },
  });

  mainWindow = win;

  if (state.maximized) win.maximize();
  win.once("ready-to-show", () => win.show());

  win.on("resize", saveWindowState);
  win.on("move", saveWindowState);
  win.on("maximize", saveWindowState);
  win.on("unmaximize", saveWindowState);

  // Minimize-to-tray on close (quitting happens from tray menu / Cmd+Q).
  win.on("close", (e) => {
    if (!quitting) {
      e.preventDefault();
      win.hide();
    }
  });

  win.on("closed", () => {
    if (mainWindow === win) mainWindow = null;
  });

  // Security: deny popups and navigation away from the app shell.
  win.webContents.setWindowOpenHandler(() => ({ action: "deny" }));
  win.webContents.on("will-navigate", (e, url) => {
    const current = win.webContents.getURL();
    const sameOrigin = url.startsWith("file://") || url.startsWith(DEV_SERVER_URL);
    if (!sameOrigin && current) {
      log.warn(`Blocked navigation to ${url}`);
      e.preventDefault();
      void shell.openExternal(url);
    }
  });

  const url = rendererUrl();
  log.info(`Loading renderer: ${url}`);
  if (url.endsWith(".html") || url.startsWith("file://")) {
    void win.loadFile(url);
  } else {
    void win.loadURL(url);
  }
}

/* ─── Tray ───────────────────────────────────────────────────── */

function createTray(): void {
  try {
    const iconPath = join(resolveRendererRoot(), "branding", "meru-logo.jpeg");
    const icon = nativeImage.createFromPath(iconPath).resize({ width: 16, height: 16 });
    tray = new Tray(icon.isEmpty() ? nativeImage.createEmpty() : icon);
    tray.setToolTip("Meru DC ID Registry");
    tray.setContextMenu(
      Menu.buildFromTemplate([
        {
          label: "Open Meru DC ID Registry",
          click: () => {
            if (mainWindow) {
              mainWindow.show();
              mainWindow.focus();
            } else {
              createMainWindow();
            }
          },
        },
        { type: "separator" },
        {
          label: "Quit",
          click: () => {
            quitting = true;
            app.quit();
          },
        },
      ])
    );
    tray.on("double-click", () => {
      if (mainWindow) {
        mainWindow.show();
        mainWindow.focus();
      }
    });
  } catch (err) {
    log.warn(`Tray not created: ${err instanceof Error ? err.message : String(err)}`);
  }
}

/* ─── IPC surface (validated, minimal) ───────────────────────── */

function asString(v: unknown, field: string): string {
  if (typeof v !== "string" || v.length === 0) {
    throw new Error(`Invalid argument: ${field} must be a non-empty string`);
  }
  return v;
}

function registerIpc(): void {
  ipcMain.handle("meru:listPrinters", async () => {
    return listPrinters();
  });

  ipcMain.handle("meru:print", async (_e, job: unknown) => {
    const j = job as Record<string, unknown>;
    return printJob({
      job_ref: asString(j.job_ref, "job_ref"),
      printer_name: asString(j.printer_name, "printer_name"),
      front_image_src: asString(j.front_image_src, "front_image_src"),
      back_image_src: typeof j.back_image_src === "string" ? j.back_image_src : undefined,
      copies: typeof j.copies === "number" ? j.copies : 1,
      duplex: j.duplex === true,
      orientation: j.orientation === "portrait" ? "portrait" : "landscape",
    });
  });

  ipcMain.handle("meru:printPdf", async (_e, job: unknown) => {
    const j = job as Record<string, unknown>;
    return printPdf({
      job_ref: asString(j.job_ref, "job_ref"),
      printer_name: asString(j.printer_name, "printer_name"),
      pdf_base64: asString(j.pdf_base64, "pdf_base64"),
      copies: typeof j.copies === "number" ? j.copies : 1,
      duplex: j.duplex === true,
    });
  });

  ipcMain.handle("meru:renderPdfFromHtml", async (_e, payload: unknown) => {
    const p = payload as Record<string, unknown>;
    return renderPdfFromHtml({
      html: asString(p.html, "html"),
      paper_width_in: typeof p.paper_width_in === "number" ? p.paper_width_in : undefined,
      paper_height_in: typeof p.paper_height_in === "number" ? p.paper_height_in : undefined,
      landscape: p.landscape === true,
      margins_in: typeof p.margins_in === "number" ? p.margins_in : 0,
    });
  });

  ipcMain.handle("meru:openDataFolder", () => openDataFolder());
  ipcMain.handle("meru:backupNow", () => backupNow());
  ipcMain.handle("meru:restoreBackup", () => restoreBackup());
  ipcMain.handle("meru:getDataFolderPath", () => getDataFolderPath());
  ipcMain.handle("meru:getAppPaths", () => getAppPaths());
  ipcMain.handle("meru:getAppVersion", () => app.getVersion());
  ipcMain.handle("meru:checkForUpdates", () => checkForUpdates(mainWindow));
}

/* ─── App lifecycle ──────────────────────────────────────────── */

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on("second-instance", () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.show();
      mainWindow.focus();
    }
  });

  app.whenReady().then(() => {
    Menu.setApplicationMenu(null); // clean chrome-less UI
    registerIpc();
    createMainWindow();
    createTray();
    log.info(`App ready (packaged=${isPackagedRuntime()}, version=${app.getVersion()})`);

    app.on("activate", () => {
      if (BrowserWindow.getAllWindows().length === 0) createMainWindow();
      else mainWindow?.show();
    });
  });

  app.on("before-quit", () => {
    quitting = true;
  });

  app.on("window-all-closed", () => {
    // Tray keeps the app alive on Windows; quit only when explicitly asked.
    if (quitting) app.quit();
  });

  process.on("uncaughtException", (err) => {
    log.error(`Uncaught exception: ${err.stack ?? err.message}`);
  });
}
