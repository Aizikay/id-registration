/**
 * Device identity for this workstation/browser.
 *
 * A stable, random device_id is generated once and kept in IndexedDB meta.
 * It is attached to offline operations, audit entries and print requests so
 * administrators can trace which workstation performed each action and can
 * revoke a device when needed.
 */

import { v4 as fallbackUuid } from "../utils/uuid-fallback";
import { getMeta, setMeta } from "@/db/database";

const DEVICE_ID_KEY = "device_id";

function randomHex(bytes: number): string {
  const arr = new Uint8Array(bytes);
  crypto.getRandomValues(arr);
  return Array.from(arr, (b) => b.toString(16).padStart(2, "0")).join("");
}

export function generateDeviceId(): string {
  // WS-<random 16 hex> e.g. WS-3f9c2a1e77b04d5c
  return `WS-${randomHex(8)}`;
}

export async function getDeviceId(): Promise<string> {
  const existing = await getMeta<string>(DEVICE_ID_KEY);
  if (existing) return existing;
  const fresh = generateDeviceId();
  await setMeta(DEVICE_ID_KEY, fresh);
  return fresh;
}

/** Best-effort human-readable workstation name. */
export async function getWorkstationName(): Promise<string> {
  const nav = navigator as Navigator & { userAgentData?: { platform?: string } };
  const platform =
    nav.userAgentData?.platform ??
    (navigator.platform || "Unknown Platform");
  const cores = navigator.hardwareConcurrency
    ? ` (${navigator.hardwareConcurrency} cores)`
    : "";
  return `${platform}${cores} — ${location.hostname}`;
}

export function newOperationId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    try {
      return crypto.randomUUID();
    } catch {
      // non-secure context (http://192.168...) — fall through
    }
  }
  return fallbackUuid();
}
