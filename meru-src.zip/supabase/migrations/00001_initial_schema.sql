-- ============================================================================
-- MERU DISTRICT COUNCIL — ID Registration & Issuance Management System
-- Migration 00001: Initial schema, enums, tables, constraints, indexes
-- Apply with: supabase db push   (or supabase migration up locally)
-- ============================================================================

create extension if not exists pgcrypto;
create extension if not exists pg_trgm;

-- ---------------------------------------------------------------------------
-- Enums
-- ---------------------------------------------------------------------------
create type public.user_role as enum ('admin', 'officer', 'supervisor', 'viewer');
create type public.user_status as enum ('active', 'disabled');
create type public.registration_status as enum ('registered', 'under_review');
create type public.identification_record_status as enum ('active', 'suspended', 'revoked', 'replaced');
create type public.issuance_status as enum ('pending', 'printing', 'issued', 'failed', 'cancelled', 'reprint_requested');
create type public.printer_status as enum ('online', 'offline', 'unknown', 'error');
create type public.device_status as enum ('active', 'revoked');
create type public.sync_operation_type as enum (
  'insert_person', 'update_person',
  'insert_issuance', 'update_issuance_status',
  'insert_audit_log'
);
create type public.sync_operation_status as enum ('pending', 'in_flight', 'synchronized', 'failed', 'conflict');

-- ---------------------------------------------------------------------------
-- profiles — staff accounts linked 1:1 to auth.users
-- ---------------------------------------------------------------------------
create table public.profiles (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null unique references auth.users(id) on delete cascade,
  staff_number  text not null,
  full_name     text not null,
  phone         text,
  role          public.user_role not null default 'viewer',
  department    text,
  status        public.user_status not null default 'active',
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  constraint profiles_staff_number_unique unique (staff_number),
  constraint profiles_staff_number_format check (staff_number ~ '^STAFF-[0-9]{3,6}$')
);

-- ---------------------------------------------------------------------------
-- persons — registered citizens/residents
-- ---------------------------------------------------------------------------
create table public.persons (
  id                   uuid primary key default gen_random_uuid(),
  identification_number text not null,
  full_name            text not null,
  date_of_birth        date not null,
  gender               text not null check (gender in ('male','female')),
  nationality          text not null default 'Tanzanian',
  address              text not null,
  phone                text,
  photo_path           text,
  registration_status  public.registration_status not null default 'registered',
  created_at           timestamptz not null default now(),
  updated_at           timestamptz not null default now(),
  created_by           uuid references public.profiles(id) on delete set null,
  constraint persons_identification_number_unique unique (identification_number),
  constraint persons_dob_not_future check (date_of_birth <= current_date),
  constraint persons_identification_number_format check (identification_number ~ '^[A-Z0-9]{8,20}$')
);

create index persons_full_name_trgm_idx on public.persons using gin (full_name gin_trgm_ops);
create index persons_phone_idx on public.persons (phone);
create index persons_created_by_idx on public.persons (created_by);
create index persons_created_at_idx on public.persons (created_at desc);

-- ---------------------------------------------------------------------------
-- identification_records — lifecycle of an identity number
-- ---------------------------------------------------------------------------
create table public.identification_records (
  id                     uuid primary key default gen_random_uuid(),
  person_id              uuid not null references public.persons(id) on delete cascade,
  identification_number  text not null,
  status                 public.identification_record_status not null default 'active',
  created_at             timestamptz not null default now(),
  updated_at             timestamptz not null default now()
);

create index identification_records_person_idx on public.identification_records (person_id);
create index identification_records_number_idx on public.identification_records (identification_number);

-- ---------------------------------------------------------------------------
-- printers — registered physical printers / workstations
-- ---------------------------------------------------------------------------
create table public.printers (
  id                  uuid primary key default gen_random_uuid(),
  printer_name        text not null,
  printer_identifier  text not null,
  location            text,
  status              public.printer_status not null default 'unknown',
  workstation_id      uuid references public.workstation_devices(id) on delete set null,
  last_seen_at        timestamptz,
  enabled             boolean not null default true,
  current_job_id      text,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  constraint printers_identifier_unique unique (printer_identifier)
);

-- ---------------------------------------------------------------------------
-- workstation_devices — registered browser/print-agent workstations
-- ---------------------------------------------------------------------------
create table public.workstation_devices (
  id             uuid primary key default gen_random_uuid(),
  device_id      text not null,
  device_name    text not null,
  location       text,
  assigned_to    uuid references public.profiles(id) on delete set null,
  status         public.device_status not null default 'active',
  last_sync_at   timestamptz,
  last_online_at timestamptz,
  registered_by  uuid references public.profiles(id) on delete set null,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  constraint workstation_devices_device_id_unique unique (device_id)
);

-- ---------------------------------------------------------------------------
-- issuance_records — one row per issuance transaction
--
-- DUPLICATE-ISSUANCE PREVENTION (database level):
-- A person may have at most ONE issuance in an "occupying" state.
-- occupied states: pending | printing | issued | reprint_requested
-- failed / cancelled release the slot so a corrected attempt can be made.
-- Two simultaneous issuances race on this partial unique index; only one
-- transaction can win.
-- ---------------------------------------------------------------------------
create table public.issuance_records (
  id                        uuid primary key default gen_random_uuid(),
  person_id                 uuid not null references public.persons(id) on delete restrict,
  identification_record_id  uuid references public.identification_records(id) on delete set null,
  issuance_reference        text not null,
  issued_by                 uuid references public.profiles(id) on delete set null,
  issued_by_staff_number    text,
  issued_at                 timestamptz,
  printer_id                uuid references public.printers(id) on delete set null,
  workstation_id            uuid references public.workstation_devices(id) on delete set null,
  print_job_id              text,
  status                    public.issuance_status not null default 'pending',
  idempotency_key           text not null,
  failure_reason            text,
  created_at                timestamptz not null default now(),
  updated_at                timestamptz not null default now(),
  constraint issuance_reference_unique unique (issuance_reference),
  constraint issuance_idempotency_unique unique (idempotency_key),
  constraint issuance_reference_format check (issuance_reference ~ '^MRU-[0-9]{8}-[A-Z0-9]{6}$'),
  constraint issuance_issued_requires_timestamp check (
    (status <> 'issued') or (issued_at is not null and issued_by is not null)
  )
);

-- One occupying issuance per person at most:
create unique index issuance_one_active_per_person_idx
  on public.issuance_records (person_id)
  where status in ('pending','printing','issued','reprint_requested');

create index issuance_person_idx on public.issuance_records (person_id);
create index issuance_issued_by_idx on public.issuance_records (issued_by);
create index issuance_status_idx on public.issuance_records (status);
create index issuance_issued_at_idx on public.issuance_records (issued_at desc);

-- ---------------------------------------------------------------------------
-- print jobs are tracked through issuance_records.print_job_id plus audit
-- logs; a dedicated view-friendly index:
-- ---------------------------------------------------------------------------
create index issuance_print_job_idx on public.issuance_records (print_job_id);

-- ---------------------------------------------------------------------------
-- audit_logs — APPEND ONLY (no update/delete grants anywhere below)
-- ---------------------------------------------------------------------------
create table public.audit_logs (
  id                   uuid primary key default gen_random_uuid(),
  actor_user_id        uuid references public.profiles(id) on delete set null,
  actor_staff_number   text,
  action               text not null,
  entity_type          text not null,
  entity_id            text,
  metadata             jsonb,
  workstation_id       text,
  ip_address           inet,
  created_at           timestamptz not null default now(),
  constraint audit_action_not_empty check (length(action) > 0),
  constraint audit_entity_type_not_empty check (length(entity_type) > 0)
);

create index audit_logs_created_at_idx on public.audit_logs (created_at desc);
create index audit_logs_actor_idx on public.audit_logs (actor_user_id);
create index audit_logs_action_idx on public.audit_logs (action);
create index audit_logs_entity_idx on public.audit_logs (entity_type, entity_id);

-- ---------------------------------------------------------------------------
-- sync_operations — idempotent upload journal (server mirror of client queue)
-- ---------------------------------------------------------------------------
create table public.sync_operations (
  id                uuid primary key default gen_random_uuid(),
  device_id         text not null,
  operation_id      text not null,
  entity_type       text not null,
  entity_id         uuid,
  operation_type    public.sync_operation_type not null,
  payload           jsonb not null,
  status            public.sync_operation_status not null default 'pending',
  retry_count       integer not null default 0,
  last_attempted_at timestamptz,
  error_message     text,
  created_at        timestamptz not null default now(),
  processed_at      timestamptz,
  constraint sync_operations_operation_unique unique (operation_id)
);

create index sync_operations_device_idx on public.sync_operations (device_id);
create index sync_operations_status_idx on public.sync_operations (status);
create index sync_operations_created_idx on public.sync_operations (created_at desc);

-- ---------------------------------------------------------------------------
-- system_settings — administrator-managed configuration
-- ---------------------------------------------------------------------------
create table public.system_settings (
  key         text primary key,
  value       jsonb not null default '{}'::jsonb,
  description text,
  updated_by  uuid references public.profiles(id) on delete set null,
  updated_at  timestamptz not null default now()
);

-- Default settings (safe operational defaults)
insert into public.system_settings (key, value, description) values
  ('offline_policy', '{"allow_offline_login": true, "max_offline_hours": 24, "allow_offline_registration": true, "allow_offline_issuance": true}',
   'Controls what staff may do while disconnected'),
  ('reprint_policy', '{"require_reason": true, "require_authorization_role": ["supervisor","admin"], "max_per_year": 2}',
   'Reprint authorization requirements'),
  ('search_logging', '{"log_searches": false}',
   'Whether person searches are written to the audit trail');

-- ---------------------------------------------------------------------------
-- updated_at maintenance triggers
-- ---------------------------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

create trigger trg_profiles_updated before update on public.profiles
  for each row execute function public.set_updated_at();
create trigger trg_persons_updated before update on public.persons
  for each row execute function public.set_updated_at();
create trigger trg_identification_records_updated before update on public.identification_records
  for each row execute function public.set_updated_at();
create trigger trg_printers_updated before update on public.printers
  for each row execute function public.set_updated_at();
create trigger trg_workstation_devices_updated before update on public.workstation_devices
  for each row execute function public.set_updated_at();
create trigger trg_issuance_records_updated before update on public.issuance_records
  for each row execute function public.set_updated_at();

comment on table public.persons is 'Registered citizens/residents. PII — access restricted by RLS.';
comment on column public.issuance_records.idempotency_key is 'Client-generated key; safe retries never double-issue.';
