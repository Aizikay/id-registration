import { describe, it, expect, beforeEach, vi } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import IdEditorPage from "./IdEditorPage";
import type * as IdCanvasModule from "./IdCanvas";
import { getMeta, setMeta } from "@/db/database";

const DRAFT_KEY = "registrar.draft.v1";

vi.mock("@/services/people-service", () => ({
  getPersonById: vi.fn().mockResolvedValue(null),
  registerPerson: vi.fn().mockResolvedValue({
    person: { full_name: "NEW MEMBER", identification_number: "0001" },
    offline: false
  }),
  searchPersonsOnline: vi.fn().mockResolvedValue({ rows: [], total: 0 })
}));

// jsdom has no canvas 2D context — render the card as a placeholder stub.
vi.mock("./IdCanvas", async (importOriginal) => {
  const mod = await importOriginal<typeof IdCanvasModule>();
  return {
    ...mod,
    IdCanvas: () => <canvas data-testid="id-canvas" />
  };
});

const renderPage = (url = "/app/id-card") =>
  render(
    <MemoryRouter initialEntries={[url]}>
      <IdEditorPage />
    </MemoryRouter>
  );

beforeEach(async () => {
  vi.clearAllMocks();
  await setMeta(DRAFT_KEY, null);
});

describe("IdEditorPage dual-mode designer", () => {
  it("defaults to View & Edit mode with the full action panel", () => {
    renderPage();
    expect(screen.getByRole("button", { name: /View & Edit/i })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Register Person/i })).toBeInTheDocument();
    expect(screen.getByText("ID Card Designer")).toBeInTheDocument();
    expect(screen.getByText("Search / Select Person")).toBeInTheDocument();
    expect(screen.getByText("Card Side")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Front Side/i })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Back Side/i })).toBeInTheDocument();
    expect(screen.getByText("Cheki Namba")).toBeInTheDocument();
    expect(screen.getByText("Jina (Full Name)")).toBeInTheDocument();
    expect(screen.getByText("Cheo (Position)")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Print ID/i })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Export PNG/i })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Export PDF/i })).toBeInTheDocument();
  });

  it("switches to the Back Side and shows the fixed-layout note", () => {
    renderPage();
    fireEvent.click(screen.getByRole("button", { name: /Back Side/i }));
    expect(screen.getByText("Fixed layout — not editable")).toBeInTheDocument();
    expect(screen.getByText(/Editing: Back Side/i)).toBeInTheDocument();
  });

  it("switches to Register Person mode with a fresh form and action panel", () => {
    renderPage();
    fireEvent.click(screen.getByRole("button", { name: /Register Person/i }));
    expect(screen.getByText("Register New Person")).toBeInTheDocument();
    expect(screen.getByText("New Registration")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Save & Register Person/i })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Clear Form/i })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Upload File/i })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Draw Signature/i })).toBeInTheDocument();
    expect(screen.queryByText("Print ID")).not.toBeInTheDocument();
  });

  it("starts directly in Register mode when opened with ?new=true", () => {
    renderPage("/app/id-card?new=true");
    expect(screen.getByRole("button", { name: /Save & Register Person/i })).toBeInTheDocument();
    expect(screen.getByText("New Registration")).toBeInTheDocument();
  });

  it("shows the zoom toolbar with Reset 100%", () => {
    renderPage();
    expect(screen.getByRole("button", { name: /Reset 100%/i })).toBeInTheDocument();
    expect(screen.getByText("Editing: Front Side")).toBeInTheDocument();
  });

  it("locks the card at the set zoom so zoom controls are disabled", () => {
    renderPage();
    fireEvent.click(screen.getByRole("button", { name: "+" }));
    expect(screen.getByText("125%")).toBeInTheDocument();

    fireEvent.click(screen.getByRole("button", { name: /lock/i }));
    const plus = screen.getByRole("button", { name: "+" }) as HTMLButtonElement;
    expect(plus).toBeDisabled();
    fireEvent.click(screen.getByRole("button", { name: "−" }));
    expect(screen.getByText("125%")).toBeInTheDocument();
  });

  it("Fit fills the card window and resets the view", () => {
    renderPage();
    fireEvent.click(screen.getByRole("button", { name: "+" }));
    fireEvent.click(screen.getByRole("button", { name: "+" }));
    expect(screen.getByText("156%")).toBeInTheDocument();

    fireEvent.click(screen.getByRole("button", { name: /Fit/i }));
    expect(screen.getByText("50%")).toBeInTheDocument();
  });

  it("auto-saves the register draft and restores it after a refresh (re-mount)", async () => {
    const { unmount } = renderPage("/app/id-card?new=true");

    fireEvent.change(screen.getByPlaceholderText("e.g. 8973229"), { target: { value: "12345" } });
    fireEvent.change(screen.getByPlaceholderText("e.g. ELIZABETH R. MGOMBELO"), { target: { value: "JOHN DOE" } });
    fireEvent.change(screen.getByPlaceholderText("e.g. AFISA ELIMU KATA"), { target: { value: "AFISA" } });

    await waitFor(async () => {
      const draft = await getMeta<{ jina?: string; cheki?: string; cheo?: string }>(DRAFT_KEY);
      expect(draft?.jina).toBe("JOHN DOE");
      expect(draft?.cheki).toBe("12345");
      expect(draft?.cheo).toBe("AFISA");
    });

    unmount();

    // Re-mount simulates a page refresh — the draft must come back.
    renderPage("/app/id-card");
    await screen.findByText("Draft restored — auto-saved on this device");
    expect(screen.getByText("Register New Person")).toBeInTheDocument();
    expect(screen.getByPlaceholderText("e.g. ELIZABETH R. MGOMBELO")).toHaveValue("JOHN DOE");
    expect(screen.getByPlaceholderText("e.g. 8973229")).toHaveValue("12345");
    expect(screen.getByText("Draft saved on this device — safe to refresh")).toBeInTheDocument();
  });
});