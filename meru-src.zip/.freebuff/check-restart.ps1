$log = 'C:\Users\hp\Pictures\ID Registration & Issuance Management System.(MERU DC) - Copy\.freebuff\preview-185ab75d-b7ac-4e90-8d29-bbede45499ca.log'
$err = "$log.err"
$since = [datetime]::Parse('6:00:52 PM')

$latestErr = Get-Content $err -ErrorAction SilentlyContinue | Select-Object -Last 1
$latestLog = Get-Content $log -ErrorAction SilentlyContinue | Select-Object -Last 1

Write-Output "ERR tail: $latestErr"
Write-Output "LOG tail: $latestLog"

if ($latestLog -match 'ready') {
  Write-Output 'SUCCESS: Vite restarted and is ready'
} elseif ($latestErr -match 'Internal server error') {
  Write-Output 'FAIL: Still crashing'
} else {
  Write-Output 'UNKNOWN'
}
