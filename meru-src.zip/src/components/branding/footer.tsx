import { FOOTER_BRAND } from "@/lib/constants";
import { cn } from "@/lib/cn";

/** Refined developer footer — never competes with official branding. */
export function AppFooter({ className }: { className?: string }) {
  return (
    <footer className={cn("py-6 text-center no-print", className)}>
      <div className="flex flex-col items-center gap-2">
        <div className="h-px w-16 bg-gradient-to-r from-transparent via-surface-200 to-transparent" />
        <p className="text-[11px] tracking-wider text-surface-400">
          {FOOTER_BRAND.madeBy}
        </p>
      </div>
    </footer>
  );
}
