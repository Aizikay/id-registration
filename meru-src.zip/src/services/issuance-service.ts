/**
 * Issuance service — the heart of the duplicate-prevention guarantee.
 *
 * Online: calls the atomic `issue_id` RPC (duplicate check + idempotency +
 * race-safe partial unique index inside one DB transaction).
 *
 * Offline: creates a locally-pending issuance with a client-generated
 * idempotency key and journals it. The sync engine replays the same key;
 * if the server rejects (already issued elsewhere) it becomes a CONFLICT
 * for supervisor review — never a silent overwrite.
 */

import { supabase } from "./supabase-client";
import { mapSupabaseError } from "./errors";
import { navigatorOnLine } from "@/lib/connectivity";
import { db, type CachedIssuance } from "@/db/database";
import { enqueueOperation } from "@/offline/outbox";
import { generateIssuanceReference } from "@/lib/identifiers";
import { authProfileCache } from "./audit-service";
import { v4 as uuidFallback } from "@/utils/uuid-fallback";
import type { IssuanceRecord, IssuanceStatus, Person } from "@/types";

function safeUuid(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    try {
      return crypto.randomUUID();
    } catch {
      // non-secure context (http://192.168...)
    }
  }
  return uuidFallback();
}

export interface IssueIdInput {
  person: Person;
  printerId: string | null;
  workstationDeviceId: string | null;
  printJobReference: string | null;
}

export type IssueIdResult =
  | {
      outcome: "created" | "idempotent_replay";
      record: CachedIssuance;
      offline: boolean;
    }
  | {
      outcome: "blocked";
      existing: CachedIssuance | null;
    };

export async function getIssuanceHistoryForPerson(
  personId: string
): Promise<CachedIssuance[]> {
  if (navigatorOnLine()) {
    try {
      const { data, error } = await supabase
        .from("issuance_records")
        .select("*")
        .eq("person_id", personId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      const rows = data as IssuanceRecord[];
      void Promise.all(
        rows.map((r) => db.issuances.put({ ...r, synced: true }))
      ).catch(() => undefined);
      return rows.map((r) => ({ ...r, synced: true }));
    } catch (err) {
      const mapped = mapSupabaseError(err);
      if (mapped.code !== "network_unavailable") throw mapped;
    }
  }
  return db.issuances.where("person_id").equals(personId).reverse().toArray();
}

/** The occupying issuance (pending/printing/issued/reprint_requested), if any. */
export async function getActiveIssuance(
  personId: string
): Promise<CachedIssuance | null> {
  const all = await getIssuanceHistoryForPerson(personId);
  const occupying = all.filter(
    (i) =>
      i.status === "issued" ||
      i.status === "pending" ||
      i.status === "printing" ||
      i.status === "reprint_requested"
  );
  return occupying[0] ?? null;
}

export async function issueId(input: IssueIdInput): Promise<IssueIdResult> {
  const idempotencyKey = safeUuid();
  const reference = generateIssuanceReference();
  const now = new Date().toISOString();

  // ---- Pre-check for immediate user feedback -----------------------------
  const active = await getActiveIssuance(input.person.id);
  if (active?.status === "issued") {
    return { outcome: "blocked", existing: active };
  }

  const localRow: CachedIssuance = {
    id: safeUuid(),
    person_id: input.person.id,
    identification_record_id: null,
    issuance_reference: reference,
    issued_by: authProfileCache.profileId,
    issued_by_staff_number: authProfileCache.staffNumber,
    issued_at: now,
    printer_id: input.printerId,
    workstation_id: input.workstationDeviceId,
    print_job_id: input.printJobReference,
    status: "issued",
    idempotency_key: idempotencyKey,
    failure_reason: null,
    created_at: now,
    updated_at: now,
    synced: false,
    person_name: input.person.full_name,
    identification_number: input.person.identification_number
  };

  if (navigatorOnLine()) {
    try {
      // Fetch the person's active identification record (required by cloud's issue_id)
      let identRecordId: string | null = null;
      try {
        const { data: rec } = await supabase
          .from("identification_records")
          .select("id")
          .eq("person_id", input.person.id)
          .eq("status", "active")
          .maybeSingle();
        identRecordId = (rec as { id: string } | null)?.id ?? null;
      } catch {
        identRecordId = null;
      }

      const { error, data } = await supabase.rpc("issue_id", {
        p_person_id: input.person.id,
        p_identification_record_id: identRecordId,
        p_issuance_reference: reference,
        p_idempotency_key: idempotencyKey,
        p_printer_id: input.printerId,
        p_workstation_device_id: null,
        p_print_job_reference: input.printJobReference
      });
      if (error) throw error;

      const payload = data as {
        status: "created" | "idempotent_replay";
        record: IssuanceRecord;
      };
      const record: CachedIssuance = {
        ...payload.record,
        synced: true,
        person_name: input.person.full_name,
        identification_number: input.person.identification_number
      };
      await db.issuances.put(record);
      return { outcome: payload.status, record, offline: false };
    } catch (err) {
      const mapped = mapSupabaseError(err);
      switch (mapped.code) {
        case "already_issued": {
          // Re-fetch authoritative copy for display.
          const existing = await getActiveIssuance(input.person.id);
          return { outcome: "blocked", existing };
        }
        case "issuance_in_progress":
          throw mapped;
        default:
          if (mapped.code !== "network_unavailable") throw mapped;
          // else fall through to offline path below
      }
    }
  }

  // ---- Offline path -------------------------------------------------------
  await db.issuances.put(localRow);
  await enqueueOperation({
    entityType: "issuance",
    entityId: localRow.id,
    operationType: "insert_issuance",
    payload: {
      person_id: input.person.id,
      identification_record_id: null,
      issuance_reference: reference,
      idempotency_key: idempotencyKey,
      printer_id: input.printerId,
      workstation_device_id: input.workstationDeviceId,
      print_job_reference: input.printJobReference
    }
  });
  return { outcome: "created", record: localRow, offline: true };
}

export interface UpdateStatusInput {
  issuanceId: string;
  newStatus: Extract<IssuanceStatus, "pending" | "printing" | "failed" | "cancelled" | "reprint_requested">;
  failureReason?: string;
  printJobId?: string;
  printerId?: string;
}

export async function updateIssuanceStatus(
  input: UpdateStatusInput
): Promise<CachedIssuance> {
  if (navigatorOnLine()) {
    try {
      const { error, data } = await supabase.rpc("update_issuance_status", {
        p_issuance_id: input.issuanceId,
        p_new_status: input.newStatus,
        p_failure_reason: input.failureReason ?? null,
        p_print_job_id: input.printJobId ?? null,
        p_printer_id: input.printerId ?? null
      });
      if (error) throw error;
      const rec = (data as { record: IssuanceRecord }).record;
      const merged: CachedIssuance = { ...rec, synced: true };
      await db.issuances.put(merged);
      return merged;
    } catch (err) {
      const mapped = mapSupabaseError(err);
      if (mapped.code !== "network_unavailable") throw mapped;
    }
  }

  // Offline: apply locally and journal.
  const local = await db.issuances.get(input.issuanceId);
  if (!local) throw mapSupabaseError(new Error("issuance_not_found"));
  const updated: CachedIssuance = {
    ...local,
    status: input.newStatus,
    failure_reason:
      input.newStatus === "failed"
        ? input.failureReason ?? local.failure_reason
        : local.failure_reason,
    updated_at: new Date().toISOString(),
    synced: false
  };
  await db.issuances.put(updated);
  await enqueueOperation({
    entityType: "issuance",
    entityId: input.issuanceId,
    operationType: "update_issuance_status",
    payload: {
      issuance_id: input.issuanceId,
      new_status: input.newStatus,
      failure_reason: input.failureReason ?? null,
      print_job_id: input.printJobId ?? null,
      printer_id: input.printerId ?? null
    }
  });
  return updated;
}

export interface ReprintInput {
  issuance: CachedIssuance;
  reason: string;
  authorizedRole: "admin" | "supervisor" | "officer";
}

/**
 * Reprint flow: requires a reason; creates a fresh print transaction on top
 * of the ORIGINAL issuance (never mutates its terminal `issued` state).
 */
export async function requestReprint(
  input: ReprintInput
): Promise<{ ok: boolean; message?: string }> {
  if (!input.issuance.synced && !navigatorOnLine()) {
    return { ok: true };
  }

  try {
    const { error } = await supabase.rpc("update_issuance_status", {
      p_issuance_id: input.issuance.id,
      p_new_status: "reprint_requested",
      p_failure_reason: input.reason,
      p_print_job_id: null,
      p_printer_id: null
    });
    if (error) throw mapSupabaseError(error);
    return { ok: true };
  } catch (err) {
    const mapped = mapSupabaseError(err);
    // Audit already recorded; report the transition problem honestly.
    return { ok: false, message: mapped.userMessage };
  }
}

export interface IssuanceQuery {
  page?: number;
  pageSize?: number;
  status?: IssuanceStatus;
  staffNumber?: string;
  from?: string;
  to?: string;
  search?: string;
}

export async function queryIssuancesOnline(query: IssuanceQuery): Promise<{
  rows: (CachedIssuance & { persons?: { full_name: string } })[];
  total: number;
}> {
  const page = Math.max(query.page ?? 0, 0);
  const pageSize = Math.min(Math.max(query.pageSize ?? 20, 1), 100);

  let request = supabase
    .from("issuance_records")
    .select(
      "*, persons(full_name)",
      { count: "exact" }
    )
    .order("created_at", { ascending: false })
    .range(page * pageSize, page * pageSize + pageSize - 1);

  if (query.status) request = request.eq("status", query.status);
  if (query.staffNumber) request = request.eq("issued_by_staff_number", query.staffNumber);
  if (query.from) request = request.gte("created_at", query.from);
  if (query.to) request = request.lte("created_at", query.to);
  if (query.search) request = request.ilike("issuance_reference", `%${query.search}%`);

  const { data, error, count } = await request;
  if (error) throw mapSupabaseError(error);
  return {
    rows: ((data ?? []) as unknown as (CachedIssuance & {
      persons?: { full_name: string };
    })[]),
    total: count ?? 0
  };
}
