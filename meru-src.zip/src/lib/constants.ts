import type { UserRole } from "@/types";

export const ORGANIZATION = {
  nameSw: "HALMASHAURI YA WILAYA YA MERU",
  nameEn: "MERU DISTRICT COUNCIL",
  shortName: "MDC",
  systemName: "Mfumo wa Usajili na Utoaji wa Vitambulisho",
  systemNameEn: "ID Registration & Issuance Management System",
  systemShort: "ID Registry",
  region: "Arusha, Tanzania",
  tagline: "Official identification registration and issuance platform",
  description: "Secure staff access · Offline capable · Complete operation logging"
} as const;

export const FOOTER_BRAND = {
  madeBy: "Made by Aizikay.dev Enterprises"
} as const;

/**
 * Branding assets live in /public/branding/.
 * Drop authorized logo files there — no code changes needed.
 */
export const BRANDING_ASSETS = {
  councilLogo: "/branding/meru-logo.jpeg",
  coatOfArms: "/branding/coat-of-arms.png",
  flag: "/branding/tanzania-flag.png",
  appIcon192: "/branding/app-icon-192.png",
  appIcon512: "/branding/app-icon-512.png",
  maskableIcon: "/branding/app-icon-maskable-512.png"
} as const;

export const ROLE_LABELS: Record<UserRole, string> = {
  admin: "Administrator",
  officer: "Officer",
  supervisor: "Supervisor",
  viewer: "Viewer"
};

export const ROLE_DESCRIPTIONS: Record<UserRole, string> = {
  admin:
    "Full control: staff management, printers, settings, and reports.",
  officer:
    "Registers people, processes ID issuance and printing, views issuance history.",
  supervisor:
    "Reviews records, issuance history, reports, and staff activity.",
  viewer: "Read-only access to authorized records."
};

export const ROLE_COLORS: Record<UserRole, { bg: string; text: string; dot: string }> = {
  admin: { bg: "bg-council-50", text: "text-council-700", dot: "bg-council-500" },
  officer: { bg: "bg-primary-50", text: "text-primary-700", dot: "bg-primary-500" },
  supervisor: { bg: "bg-gold-50", text: "text-gold-700", dot: "bg-gold-500" },
  viewer: { bg: "bg-surface-100", text: "text-surface-600", dot: "bg-surface-400" }
};

/**
 * Shape of a department entry used by the UI.
 *
 * There is NO built-in department catalogue — the list shown everywhere
 * (Departments page, ID Card Designer dropdown) comes exclusively from
 * departments the user registers (stored in the Supabase `departments` table).
 */
export interface DepartmentDef {
  id: string;
  nameSw: string;
  nameEn: string;
}

export const DEPARTMENTS: DepartmentDef[] = [];

export const APP_NAME = `${ORGANIZATION.nameEn} — ${ORGANIZATION.systemShort}`;

export const IDENTIFICATION_NUMBER_PATTERN = /^[A-Z0-9\/\-]{1,30}$/;
export const STAFF_NUMBER_PATTERN = /^STAFF-\d{3,6}$/;
export const TANZANIA_PHONE_PATTERN = /^(?:\+255|0)[17]\d{8}$/;
