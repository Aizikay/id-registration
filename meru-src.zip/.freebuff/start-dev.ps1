Set-Location "C:\Users\hp\Pictures\ID Registration & Issuance Management System.(MERU DC) - Copy"
& npm run dev
