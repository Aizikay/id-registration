import { useCallback, useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Card, CardBody, CardHeader, PageHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/ui/status-badge";
import { ConfirmDialog, Modal } from "@/components/ui/modal";
import { Textarea } from "@/components/ui/form";
import { EmptyState, ErrorState } from "@/components/ui/data-table";
import { Icon } from "@/components/icons/icon";
import { useToast } from "@/components/ui/toast";
import { deletePerson, getPersonById } from "@/services/people-service";
import {
  getIssuanceHistoryForPerson,
  issueId,
  requestReprint,
  updateIssuanceStatus
} from "@/services/issuance-service";
import { mapSupabaseError } from "@/services/errors";
import { listPrinters } from "@/services/devices-service";
import { printAgentClient } from "@/printing/agent-client";
import { getDeviceId } from "@/offline/device";
import type { CachedIssuance, CachedPerson } from "@/db/database";
import type { IssuanceRecord, Person, Printer } from "@/types";
import { calculateAge, formatDate, formatDateTime } from "@/lib/format";
import { can as roleCan } from "@/lib/permissions";
import { useAuth } from "@/features/auth/auth-context";
import { ORGANIZATION } from "@/lib/constants";

export function PersonProfilePage() {
  const { personId } = useParams<{ personId: string }>();
  const navigate = useNavigate();
  const toast = useToast();
  const { profile, online } = useAuth();

  const [person, setPerson] = useState<CachedPerson | Person | null>(null);
  const [issuances, setIssuances] = useState<CachedIssuance[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Issue flow state
  const [confirmIssue, setConfirmIssue] = useState(false);
  const [issuing, setIssuing] = useState(false);
  const [blockedBy, setBlockedBy] = useState<CachedIssuance | null>(null);
  const [printers, setPrinters] = useState<Printer[]>([]);
  const [selectedPrinter, setSelectedPrinter] = useState<string>("");
  const [reprintTarget, setReprintTarget] = useState<CachedIssuance | null>(null);
  const [reprintReason, setReprintReason] = useState("");
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [issueWithPrint, setIssueWithPrint] = useState(true);

  const load = useCallback(async (): Promise<void> => {
    if (!personId) return;
    setLoading(true);
    setError(null);
    try {
      const p = await getPersonById(personId);
      if (!p) {
        setError("This record could not be found.");
        setPerson(null);
      } else {
        setPerson(p);
      }
      const history = await getIssuanceHistoryForPerson(personId);
      setIssuances(history);
    } catch (err) {
      setError(mapSupabaseError(err).userMessage);
    } finally {
      setLoading(false);
    }
  }, [personId]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    if (!online) return;
    listPrinters()
      .then((ps) => {
        const enabled = ps.filter((p) => p.enabled);
        setPrinters(enabled);
        if (enabled.length > 0) setSelectedPrinter((prev) => prev || enabled[0]!.id);
      })
      .catch(() => undefined);
  }, [online]);

  const activeIssuance = issuances.find(
    (i) =>
      i.status === "issued" ||
      i.status === "pending" ||
      i.status === "printing" ||
      i.status === "reprint_requested"
  );

  const canIssue =
    roleCan(profile?.role ?? null, "issuance.create") && !activeIssuance;

  const handleIssueConfirmed = async (): Promise<void> => {
    if (!person) return;
    setConfirmIssue(false);
    setIssuing(true);
    const usePrint = issueWithPrint && !!selectedPrinter;
    try {
      const result = await issueId({
        person,
        printerId: usePrint ? selectedPrinter : null,
        workstationDeviceId: await getDeviceId(),
        printJobReference: usePrint
          ? `PRT-${Date.now().toString(36).toUpperCase()}`
          : null
      });

      if (result.outcome === "blocked") {
        setBlockedBy(result.existing ?? activeIssuance ?? null);
        toast.warning("ID already issued", "Duplicate issuance is blocked by policy.");
        await load();
        return;
      }

      toast.success(
        result.outcome === "idempotent_replay"
          ? "Already processed"
          : result.offline
            ? "Issued offline"
            : "ID issued",
        `Reference ${result.record.issuance_reference}${result.offline ? " — will sync automatically" : ""}`
      );
      await load();

      // Attempt physical printing through the local agent (best effort) — only if user chose printing.
      if (usePrint && navigator.onLine) {
        await attemptPrint(result.record, person);
      }
    } catch (err) {
      const mapped = mapSupabaseError(err);
      toast.error("Issuance failed", mapped.userMessage);
    } finally {
      setIssuing(false);
    }
  };

  const attemptPrint = async (
    record: CachedIssuance,
    p: Person
  ): Promise<void> => {
    try {
      const printResult = await printAgentClient.submitPrintJob({
        document_reference: record.print_job_id ?? record.id,
        issuance_reference: record.issuance_reference,
        idempotency_key: record.idempotency_key,
        printer_id: selectedPrinter,
        person_name: p.full_name,
        identification_number: p.identification_number,
        issued_by_staff_number: record.issued_by_staff_number,
        issued_at_iso: record.issued_at ?? new Date().toISOString(),
        council_name_sw: ORGANIZATION.nameSw,
        council_name_en: ORGANIZATION.nameEn
      });
      if (printResult.ok) {
        toast.success("Sent to printer", `Job ${printResult.job_id}`);
      } else {
        await updateIssuanceStatus({
          issuanceId: record.id,
          newStatus: "failed",
          failureReason: printResult.error_message ?? "printer_error"
        });
        toast.error("Printing failed", printResult.error_message ?? "The printer reported an error.");
        await load();
      }
    } catch {
      toast.warning(
        "Print Agent unreachable",
        "The ID is recorded. Start the Print Agent on this workstation to print the card."
      );
    }
  };

  const handleReprint = async (): Promise<void> => {
    if (!reprintTarget || !reprintReason.trim()) return;
    const target = reprintTarget;
    setReprintTarget(null);
    const result = await requestReprint({
      issuance: target,
      reason: reprintReason.trim(),
      authorizedRole: profile?.role === "admin" || profile?.role === "supervisor"
        ? profile.role
        : "officer"
    });
    setReprintReason("");
    if (result.ok) {
      toast.success("Reprint requested", "A new print transaction has been recorded.");
      await load();
    } else {
      toast.error("Reprint not completed", result.message);
    }
  };

  const handleDelete = async (): Promise<void> => {
    if (!person || !personId) return;
    setDeleting(true);
    try {
      await deletePerson(personId);
      toast.success("Deleted", `${person.full_name} has been removed.`);
      navigate("/app/people");
    } catch (err) {
      toast.error("Delete failed", mapSupabaseError(err).userMessage);
    } finally {
      setDeleting(false);
      setConfirmDelete(false);
    }
  };

  if (loading) {
    return (
      <div className="mx-auto max-w-4xl space-y-4">
        <div className="h-9 w-64 animate-pulse rounded-lg bg-slate-200" />
        <div className="h-48 animate-pulse rounded-xl bg-slate-200" />
        <div className="h-72 animate-pulse rounded-xl bg-slate-200" />
      </div>
    );
  }

  if (error || !person) {
    return (
      <Card className="mx-auto max-w-2xl">
        <ErrorState message={error ?? "Record not found"} onRetry={() => void load()} />
      </Card>
    );
  }

  return (
    <div className="mx-auto max-w-4xl animate-fade-in">
      <PageHeader
        title={person.full_name}
        subtitle={`Identification № ${person.identification_number}`}
        actions={
          <div className="flex items-center gap-2">
            {roleCan(profile?.role ?? null, "people.delete") && (
              <Button
                variant="danger"
                size="sm"
                onClick={() => setConfirmDelete(true)}
                icon={<Icon name="trash" className="h-4 w-4" />}
              >
                Delete
              </Button>
            )}
            <Button variant="ghost" onClick={() => navigate("/app/people")} icon={<Icon name="chevron-left" className="h-4 w-4" />}>
              Registry
            </Button>
            <Button variant="outline" size="sm" onClick={() => navigate(`/app/id-card?person=${personId}`)} icon={<Icon name="credit-card" className="h-4 w-4" />}>
              ID Card
            </Button>
          </div>
        }
      />

      <div className="grid gap-4 lg:grid-cols-3">
        {/* Identity card */}
        <Card className="lg:col-span-1">
          <CardHeader title="Identity" icon={<Icon name="id-card" className="h-4 w-4" />} />
          <CardBody className="space-y-4 text-sm">
            <Detail label="Full name" value={person.full_name} />
            <Detail label="Identification number" value={<span className="font-mono">{person.identification_number}</span>} />
            <Detail
              label="Date of birth"
              value={
                <>
                  {formatDate(person.date_of_birth)}{" "}
                  <span className="text-xs text-slate-400">
                    ({calculateAge(person.date_of_birth)} yrs)
                  </span>
                </>
              }
            />
            <Detail label="Gender" value={<span className="capitalize">{person.gender}</span>} />
            <Detail label="Nationality" value={person.nationality} />
            <Detail label="Address" value={person.address} />
            <Detail label="Phone" value={<span className="font-mono">{person.phone ?? "—"}</span>} />
            <div className="border-t border-slate-100 pt-3">
              <Detail label="Registered" value={formatDateTime(person.created_at)} />
              <p className="mt-1.5">
                <StatusBadge
                  status={"registered"}
                  label={(person as CachedPerson).synced === false ? "PENDING SYNC" : "REGISTERED"}
                  tone={(person as CachedPerson).synced === false ? "amber" : undefined}
                />
              </p>
            </div>
          </CardBody>
        </Card>

        {/* Issuance panel */}
        <div className="space-y-4 lg:col-span-2">
          <Card>
            <CardHeader
              title="Identification status"
              subtitle="Duplicate issuance is prevented at database level"
              icon={<Icon name="shield-check" className="h-4 w-4" />}
              actions={
                activeIssuance ? (
                  <StatusBadge status={activeIssuance.status} pulse={activeIssuance.status !== "issued"} />
                ) : (
                  <StatusBadge status="pending" label="NOT ISSUED" tone="slate" />
                )
              }
            />
            <CardBody>
              {activeIssuance?.status === "issued" ? (
                <IssuedSummary record={activeIssuance} />
              ) : activeIssuance ? (
                <div className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
                  <p className="flex items-center gap-2 font-semibold">
                    <Icon name="clock" className="h-4 w-4" />
                    An issuance transaction is in progress ({activeIssuance.status})
                  </p>
                  <p className="mt-1 text-xs">
                    Reference <span className="font-mono">{activeIssuance.issuance_reference}</span>.
                    A new issuance cannot start until this completes.
                  </p>
                </div>
              ) : (
                <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-dashed border-slate-300 bg-slate-50/60 px-4 py-3">
                  <div className="text-sm text-slate-600">
                    <p className="font-medium">No ID issued yet</p>
                    <p className="text-xs text-slate-500">
                      This person is eligible for identification issuance.
                    </p>
                  </div>
                  {canIssue && (
                    <Button
                      onClick={() => setConfirmIssue(true)}
                      loading={issuing}
                      disabled={!online && issuances.some((i) => !i.synced)}
                      icon={<Icon name="id-card" className="h-4 w-4" />}
                    >
                      Issue ID
                    </Button>
                  )}
                </div>
              )}

              {!online && (
                <p className="mt-3 flex items-center gap-2 text-xs text-slate-500">
                  <Icon name="wifi-off" className="h-3.5 w-3.5" />
                  Offline mode: issuance records are stored locally and synchronized later.
                </p>
              )}

              {printers.length > 0 && canIssue && (
                <div className="mt-4 flex flex-wrap items-end gap-3 border-t border-slate-100 pt-4">
                  <label className="text-xs font-medium text-slate-600">
                    Printer for this session
                    <select
                      value={selectedPrinter}
                      onChange={(e) => setSelectedPrinter(e.target.value)}
                      className="input-base mt-1 w-64"
                    >
                      {printers.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.printer_name} ({p.location ?? p.status})
                        </option>
                      ))}
                    </select>
                  </label>
                </div>
              )}
            </CardBody>
          </Card>

          {/* History */}
          <Card>
            <CardHeader
              title="Issuance history"
              subtitle={`${issuances.length} record${issuances.length === 1 ? "" : "s"}`}
              icon={<Icon name="history" className="h-4 w-4" />}
            />
            {issuances.length === 0 ? (
              <EmptyState icon="history" title="No issuance records" message="Issuances for this person will appear here." />
            ) : (
              <ul role="list" className="divide-y divide-slate-100">
                {issuances.map((rec) => (
                  <li key={rec.id} className="flex flex-wrap items-center justify-between gap-3 px-5 py-3.5">
                    <div className="min-w-0">
                      <p className="font-mono text-xs font-semibold text-slate-700">
                        {rec.issuance_reference}
                        {!rec.synced && (
                          <span className="ml-2 rounded bg-amber-100 px-1.5 py-0.5 align-middle text-[10px] font-bold uppercase text-amber-700">
                            pending sync
                          </span>
                        )}
                      </p>
                      <p className="mt-0.5 text-xs text-slate-500">
                        {rec.issued_at
                          ? `${formatDateTime(rec.issued_at)} · ${rec.issued_by_staff_number ?? "—"}`
                          : `Created ${formatDateTime(rec.created_at)}`}
                      </p>
                      {rec.failure_reason && (
                        <p className="mt-1 text-[11px] font-medium text-red-600">
                          Failure reason: {rec.failure_reason}
                        </p>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <StatusBadge status={rec.status} />
                      {rec.status === "issued" &&
                        roleCan(profile?.role ?? null, "print.reprint") && (
                          <Button size="sm" variant="outline" onClick={() => setReprintTarget(rec)}>
                            Reprint
                          </Button>
                        )}
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>
      </div>

      {/* Confirm issuance */}
      <ConfirmDialog
        open={confirmIssue}
        options={{
          title: "Issue identification card?",
          message: (
            <div className="space-y-3">
              <p>
                You are about to issue an ID to{" "}
                <strong>{person.full_name}</strong>{" "}
                (<span className="font-mono">{person.identification_number}</span>).
                This action is permanent.
              </p>
              {printers.length > 0 ? (
                <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
                  <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">How to issue</p>
                  <label className="flex items-center gap-2 text-sm">
                    <input
                      type="radio"
                      name="issue-mode"
                      checked={issueWithPrint}
                      onChange={() => setIssueWithPrint(true)}
                      className="h-4 w-4"
                    />
                    Issue &amp; print now{selectedPrinter ? ` — ${printers.find((p) => p.id === selectedPrinter)?.printer_name ?? "selected printer"}` : " (select a printer first)"}
                  </label>
                  <label className="mt-2 flex items-center gap-2 text-sm">
                    <input
                      type="radio"
                      name="issue-mode"
                      checked={!issueWithPrint}
                      onChange={() => setIssueWithPrint(false)}
                      className="h-4 w-4"
                    />
                    Issue without printing (record only — can reprint later)
                  </label>
                </div>
              ) : (
                <p className="text-xs text-slate-500">No printers configured — ID will be issued without printing. You can print later from the issuance history.</p>
              )}
            </div>
          ),
          confirmLabel: issueWithPrint && selectedPrinter ? "Confirm & issue + print" : "Confirm & issue",
          danger: false,
          loading: issuing,
          onConfirm: () => {
            void handleIssueConfirmed();
          },
          cancelLabel: "Cancel"
        }}
        onCancel={() => setConfirmIssue(false)}
      />

      {/* Duplicate blocked */}
      <Modal
        open={blockedBy !== null}
        onClose={() => setBlockedBy(null)}
        title="ID ALREADY ISSUED"
        tone="danger"
        size="sm"
        footer={
          <Button variant="outline" data-autofocus onClick={() => setBlockedBy(null)}>
            Close
          </Button>
        }
      >
        {blockedBy && (
          <dl className="space-y-2.5 rounded-lg border border-red-200 bg-red-50/60 p-4 text-sm">
            <BlockRow label="Name" value={person.full_name} />
            <BlockRow label="Identification Number" value={person.identification_number} mono />
            <BlockRow label="Issued Date" value={formatDate(blockedBy.issued_at)} />
            <BlockRow label="Issued Time" value={blockedBy.issued_at ? formatDateTime(blockedBy.issued_at).split(" ").slice(-1)[0]! : "—"} />
            <BlockRow label="Issued By" value={blockedBy.issued_by_staff_number ?? "—"} />
            <BlockRow
              label="Printer"
              value={printers.find((p) => p.id === blockedBy.printer_id)?.printer_name ?? blockedBy.printer_id ?? "—"}
            />
            <BlockRow label="Status" value={blockedBy.status.toUpperCase()} />
            <BlockRow label="Reference" value={blockedBy.issuance_reference} mono />
          </dl>
        )}
      </Modal>

      {/* Reprint */}
      <Modal
        open={reprintTarget !== null}
        onClose={() => setReprintTarget(null)}
        title="Request card reprint"
        description="A documented reason is required for every reprint."
        size="sm"
        footer={
          <>
            <Button variant="outline" onClick={() => setReprintTarget(null)}>
              Cancel
            </Button>
            <Button
              disabled={reprintReason.trim().length < 5}
              onClick={() => {
                void handleReprint();
              }}
            >
              Request reprint
            </Button>
          </>
        }
      >
        <Textarea
          label="Reason for reprint"
          required
          placeholder="e.g. Card damaged after issuance / printer failure during original job…"
          value={reprintReason}
          onChange={(e) => setReprintReason(e.target.value)}
          rows={3}
        />
      </Modal>

      {/* Delete confirmation — admin only, double confirm */}
      <ConfirmDialog
        open={confirmDelete}
        onCancel={() => setConfirmDelete(false)}
        options={{
          title: "Delete this person?",
          message: (
            <>
              You are about to permanently delete <strong>{person.full_name}</strong>{" "}
              (<span className="font-mono">{person.identification_number}</span>). This cannot be undone.
              {activeIssuance ? " This person has an active issuance and cannot be deleted — cancel it first." : ""}
            </>
          ),
          confirmLabel: "Yes, delete",
          cancelLabel: "Cancel",
          danger: true,
          loading: deleting,
          onConfirm: () => { void handleDelete(); }
        }}
      />
    </div>
  );
}

function Detail({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-0.5 sm:flex-row sm:items-baseline sm:justify-between sm:gap-6">
      <dt className="shrink-0 text-xs font-medium uppercase tracking-wide text-slate-400">
        {label}
      </dt>
      <dd className="min-w-0 break-words text-right font-medium text-slate-800 sm:text-left">
        {value}
      </dd>
    </div>
  );
}

function BlockRow({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex items-baseline justify-between gap-4">
      <dt className="text-xs font-semibold uppercase tracking-wide text-red-500">{label}</dt>
      <dd className={mono ? "font-mono text-xs font-semibold" : "font-semibold"}>{value}</dd>
    </div>
  );
}

function IssuedSummary({ record }: { record: IssuanceRecord | CachedIssuance }) {
  return (
    <div className="rounded-lg border border-emerald-200 bg-emerald-50/70 px-4 py-3">
      <p className="flex items-center gap-2 text-sm font-semibold text-emerald-800">
        <Icon name="check-circle" className="h-5 w-5" />
        Identification issued
      </p>
      <dl className="mt-2 grid grid-cols-1 gap-x-8 gap-y-1.5 text-xs sm:grid-cols-2">
        <SummaryItem label="Reference" value={record.issuance_reference} mono />
        <SummaryItem label="Issued at" value={formatDateTime(record.issued_at)} />
        <SummaryItem label="Issued by" value={record.issued_by_staff_number ?? "—"} />
        <SummaryItem
          label="Workstation"
          value={record.workstation_id ?? "—"}
        />
      </dl>
    </div>
  );
}

function SummaryItem({ label, value, mono }: { label: string; value: React.ReactNode; mono?: boolean }) {
  return (
    <div className="flex justify-between gap-4 sm:block">
      <dt className="font-medium uppercase tracking-wide text-emerald-600/70">{label}</dt>
      <dd className={mono ? "font-mono font-semibold text-slate-700" : "font-semibold text-slate-700"}>
        {value}
      </dd>
    </div>
  );
}
