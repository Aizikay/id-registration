import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Icon, type IconName } from "@/components/icons/icon";
import {
  deletePerson,
  searchPersonsOffline,
  searchPersonsOnline,
  checkIssuanceStatus,
} from "@/services/people-service";
import { mapSupabaseError } from "@/services/errors";
import { useAuth } from "@/features/auth/auth-context";
import { ConfirmDialog } from "@/components/ui/modal";
import { useToast } from "@/components/ui/toast";
import { cn } from "@/lib/cn";
import { GlassCheckbox } from "@/components/GlassCheckbox";

/* ─── Types ──────────────────────────────────────────────────── */

type PersonRow = {
  id: string;
  full_name: string;
  identification_number: string;
  date_of_birth: string;
  gender: string;
  phone: string | null;
  position: string | null;
  signature_path: string | null;
  created_at: string;
  synced?: boolean;
};

type FilterTab = "all" | "recent" | "pending";

interface Column {
  key: string;
  label: string;
  className?: string;
}

/* ─── Constants ──────────────────────────────────────────────── */

const PAGE_SIZES = [10, 25, 50] as const;
const DEBOUNCE_MS = 300;

const COLUMNS: Column[] = [
  { key: "cheki", label: "Cheki Namba" },
  { key: "jina", label: "Jina" },
  { key: "cheo", label: "Cheo" },
  { key: "sahihi", label: "Sahihi ya Mtumishi" },
  { key: "issued", label: "ID Issued" },
  { key: "status", label: "Status" },
  { key: "actions", label: "" },
];

const FILTER_TABS: { id: FilterTab; label: string; icon: IconName }[] = [
  { id: "all", label: "All Records", icon: "users" },
  { id: "recent", label: "Recently Added", icon: "clock" },
  { id: "pending", label: "Pending Sync", icon: "refresh" },
];

/* ─── Helpers ────────────────────────────────────────────────── */

function initials(name: string): string {
  return name
    .split(/\s+/)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase() ?? "")
    .join("");
}

function initialsColor(name: string): string {
  const colors = [
    "from-emerald-500 to-emerald-700",
    "from-teal-500 to-teal-700",
    "from-blue-500 to-blue-700",
    "from-purple-500 to-purple-700",
    "from-amber-500 to-amber-700",
    "from-rose-500 to-rose-700",
    "from-cyan-500 to-cyan-700",
    "from-indigo-500 to-indigo-700",
  ];
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }
  return colors[Math.abs(hash) % colors.length]!;
}

/* ─── Main Component ─────────────────────────────────────────── */

export function PeopleListPage() {
  const navigate = useNavigate();
  const { online, can, profile } = useAuth();
  const toast = useToast();
  const searchRef = useRef<HTMLInputElement>(null);

  // State
  const [search, setSearch] = useState("");
  const [debounced, setDebounced] = useState("");
  const [activeTab, setActiveTab] = useState<FilterTab>("all");
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(25);
  const [rows, setRows] = useState<PersonRow[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [refreshNonce, setRefreshNonce] = useState(0);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [openMenu, setOpenMenu] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<{
    id: string;
    name: string;
  } | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [issuedMap, setIssuedMap] = useState<Set<string>>(new Set());

  // Keyboard shortcut
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "/" && document.activeElement?.tagName !== "INPUT") {
        e.preventDefault();
        searchRef.current?.focus();
      }
      if (e.key === "Escape") {
        setOpenMenu(null);
        setSelected(new Set());
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  // Debounce search
  useEffect(() => {
    const t = window.setTimeout(() => {
      setDebounced(search.trim());
      setPage(0);
    }, DEBOUNCE_MS);
    return () => window.clearTimeout(t);
  }, [search]);

  // Fetch data
  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);

    (async () => {
      try {
        if (online) {
          const result = await searchPersonsOnline({
            search: debounced || undefined,
            page,
            pageSize,
          });
          if (!cancelled) {
            setRows(result.rows as PersonRow[]);
            setTotal(result.total);
          }
        } else {
          const all = await searchPersonsOffline(debounced, 200);
          if (!cancelled) {
            setRows(all.slice(page * pageSize, (page + 1) * pageSize));
            setTotal(all.length);
          }
        }
      } catch (err) {
        if (!cancelled) setError(mapSupabaseError(err).userMessage);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [debounced, page, pageSize, online, refreshNonce]);

  // Check issuance status for visible rows
  useEffect(() => {
    if (rows.length === 0 || !online) return;
    let cancelled = false;
    void checkIssuanceStatus(rows.map((r) => r.id)).then((ids) => {
      if (!cancelled) setIssuedMap(ids);
    });
    return () => { cancelled = true; };
  }, [rows, online]);

  // Derived data (tabs filter client-side)
  const filteredRows = rows.filter((r) => {
    if (activeTab === "recent") {
      const d = new Date(r.created_at);
      const now = Date.now();
      return now - d.getTime() < 7 * 24 * 60 * 60 * 1000;
    }
    if (activeTab === "pending") return r.synced === false;
    return true;
  });

  // Selection
  const allVisibleSelected =
    filteredRows.length > 0 && filteredRows.every((r) => selected.has(r.id));

  const toggleAll = () => {
    if (allVisibleSelected) {
      setSelected(new Set());
    } else {
      setSelected(new Set(filteredRows.map((r) => r.id)));
    }
  };

  const toggleOne = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  // Delete
  const handleDelete = async () => {
    if (!confirmDelete) return;
    // RBAC safety check: only admin and supervisor can delete
    if (!can("people.delete")) {
      toast.error("Permission Denied", "Only a Supervisor or Admin can delete records.");
      setConfirmDelete(null);
      return;
    }
    setDeleting(true);
    try {
      const isForce = profile?.role === "admin" || profile?.role === "supervisor";
      await deletePerson(confirmDelete.id, isForce);
      toast.success("Deleted", isForce ? `${confirmDelete.name} has been forcefully removed.` : `${confirmDelete.name} has been removed.`);
      setConfirmDelete(null);
      setPage(0);
      const result = online
        ? await searchPersonsOnline({
            search: debounced || undefined,
            page: 0,
            pageSize,
          })
        : {
            rows: (await searchPersonsOffline(debounced, 200)).slice(
              0,
              pageSize
            ),
            total: 0,
          };
      setRows(result.rows as PersonRow[]);
      if ("total" in result) setTotal((result as { total: number }).total);
    } catch (err) {
      toast.error("Delete failed", mapSupabaseError(err).userMessage);
    } finally {
      setDeleting(false);
    }
  };

  // Export CSV
  const exportCSV = () => {
    const data = selected.size > 0
      ? filteredRows.filter((r) => selected.has(r.id))
      : filteredRows;
    const header = "Cheki Namba,Jina,Cheo,Sahihi ya Mtumishi,ID Issued,Status,Created\n";
    const body = data
      .map(
        (r) =>
          `"${r.identification_number}","${r.full_name}","${r.position ?? ""}","${r.signature_path ? "Signed" : "Not signed"}","${issuedMap.has(r.id) ? "Yes" : "No"}","${r.synced === false ? "Pending Sync" : "Registered"}","${r.created_at}"`
      )
      .join("\n");
    const blob = new Blob([header + body], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `people-registry-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Exported", `${data.length} records exported as CSV`);
  };

  // Copy to clipboard
  const copyId = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(id).then(() => {
      toast.success("Copied", `${id} copied to clipboard`);
    });
  };

  const totalPages = Math.max(Math.ceil(total / pageSize), 1);
  const startItem = total === 0 ? 0 : page * pageSize + 1;
  const endItem = Math.min((page + 1) * pageSize, total);

  return (
    <div className="space-y-4 animate-fade-in">
      {/* ─── Page Header ─────────────────────────────────────── */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-900 dark:text-slate-100">
            People Registry
          </h1>
          <p className="mt-0.5 text-sm text-gray-500 dark:text-slate-400">
            {online
              ? "Search the national registry by name, ID number, or phone"
              : "OFFLINE — searching locally synced records only"}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={exportCSV}
            disabled={loading || filteredRows.length === 0}
            icon={<Icon name="download" className="h-4 w-4" />}
          >
            Export
          </Button>
          {can("people.create") && (
            <Button
              size="sm"
              onClick={() => navigate("/app/id-card?new=true")}
              icon={<Icon name="plus" className="h-4 w-4" />}
            >
              Register Person
            </Button>
          )}
        </div>
      </div>

      {/* ─── Toolbar ─────────────────────────────────────────── */}
      <div className="rounded-2xl border border-gray-200/80 dark:border-slate-700/80 bg-white dark:bg-slate-800 shadow-sm">
        {/* Search + Filters Row */}
        <div className="flex flex-col gap-3 border-b border-gray-100 dark:border-slate-700 p-4 sm:flex-row sm:items-center">
          {/* Search */}
          <div className="relative flex-1">
            <Icon
              name="search"
              className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400 dark:text-slate-500"
            />
            <input
              ref={searchRef}
              type="text"
              placeholder="Search cheki namba, jina, or cheo..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className={cn(
                "w-full rounded-xl border border-gray-200 dark:border-slate-600 bg-gray-50/50 dark:bg-slate-900/50 py-2.5 pl-10 pr-10",
                "text-sm text-gray-900 dark:text-slate-100 placeholder-gray-400 dark:placeholder-slate-500",
                "outline-none transition-all duration-200",
                "focus:border-emerald-400 focus:bg-white dark:focus:bg-slate-800 focus:ring-2 focus:ring-emerald-500/10"
              )}
            />
            {search && (
              <button
                onClick={() => setSearch("")}
                className="absolute right-2 top-1/2 -translate-y-1/2 rounded-md p-1 text-gray-400 transition-colors hover:bg-gray-100 hover:text-gray-600"
              >
                <Icon name="x" className="h-3.5 w-3.5" />
              </button>
            )}
          </div>

          {/* Keyboard shortcut hint */}
          {!search && (
            <kbd className="hidden lg:inline-flex h-5 items-center rounded border border-gray-200 dark:border-slate-600 bg-gray-50 dark:bg-slate-900 px-1.5 font-mono text-[10px] text-gray-400 dark:text-slate-500">
              /
            </kbd>
          )}

          {/* Page size */}
          <select
            value={pageSize}
            onChange={(e) => {
              setPageSize(Number(e.target.value));
              setPage(0);
            }}                className="rounded-lg border border-gray-200 dark:border-slate-600 bg-white dark:bg-slate-800 px-3 py-2 text-xs font-medium text-gray-600 dark:text-slate-300 outline-none focus:border-emerald-400 focus:ring-2 focus:ring-emerald-500/10"
          >
            {PAGE_SIZES.map((s) => (
              <option key={s} value={s}>
                {s} / page
              </option>
            ))}
          </select>
        </div>

        {/* Filter Tabs + Bulk Actions */}
        <div className="flex items-center justify-between gap-3 px-4 py-2.5">
          <div className="flex items-center gap-1">
            {FILTER_TABS.map((tab) => (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id);
                  setPage(0);
                }}
                className={cn(
                  "inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium transition-all duration-200",
                  activeTab === tab.id
                    ? "bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 ring-1 ring-emerald-200 dark:ring-emerald-800"
                    : "text-gray-500 dark:text-slate-400 hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-700 dark:hover:text-slate-200"
                )}
              >
                <Icon name={tab.icon} className="h-3.5 w-3.5" />
                {tab.label}
                {tab.id === "pending" && (
                  <span className="ml-0.5 rounded-full bg-amber-100 px-1.5 py-0.5 text-[10px] font-bold text-amber-700">
                    {rows.filter((r) => r.synced === false).length || 0}
                  </span>
                )}
              </button>
            ))}
          </div>

          {/* Bulk Actions */}
          {selected.size > 0 && (
            <div className="flex items-center gap-2 animate-fade-in">
              <span className="text-xs font-medium text-gray-500">
                {selected.size} selected
              </span>
              <Button
                size="sm"
                variant="outline"
                onClick={() => {
                  toast.info(
                    "Bulk Print",
                    `${selected.size} records queued for batch printing`
                  );
                }}
                icon={<Icon name="printer" className="h-3.5 w-3.5" />}
              >
                Print
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={exportCSV}
                icon={<Icon name="download" className="h-3.5 w-3.5" />}
              >
                Export
              </Button>
              <button
                onClick={() => setSelected(new Set())}
                className="rounded-md p-1 text-gray-400 dark:text-slate-500 hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-600 dark:hover:text-slate-300"
              >
                <Icon name="x" className="h-3.5 w-3.5" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* ─── Data Table ──────────────────────────────────────── */}
      {error && (
        <div className="flex items-start justify-between gap-4 rounded-2xl border border-red-200 dark:border-red-900/50 bg-red-50 dark:bg-red-950/30 px-4 py-3">
          <div className="flex items-start gap-3">
            <Icon name="alert-circle" className="mt-0.5 h-5 w-5 shrink-0 text-red-500" />
            <div>
              <p className="text-sm font-semibold text-red-700 dark:text-red-400">
                Could not load the registry
              </p>
              <p className="mt-0.5 text-xs text-red-600/90 dark:text-red-400/80">{error}</p>
            </div>
          </div>
          <Button
            size="sm"
            variant="outline"
            onClick={() => { setRefreshNonce((n) => n + 1); setError(null); }}
            icon={<Icon name="refresh" className="h-3.5 w-3.5" />}
          >
            Retry
          </Button>
        </div>
      )}

      <div className="rounded-2xl border border-gray-200/80 dark:border-slate-700/80 bg-white dark:bg-slate-800 shadow-sm overflow-visible">
        {/* Table */}
        <div className="overflow-x-auto overflow-y-visible">
          <table className="w-full text-sm">
            {/* Header */}
            <thead>
              <tr className="border-b border-gray-100 dark:border-slate-700 bg-gray-50/80 dark:bg-slate-900/50">
                <th className="w-10 px-4 py-3">
                  <GlassCheckbox
                    checked={allVisibleSelected}
                    onChange={toggleAll}
                  />
                </th>
                {COLUMNS.map((col) => (
                  <th
                    key={col.key}
                    className={cn(
                      "px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:text-slate-400",
                      col.key === "actions" && "w-16 text-right",
                      col.className
                    )}
                  >
                    {col.label}
                  </th>
                ))}
              </tr>
            </thead>

            {/* Body */}
            <tbody className="divide-y divide-gray-100/80 dark:divide-slate-700/50">
              {loading ? (
                [...Array(pageSize < 10 ? pageSize : 10)].map((_, i) => (
                  <tr
                    key={i}
                    className="border-b border-gray-50 dark:border-slate-700"
                    style={{ animationDelay: `${i * 40}ms` }}
                  >
                    <td className="px-4 py-3">
                      <div className="h-4 w-4 rounded bg-gray-100 dark:bg-slate-700 animate-pulse" />
                    </td>
                    <td className="px-4 py-3">
                      <div className="h-3.5 w-24 rounded bg-gray-100 dark:bg-slate-700 animate-pulse" />
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="h-8 w-8 rounded-full bg-gray-100 dark:bg-slate-700 animate-pulse" />
                        <div className="h-3.5 w-28 rounded bg-gray-100 dark:bg-slate-700 animate-pulse" />
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="h-3.5 w-20 rounded bg-gray-100 dark:bg-slate-700 animate-pulse" />
                    </td>
                    <td className="px-4 py-3">
                      <div className="h-3.5 w-16 rounded bg-gray-100 dark:bg-slate-700 animate-pulse" />
                    </td>
                    <td className="px-4 py-3">
                      <div className="h-6 w-6 rounded-full bg-gray-100 dark:bg-slate-700 animate-pulse" />
                    </td>
                    <td className="px-4 py-3">
                      <div className="h-3.5 w-14 rounded bg-gray-100 dark:bg-slate-700 animate-pulse" />
                    </td>
                    <td className="px-4 py-3">
                      <div className="h-3.5 w-10 rounded bg-gray-100 dark:bg-slate-700 animate-pulse ml-auto" />
                    </td>
                  </tr>
                ))
              ) : filteredRows.length === 0 ? (
                <tr>
                  <td colSpan={8}>
                    <div className="flex flex-col items-center justify-center gap-4 py-16">
                      {error ? (
                        <>
                          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-red-50 dark:bg-red-950/40">
                            <Icon name="alert-circle" className="h-7 w-7 text-red-400" />
                          </div>
                          <div className="text-center">
                            <p className="text-sm font-medium text-red-600 dark:text-red-400">
                              Registry query failed
                            </p>
                            <p className="mt-1 max-w-md text-xs text-gray-400 dark:text-slate-500">
                              {error}
                            </p>
                          </div>
                        </>
                      ) : (
                        <>
                          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gray-100 dark:bg-slate-700">
                            <Icon
                              name={debounced ? "search" : "users"}
                              className="h-7 w-7 text-gray-300 dark:text-slate-500"
                            />
                          </div>
                          <div className="text-center">
                            <p className="text-sm font-medium text-gray-600 dark:text-slate-300">
                              {debounced
                                ? "No matching records"
                                : "No registered people yet"}
                            </p>
                            <p className="mt-1 text-xs text-gray-400 dark:text-slate-500">
                              {debounced
                                ? `No results for "${debounced}". Try a different search term.`
                                : "Register the first person to start using the system."}
                            </p>
                          </div>
                        </>
                      )}
                      {!error && can("people.create") && !debounced && (
                        <button
                          onClick={() => navigate("/app/id-card?new=true")}
                          className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 px-4 py-2 text-xs font-semibold text-white shadow-sm transition-all hover:bg-emerald-700 hover:shadow-md active:scale-95"
                        >
                          <Icon name="plus" className="h-3.5 w-3.5" />
                          Register First Person
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ) : (
                filteredRows.map((p, idx) => {
                  const isSelected = selected.has(p.id);
                  const isPending = p.synced === false;
                  return (
                    <tr
                      key={p.id}
                      onClick={() => navigate(`/app/id-card?person=${p.id}`)}
                      className={cn(
                        "group relative z-0 cursor-pointer transition-colors duration-100",
                        isSelected
                          ? "bg-emerald-50/60 dark:bg-emerald-950/20"
                          : idx % 2 === 1
                            ? "bg-gray-50/40 dark:bg-slate-800/40 hover:bg-emerald-50/30 dark:hover:bg-slate-700/40"
                            : "hover:bg-emerald-50/30 dark:hover:bg-slate-700/40"
                      )}
                    >
                      {/* Checkbox */}
                      <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                        <GlassCheckbox
                          checked={isSelected}
                          onChange={() => toggleOne(p.id)}
                        />
                      </td>

                      {/* Cheki Namba (Identification Number) */}
                      <td className="px-4 py-3">
                        <div className="group/id flex items-center gap-1.5">
                          <span className="font-mono text-xs font-semibold tracking-wide text-gray-900 dark:text-white">
                            {p.identification_number}
                          </span>
                          <button
                            onClick={(e) => copyId(p.identification_number, e)}
                            className="opacity-0 group-hover/id:opacity-100 rounded p-0.5 text-gray-400 dark:text-slate-500 transition-all hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-600 dark:hover:text-slate-300"
                            title="Copy to clipboard"
                          >
                            <svg
                              className="h-3 w-3"
                              fill="none"
                              viewBox="0 0 24 24"
                              strokeWidth={2}
                              stroke="currentColor"
                            >
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                d="M15.666 3.888A2.25 2.25 0 0013.5 2.25h-3c-1.03 0-1.9.693-2.166 1.638m7.332 0c.055.194.084.4.084.612v0a.75.75 0 01-.75.75H9.75a.75.75 0 01-.75-.75v0c0-.212.03-.418.084-.612m7.332 0c.646.049 1.288.11 1.927.184 1.1.128 1.907 1.077 1.907 2.185V19.5a2.25 2.25 0 01-2.25 2.25H6.75A2.25 2.25 0 014.5 19.5V6.257c0-1.108.806-2.057 1.907-2.185a48.208 48.208 0 011.927-.184"
                              />
                            </svg>
                          </button>
                        </div>
                      </td>

                      {/* Jina (Full Name) */}
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <div
                            className={cn(
                              "flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br text-[11px] font-bold text-white shadow-sm",
                              initialsColor(p.full_name)
                            )}
                          >
                            {initials(p.full_name)}
                          </div>
                          <div className="min-w-0">
                            <p className="truncate font-semibold text-gray-900 dark:text-white">
                              {p.full_name}
                            </p>
                          </div>
                        </div>
                      </td>

                      {/* Cheo (Position) */}
                      <td className="px-4 py-3">
                        <span className="text-sm font-medium text-gray-700 dark:text-slate-200">
                          {p.position || "-"}
                        </span>
                      </td>

                      {/* Sahihi ya Mtumishi (Employee Signature) */}
                      <td className="px-4 py-3">
                        {p.signature_path ? (
                          <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-emerald-700 dark:text-emerald-400 ring-1 ring-emerald-200 dark:ring-emerald-800">
                            <svg className="h-3 w-3" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                            </svg>
                            Signed
                          </span>
                        ) : (
                          <span className="text-xs text-gray-400 dark:text-slate-500 italic">
                            Not signed
                          </span>
                        )}
                      </td>

                      {/* ID Issued */}
                      <td className="px-4 py-3">
                        {issuedMap.has(p.id) ? (
                          <span className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-950/60">
                            <svg className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                            </svg>
                          </span>
                        ) : (
                          <span className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-red-100 dark:bg-red-950/60">
                            <svg className="h-3.5 w-3.5 text-red-500 dark:text-red-400" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                            </svg>
                          </span>
                        )}
                      </td>

                      {/* Status */}
                      <td className="px-4 py-3">
                        <span
                          className={cn(
                            "inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wide",
                            isPending
                              ? "bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400 ring-1 ring-amber-200 dark:ring-amber-800"
                              : "bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 ring-1 ring-emerald-200 dark:ring-emerald-800"
                          )}
                        >
                          <span
                            className={cn(
                              "h-1 w-1 rounded-full",
                              isPending
                                ? "bg-amber-500 animate-pulse"
                                : "bg-emerald-500"
                            )}
                          />
                          {isPending ? "Pending" : "Registered"}
                        </span>
                      </td>

                      {/* Actions */}
                      <td
                        className="relative z-10 px-4 py-3 text-right"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <div className="relative inline-block">
                          <button
                            onClick={() =>
                              setOpenMenu(
                                openMenu === p.id ? null : p.id
                              )
                            }
                            className="rounded-lg p-1.5 text-gray-400 dark:text-slate-500 transition-all duration-200 hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-600 dark:hover:text-slate-300"
                          >
                            <svg
                              className="h-4 w-4"
                              fill="none"
                              viewBox="0 0 24 24"
                              strokeWidth={2}
                              stroke="currentColor"
                            >
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                d="M6.75 12a.75.75 0 11-1.5 0 .75.75 0 011.5 0zM12.75 12a.75.75 0 11-1.5 0 .75.75 0 011.5 0zM18.75 12a.75.75 0 11-1.5 0 .75.75 0 011.5 0z"
                              />
                            </svg>
                          </button>

                          {/* Dropdown Menu */}
                          {openMenu === p.id && (
                            <>
                              {/* Click-away backdrop */}
                              <div
                                className="fixed inset-0 z-40"
                                onClick={() => setOpenMenu(null)}
                              />
                              <div className="absolute right-0 bottom-full z-50 mb-1 w-52 rounded-xl border border-gray-200/80 dark:border-slate-600/80 bg-white/95 dark:bg-slate-800/95 backdrop-blur-md py-1.5 shadow-xl dark:shadow-2xl dark:shadow-black/40 origin-bottom-right animate-scale-in">
                                <button
                                  onClick={() => {
                                    setOpenMenu(null);
                                    navigate(`/app/id-card?person=${p.id}`);
                                  }}
                                  className="flex w-full items-center gap-2.5 px-3.5 py-2.5 text-sm text-gray-700 dark:text-slate-200 hover:bg-gray-100 dark:hover:bg-slate-700/60 transition-colors rounded-md mx-1 w-[calc(100%-8px)]"
                                >
                                  <Icon
                                    name="eye"
                                    className="h-4 w-4 text-gray-400 dark:text-slate-400"
                                  />
                                  View Details
                                </button>
                                {can("issuance.create") && (
                                  <button
                                    onClick={() => {
                                      setOpenMenu(null);
                                      navigate(`/app/id-card?person=${p.id}`);
                                    }}
                                    className="flex w-full items-center gap-2.5 px-3.5 py-2.5 text-sm text-gray-700 dark:text-slate-200 hover:bg-gray-100 dark:hover:bg-slate-700/60 transition-colors rounded-md mx-1 w-[calc(100%-8px)]"
                                  >
                                    <Icon
                                      name="id-card"
                                      className="h-4 w-4 text-gray-400 dark:text-slate-400"
                                    />
                                    Issue ID
                                  </button>
                                )}
                                {can("people.delete") && (
                                  <>
                                    <div className="my-1.5 mx-3 border-t border-gray-200/60 dark:border-slate-600/60" />
                                    <button
                                      onClick={() => {
                                        setOpenMenu(null);
                                        setConfirmDelete({
                                          id: p.id,
                                          name: p.full_name,
                                        });
                                      }}
                                      className="flex w-full items-center gap-2.5 px-3.5 py-2.5 text-sm text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-500/10 transition-colors rounded-md mx-1 w-[calc(100%-8px)]"
                                    >
                                      <Icon
                                        name="trash"
                                        className="h-4 w-4 text-red-500 dark:text-red-400"
                                      />
                                      Delete
                                    </button>
                                  </>
                                )}
                              </div>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* ─── Pagination Footer ─────────────────────────────── */}
        {!loading && filteredRows.length > 0 && (
          <div className="flex items-center justify-between border-t border-gray-100 dark:border-slate-700 bg-gray-50/50 dark:bg-slate-900/50 px-4 py-3">
            <p className="text-xs text-gray-500 dark:text-slate-400">
              Showing <span className="font-semibold text-gray-700 dark:text-slate-200">{startItem}</span>
              {" - "}
              <span className="font-semibold text-gray-700 dark:text-slate-200">{endItem}</span>
              {" of "}
              <span className="font-semibold text-gray-700 dark:text-slate-200">
                {total.toLocaleString()}
              </span>
              {" entries"}
            </p>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setPage(Math.max(0, page - 1))}
                disabled={page === 0}
                className="flex h-8 w-8 items-center justify-center rounded-lg border border-gray-200 dark:border-slate-600 text-gray-600 dark:text-slate-400 transition-all hover:bg-white dark:hover:bg-slate-700 hover:shadow-sm disabled:opacity-40 disabled:hover:bg-transparent"
              >
                <Icon name="chevron-left" className="h-4 w-4" />
              </button>
              {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => {
                const pageNum =
                  totalPages <= 5
                    ? i
                    : Math.max(0, Math.min(page - 2, totalPages - 5)) + i;
                return (
                  <button
                    key={pageNum}
                    onClick={() => setPage(pageNum)}
                    className={cn(
                      "flex h-8 w-8 items-center justify-center rounded-lg text-xs font-medium transition-all duration-200",
                      page === pageNum
                        ? "bg-emerald-600 text-white shadow-sm shadow-emerald-500/25"
                        : "text-gray-600 dark:text-slate-400 hover:bg-white dark:hover:bg-slate-700 hover:text-gray-900 dark:hover:text-slate-100"
                    )}
                  >
                    {pageNum + 1}
                  </button>
                );
              })}
              <button
                onClick={() => setPage(Math.min(totalPages - 1, page + 1))}
                disabled={page >= totalPages - 1}
                className="flex h-8 w-8 items-center justify-center rounded-lg border border-gray-200 dark:border-slate-600 text-gray-600 dark:text-slate-400 transition-all hover:bg-white dark:hover:bg-slate-700 hover:shadow-sm disabled:opacity-40 disabled:hover:bg-transparent"
              >
                <Icon name="chevron-right" className="h-4 w-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* ─── Delete Confirmation ─────────────────────────────── */}
      <ConfirmDialog
        open={confirmDelete !== null}
        onCancel={() => setConfirmDelete(null)}
        options={{
          title: "Delete this person?",
          message: (
            <>
              You are about to permanently delete{" "}
              <strong>{confirmDelete?.name}</strong>. This cannot be undone.
              {online
                ? " The record will be removed from the central database."
                : " It will be removed locally and synced later."}
            </>
          ),
          confirmLabel: "Yes, delete",
          cancelLabel: "Cancel",
          danger: true,
          loading: deleting,
          onConfirm: () => {
            void handleDelete();
          },
        }}
      />
    </div>
  );
}
