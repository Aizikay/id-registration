/**
 * IdEditorPage — Dual-mode ID card designer.
 *
 * Mode A "View & Edit Card": search an existing person, preview their card,
 *   tweak the live fields, and print/export.
 * Mode B "Register Person": enter a brand-new person's details, capture a
 *   passport photo + signature, and save straight to the registry.
 *
 * Dark, high-contrast control panel paired with the yellow card canvas.
 */

import { useState, useCallback, useEffect, useRef } from "react";
import Loader from "@/components/Loader";
import { useSearchParams } from "react-router-dom";
import { Modal } from "@/components/ui/modal";
import { CropModal, type ImageTransform } from "./CropModal";
import { IdCanvas, renderHighResFront, renderHighResBack } from "./IdCanvas";
import { CARD_CONFIG, EDITABLE_FIELDS, FONT_OPTIONS, loadPresets, savePreset, deletePreset, resetToDefaults, loadPreset } from "./editorConfig";
import { getPersonById, registerPerson, updatePerson, searchPersonsOnline } from "@/services/people-service";
import { mapSupabaseError, AppError } from "@/services/errors";
import { getMeta, setMeta } from "@/db/database";
import { listDepartments, type DepartmentRow } from "@/services/departments-service";
import { printAgentClient } from "@/printing/agent-client";
import { desktop } from "@/lib/desktop";
import { createPrintHistory } from "@/services/print-history-service";
import type { EditorData } from "./IdCanvas";
import type { Gender, Person } from "@/types";

/**
 * Local draft key for the Register Person flow. The whole draft (fields +
 * photo + signature) is persisted to the app's IndexedDB (db.meta) on every
 * change, so a page refresh, tab close, or offline session never loses work.
 */
const REGISTER_DRAFT_KEY = "registrar.draft.v1";

interface RegisterDraft {
  mode: "register";
  cheki: string;
  jina: string;
  cheo: string;
  department: string;
  page: "front" | "back";
  photoSrc: string | null;
  photoTransform: EditorData["photoTransform"];
  sigSrc: string | null;
  sigTransform: EditorData["sigTransform"];
  savedAt: number;
}

function newId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    try { return crypto.randomUUID(); } catch { /* fall through */ }
  }
  return crypto.randomUUID?.() || Math.random().toString(36).slice(2);
}

interface HistoryEntry {
  cheki: string;
  jina: string;
  cheo: string;
  photoSrc: string | null;
  photoTransform: ImageTransform | null;
  sigSrc: string | null;
  sigTransform: ImageTransform | null;
}

type CalState = { x: number; y: number; fontSize: number; fontWeight: number; letterSpacing: number; lineHeight: number; color: string; fontFamily: string };

function loadImage(url: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error(`Failed to load: ${url}`));
    img.src = url;
  });
}

function getCalDef(field: string): CalState {
  const f = EDITABLE_FIELDS[field]!;
  return { x: f.x, y: f.y, fontSize: f.fontSize, fontWeight: f.fontWeight, letterSpacing: f.letterSpacing, lineHeight: f.lineHeight, color: f.color, fontFamily: f.fontFamily };
}

/** Shared, high-contrast input/label/card styling tokens. */
const inputCls =
  "w-full rounded-lg border border-slate-700/80 bg-slate-900 px-3 py-2.5 text-white shadow-inner outline-none transition-all duration-200 placeholder:text-slate-500 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20";
const labelCls = "mb-1.5 block text-[11px] font-semibold uppercase tracking-[0.1em] text-slate-200";
const cardCls = "rounded-xl border border-slate-800 bg-slate-900/60 p-3.5";
const ghostBtnCls =
  "flex items-center justify-center gap-1.5 rounded-lg border border-slate-700 bg-slate-950/40 px-2.5 py-1.5 text-[11px] font-medium text-slate-300 transition-all duration-200 hover:border-slate-600 hover:bg-slate-800 hover:text-white disabled:cursor-not-allowed disabled:opacity-40 active:scale-95";

// Dark Slider with progress fill
function Slider({ label, value, min, max, step = 1, onChange, unit = "" }: {
  label: string; value: number; min: number; max: number; step?: number;
  onChange: (v: number) => void; unit?: string;
}) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div className="flex items-center gap-2.5 py-1">
      <span className="w-[72px] shrink-0 text-[11px] font-medium text-slate-400 tracking-wide">{label}</span>
      <div className="relative flex-1">
        <input
          type="range"
          min={min}
          max={max}
          step={step}
          value={value}
          onChange={(e) => onChange(parseFloat(e.target.value) || 0)}
          className="slider-modern w-full"
          style={{ "--progress": `${pct}%` } as React.CSSProperties}
        />
      </div>
      <div className="w-[52px] shrink-0 rounded-md border border-slate-700 bg-slate-950 px-2 py-0.5 text-right text-[11px] font-mono text-slate-300 tabular-nums">
        {Math.round(value * 10) / 10}{unit}
      </div>
    </div>
  );
}

// Collapsible dark section (no nested scroll containers)
function Section({ title, icon, defaultOpen = false, accent = false, children }: {
  title: string; icon?: React.ReactNode; defaultOpen?: boolean; accent?: boolean; children: React.ReactNode;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className={`rounded-xl border transition-colors duration-200 overflow-hidden ${accent ? 'border-emerald-700/40 bg-emerald-950/20' : 'border-slate-800 bg-slate-900/60'}`}>
      <button
        onClick={() => setOpen(!open)}
        className={`flex w-full items-center justify-between px-3.5 py-2.5 text-left transition-colors ${accent ? 'hover:bg-emerald-900/20' : 'hover:bg-white/5'}`}
      >
        <span className={`flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider ${accent ? 'text-emerald-300' : 'text-slate-200'}`}>
          {icon}
          {title}
        </span>
        <span className={`flex h-5 w-5 items-center justify-center rounded-md transition-transform duration-200 ${open ? 'rotate-180 bg-slate-800 text-slate-300' : 'bg-slate-800/60 text-slate-500'}`}>
          <svg className="h-3 w-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" /></svg>
        </span>
      </button>
      {open && <div className={`space-y-0.5 border-t px-3.5 py-2.5 ${accent ? 'border-emerald-800/40' : 'border-slate-800'}`}>{children}</div>}
    </div>
  );
}

// Small inline signature pad (canvas draw)
function SignaturePadModal({ open, onClose, onApply }: {
  open: boolean; onClose: () => void; onApply: (img: HTMLImageElement) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const drawingRef = useRef(false);

  const clear = useCallback(() => {
    const c = canvasRef.current;
    const ctx = c?.getContext("2d");
    if (!c || !ctx) return;
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, c.width, c.height);
  }, []);

  useEffect(() => {
    if (!open) return;
    clear();
    const ctx = canvasRef.current?.getContext("2d");
    if (ctx) {
      ctx.strokeStyle = "#000000";
      ctx.lineWidth = 2.5;
      ctx.lineCap = "round";
      ctx.lineJoin = "round";
    }
  }, [open, clear]);

  const pos = (e: React.PointerEvent): { x: number; y: number } => {
    const r = canvasRef.current!.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  };

  const onDown = (e: React.PointerEvent) => {
    e.preventDefault();
    const ctx = canvasRef.current?.getContext("2d");
    if (!ctx) return;
    drawingRef.current = true;
    ctx.beginPath();
    const p = pos(e);
    ctx.moveTo(p.x, p.y);
  };

  const onMove = (e: React.PointerEvent) => {
    if (!drawingRef.current) return;
    e.preventDefault();
    const ctx = canvasRef.current?.getContext("2d");
    if (!ctx) return;
    const p = pos(e);
    ctx.lineTo(p.x, p.y);
    ctx.stroke();
  };

  const onUp = () => { drawingRef.current = false; };

  const apply = () => {
    const c = canvasRef.current;
    if (!c) return;
    const img = new Image();
    img.onload = () => onApply(img);
    img.src = c.toDataURL("image/png");
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Draw Signature"
      description="Sign inside the box with your mouse or touch"
      size="md"
      footer={
        <>
          <button onClick={clear} className={ghostBtnCls}>Clear</button>
          <button onClick={onClose} className={ghostBtnCls}>Cancel</button>
          <button
            onClick={apply}
            className="rounded-lg bg-emerald-600 px-5 py-2 text-sm font-semibold text-white shadow-lg shadow-emerald-600/25 transition-all hover:bg-emerald-500 active:scale-95"
          >
            Apply Signature
          </button>
        </>
      }
    >
      <canvas
        ref={canvasRef}
        width={480}
        height={160}
        className="w-full cursor-crosshair touch-none select-none rounded-xl border-2 border-dashed border-slate-600 bg-white shadow-inner"
        style={{ touchAction: "none" }}
        onPointerDown={onDown}
        onPointerMove={onMove}
        onPointerUp={onUp}
        onPointerLeave={onUp}
      />
      <p className="mt-2 text-xs text-slate-500 dark:text-slate-400">
        Draw with your mouse or finger, then press Apply Signature.
      </p>
    </Modal>
  );
}

export default function IdEditorPage() {
  const [searchParams] = useSearchParams();
  const isNewRegistration = searchParams.get("new") === "true";

  const [activeMode, setActiveMode] = useState<"view" | "register">(isNewRegistration ? "register" : "view");
  const [page, setPage] = useState<"front" | "back">("front");
  const [zoom, setZoom] = useState(1);
  const [zoomLocked, setZoomLocked] = useState(false);
  const [data, setData] = useState<EditorData>({
    cheki: "", jina: "", cheo: "",
    photo: null, photoTransform: null,
    signature: null, sigTransform: null,
  });
  const [department, setDepartment] = useState("");

  // Registered departments (user-created) — no built-in catalogue
  const [departments, setDepartments] = useState<DepartmentRow[]>([]);
  useEffect(() => {
    let cancelled = false;
    listDepartments()
      .then((rows) => {
        if (!cancelled) setDepartments(rows);
      })
      .catch(() => undefined); // dropdown simply stays empty when offline/table missing
    return () => {
      cancelled = true;
    };
  }, []);

  const [registering, setRegistering] = useState(false);
  const [currentPersonId, setCurrentPersonId] = useState<string | null>(null);
  const [hasDraft, setHasDraft] = useState(false);

  // ── Person search/select (View mode) ──────────────────────────────
  const [personQuery, setPersonQuery] = useState("");
  const [personResults, setPersonResults] = useState<Person[]>([]);
  const [peopleLoading, setPeopleLoading] = useState(false);
  const [selectedPerson, setSelectedPerson] = useState<Person | null>(null);
  const [peopleOpen, setPeopleOpen] = useState(false);
  const peopleRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let cancelled = false;
    const t = window.setTimeout(async () => {
      setPeopleLoading(true);
      try {
        const { rows } = await searchPersonsOnline({ search: personQuery.trim() || undefined, page: 0, pageSize: 20 });
        if (!cancelled) setPersonResults(rows);
      } catch {
        if (!cancelled) setPersonResults([]);
      } finally {
        if (!cancelled) setPeopleLoading(false);
      }
    }, personQuery.trim() ? 300 : 0);
    return () => { cancelled = true; window.clearTimeout(t); };
  }, [personQuery]);

  useEffect(() => {
    if (!peopleOpen) return;
    const h = (e: MouseEvent) => {
      if (!peopleRef.current?.contains(e.target as Node)) setPeopleOpen(false);
    };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, [peopleOpen]);

  const isDataUri = (v: string): boolean => v.startsWith("data:") || v.startsWith("blob:") || v.startsWith("http");

  const loadPersonImage = useCallback(async (src: string | null): Promise<HTMLImageElement | null> => {
    if (!src || !isDataUri(src)) return null;
    try {
      const img = new Image();
      img.crossOrigin = "anonymous";
      await new Promise<void>((resolve, reject) => {
        img.onload = () => resolve();
        img.onerror = () => reject(new Error("image"));
        img.src = src;
      });
      return img;
    } catch {
      return null;
    }
  }, []);

  // Load person data from ?person=, or clear for ?new=
  useEffect(() => {
    if (isNewRegistration) {
      clearForm();
      setSelectedPerson(null);
      setPersonQuery("");
      setPage("front");
      setActiveMode("register");
      return;
    }
    setActiveMode("view");
    const personId = searchParams.get("person");
    if (!personId) return;
    setCurrentPersonId(personId);
    let cancelled = false;
    void getPersonById(personId)
      .then(async (p) => {
        if (cancelled || !p) return;
        const photo = await loadPersonImage(p.photo_path);
        if (cancelled) return;
        const sig = await loadPersonImage(p.signature_path);
        if (cancelled) return;
        setSelectedPerson(p);
        setPersonQuery(p.identification_number);
        setDepartment(p.department ?? "");
        setData({
          cheki: p.identification_number || "",
          jina: (p.full_name || "").toUpperCase(),
          cheo: p.position ?? "",
          photo,
          photoTransform: null,
          signature: sig,
          sigTransform: null,
        });
        setPhotoThumb(photo ? photo.src : null);
        setSigThumb(sig ? sig.src : null);
        setPage("front");
      })
      .catch(() => undefined);
    return () => { cancelled = true; };
  }, [searchParams, isNewRegistration, loadPersonImage]); // eslint-disable-line react-hooks/exhaustive-deps

  const selectPerson = useCallback(async (p: Person) => {
    setSelectedPerson(p);
    setPeopleOpen(false);
    setPersonQuery(p.identification_number);
    setPage("front");
    const photo = await loadPersonImage(p.photo_path);
    const sig = await loadPersonImage(p.signature_path);
    setData({
      cheki: p.identification_number || "",
      jina: (p.full_name || "").toUpperCase(),
      cheo: p.position ?? "",
      photo,
      photoTransform: null,
      signature: sig,
      sigTransform: null,
    });
    setDepartment(p.department ?? "");
    setPhotoThumb(photo ? photo.src : null);
    setSigThumb(sig ? sig.src : null);
    showToast(`Loaded ${p.full_name}`, "info");
  }, [loadPersonImage]); // eslint-disable-line react-hooks/exhaustive-deps

  const [photoCropOpen, setPhotoCropOpen] = useState(false);
  const [sigCropOpen, setSigCropOpen] = useState(false);
  const [sigPadOpen, setSigPadOpen] = useState(false);
  const [pendingCropFile, setPendingCropFile] = useState<File | null>(null);
  const [frontBg, setFrontBg] = useState<HTMLImageElement | null>(null);
  const [backBg, setBackBg] = useState<HTMLImageElement | null>(null);

  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [historyIdx, setHistoryIdx] = useState(-1);

  const [photoPos, setPhotoPos] = useState({ x: 74.1, y: 40.3, w: 24.6, h: 52.0 });
  const [sigPos, setSigPos] = useState({ x: 30.0, y: 61.0, w: 12, h: 8 });
  const [posVersion, setPosVersion] = useState(0);
  const [chekiCal, setChekiCal] = useState<CalState>(getCalDef("cheki"));
  const [jinaCal, setJinaCal] = useState<CalState>(getCalDef("jina"));
  const [cheoCal, setCheoCal] = useState<CalState>(getCalDef("cheo"));
  const [fieldCalVersion, setFieldCalVersion] = useState(0);

  const [photoThumb, setPhotoThumb] = useState<string | null>(null);
  const [sigThumb, setSigThumb] = useState<string | null>(null);
  const [toast, setToast] = useState<{ msg: string; type: string } | null>(null);

  // Calibration presets
  const [presets, setPresets] = useState(loadPresets());
  const [presetName, setPresetName] = useState("");
  const [showPresetInput, setShowPresetInput] = useState(false);

  const showToast = (msg: string, type = "info") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 2800);
  };

  useEffect(() => {
    loadImage(CARD_CONFIG.frontImage).then(setFrontBg).catch(() => {});
    loadImage(CARD_CONFIG.backImage).then(setBackBg).catch(() => {});
  }, []);

  useEffect(() => {
    const timer = setTimeout(zoomFit, 150);
    return () => clearTimeout(timer);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Register-draft persistence (survives refresh / tab close / offline) ──
  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const draft = await getMeta<RegisterDraft>(REGISTER_DRAFT_KEY);
        if (cancelled || !draft || draft.mode !== "register") return;
        const hasContent = !!draft.jina || !!draft.cheki || !!draft.cheo || !!draft.photoSrc || !!draft.sigSrc;
        if (!hasContent) return;
        setActiveMode("register");
        setPage(draft.page === "back" ? "back" : "front");
        setDepartment(draft.department ?? "");
        setData((d) => ({
          ...d,
          cheki: draft.cheki ?? "",
          jina: draft.jina ?? "",
          cheo: draft.cheo ?? "",
          photoTransform: draft.photoTransform ?? null,
          sigTransform: draft.sigTransform ?? null,
        }));
        setPhotoThumb(draft.photoSrc ?? null);
        setSigThumb(draft.sigSrc ?? null);
        if (draft.photoSrc) { const img = new Image(); img.onload = () => setData((d) => ({ ...d, photo: img })); img.src = draft.photoSrc; }
        if (draft.sigSrc) { const img = new Image(); img.onload = () => setData((d) => ({ ...d, signature: img })); img.src = draft.sigSrc; }
        setHasDraft(true);
        showToast("Draft restored — auto-saved on this device", "info");
      } catch { /* storage unavailable */ }
    })();
    return () => { cancelled = true; };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (activeMode !== "register") return;
    const isEmpty = !data.cheki && !data.jina && !data.cheo && !photoThumb && !sigThumb;
    if (isEmpty) return;
    const draft: RegisterDraft = {
      mode: "register",
      cheki: data.cheki,
      jina: data.jina,
      cheo: data.cheo,
      department,
      page,
      photoSrc: photoThumb,
      photoTransform: data.photoTransform,
      sigSrc: sigThumb,
      sigTransform: data.sigTransform,
      savedAt: Date.now(),
    };
    const t = setTimeout(() => {
      void setMeta(REGISTER_DRAFT_KEY, draft)
        .then(() => setHasDraft(true))
        .catch(() => {});
    }, 400);
    return () => clearTimeout(t);
  }, [activeMode, data.cheki, data.jina, data.cheo, department, data.photoTransform, data.sigTransform, photoThumb, sigThumb, page]);

  // History management
  const snapshot = useCallback((): HistoryEntry => ({
    cheki: data.cheki, jina: data.jina, cheo: data.cheo,
    photoSrc: data.photo?.src || null, photoTransform: data.photoTransform,
    sigSrc: data.signature?.src || null, sigTransform: data.sigTransform,
  }), [data]);

  const pushHistory = useCallback(() => {
    setHistory((prev) => [...prev.slice(0, historyIdx + 1), snapshot()]);
    setHistoryIdx((i) => i + 1);
  }, [historyIdx, snapshot]);

  const restore = useCallback((entry: HistoryEntry) => {
    setData((d) => ({
      ...d, cheki: entry.cheki, jina: entry.jina, cheo: entry.cheo,
      photoTransform: entry.photoTransform, sigTransform: entry.sigTransform,
    }));
    setPhotoThumb(entry.photoSrc);
    setSigThumb(entry.sigSrc);
    if (entry.photoSrc) { const img = new Image(); img.onload = () => setData((d) => ({ ...d, photo: img })); img.src = entry.photoSrc; } else { setData((d) => ({ ...d, photo: null })); }
    if (entry.sigSrc) { const img = new Image(); img.onload = () => setData((d) => ({ ...d, signature: img })); img.src = entry.sigSrc; } else { setData((d) => ({ ...d, signature: null })); }
  }, []);

  const undo = useCallback(() => {
    if (historyIdx > 0 && history[historyIdx - 1]) { restore(history[historyIdx - 1]!); setHistoryIdx((i) => i - 1); }
  }, [history, historyIdx, restore]);

  const redo = useCallback(() => {
    if (historyIdx < history.length - 1 && history[historyIdx + 1]) { restore(history[historyIdx + 1]!); setHistoryIdx((i) => i + 1); }
  }, [history, historyIdx, restore]);

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "z") { e.preventDefault(); e.shiftKey ? redo() : undo(); }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [undo, redo]);

  // Handlers
  const handlePhotoApply = (img: HTMLImageElement, t: ImageTransform) => {
    pushHistory(); setData((d) => ({ ...d, photo: img, photoTransform: t })); setPhotoThumb(img.src); setPhotoCropOpen(false); setPendingCropFile(null); showToast("Photo applied", "success");
  };
  const handleSigApply = (img: HTMLImageElement, t: ImageTransform) => {
    pushHistory(); setData((d) => ({ ...d, signature: img, sigTransform: t })); setSigThumb(img.src); setSigCropOpen(false); setPendingCropFile(null); showToast("Signature applied", "success");
  };
  const handlePadApply = (img: HTMLImageElement) => {
    pushHistory(); setData((d) => ({ ...d, signature: img, sigTransform: null })); setSigThumb(img.src); setSigPadOpen(false); showToast("Signature drawn", "success");
  };
  const removePhoto = () => { pushHistory(); setData((d) => ({ ...d, photo: null, photoTransform: null })); setPhotoThumb(null); showToast("Photo removed", "info"); };
  const removeSig = () => { pushHistory(); setData((d) => ({ ...d, signature: null, sigTransform: null })); setSigThumb(null); showToast("Signature removed", "info"); };
  const handleFieldChange = (key: string, value: string) => { pushHistory(); setData((d) => ({ ...d, [key]: value })); };

  const closePhoto = () => { setPhotoCropOpen(false); setPendingCropFile(null); };
  const closeSig = () => { setSigCropOpen(false); setPendingCropFile(null); };

  const handlePhotoDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (!file) return;
    setPendingCropFile(file);
    setPhotoCropOpen(true);
  };

  const updateFieldCal = (field: string, key: string, value: string | number) => {
    const setter = field === "cheki" ? setChekiCal : field === "jina" ? setJinaCal : setCheoCal;
    setter((prev) => ({ ...prev, [key]: value }));
    const f = EDITABLE_FIELDS[field];
    if (f) (f as unknown as Record<string, unknown>)[key] = value;
    setFieldCalVersion((v) => v + 1);
  };

  const zoomFit = () => {
    const wrap = document.getElementById("canvasWrap");
    if (!wrap) return;
    const maxW = wrap.clientWidth - 60;
    const maxH = wrap.clientHeight - 60;
    const scale = Math.min(maxW / CARD_CONFIG.width, maxH / CARD_CONFIG.height, 2.5);
    setZoom(Math.max(0.5, scale));
    wrap.scrollLeft = 0;
    wrap.scrollTop = 0;
  };

  // Guarded zoom change — no-op while locked so the card stays at the set zoom.
  const changeZoom = useCallback((fn: (z: number) => number) => {
    if (zoomLocked) return;
    setZoom(fn);
  }, [zoomLocked]);

  // ── Mode helpers ──────────────────────────────────────────────────
  const clearForm = useCallback(() => {
    setDepartment("");
    setData((d) => ({
      ...d, cheki: "", jina: "", cheo: "",
      photo: null, photoTransform: null,
      signature: null, sigTransform: null,
    }));
    setPhotoThumb(null);
    setSigThumb(null);
    setPage("front");
    setHasDraft(false);
    void setMeta(REGISTER_DRAFT_KEY, null).catch(() => {});
  }, []);

  const switchMode = (m: "view" | "register") => {
    if (m === "register" && activeMode !== "register") clearForm();
    setActiveMode(m);
  };

  // Export functions
  const exportPNG = () => {
    showToast("Generating PNG...", "info");
    requestAnimationFrame(() => {
      try {
        const f = renderHighResFront(frontBg, data, photoPos, sigPos);
        const b = renderHighResBack(backBg);
        const scale = CARD_CONFIG.renderScale;
        const w = CARD_CONFIG.width * scale;
        const h = (CARD_CONFIG.height * 2 + 4) * scale;
        const c = document.createElement("canvas");
        c.width = w;
        c.height = h;
        const ctx = c.getContext("2d")!;
        ctx.fillStyle = "#fff";
        ctx.fillRect(0, 0, w, h);
        ctx.drawImage(f, 0, 0);
        ctx.strokeStyle = "#ccc";
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(0, CARD_CONFIG.height * scale + 2);
        ctx.lineTo(w, CARD_CONFIG.height * scale + 2);
        ctx.stroke();
        ctx.drawImage(b, 0, CARD_CONFIG.height * scale + 4 * scale);
        const link = document.createElement("a");
        link.download = `ID-${data.jina || "template"}.png`;
        link.href = c.toDataURL("image/png", 1);
        link.click();
        showToast("PNG exported", "success");
      } catch {
        showToast("Export failed", "error");
      }
    });
  };

  const exportPDF = async () => {
    showToast("Generating PDF...", "info");
    try {
      if (!(window as unknown as Record<string, unknown>).jspdf) {
        await new Promise<void>((resolve, reject) => {
          const s = document.createElement("script");
          s.src = "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js";
          s.onload = () => resolve();
          s.onerror = reject;
          document.head.appendChild(s);
        });
      }
      const { jsPDF } = (window as unknown as Record<string, unknown>).jspdf as { jsPDF: never };
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const pdf = new (jsPDF as any)({
        orientation: "landscape",
        unit: "mm",
        format: [CARD_CONFIG.physicalWidth, CARD_CONFIG.physicalHeight * 2 + 4],
      });
      pdf.addImage(
        renderHighResFront(frontBg, data, photoPos, sigPos).toDataURL("image/png", 1),
        "PNG", 0, 0, CARD_CONFIG.physicalWidth, CARD_CONFIG.physicalHeight
      );
      pdf.addPage([CARD_CONFIG.physicalWidth, CARD_CONFIG.physicalHeight], "landscape");
      pdf.addImage(
        renderHighResBack(backBg).toDataURL("image/png", 1),
        "PNG", 0, 0, CARD_CONFIG.physicalWidth, CARD_CONFIG.physicalHeight
      );
      pdf.save(`ID-${data.jina || "template"}.pdf`);
      showToast("PDF exported", "success");
    } catch {
      showToast("PDF export failed", "error");
    }
  };

  const printID = async () => {
    // Generate front and back page images
    const f = renderHighResFront(frontBg, data, photoPos, sigPos);
    const b = renderHighResBack(backBg);
    const frontDataUrl = f.toDataURL('image/png', 1);
    const backDataUrl = b.toDataURL('image/png', 1);

    // In the desktop app, print natively (main process → OS spooler).
    const native = desktop();
    if (native) {
      try {
        const printers = await native.listPrinters();
        const printer = printers.find((p) => p.is_default) ?? printers[0];
        if (!printer) {
          showToast('No printer installed on this computer', 'error');
          return;
        }
        const result = await native.print({
          job_ref: `PRINT-${Date.now().toString(36).toUpperCase()}`,
          printer_name: printer.name,
          front_image_src: frontDataUrl,
          back_image_src: backDataUrl,
          copies: 1,
          duplex: true,
          orientation: 'landscape',
        });
        if (result.ok) {
          showToast(`Print sent to ${printer.name}`, 'success');
        } else {
          showToast(`Print failed: ${result.error_message || 'Unknown error'}`, 'error');
        }
      } catch (err) {
        showToast(`Print failed: ${err instanceof Error ? err.message : 'Unknown error'}`, 'error');
      }
      return;
    }

    // Try to send to Print Agent first
    try {
      const status = await printAgentClient.status();
      if (status.printers.length > 0) {
        const printer = status.printers.find((p) => p.is_default) ?? status.printers[0];
        if (!printer) return;
        
        // Create print history record
        const historyRecord = await createPrintHistory({
          document_name: `ID Card — ${data.jina || 'Template'}`,
          printer_name: printer.name,
          printer_connection_type: 'unknown',
          person_name: data.jina || null,
          identification_number: null,
          status: 'printing',
        });

        // Send to Print Agent
        const idempotencyKey = `PRINT-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 8)}`;
        const result = await printAgentClient.submitPrintJob({
          document_reference: historyRecord.id,
          issuance_reference: `PH-${historyRecord.id.slice(0, 8)}`,
          idempotency_key: idempotencyKey,
          printer_id: printer.id,
          person_name: data.jina || 'ID Card',
          identification_number: 'DIRECT-PRINT',
          issued_by_staff_number: null,
          issued_at_iso: new Date().toISOString(),
          council_name_sw: 'HALMASHAURI YA WILAYA YA MERU',
          council_name_en: 'MERU DISTRICT COUNCIL',
          front_image_src: frontDataUrl,
          back_image_src: backDataUrl,
        });

        if (result.ok) {
          showToast(`Print sent to ${printer.name}`, 'success');
        } else {
          showToast(`Print failed: ${result.error_message || 'Unknown error'}`, 'error');
        }
        return;
      }
    } catch {
      // Print Agent not available, fall through to browser print
    }

    // Fallback: browser print dialog
    const w = window.open("", "_blank");
    if (!w) return;
    w.document.write(`<!DOCTYPE html><html><head><title>Print ID — ${data.jina || 'Template'}</title><style>
      @page{size:${CARD_CONFIG.physicalWidth}mm ${CARD_CONFIG.physicalHeight}mm;margin:0}
      *{margin:0;padding:0;box-sizing:border-box}
      body{font-family:serif;-webkit-print-color-adjust:exact;print-color-adjust:exact}
      .pg{width:${CARD_CONFIG.physicalWidth}mm;height:${CARD_CONFIG.physicalHeight}mm;page-break-after:always;overflow:hidden}
      .pg:last-child{page-break-after:auto}
      .pg img{width:100%;height:100%;display:block}
      @media print{.pg{margin:0!important}}
    </style></head><body>
      <div class="pg"><img src="${frontDataUrl}"></div>
      <div class="pg"><img src="${backDataUrl}"></div>
      <script>onload=function(){setTimeout(()=>print(),500)}</script>
    </body></html>`);
    w.document.close();
  };

  const resetCard = () => {
    if (!confirm("Reset the card fields and layout calibration to defaults?")) return;
    pushHistory();
    resetToDefaults();
    setChekiCal(getCalDef("cheki"));
    setJinaCal(getCalDef("jina"));
    setCheoCal(getCalDef("cheo"));
    setFieldCalVersion((v) => v + 1);
    clearForm();
    showToast("Card reset", "info");
  };

  const handleSavePreset = () => {
    if (!presetName.trim()) { showToast("Enter a preset name", "error"); return; }
    savePreset(presetName.trim());
    setPresets(loadPresets());
    setPresetName("");
    setShowPresetInput(false);
    showToast(`Saved "${presetName.trim()}"`, "success");
  };

  const handleLoadPreset = (id: string) => {
    if (loadPreset(id)) {
      setChekiCal(getCalDef("cheki"));
      setJinaCal(getCalDef("jina"));
      setCheoCal(getCalDef("cheo"));
      setFieldCalVersion((v) => v + 1);
      showToast("Calibration loaded", "success");
    }
  };

  const handleDeletePreset = (id: string) => {
    deletePreset(id);
    setPresets(loadPresets());
    showToast("Preset deleted", "info");
  };

  // ── Registration handler ──────────────────────────────────────────
  const handleRegisterSubmit = async () => {
    if (!data.jina.trim()) { showToast("Enter a name (Jina)", "error"); return; }
    if (!data.cheki.trim()) { showToast("Enter an ID number (Cheki Namba)", "error"); return; }
    if (!data.cheo.trim()) { showToast("Enter a position (Cheo)", "error"); return; }
    setRegistering(true);
    try {
      const result = await registerPerson({
        id: newId(),
        identification_number: data.cheki.trim().toUpperCase(),
        full_name: data.jina.trim().toUpperCase(),
        date_of_birth: new Date().toISOString().slice(0, 10),
        gender: "male" as Gender,
        nationality: "Tanzanian",
        address: "Not specified",
        phone: null,
        position: data.cheo.trim() || null,
        department: department.trim() || null,
        photo_path: photoThumb ?? null,
        signature_path: sigThumb ?? null,
      });
      showToast(`${result.person.full_name} registered successfully`, "success");
      // Clear the local draft — this record now lives in the database.
      setHasDraft(false);
      void setMeta(REGISTER_DRAFT_KEY, null).catch(() => {});
      // Update the card with the new record and hand off to View mode.
      const newPerson = { ...result.person } as Person;
      setSelectedPerson(newPerson);
      setPersonQuery(newPerson.identification_number);
      setActiveMode("view");
    } catch (err) {
      const mapped = err instanceof AppError ? err : mapSupabaseError(err);
      showToast(`Registration failed: ${mapped.userMessage}`, "error");
    } finally {
      setRegistering(false);
    }
  };

  // ── Update existing person handler ──────────────────────────────
  const handleUpdateRecord = async () => {
    if (!currentPersonId) return;
    if (!data.jina.trim()) { showToast("Enter a name (Jina)", "error"); return; }
    if (!data.cheki.trim()) { showToast("Enter an ID number (Cheki Namba)", "error"); return; }
    setRegistering(true);
    try {
      await updatePerson(currentPersonId, {
        identification_number: data.cheki.trim().toUpperCase(),
        full_name: data.jina.trim().toUpperCase(),
        position: data.cheo.trim() || null,
        department: department.trim() || null,
        photo_path: photoThumb ?? null,
        signature_path: sigThumb ?? null,
      });
      showToast("Record updated successfully", "success");
    } catch (err) {
      const mapped = err instanceof AppError ? err : mapSupabaseError(err);
      showToast(`Update failed: ${mapped.userMessage}`, "error");
    } finally {
      setRegistering(false);
    }
  };

  // Build the field calibration sliders for each editable field
  const renderFieldCalibration = (fieldKey: string, cal: CalState, yRange: [number, number]) => (
    <>
      <Slider label="X Position" value={cal.x} min={10} max={50} step={0.1} onChange={(v) => { updateFieldCal(fieldKey, "x", v); setChekiCal(prev => fieldKey === "cheki" ? { ...prev, x: v } : prev); setJinaCal(prev => fieldKey === "jina" ? { ...prev, x: v } : prev); setCheoCal(prev => fieldKey === "cheo" ? { ...prev, x: v } : prev); }} unit="%" />
      <Slider label="Y Position" value={cal.y} min={yRange[0]} max={yRange[1]} step={0.1} onChange={(v) => { updateFieldCal(fieldKey, "y", v); setChekiCal(prev => fieldKey === "cheki" ? { ...prev, y: v } : prev); setJinaCal(prev => fieldKey === "jina" ? { ...prev, y: v } : prev); setCheoCal(prev => fieldKey === "cheo" ? { ...prev, y: v } : prev); }} unit="%" />
      <Slider label="Font Size" value={cal.fontSize} min={8} max={40} step={1} onChange={(v) => { updateFieldCal(fieldKey, "fontSize", v); setChekiCal(prev => fieldKey === "cheki" ? { ...prev, fontSize: v } : prev); setJinaCal(prev => fieldKey === "jina" ? { ...prev, fontSize: v } : prev); setCheoCal(prev => fieldKey === "cheo" ? { ...prev, fontSize: v } : prev); }} unit="px" />
      <Slider label="Font Weight" value={cal.fontWeight} min={100} max={900} step={100} onChange={(v) => { updateFieldCal(fieldKey, "fontWeight", v); setChekiCal(prev => fieldKey === "cheki" ? { ...prev, fontWeight: v } : prev); setJinaCal(prev => fieldKey === "jina" ? { ...prev, fontWeight: v } : prev); setCheoCal(prev => fieldKey === "cheo" ? { ...prev, fontWeight: v } : prev); }} />
      <Slider label="Spacing" value={cal.letterSpacing} min={-2} max={5} step={0.1} onChange={(v) => { updateFieldCal(fieldKey, "letterSpacing", v); setChekiCal(prev => fieldKey === "cheki" ? { ...prev, letterSpacing: v } : prev); setJinaCal(prev => fieldKey === "jina" ? { ...prev, letterSpacing: v } : prev); setCheoCal(prev => fieldKey === "cheo" ? { ...prev, letterSpacing: v } : prev); }} unit="px" />
      <Slider label="Line Height" value={cal.lineHeight} min={0.5} max={2} step={0.05} onChange={(v) => { updateFieldCal(fieldKey, "lineHeight", v); setChekiCal(prev => fieldKey === "cheki" ? { ...prev, lineHeight: v } : prev); setJinaCal(prev => fieldKey === "jina" ? { ...prev, lineHeight: v } : prev); setCheoCal(prev => fieldKey === "cheo" ? { ...prev, lineHeight: v } : prev); }} />
      <div className="flex items-center gap-2.5 py-1">
        <span className="w-[72px] shrink-0 text-[11px] font-medium text-slate-400 tracking-wide">Font</span>
        <select
          className="flex-1 rounded-lg border border-slate-700 bg-slate-900 px-2 py-1.5 text-[11px] text-slate-100 outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
          value={cal.fontFamily}
          onChange={(e) => { updateFieldCal(fieldKey, "fontFamily", e.target.value); setChekiCal(prev => fieldKey === "cheki" ? { ...prev, fontFamily: e.target.value } : prev); setJinaCal(prev => fieldKey === "jina" ? { ...prev, fontFamily: e.target.value } : prev); setCheoCal(prev => fieldKey === "cheo" ? { ...prev, fontFamily: e.target.value } : prev); }}
        >
          {FONT_OPTIONS.map((fo) => (
            <option key={fo.value} value={fo.value} style={{ fontFamily: fo.value }}>{fo.label}</option>
          ))}
        </select>
      </div>
      <div className="flex items-center gap-2.5 py-1">
        <span className="w-[72px] shrink-0 text-[11px] font-medium text-slate-400 tracking-wide">Color</span>
        <div className="flex items-center gap-2">
          <input type="color" className="h-6 w-8 cursor-pointer rounded-md border border-slate-700 bg-slate-900 p-0.5" value={cal.color} onChange={(e) => { updateFieldCal(fieldKey, "color", e.target.value); setChekiCal(prev => fieldKey === "cheki" ? { ...prev, color: e.target.value } : prev); setJinaCal(prev => fieldKey === "jina" ? { ...prev, color: e.target.value } : prev); setCheoCal(prev => fieldKey === "cheo" ? { ...prev, color: e.target.value } : prev); }} />
          <span className="text-[10px] font-mono text-slate-400">{cal.color}</span>
        </div>
      </div>
    </>
  );

  const renderPhotoBlock = () => (
    <div className={cardCls}>
      <label className={labelCls}>Passport Photo</label>
      {photoThumb ? (
        <div className="flex items-center gap-3 rounded-lg border border-slate-700 bg-slate-950/40 p-3">
          <div className="h-[72px] w-[52px] shrink-0 overflow-hidden rounded-lg border-2 border-slate-700 shadow-inner">
            <img src={photoThumb} alt="Passport photo" className="h-full w-full object-cover" />
          </div>
          <div className="flex flex-1 flex-col gap-1.5">
            <button onClick={() => setPhotoCropOpen(true)} className={ghostBtnCls + " border-emerald-700/50 bg-emerald-950/30 text-emerald-300 hover:border-emerald-600 hover:bg-emerald-900/40"}>
              Change Photo
            </button>
            <button onClick={removePhoto} className={ghostBtnCls + " border-red-800/50 bg-red-950/20 text-red-300 hover:border-red-700 hover:bg-red-950/40"}>
              Remove Photo
            </button>
          </div>
        </div>
      ) : (
        <div
          onDrop={handlePhotoDrop}
          onDragOver={(e) => e.preventDefault()}
          onClick={() => setPhotoCropOpen(true)}
          className="flex cursor-pointer flex-col items-center rounded-xl border-2 border-dashed border-slate-700 bg-slate-950/40 p-6 text-center transition-all duration-200 hover:border-emerald-500/60 hover:bg-emerald-950/20 hover:shadow-inner active:scale-[0.99]"
        >
          <svg className="mx-auto mb-2 h-9 w-9 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
          <p className="text-[13px] font-medium text-slate-200">Drop photo or click to upload</p>
          <p className="mt-0.5 text-[11px] text-slate-500">Crop, zoom and rotate</p>
        </div>
      )}
    </div>
  );

  const renderSignatureBlock = () => (
    <div className={cardCls}>
      <label className={labelCls}>Sahihi ya Mtumishi</label>
      {sigThumb ? (
        <div className="flex items-center gap-3 rounded-lg border border-slate-700 bg-slate-950/40 p-3">
          <div className="h-14 w-24 shrink-0 overflow-hidden rounded-lg border-2 border-slate-700 bg-white shadow-inner">
            <img src={sigThumb} alt="Signature" className="h-full w-full object-contain p-1" />
          </div>
          <div className="flex flex-1 flex-col gap-1.5">
            <button onClick={() => setSigCropOpen(true)} className={ghostBtnCls + " border-emerald-700/50 bg-emerald-950/30 text-emerald-300 hover:border-emerald-600 hover:bg-emerald-900/40"}>
              Upload / Replace
            </button>
            <button onClick={() => setSigPadOpen(true)} className={ghostBtnCls + " border-sky-700/50 bg-sky-950/30 text-sky-300 hover:border-sky-600 hover:bg-sky-900/40"}>
              Re-draw
            </button>
            <button onClick={removeSig} className={ghostBtnCls + " border-red-800/50 bg-red-950/20 text-red-300 hover:border-red-700 hover:bg-red-950/40"}>
              Remove
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => setSigCropOpen(true)}
            className="flex flex-col items-center gap-2 rounded-xl border-2 border-dashed border-slate-700 bg-slate-950/40 p-5 text-center transition-all duration-200 hover:border-slate-600 hover:bg-slate-900 hover:shadow-inner active:scale-[0.98]"
          >
            <svg className="h-7 w-7 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5" /></svg>
            <span className="text-[12px] font-semibold text-slate-200">Upload File</span>
            <span className="text-[10px] text-slate-500">JPG · PNG · WebP</span>
          </button>
          <button
            onClick={() => setSigPadOpen(true)}
            className="flex flex-col items-center gap-2 rounded-xl border-2 border-dashed border-slate-700 bg-slate-950/40 p-5 text-center transition-all duration-200 hover:border-slate-600 hover:bg-slate-900 hover:shadow-inner active:scale-[0.98]"
          >
            <svg className="h-7 w-7 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
            <span className="text-[12px] font-semibold text-slate-200">Draw Signature</span>
            <span className="text-[10px] text-slate-500">Mouse or touch</span>
          </button>
        </div>
      )}
    </div>
  );

  const renderPersonPicker = () => (
    <div className={cardCls}>
      <label className={labelCls}>Search / Select Person</label>
      <div ref={peopleRef}>
        <div className="relative">
          <svg className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-4.35-4.35M17 10a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
          <input
            type="text"
            value={personQuery}
            onChange={(e) => { setPersonQuery(e.target.value); setPeopleOpen(true); }}
            onFocus={() => setPeopleOpen(true)}
            placeholder="Search by name or Cheki Namba..."
            className={inputCls + " pl-9"}
          />
          {peopleLoading && (
            <span className="absolute right-3 top-1/2 -translate-y-1/2"><Loader /></span>
          )}
        </div>

        {peopleOpen && (
          <ul className="mt-1.5 max-h-52 space-y-0.5 overflow-y-auto rounded-xl border border-slate-700 bg-slate-900 p-1 shadow-2xl">
            {personResults.length === 0 ? (
              <li className="px-3 py-4 text-center text-xs text-slate-500">
                {peopleLoading ? "Searching..." : "No people found"}
              </li>
            ) : (
              personResults.map((p) => (
                <li key={p.id}>
                  <button
                    onClick={() => void selectPerson(p)}
                    className="flex w-full items-center gap-3 rounded-lg px-2.5 py-2 text-left transition-colors hover:bg-slate-800"
                  >
                    <div className="flex h-8 w-8 shrink-0 items-center justify-center overflow-hidden rounded-full bg-slate-800 text-[10px] font-semibold text-slate-300">
                      {p.photo_path && isDataUri(p.photo_path) ? (
                        <img src={p.photo_path} alt="" className="h-full w-full object-cover" />
                      ) : (
                        p.full_name.split(/\s+/).slice(0, 2).map((s) => s[0]).join("").toUpperCase()
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[13px] font-medium text-white">{p.full_name}</p>
                      <p className="truncate font-mono text-[11px] text-slate-400">{p.identification_number}</p>
                    </div>
                  </button>
                </li>
              ))
            )}
          </ul>
        )}
      </div>
      {selectedPerson ? (
        <p className="mt-2 flex items-center gap-1.5 text-[11px] text-emerald-400">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
          Editing: {selectedPerson.full_name}
        </p>
      ) : (
        <p className="mt-2 text-[11px] text-slate-500">
          Pick a person above, or switch to Register to add a new one.
        </p>
      )}
    </div>
  );

  const renderFieldBlock = (key: "cheki" | "jina" | "cheo", label: string, placeholder: string, transform: "upper" | "none") => (
    <div className={cardCls}>
      <label className={labelCls}>
        {label}
        {activeMode === "register" && <span className="ml-1 text-red-400">*</span>}
      </label>
      <input
        type="text"
        className={inputCls}
        placeholder={placeholder}
        value={data[key]}
        onChange={(e) => handleFieldChange(key, transform === "upper" ? e.target.value.toUpperCase() : e.target.value)}
      />
    </div>
  );

  const renderDepartmentBlock = () => (
    <div className={cardCls}>
      <label className={labelCls}>Idara / Department</label>
      <select
        className={inputCls + " cursor-pointer appearance-none"}
        value={department}
        onChange={(e) => setDepartment(e.target.value)}
      >
        <option value="">-- Select department --</option>
        {departments.map((dep) => (
          <option key={dep.id} value={dep.id}>
            {dep.name_sw} — {dep.name_en}
          </option>
        ))}
      </select>
      <p className="mt-1.5 text-[10px] text-slate-500">
        {departments.length === 0
          ? "No departments registered yet — add them on the Departments page."
          : "Registered IDs are filed under this department."}
      </p>
    </div>
  );

  return (
    <div className="flex h-[calc(100vh-3.5rem)] overflow-hidden bg-slate-950 text-slate-100 animate-fade-in">
      {/* Toast */}
      {toast && (
        <div className={`fixed bottom-6 right-6 z-[9999] flex items-center gap-2 rounded-xl px-5 py-3 text-sm font-medium shadow-2xl backdrop-blur-sm transition-all duration-300 ${
          toast.type === "success" ? "bg-emerald-600/95 text-white shadow-emerald-500/30" :
          toast.type === "error" ? "bg-red-500/95 text-white shadow-red-500/30" :
          "bg-slate-800/95 text-white shadow-slate-800/30"
        }`}>
          {toast.msg}
        </div>
      )}

      {/* ═══ LEFT SIDEBAR CONTROL PANEL ═══ */}
      <aside className="flex w-96 shrink-0 flex-col gap-3 border-r border-slate-800 bg-slate-900/90 p-4">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-base font-semibold tracking-tight text-white">
              {activeMode === "register" ? "Register New Person" : currentPersonId ? "Edit Person" : "ID Card Designer"}
            </h2>
            <p className="mt-0.5 text-[11px] text-emerald-300/80">
              {activeMode === "register"
                ? "Fill the form below and save to registry"
                : currentPersonId
                  ? `Editing: ${data.jina || "..."}`
                  : "Halmashauri ya Wilaya ya Meru"}
            </p>
          </div>
          {activeMode === "register" && (
            <span className="flex items-center gap-1.5 rounded-full border border-emerald-700/50 bg-emerald-950/40 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider text-emerald-300">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-60" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
              </span>
              New
            </span>
          )}
          {currentPersonId && activeMode === "view" && (
            <span className="flex items-center gap-1.5 rounded-full border border-sky-700/50 bg-sky-950/40 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider text-sky-300">
              <svg className="h-3 w-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125" /></svg>
              Editing
            </span>
          )}
        </div>

        {/* Mode Switcher */}
        <div className="grid grid-cols-2 gap-1 rounded-xl border border-slate-800 bg-slate-950 p-1">
          <button
            onClick={() => switchMode("view")}
            className={`flex items-center justify-center gap-1.5 rounded-lg py-2 text-[13px] font-medium transition-all duration-200 ${
              activeMode === "view" ? "bg-emerald-600 text-white shadow-lg shadow-emerald-600/25" : "text-slate-400 hover:text-white"
            }`}
          >
            <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
            View &amp; Edit
          </button>
          <button
            onClick={() => switchMode("register")}
            className={`flex items-center justify-center gap-1.5 rounded-lg py-2 text-[13px] font-medium transition-all duration-200 ${
              activeMode === "register" ? "bg-emerald-600 text-white shadow-lg shadow-emerald-600/25" : "text-slate-400 hover:text-white"
            }`}
          >
            <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M18 9v3m0 0v3m0-3h3M7 7h.01M3 4h4v4H3V4zm10 0h4v4h-4V4zM3 16h4v4H3v-4zm10 0h4v4h-4v-4z" /></svg>
            Register Person
          </button>
        </div>

        {/* Scrollable tab content — single scroll region, no nested wrappers */}
        <div className="min-h-0 flex-1 space-y-3 overflow-y-auto pr-1" style={{ scrollbarWidth: "thin", scrollbarColor: "#334155 transparent" }}>
          {activeMode === "view" ? (
            <>
              {renderPersonPicker()}

              {/* Card Side Selector */}
              <div className={cardCls}>
                <label className={labelCls}>Card Side</label>
                <div className="grid grid-cols-2 gap-1.5 rounded-xl bg-slate-950 p-1 border border-slate-800">
                  <button
                    onClick={() => setPage("front")}
                    className={`flex items-center justify-center gap-1.5 rounded-lg px-3 py-2.5 text-[13px] font-medium transition-all duration-200 ${
                      page === "front"
                        ? "bg-emerald-600 text-white shadow-lg shadow-emerald-600/25"
                        : "text-slate-400 hover:bg-slate-800 hover:text-white"
                    }`}
                  >
                    Front Side
                  </button>
                  <button
                    onClick={() => setPage("back")}
                    className={`flex items-center justify-center gap-1.5 rounded-lg px-3 py-2.5 text-[13px] font-medium transition-all duration-200 ${
                      page === "back"
                        ? "bg-emerald-600 text-white shadow-lg shadow-emerald-600/25"
                        : "text-slate-400 hover:bg-slate-800 hover:text-white"
                    }`}
                  >
                    Back Side
                  </button>
                </div>
              </div>              {page === "front" && (
                <>
                  {renderFieldBlock("cheki", "Cheki Namba", "8973229", "none")}
                  {renderFieldBlock("jina", "Jina (Full Name)", "ELIZABETH R. MGOMBELO", "upper")}
                  {renderFieldBlock("cheo", "Cheo (Position)", "AFISA ELIMU KATA", "upper")}
                  {renderDepartmentBlock()}

                  {renderPhotoBlock()}
                  {renderSignatureBlock()}

                  {/* Advanced layout calibration — tucked away */}
                  <Section title="Advanced Layout" defaultOpen={false}>
                    <Section title="Cheki Namba">
                      {renderFieldCalibration("cheki", chekiCal, [20, 70])}
                    </Section>
                    <Section title="Jina">
                      {renderFieldCalibration("jina", jinaCal, [30, 80])}
                    </Section>
                    <Section title="Cheo">
                      {renderFieldCalibration("cheo", cheoCal, [40, 90])}
                    </Section>
                    <Section title="Photo Position">
                      <Slider label="X Position" value={photoPos.x} min={40} max={90} step={0.1} onChange={(v) => { setPhotoPos(p => ({ ...p, x: v })); setPosVersion(v => v + 1); }} unit="%" />
                      <Slider label="Y Position" value={photoPos.y} min={10} max={80} step={0.1} onChange={(v) => { setPhotoPos(p => ({ ...p, y: v })); setPosVersion(v => v + 1); }} unit="%" />
                      <Slider label="Width" value={photoPos.w} min={10} max={40} step={0.1} onChange={(v) => { setPhotoPos(p => ({ ...p, w: v })); setPosVersion(v => v + 1); }} unit="%" />
                      <Slider label="Height" value={photoPos.h} min={20} max={80} step={0.1} onChange={(v) => { setPhotoPos(p => ({ ...p, h: v })); setPosVersion(v => v + 1); }} unit="%" />
                    </Section>
                    <Section title="Signature Position">
                      <Slider label="X Position" value={sigPos.x} min={5} max={50} step={0.1} onChange={(v) => { setSigPos(p => ({ ...p, x: v })); setPosVersion(q => q + 1); }} unit="%" />
                      <Slider label="Y Position" value={sigPos.y} min={40} max={90} step={0.1} onChange={(v) => { setSigPos(p => ({ ...p, y: v })); setPosVersion(q => q + 1); }} unit="%" />
                      <Slider label="Width" value={sigPos.w} min={5} max={25} step={0.1} onChange={(v) => { setSigPos(p => ({ ...p, w: v })); setPosVersion(q => q + 1); }} unit="%" />
                      <Slider label="Height" value={sigPos.h} min={3} max={20} step={0.1} onChange={(v) => { setSigPos(p => ({ ...p, h: v })); setPosVersion(q => q + 1); }} unit="%" />
                    </Section>
                    <Section title="Calibration Presets">
                      <div className="space-y-2">
                        {presets.length > 0 && (
                          <div className="space-y-1">
                            {presets.map((p) => (
                              <div key={p.id} className="flex items-center gap-2 rounded-lg border border-slate-800 bg-slate-950/40 px-2.5 py-1.5">
                                <button onClick={() => handleLoadPreset(p.id)} className="flex-1 truncate text-left text-[11px] font-medium text-slate-300 transition-colors hover:text-emerald-400">
                                  {p.name}
                                </button>
                                <button onClick={() => handleDeletePreset(p.id)} className="flex h-5 w-5 shrink-0 items-center justify-center rounded text-[10px] text-slate-400 hover:bg-red-950/40 hover:text-red-400 transition-all">
                                  ✕
                                </button>
                              </div>
                            ))}
                          </div>
                        )}

                        {showPresetInput ? (
                          <div className="flex gap-1.5">
                            <input
                              autoFocus
                              type="text"
                              value={presetName}
                              onChange={(e) => setPresetName(e.target.value)}
                              onKeyDown={(e) => e.key === "Enter" && handleSavePreset()}
                              placeholder="Preset name..."
                              className={inputCls + " py-1.5 text-[11px]"}
                            />
                            <button onClick={handleSavePreset} className={ghostBtnCls + " bg-emerald-700/60 text-white hover:bg-emerald-600 border-emerald-700/50"}>Save</button>
                            <button onClick={() => { setShowPresetInput(false); setPresetName(""); }} className={ghostBtnCls}>✕</button>
                          </div>
                        ) : (
                          <button onClick={() => setShowPresetInput(true)} className="flex w-full items-center justify-center gap-1.5 rounded-lg border border-dashed border-slate-700 bg-slate-950/40 px-3 py-2 text-[11px] font-medium text-slate-400 transition-all duration-200 hover:border-emerald-600 hover:text-emerald-400 hover:bg-emerald-950/20 active:scale-[0.98]">
                            + Save Current Preset
                          </button>
                        )}

                        <button onClick={() => { resetToDefaults(); setChekiCal(getCalDef("cheki")); setJinaCal(getCalDef("jina")); setCheoCal(getCalDef("cheo")); setFieldCalVersion(v => v + 1); showToast("Defaults restored", "info"); }} className="flex w-full items-center justify-center gap-1.5 rounded-lg border border-amber-700/50 bg-amber-950/20 px-3 py-2 text-[11px] font-medium text-amber-300 transition-all duration-200 hover:border-amber-600 hover:bg-amber-950/40 active:scale-[0.98]">
                          ↺ Restore Defaults
                        </button>
                      </div>
                    </Section>
                  </Section>
                </>
              )}

              {page === "back" && (
                <div className="flex flex-col items-center rounded-xl border border-dashed border-slate-700 bg-slate-950/40 p-8 text-center">
                  <svg className="mb-3 h-9 w-9 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                  <p className="text-sm font-medium text-slate-200">Back Side</p>
                  <p className="mt-1 text-[11px] text-slate-500">Fixed layout — not editable</p>
                </div>
              )}
            </>
          ) : (
            <>
              {/* ── Register Person ── */}
              <div className="flex items-center gap-2 rounded-xl border border-emerald-800/40 bg-emerald-950/30 px-3.5 py-2.5">
                <span className="relative flex h-2 w-2 shrink-0">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-60" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
                </span>
                <div>
                  <p className="text-[11px] font-semibold uppercase tracking-[0.1em] text-emerald-300">New Registration</p>
                  <p className="text-[10px] text-slate-400">Cheki Namba, Jina and Cheo are required.</p>
                </div>
              </div>

              {renderFieldBlock("cheki", "Cheki Namba", "e.g. 8973229", "none")}
              {renderFieldBlock("jina", "Jina (Full Name)", "e.g. ELIZABETH R. MGOMBELO", "upper")}
              {renderFieldBlock("cheo", "Cheo (Position)", "e.g. AFISA ELIMU KATA", "upper")}
              {renderDepartmentBlock()}
              {renderPhotoBlock()}
              {renderSignatureBlock()}
            </>
          )}
        </div>

        {/* ═══ BOTTOM FIXED ACTION PANEL ═══ */}
        <div className="space-y-2 border-t border-slate-800 pt-3">
          {activeMode === "view" ? (
            <>
              <div className="flex gap-2">
                <button onClick={undo} disabled={historyIdx <= 0} className={ghostBtnCls + " flex-1"}>
                  <svg className="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6" /></svg>
                  Undo
                </button>
                <button onClick={redo} disabled={historyIdx >= history.length - 1} className={ghostBtnCls + " flex-1"}>
                  <svg className="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M21 10H11a8 8 0 00-8 8v2m18-10l-6 6m6-6l-6-6" /></svg>
                  Redo
                </button>
                <button onClick={resetCard} className={ghostBtnCls + " flex-1"}>Reset</button>
              </div>
              {currentPersonId ? (
                <>
                  <button
                    onClick={() => void handleUpdateRecord()}
                    disabled={registering}
                    className="flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-600 px-3 py-2.5 font-semibold text-white shadow-lg shadow-emerald-600/25 transition-all duration-200 hover:bg-emerald-500 hover:shadow-xl hover:shadow-emerald-500/30 active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    {registering ? (
                      <><Loader /> Saving...</>
                    ) : (
                      <><svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" /></svg> Update Record</>
                    )}
                  </button>
                  <button
                    onClick={async () => { await handleUpdateRecord(); setTimeout(printID, 500); }}
                    disabled={registering}
                    className="flex w-full items-center justify-center gap-2 rounded-xl border border-emerald-600 bg-emerald-950/40 px-3 py-2.5 font-semibold text-emerald-300 transition-all duration-200 hover:bg-emerald-900/40 hover:text-emerald-200 active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6.72 13.829c-.24.03-.48.062-.72.096m.72-.096a42.415 42.415 0 0110.56 0m-10.56 0L6.34 18m10.94-4.171c.24.03.48.062.72.096m-.72-.096L17.66 18m0 0l.229 2.523a1.125 1.125 0 01-1.12 1.227H7.231c-.662 0-1.18-.568-1.12-1.227L6.34 18m11.318 0h1.091A2.25 2.25 0 0021 15.75V9.456c0-1.081-.768-2.015-1.837-2.175a48.055 48.055 0 00-1.913-.247M6.34 18H5.25A2.25 2.25 0 013 15.75V9.456c0-1.081.768-2.015 1.837-2.175a48.041 48.041 0 011.913-.247m10.5 0a48.536 48.536 0 00-10.5 0m10.5 0V3.375c0-.621-.504-1.125-1.125-1.125h-8.25c-.621 0-1.125.504-1.125 1.125v3.659M18 10.5h.008v.008H18V10.5z" /></svg>
                    Save & Print
                  </button>
                </>
              ) : (
                <button
                  onClick={printID}
                  className="flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-600 px-3 py-2.5 font-semibold text-white shadow-lg shadow-emerald-600/25 transition-all duration-200 hover:bg-emerald-500 hover:shadow-xl hover:shadow-emerald-500/30 active:scale-[0.99]"
                >
                  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6.72 13.829c-.24.03-.48.062-.72.096m.72-.096a42.415 42.415 0 0110.56 0m-10.56 0L6.34 18m10.94-4.171c.24.03.48.062.72.096m-.72-.096L17.66 18m0 0l.229 2.523a1.125 1.125 0 01-1.12 1.227H7.231c-.662 0-1.18-.568-1.12-1.227L6.34 18m11.318 0h1.091A2.25 2.25 0 0021 15.75V9.456c0-1.081-.768-2.015-1.837-2.175a48.055 48.055 0 00-1.913-.247M6.34 18H5.25A2.25 2.25 0 013 15.75V9.456c0-1.081.768-2.015 1.837-2.175a48.041 48.041 0 011.913-.247m10.5 0a48.536 48.536 0 00-10.5 0m10.5 0V3.375c0-.621-.504-1.125-1.125-1.125h-8.25c-.621 0-1.125.504-1.125 1.125v3.659M18 10.5h.008v.008H18V10.5z" /></svg>
                  Print ID
                </button>
              )}
              <div className="flex gap-2">
                <button onClick={exportPNG} className={ghostBtnCls + " flex-1 border-sky-700/50 bg-sky-950/20 text-sky-300 hover:border-sky-600 hover:bg-sky-900/30"}>
                  Export PNG
                </button>
                <button onClick={exportPDF} className={ghostBtnCls + " flex-1 border-violet-700/50 bg-violet-950/20 text-violet-300 hover:border-violet-600 hover:bg-violet-900/30"}>
                  Export PDF
                </button>
              </div>
            </>
          ) : (
            <>
              <button
                onClick={() => void handleRegisterSubmit()}
                disabled={registering}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-600 px-3 py-2.5 font-semibold text-white shadow-lg shadow-emerald-600/25 transition-all duration-200 hover:bg-emerald-500 hover:shadow-xl hover:shadow-emerald-500/30 active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-60"
              >
                {registering ? (
                  <><Loader /> Saving...</>
                ) : (
                  <><svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg> Save &amp; Register Person</>
                )}
              </button>
              <button
                onClick={clearForm}
                disabled={registering}
                className="flex w-full items-center justify-center gap-1.5 rounded-xl border border-slate-700 bg-slate-950/40 px-3 py-2.5 text-[13px] font-medium text-slate-300 transition-all duration-200 hover:border-slate-600 hover:bg-slate-800 hover:text-white active:scale-[0.99] disabled:opacity-60"
              >
                Clear Form
              </button>
              <p className={`flex items-center justify-center gap-1.5 text-[10px] ${hasDraft ? "text-emerald-400/90" : "text-slate-500"}`}>
                <svg className="h-3 w-3 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" /></svg>
                {hasDraft ? "Draft saved on this device — safe to refresh" : "Draft is auto-saved locally as you type"}
              </p>
            </>
          )}
        </div>
      </aside>

      {/* ═══ MAIN CANVAS WORKSPACE ═══ */}
      <main className="flex flex-1 flex-col overflow-hidden">
        {/* Top Toolbar */}
        <div className="flex items-center gap-3 border-b border-slate-800 bg-slate-900/70 px-5 py-3">
          <span className={`flex items-center gap-2 rounded-lg px-3 py-1.5 text-[12px] font-semibold ${page === "front" ? "bg-emerald-950/50 text-emerald-300 ring-1 ring-emerald-700/50" : "bg-slate-800 text-slate-200 ring-1 ring-slate-700"}`}>
            <span className={`h-1.5 w-1.5 rounded-full ${page === "front" ? "bg-emerald-400" : "bg-slate-400"}`} />
            Editing: {page === "front" ? "Front Side" : "Back Side"}
          </span>
          <span className="rounded-md bg-slate-800 px-2 py-0.5 font-mono text-[10px] text-slate-400 tabular-nums">
            {CARD_CONFIG.width}×{CARD_CONFIG.height}px
          </span>
          <div className="flex-1" />
          {/* View Controls */}
          <div className="flex items-center gap-2">
            <button
              onClick={zoomFit}
              title="Fit card to window"
              className="flex h-7 items-center gap-1.5 rounded-lg px-2.5 text-[11px] font-medium text-slate-300 transition-all duration-200 hover:bg-slate-800 hover:text-white active:scale-90"
            >
              <svg className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M8 3H5a2 2 0 00-2 2v3m18 0V5a2 2 0 00-2-2h-3m0 18h3a2 2 0 002-2v-3M3 16v3a2 2 0 002 2h3" /></svg>
              Fit
            </button>
            <div className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-900 px-1.5 py-1">
              <button
                onClick={() => setZoomLocked((z) => !z)}
                title={zoomLocked ? "Unlock zoom" : "Lock zoom at current level"}
                className={`flex h-7 w-7 items-center justify-center rounded-lg transition-all duration-200 active:scale-90 ${zoomLocked ? "bg-emerald-600 text-white shadow-lg shadow-emerald-600/25" : "text-slate-300 hover:bg-slate-800 hover:text-white"}`}
              >
                {zoomLocked ? (
                  <svg className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><rect width="18" height="11" x="3" y="11" rx="2" ry="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" /></svg>
                ) : (
                  <svg className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><rect width="18" height="11" x="3" y="11" rx="2" ry="2" /><path d="M7 11V7a5 5 0 0 1 9.9-1" /></svg>
                )}
              </button>
              <button
                onClick={() => changeZoom((z) => Math.max(0.25, z / 1.25))}
                disabled={zoomLocked}
                title={zoomLocked ? "Zoom is locked" : "Zoom out"}
                className="flex h-7 w-7 items-center justify-center rounded-lg text-sm font-medium text-slate-300 transition-all duration-200 hover:bg-slate-800 hover:text-white active:scale-90 disabled:cursor-not-allowed disabled:opacity-40"
              >
                −
              </button>
              <span className="flex min-w-[52px] items-center justify-center gap-1 text-center text-[12px] font-medium tabular-nums text-slate-300">
                {zoomLocked && (
                  <svg className="h-3 w-3 text-emerald-400" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24"><rect width="18" height="11" x="3" y="11" rx="2" ry="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" /></svg>
                )}
                {Math.round(zoom * 100)}%
              </span>
              <button
                onClick={() => changeZoom((z) => Math.min(4, z * 1.25))}
                disabled={zoomLocked}
                title={zoomLocked ? "Zoom is locked" : "Zoom in"}
                className="flex h-7 w-7 items-center justify-center rounded-lg text-sm font-medium text-slate-300 transition-all duration-200 hover:bg-slate-800 hover:text-white active:scale-90 disabled:cursor-not-allowed disabled:opacity-40"
              >
                +
              </button>
              <button
                onClick={() => changeZoom(() => 1)}
                disabled={zoomLocked}
                title={zoomLocked ? "Zoom is locked" : "Reset to 100%"}
                className="rounded-lg px-2.5 py-1 text-[11px] font-medium text-slate-400 transition-all duration-200 hover:bg-slate-800 hover:text-white disabled:cursor-not-allowed disabled:opacity-40"
              >
                Reset 100%
              </button>
            </div>
          </div>
        </div>

        {/* Canvas Area */}
        <div
          id="canvasWrap"
          className="flex flex-1 items-center justify-center overflow-auto p-8"
          style={{
            backgroundImage: "radial-gradient(circle, #1e293b 1px, transparent 1px)",
            backgroundSize: "22px 22px",
            backgroundColor: "#020617",
          }}
          onWheel={(e) => {
            e.preventDefault();
            if (zoomLocked) return;
            setZoom((z) => Math.min(4, Math.max(0.25, e.deltaY < 0 ? z * 1.1 : z / 1.1)));
          }}
        >
          <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-8 shadow-2xl shadow-black/60 transition-all duration-300">
            <IdCanvas
              frontBg={frontBg}
              backBg={backBg}
              data={data}
              zoom={zoom}
              page={page}
              calVersion={fieldCalVersion}
              photoArea={photoPos}
              sigArea={sigPos}
              posVersion={posVersion}
            />
          </div>
        </div>
      </main>

      {/* Crop & Signature Modals */}
      <CropModal open={photoCropOpen} onClose={closePhoto} onApply={handlePhotoApply} aspect="photo" initialFile={pendingCropFile} />
      <CropModal open={sigCropOpen} onClose={closeSig} onApply={handleSigApply} aspect="signature" removeBgOption initialFile={pendingCropFile} />
      <SignaturePadModal open={sigPadOpen} onClose={() => setSigPadOpen(false)} onApply={handlePadApply} />
    </div>
  );
}