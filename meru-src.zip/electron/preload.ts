import { contextBridge, ipcRenderer } from "electron";

/**
 * Preload: the only bridge between the sandboxed renderer and the main
 * process. Exposes a minimal, typed API on window.meru — no raw ipcRenderer,
 * no Node primitives, ever.
 */

const api = {
  isDesktop: true as const,
  platform: process.platform,
  appVersion: process.env.MERU_APP_VERSION || "1.0.0",
  listPrinters: () => ipcRenderer.invoke("meru:listPrinters"),
  print: (job: unknown) => ipcRenderer.invoke("meru:print", job),
  printPdf: (payload: unknown) => ipcRenderer.invoke("meru:printPdf", payload),
  renderPdfFromHtml: (payload: unknown) => ipcRenderer.invoke("meru:renderPdfFromHtml", payload),
  openDataFolder: () => ipcRenderer.invoke("meru:openDataFolder"),
  backupNow: () => ipcRenderer.invoke("meru:backupNow"),
  restoreBackup: () => ipcRenderer.invoke("meru:restoreBackup"),
  getDataFolderPath: () => ipcRenderer.invoke("meru:getDataFolderPath"),
  getAppPaths: () => ipcRenderer.invoke("meru:getAppPaths"),
  getAppVersion: () => ipcRenderer.invoke("meru:getAppVersion"),
  checkForUpdates: () => ipcRenderer.invoke("meru:checkForUpdates"),
};

contextBridge.exposeInMainWorld("meru", api);
