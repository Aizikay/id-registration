/**
 * ID Card Template Engine — PDF as Source of Truth
 *
 * CRITICAL: The original ELIZABETH MGOMBELO PDF is the actual template.
 * We do NOT recreate the card with HTML/CSS. The PDF is rendered via PDF.js
 * and dynamic fields are overlaid with exact PDF coordinates.
 *
 * Architecture:
 *   Layer 1: Original PDF (LOCKED, rendered via PDF.js)
 *   Layer 2: Masks (cover sample data like "ELIZABETH R. MGOMBELO")
 *   Layer 3: Dynamic text overlays (editable)
 *   Layer 4: Dynamic photo overlay (exact original photo frame)
 *   Layer 5: Editor controls (not printed)
 */

export type TemplateVersionStatus = "active" | "draft" | "archived";

export interface PdfDimensions {
  width: number;
  height: number;
  /** e.g. "595x842" for A4, or "243x154" for CR-80 */
  unit: "pt" | "mm";
}

export interface FieldStyle {
  fontSizePt: number;
  fontWeight: 400 | 500 | 600 | 700 | 800;
  fontFamily: string;
  letterSpacingEm: number;
  lineHeight: number;
  textAlign: "left" | "center" | "right";
  color: string;
  textTransform?: "uppercase" | "none";
}

export interface FieldPosition {
  /** PDF coordinates: 0-100% of page width/height, or absolute pt */
  xPct: number;
  yPct: number;
  wPct: number;
  hPct: number;
  /** Also store absolute for pdf-lib */
  xPt?: number;
  yPt?: number;
  wPt?: number;
  hPt?: number;
}

export interface CardField {
  id: string;
  label: string;
  dataKey: keyof EmployeeData | null;
  staticText?: string;
  position: FieldPosition;
  style: FieldStyle;
  visible: boolean;
  locked?: boolean;
  /** Mask to hide original PDF sample text in this area */
  maskColor?: string;
}

export interface PhotoArea {
  position: FieldPosition;
  radiusPt: number;
  borderWidthPt: number;
  borderColor: string;
  background: string;
  objectFit: "cover" | "contain" | "fill";
}

export interface EmployeeData {
  fullName: string;
  checkNumber: string;
  position: string;
  fileNumber: string;
  identificationNumber: string;
  photoUrl: string | null;
  photoCroppedUrl: string | null;
}

export interface IdCardTemplate {
  id: string;
  name: string;
  version: string;
  status: TemplateVersionStatus;
  createdAt: string;
  updatedAt: string;
  createdBy: string | null;
  /** Path to original PDF in public/ — e.g. /branding/meru-employee-id-template.pdf */
  pdfSrc: string;
  /** Fallback if PDF not available */
  pdfFallbackText: string;
  dimensions: PdfDimensions;
  fields: CardField[];
  photo: PhotoArea;
  masks: Array<{ id: string; position: FieldPosition; color: string }>;
}

export const REFERENCE_LABELS = {
  checkNumber: "Cheki Namba.",
  fullName: "Jina",
  position: "Cheo",
  employeeSignature: "Sahihi ya Mtumishi",
  employerSignature: "Sahihi ya Mwajiri",
  employerTitle: "Cheo cha Mwajiri",
  fileNumber: "Namba"
} as const;

/**
 * Default template derived from ELIZABETH MGOMBELO PDF.
 * Positions are % of PDF page — measured from the original.
 * The yellow card's photo is on the right (~65% x), fields on left.
 * Masks cover the sample data so new dynamic text doesn't overlap.
 */
export function createDefaultTemplate(): IdCardTemplate {
  const now = new Date().toISOString();
  return {
    id: "employee-id-v1",
    name: "Employee ID — KITAMBULISHO CHA MTUMISHI (Original PDF)",
    version: "1.0.0",
    status: "active",
    createdAt: now,
    updatedAt: now,
    createdBy: null,
    pdfSrc: "/branding/meru-employee-id-template.pdf",
    pdfFallbackText: "ELIZABETH MGOMBELO ID.pdf — place the official PDF at public/branding/meru-employee-id-template.pdf",
    dimensions: { width: 595, height: 842, unit: "pt" }, // A4-like, will be scaled to card
    fields: [
      {
        id: "checkNumber",
        label: REFERENCE_LABELS.checkNumber,
        dataKey: "checkNumber",
        position: { xPct: 6, yPct: 38, wPct: 42, hPct: 4, xPt: 35, yPt: 520, wPt: 250, hPt: 14 },
        style: { fontSizePt: 7, fontWeight: 600, fontFamily: "Helvetica", letterSpacingEm: 0, lineHeight: 1.2, textAlign: "left", color: "#1a1a1a" },
        visible: true,
        maskColor: "#FDE68A"
      },
      {
        id: "fullName",
        label: REFERENCE_LABELS.fullName,
        dataKey: "fullName",
        position: { xPct: 6, yPct: 43, wPct: 42, hPct: 4, xPt: 35, yPt: 480, wPt: 250, hPt: 14 },
        style: { fontSizePt: 7, fontWeight: 700, fontFamily: "Helvetica", letterSpacingEm: 0, lineHeight: 1.2, textAlign: "left", color: "#1a1a1a", textTransform: "uppercase" },
        visible: true,
        maskColor: "#FDE68A"
      },
      {
        id: "position",
        label: REFERENCE_LABELS.position,
        dataKey: "position",
        position: { xPct: 6, yPct: 48, wPct: 42, hPct: 4, xPt: 35, yPt: 440, wPt: 250, hPt: 14 },
        style: { fontSizePt: 6.5, fontWeight: 600, fontFamily: "Helvetica", letterSpacingEm: 0, lineHeight: 1.2, textAlign: "left", color: "#1a1a1a", textTransform: "uppercase" },
        visible: true,
        maskColor: "#FDE68A"
      },
      {
        id: "fileNumber",
        label: REFERENCE_LABELS.fileNumber,
        dataKey: "fileNumber",
        position: { xPct: 6, yPct: 62, wPct: 42, hPct: 3, xPt: 35, yPt: 320, wPt: 250, hPt: 12 },
        style: { fontSizePt: 6, fontWeight: 500, fontFamily: "Helvetica", letterSpacingEm: 0, lineHeight: 1.2, textAlign: "left", color: "#1a1a1a" },
        visible: true,
        maskColor: "#FDE68A"
      }
    ],
    photo: {
      position: { xPct: 62, yPct: 35, wPct: 30, hPct: 28, xPt: 365, yPt: 380, wPt: 175, hPt: 165 },
      radiusPt: 2,
      borderWidthPt: 0.8,
      borderColor: "#1a3a2a",
      background: "#fffde7",
      objectFit: "cover"
    },
    masks: [
      // Cover sample photo area
      { id: "mask-photo", position: { xPct: 62, yPct: 35, wPct: 30, hPct: 28, xPt: 365, yPt: 380, wPt: 175, hPt: 165 }, color: "#FDE68A" },
      // Cover sample text blocks (so new dynamic text doesn't double)
      { id: "mask-check", position: { xPct: 20, yPct: 38, wPct: 25, hPct: 3, xPt: 120, yPt: 522, wPt: 150, hPt: 10 }, color: "#FDE68A" },
      { id: "mask-name", position: { xPct: 20, yPct: 43, wPct: 30, hPct: 3, xPt: 120, yPt: 482, wPt: 180, hPt: 10 }, color: "#FDE68A" },
      { id: "mask-position", position: { xPct: 20, yPct: 48, wPct: 28, hPct: 3, xPt: 120, yPt: 442, wPt: 165, hPt: 10 }, color: "#FDE68A" },
      { id: "mask-file", position: { xPct: 20, yPct: 62, wPct: 28, hPct: 2.5, xPt: 120, yPt: 322, wPt: 165, hPt: 9 }, color: "#FDE68A" }
    ]
  };
}

export const DRAFT_TEMPLATE_KEY = "meru-id-template-draft";
export const ACTIVE_TEMPLATE_KEY = "meru-id-template-active";

export function loadTemplate(): IdCardTemplate {
  try {
    const raw = localStorage.getItem(ACTIVE_TEMPLATE_KEY);
    if (raw) return JSON.parse(raw) as IdCardTemplate;
    const draft = localStorage.getItem(DRAFT_TEMPLATE_KEY);
    if (draft) return JSON.parse(draft) as IdCardTemplate;
  } catch {
    // ignore
  }
  return createDefaultTemplate();
}

export function saveTemplate(template: IdCardTemplate, asDraft = true): void {
  const key = asDraft ? DRAFT_TEMPLATE_KEY : ACTIVE_TEMPLATE_KEY;
  localStorage.setItem(key, JSON.stringify(template));
  if (!asDraft) localStorage.removeItem(DRAFT_TEMPLATE_KEY);
}

export function resetTemplate(): IdCardTemplate {
  localStorage.removeItem(DRAFT_TEMPLATE_KEY);
  localStorage.removeItem(ACTIVE_TEMPLATE_KEY);
  return createDefaultTemplate();
}
