import { Navigate, Outlet, useLocation } from "react-router-dom";
import { useAuth } from "./auth-context";
import type { Permission } from "@/lib/permissions";
import Loader from "@/components/Loader";
import { isSupabasePlaceholder } from "@/lib/env";

/**
 * Route guard. Enforces authentication (and optional permission) before
 * rendering children (or the nested Outlet when used as a layout route).
 */
export function ProtectedRoute({
  permission,
  children
}: {
  permission?: Permission;
  children?: React.ReactNode;
}) {
  const { loading, profile } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-4">
          <Loader />
          <p className="text-sm text-slate-500">Inapakia… Loading system…</p>
        </div>
      </div>
    );
  }

  if (isSupabasePlaceholder) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50 p-6">
        <div className="max-w-lg rounded-xl border border-amber-200 bg-white p-8 shadow-card">
          <h1 className="text-lg font-bold text-slate-900">Supabase haijaunganishwa — Not configured</h1>
          <p className="mt-2 text-sm text-slate-600">
            <code className="rounded bg-slate-100 px-1.5 py-0.5 font-mono text-xs">.env.local</code> bado ina placeholder values.
            Unda mradi Supabase na uweke <code className="font-mono text-xs">VITE_SUPABASE_URL</code> na{" "}
            <code className="font-mono text-xs">VITE_SUPABASE_ANON_KEY</code> halisi, kisha anzisha upya dev server.
          </p>
          <pre className="mt-4 overflow-auto rounded-lg bg-slate-900 p-3 text-xs text-slate-100">
{`# .env.local
VITE_SUPABASE_URL=https://<project-ref>.supabase.co
VITE_SUPABASE_ANON_KEY=<anon-key>
# then restart: node node_modules/vite/bin/vite.js --host 0.0.0.0 --port 5173`}
          </pre>
          <p className="mt-3 text-xs text-slate-500">
            See <code className="font-mono">README.md</code> &amp; <code className="font-mono">.env.example</code>. Demo mode bila Supabase bado haijawezeshwa.
          </p>
        </div>
      </div>
    );
  }

  // Authenticated via live session OR bounded offline capability.
  if (!profile) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  if (permission) {
    return (
      <PermissionGate permission={permission}>
        {children ?? <Outlet />}
      </PermissionGate>
    );
  }

  return <>{children ?? <Outlet />}</>;
}

export function PermissionGate({
  permission,
  children
}: {
  permission: Permission;
  children: React.ReactNode;
}) {
  const { can } = useAuth();
  if (!can(permission)) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-3 p-10 text-center">
        <div className="rounded-full bg-red-50 p-4">
          {/* eslint-disable-next-line */}
          <svg className="h-8 w-8 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5} aria-hidden="true">
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m0 3.75h.007v.008H12v-.008zM12 15a2.25 2.25 0 100-4.5 2.25 2.25 0 000 4.5zm0-9.75a7.5 7.5 0 100 15 7.5 7.5 0 000-15z" />
          </svg>
        </div>
        <h2 className="text-lg font-semibold text-slate-800">
          Ruhusa Haiitoshelezi — Insufficient Permission
        </h2>
        <p className="max-w-md text-sm text-slate-500">
          Your role does not include access to this area. Contact an
          administrator if you believe this is an error.
        </p>
      </div>
    );
  }
  return <>{children}</>;
}
