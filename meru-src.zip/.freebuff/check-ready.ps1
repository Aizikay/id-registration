$log = 'C:\Users\hp\Pictures\ID Registration & Issuance Management System.(MERU DC) - Copy\.freebuff\preview-185ab75d-b7ac-4e90-8d29-bbede45499ca.log'
$all = Get-Content $log -ErrorAction SilentlyContinue
$lastReady = $all | Select-String -Pattern 'ready' | Select-Object -Last 1
Write-Output "Last ready line: $lastReady"

$lastErr = Get-Content "$log.err" -ErrorAction SilentlyContinue | Select-Object -Last 1
Write-Output "Last error line: $lastErr"

if ($lastReady -match 'ready') {
  Write-Output 'STATUS: Vite started successfully'
} elseif ($lastErr -match 'Internal server error') {
  Write-Output 'STATUS: Still has errors'
} else {
  Write-Output 'STATUS: Unknown'
}
