/**
 * ID Card Designer — Template Gallery + Upload + Editable Preview
 */

import { useEffect, useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardBody, CardHeader, PageHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input, Select } from "@/components/ui/form";
import { Icon } from "@/components/icons/icon";
import { useToast } from "@/components/ui/toast";
import { PdfIdCardPreview } from "../components/PdfIdCardPreview";
import { TemplateRenderer } from "../components/TemplateRenderer";
import { TemplateGallery } from "../components/TemplateGallery";
import { TemplateUploadModal } from "../components/TemplateUploadModal";
import { TemplateEditPanel } from "../components/TemplateEditPanel";
import { PhotoCropper } from "../components/PhotoCropper";
import { Modal } from "@/components/ui/modal";
import {
  createDefaultTemplate,
  loadTemplate,
  saveTemplate,
  type EmployeeData,
  type IdCardTemplate,
} from "../template";
import {
  setActiveTemplate as setActiveTemplateDb,
  getAllTemplates,
  type CustomTemplate,
} from "../template-manager";
import { searchPersonsOnline, searchPersonsOffline } from "@/services/people-service";
import { useAuth as useAuthContext } from "@/features/auth/auth-context";
import type { Person } from "@/types";

type ViewMode = "gallery" | "designer";

export function DesignerPage() {
  const navigate = useNavigate();
  const toast = useToast();
  const { profile } = useAuthContext();
  const isAdmin = profile?.role === "admin";

  const [viewMode, setViewMode] = useState<ViewMode>("gallery");
  const [editMode, setEditMode] = useState(false);

  const [defaultTemplate, setDefaultTemplate] = useState<IdCardTemplate>(() => loadTemplate());
  const [activeCustomTemplate, setActiveCustomTemplate] = useState<CustomTemplate | null>(null);
  const [selectedCustomField, setSelectedCustomField] = useState<string | null>(null);

  const [showUploadModal, setShowUploadModal] = useState(false);

  const [data, setData] = useState<EmployeeData>({
    fullName: "ELIZABETH R. MGOMBELO",
    checkNumber: "8973229",
    position: "AFISA ELIMU KATA",
    fileNumber: "HW/MER/PF/17358",
    identificationNumber: "MRU2019001234",
    photoUrl: null,
    photoCroppedUrl: null,
  });

  const [search, setSearch] = useState("");
  const [searchResults, setSearchResults] = useState<Person[]>([]);
  const [searching, setSearching] = useState(false);

  const [showCropper, setShowCropper] = useState<string | null>(null);
  const [rawPhoto, setRawPhoto] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const cameraRef = useRef<HTMLInputElement>(null);
  const [previewScale, setPreviewScale] = useState(2.5);

  useEffect(() => {
    void (async () => {
      const customTemplates = await getAllTemplates();
      const active = customTemplates.find((t) => t.isActive);
      if (active) {
        setActiveCustomTemplate(active);
        setViewMode("designer");
      }
    })();
  }, []);

  useEffect(() => {
    if (editMode && !activeCustomTemplate) {
      saveTemplate(defaultTemplate, true);
    }
  }, [defaultTemplate, editMode, activeCustomTemplate]);

  useEffect(() => {
    if (search.trim().length < 2) {
      setSearchResults([]);
      return;
    }
    const t = window.setTimeout(async () => {
      setSearching(true);
      try {
        const online = navigator.onLine;
        const res = online
          ? await searchPersonsOnline({ search: search.trim(), pageSize: 8 })
          : { rows: (await searchPersonsOffline(search.trim(), 8)) as unknown as Person[], total: 0 };
        setSearchResults((res.rows as Person[]).slice(0, 8));
      } catch {
        setSearchResults([]);
      } finally {
        setSearching(false);
      }
    }, 350);
    return () => window.clearTimeout(t);
  }, [search]);

  const selectPerson = (p: Person) => {
    setData({
      fullName: p.full_name.toUpperCase(),
      checkNumber: (p as unknown as { staff_number?: string }).staff_number ?? p.identification_number.slice(-7),
      position: (p as unknown as { position?: string }).position ?? (p as unknown as { department?: string }).department ?? "MTUMISHI",
      fileNumber: `HW/MER/PF/${p.identification_number.slice(-5)}`,
      identificationNumber: p.identification_number,
      photoUrl: data.photoUrl,
      photoCroppedUrl: data.photoCroppedUrl,
    });
    setSearch("");
    setSearchResults([]);
    toast.success("Loaded", `${p.full_name} loaded into template`);
  };

  const handlePhotoFile = (file: File | null) => {
    if (!file) return;
    if (!["image/jpeg", "image/png", "image/webp", "image/jpg"].includes(file.type)) {
      toast.error("Invalid file", "Use JPG, PNG or WebP");
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      toast.error("Too large", "Max 8MB");
      return;
    }
    const url = URL.createObjectURL(file);
    setRawPhoto(url);
    setShowCropper(url);
  };

  const handleSelectCustomTemplate = async (template: CustomTemplate) => {
    setActiveCustomTemplate(template);
    await setActiveTemplateDb(template.id);
    setViewMode("designer");
    setEditMode(true);
  };

  const handleCreateDefault = () => {
    const d = createDefaultTemplate();
    setDefaultTemplate(d);
    saveTemplate(d, true);
    setActiveCustomTemplate(null);
    setViewMode("designer");
    toast.success("Reset", "Template reset to default");
  };

  const handleUploadCreated = (template: CustomTemplate) => {
    setActiveCustomTemplate(template);
    setViewMode("designer");
    setEditMode(true);
    toast.success("Template Created", `"${template.name}" is ready to edit`);
  };

  const updateDefaultField = (fieldId: string, patch: Partial<(typeof defaultTemplate.fields)[number]>) => {
    setDefaultTemplate((t) => ({
      ...t,
      fields: t.fields.map((f) => (f.id === fieldId ? { ...f, ...patch } : f)),
      updatedAt: new Date().toISOString(),
    }));
  };

  const selectedDefaultFieldObj = defaultTemplate.fields.find((f) => f.id === selectedCustomField) ?? null;

  const customDataMap: Record<string, string> = {
    fullName: data.fullName,
    checkNumber: data.checkNumber,
    position: data.position,
    fileNumber: data.fileNumber,
    identificationNumber: data.identificationNumber,
  };

  return (
    <div className="animate-fade-in">
      <PageHeader
        title="ID Card Designer"
        subtitle={
          viewMode === "gallery"
            ? "Choose a template or upload your own (PDF, Adobe Illustrator, or screenshots)"
            : activeCustomTemplate
              ? `Editing: ${activeCustomTemplate.name} (${activeCustomTemplate.sourceType.toUpperCase()})`
              : "Default PDF template — live preview with editable fields"
        }
        actions={
          <div className="flex flex-wrap gap-2">
            {viewMode === "designer" && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setViewMode("gallery")}
                icon={<Icon name="grid" className="h-4 w-4" />}
              >
                Templates
              </Button>
            )}
            {viewMode === "designer" && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigate("/app/id-card/preview")}
                icon={<Icon name="eye" className="h-4 w-4" />}
              >
                Print preview
              </Button>
            )}
            {isAdmin && viewMode === "designer" && !activeCustomTemplate && (
              editMode ? (
                <Button
                  size="sm"
                  onClick={() => {
                    saveTemplate({ ...defaultTemplate, status: "active", version: bumpVersion(defaultTemplate.version) }, false);
                    setEditMode(false);
                    toast.success("Saved", `Template ${defaultTemplate.version} is now active`);
                  }}
                  icon={<Icon name="check" className="h-4 w-4" />}
                >
                  Save as active
                </Button>
              ) : (
                <Button size="sm" onClick={() => setEditMode(true)} icon={<Icon name="pencil" className="h-4 w-4" />}>
                  Edit template
                </Button>
              )
            )}
          </div>
        }
      />

      {viewMode === "gallery" && (
        <TemplateGallery
          onSelectTemplate={handleSelectCustomTemplate}
          onUploadNew={() => setShowUploadModal(true)}
          onCreateDefault={handleCreateDefault}
          currentTemplateId={activeCustomTemplate?.id}
        />
      )}

      {viewMode === "designer" && (
        <div className="grid gap-6 lg:grid-cols-[1.15fr_0.85fr]">
          <div className="space-y-4">
            <Card>
              <CardHeader
                title="Live preview"
                subtitle={
                  activeCustomTemplate
                    ? `${activeCustomTemplate.width}×${activeCustomTemplate.height}px • ${activeCustomTemplate.fileName}`
                    : `${defaultTemplate.dimensions.width}×${defaultTemplate.dimensions.height}${defaultTemplate.dimensions.unit} • v${defaultTemplate.version}`
                }
                icon={<Icon name="id-card" className="h-4 w-4" />}
                actions={
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-surface-500">Zoom</span>
                    <input
                      type="range"
                      min={1.5}
                      max={4}
                      step={0.1}
                      value={previewScale}
                      onChange={(e) => setPreviewScale(Number(e.target.value))}
                      className="w-24 accent-council-700"
                    />
                  </div>
                }
              />
              <CardBody className="flex flex-col items-center gap-4 bg-surface-100/60 py-8">
                <div className="overflow-auto rounded-xl border border-surface-200 bg-white p-6 shadow-inner" style={{ maxWidth: "100%" }}>
                  {activeCustomTemplate ? (
                    <TemplateRenderer
                      template={activeCustomTemplate}
                      data={customDataMap}
                      scale={previewScale}
                      showGuides={editMode}
                      selectedField={selectedCustomField}
                      onFieldClick={editMode ? setSelectedCustomField : undefined}
                    />
                  ) : (
                    <PdfIdCardPreview
                      template={defaultTemplate}
                      data={data}
                      scale={previewScale}
                      showGuides={editMode}
                      selectedField={selectedCustomField}
                      onFieldClick={editMode ? setSelectedCustomField : undefined}
                    />
                  )}
                </div>
                <div className="flex flex-wrap items-center gap-2 text-xs text-surface-500">
                  <span className={`rounded-full px-2.5 py-1 text-xs font-medium uppercase ${(activeCustomTemplate ? activeCustomTemplate.isActive : defaultTemplate.status === "active") ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700"}`}>
                    {activeCustomTemplate ? (activeCustomTemplate.isActive ? "active" : "draft") : defaultTemplate.status}
                  </span>
                  <span>{activeCustomTemplate ? activeCustomTemplate.name : `Default: ${defaultTemplate.name}`}</span>
                </div>
              </CardBody>
            </Card>

            <Card>
              <CardHeader title="Employee photo" icon={<Icon name="image" className="h-4 w-4" />} />
              <CardBody className="space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  <Button variant="outline" size="sm" onClick={() => fileRef.current?.click()} icon={<Icon name="upload" className="h-4 w-4" />}>Upload</Button>
                  <Button variant="outline" size="sm" onClick={() => cameraRef.current?.click()} icon={<Icon name="camera" className="h-4 w-4" />}>Camera</Button>
                </div>
                <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp,image/jpg" className="hidden" onChange={(e) => handlePhotoFile(e.target.files?.[0] ?? null)} />
                <input ref={cameraRef} type="file" accept="image/*" capture="user" className="hidden" onChange={(e) => handlePhotoFile(e.target.files?.[0] ?? null)} />
                <div onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); handlePhotoFile(e.dataTransfer.files[0] ?? null); }} className="flex flex-col items-center justify-center rounded-xl border-2 border-dashed border-surface-300 bg-surface-50 px-4 py-6 text-center">
                  {data.photoCroppedUrl || data.photoUrl ? (
                    <div className="flex flex-col items-center gap-3">
                      <img src={data.photoCroppedUrl ?? data.photoUrl ?? ""} alt="Preview" className="h-28 rounded-lg border border-surface-200 object-cover" style={{ width: 88, height: 112 }} />
                      <div className="flex gap-2">
                        <Button size="sm" variant="ghost" onClick={() => rawPhoto && setShowCropper(rawPhoto)}>Re-crop</Button>
                        <Button size="sm" variant="ghost" className="text-red-600" onClick={() => setData((d) => ({ ...d, photoUrl: null, photoCroppedUrl: null }))}>Remove</Button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <Icon name="image" className="h-8 w-8 text-surface-400" />
                      <p className="mt-2 text-sm font-medium text-surface-600">Drag & drop photo here</p>
                      <p className="text-xs text-surface-400">JPG, PNG, WebP · max 8MB</p>
                    </>
                  )}
                </div>
              </CardBody>
            </Card>
          </div>

          <div className="space-y-4">
            <Card>
              <CardHeader title="Load employee" subtitle="Search → auto-populate template" icon={<Icon name="search" className="h-4 w-4" />} />
              <CardBody className="space-y-3">
                <div className="relative">
                  <Input placeholder="Search name, Cheki Namba or ID…" value={search} onChange={(e) => setSearch(e.target.value)} className="pr-8" />
                  {searching && <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-surface-400">…</span>}
                  {searchResults.length > 0 && (
                    <div className="absolute z-10 mt-1 max-h-64 w-full overflow-auto rounded-xl border border-surface-200 bg-white shadow-elevated-3">
                      {searchResults.map((p) => (
                        <button key={p.id} onClick={() => selectPerson(p)} className="flex w-full items-center justify-between gap-3 px-3 py-2.5 text-left hover:bg-surface-50">
                          <span className="min-w-0">
                            <span className="block truncate text-sm font-medium text-surface-800">{p.full_name}</span>
                            <span className="block truncate font-mono text-xs text-surface-400">{(p as unknown as { staff_number?: string }).staff_number ?? p.identification_number}</span>
                          </span>
                          <Icon name="chevron-right" className="h-4 w-4 shrink-0 text-surface-400" />
                        </button>
                      ))}
                    </div>
                  )}
                </div>
                {searchResults.length === 0 && search.trim().length >= 2 && !searching && (
                  <p className="text-xs text-surface-400">No match. You can still fill the fields manually.</p>
                )}
              </CardBody>
            </Card>

            <Card>
              <CardHeader title="Card fields" subtitle="Live — preview updates instantly" icon={<Icon name="pencil" className="h-4 w-4" />} />
              <CardBody className="space-y-4">
                <Input label="Jina — Full name" value={data.fullName} onChange={(e) => setData((d) => ({ ...d, fullName: e.target.value.toUpperCase() }))} placeholder="ELIZABETH R. MGOMBELO" />
                <Input label="Cheki Namba." value={data.checkNumber} onChange={(e) => setData((d) => ({ ...d, checkNumber: e.target.value }))} placeholder="8973229" />
                <Input label="Cheo — Position" value={data.position} onChange={(e) => setData((d) => ({ ...d, position: e.target.value.toUpperCase() }))} placeholder="AFISA ELIMU KATA" />
                <Input label="Namba — File number" value={data.fileNumber} onChange={(e) => setData((d) => ({ ...d, fileNumber: e.target.value.toUpperCase() }))} placeholder="HW/MER/PF/17358" />
                <Input label="Identification number" value={data.identificationNumber} onChange={(e) => setData((d) => ({ ...d, identificationNumber: e.target.value.toUpperCase() }))} placeholder="MRU… (optional)" hint="Used for QR/barcode future" />
              </CardBody>
            </Card>

            {editMode && (
              activeCustomTemplate ? (
                <TemplateEditPanel
                  template={activeCustomTemplate}
                  onUpdate={setActiveCustomTemplate}
                  selectedField={selectedCustomField}
                  onSelectField={setSelectedCustomField}
                />
              ) : selectedDefaultFieldObj ? (
                <Card>
                  <CardHeader title={`Edit: ${selectedDefaultFieldObj.label}`} icon={<Icon name="sliders" className="h-4 w-4" />} />
                  <CardBody className="space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                      <Input label="X (%)" type="number" step={0.5} value={String(selectedDefaultFieldObj.position.xPct)} onChange={(e) => updateDefaultField(selectedDefaultFieldObj.id, { position: { ...selectedDefaultFieldObj.position, xPct: Number(e.target.value) } })} />
                      <Input label="Y (%)" type="number" step={0.5} value={String(selectedDefaultFieldObj.position.yPct)} onChange={(e) => updateDefaultField(selectedDefaultFieldObj.id, { position: { ...selectedDefaultFieldObj.position, yPct: Number(e.target.value) } })} />
                      <Input label="W (%)" type="number" step={0.5} value={String(selectedDefaultFieldObj.position.wPct)} onChange={(e) => updateDefaultField(selectedDefaultFieldObj.id, { position: { ...selectedDefaultFieldObj.position, wPct: Number(e.target.value) } })} />
                      <Input label="H (%)" type="number" step={0.5} value={String(selectedDefaultFieldObj.position.hPct)} onChange={(e) => updateDefaultField(selectedDefaultFieldObj.id, { position: { ...selectedDefaultFieldObj.position, hPct: Number(e.target.value) } })} />
                      <Input label="Font (pt)" type="number" step={0.5} value={String(selectedDefaultFieldObj.style.fontSizePt)} onChange={(e) => updateDefaultField(selectedDefaultFieldObj.id, { style: { ...selectedDefaultFieldObj.style, fontSizePt: Number(e.target.value) } })} />
                      <Select label="Weight" value={String(selectedDefaultFieldObj.style.fontWeight)} onChange={(e) => updateDefaultField(selectedDefaultFieldObj.id, { style: { ...selectedDefaultFieldObj.style, fontWeight: Number(e.target.value) as 400 | 500 | 600 | 700 | 800 } })} options={[{ value: "400", label: "400 Regular" }, { value: "500", label: "500 Medium" }, { value: "600", label: "600 Semibold" }, { value: "700", label: "700 Bold" }, { value: "800", label: "800 Extrabold" }]} />
                    </div>
                    <div className="flex gap-2">
                      {(["left", "center", "right"] as const).map((a) => (
                        <Button key={a} size="sm" variant={selectedDefaultFieldObj.style.textAlign === a ? "primary" : "outline"} onClick={() => updateDefaultField(selectedDefaultFieldObj.id, { style: { ...selectedDefaultFieldObj.style, textAlign: a } })}>{a}</Button>
                      ))}
                      <Button size="sm" variant="ghost" onClick={() => updateDefaultField(selectedDefaultFieldObj.id, { visible: !selectedDefaultFieldObj.visible })}>{selectedDefaultFieldObj.visible ? "Hide" : "Show"}</Button>
                    </div>
                  </CardBody>
                </Card>
              ) : (
                <Card>
                  <CardHeader title="Template & branding" icon={<Icon name="settings" className="h-4 w-4" />} />
                  <CardBody className="space-y-3">
                    <Input label="Template PDF src" value={defaultTemplate.pdfSrc} onChange={(e) => setDefaultTemplate((t) => ({ ...t, pdfSrc: e.target.value }))} />
                    <div className="grid grid-cols-2 gap-3">
                      <Input label="Page width" type="number" value={String(defaultTemplate.dimensions.width)} onChange={(e) => setDefaultTemplate((t) => ({ ...t, dimensions: { ...t.dimensions, width: Number(e.target.value) } }))} />
                      <Input label="Page height" type="number" value={String(defaultTemplate.dimensions.height)} onChange={(e) => setDefaultTemplate((t) => ({ ...t, dimensions: { ...t.dimensions, height: Number(e.target.value) } }))} />
                    </div>
                  </CardBody>
                </Card>
              )
            )}

            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => setViewMode("gallery")}>Back to Templates</Button>
              <Button className="flex-1" onClick={() => navigate("/app/id-card/preview")} icon={<Icon name="printer" className="h-4 w-4" />}>Print preview</Button>
            </div>
          </div>
        </div>
      )}

      <TemplateUploadModal
        open={showUploadModal}
        onClose={() => setShowUploadModal(false)}
        onCreated={handleUploadCreated}
        creatorName={profile?.full_name ?? "Unknown"}
      />

      <Modal open={!!showCropper} onClose={() => setShowCropper(null)} title="Crop photo" size="lg">
        {showCropper && (
          <PhotoCropper
            src={showCropper}
            onCropped={(cropped) => {
              setData((d) => ({ ...d, photoCroppedUrl: cropped, photoUrl: cropped }));
              setShowCropper(null);
              toast.success("Photo cropped", "High-res crop saved for print");
            }}
            onCancel={() => setShowCropper(null)}
          />
        )}
      </Modal>
    </div>
  );
}

function bumpVersion(v: string): string {
  const parts = v.split(".").map(Number);
  parts[2] = (parts[2] ?? 0) + 1;
  return parts.join(".");
}
