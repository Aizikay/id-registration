/**
 * Departments service.
 *
 * A department is an organizational bucket into which registered IDs are filed.
 * There is NO built-in catalogue: the operational source of truth is the
 * `departments` table in Supabase, populated exclusively by the user via
 * "Register Department" (admin-managed, RLS-protected).
 */

import { supabase } from "./supabase-client";
import { mapSupabaseError } from "./errors";
import { db } from "@/db/database";
import type { Person, DepartmentRow } from "@/types";

export type { DepartmentRow };

export interface DepartmentWithCount extends DepartmentRow {
  person_count: number;
}

/**
 * List departments registered by the user. The list is always exactly what is
 * in the `departments` table — nothing is injected client-side.
 */
export async function listDepartments(): Promise<DepartmentWithCount[]> {
  const { data, error } = await supabase
    .from("departments")
    .select(`
      *,
      person_count:
        persons(id)
    `)
    .order("sort_order", { ascending: true, nullsFirst: false })
    .order("created_at", { ascending: true })
    .limit(200);

  if (error) throw mapSupabaseError(error);

  return (data ?? []).map((row) => ({
    ...row,
    person_count: Array.isArray(row.person_count) ? row.person_count.length : 0,
  }));
}

/** Fetch people registered under a department (online only — paginated). */
export async function getPeopleInDepartment(
  departmentId: string,
  page = 0,
  pageSize = 50
): Promise<{ rows: Person[]; total: number }> {
  const from = page * pageSize;
  const to = from + pageSize - 1;

  const { data, error, count } = await supabase
    .from("persons")
    .select("*", { count: "exact" })
    .eq("department", departmentId)
    .order("created_at", { ascending: false })
    .range(from, to);

  if (error) throw mapSupabaseError(error);

  return {
    rows: (data ?? []) as Person[],
    total: count ?? 0,
  };
}

/**
 * Reassign a person to a different department.
 *
 * Updates the persons table AND enqueues a sync operation so the change survives
 * offline sessions and reaches Supabase when connectivity returns.
 */
export async function assignPersonToDepartment(
  personId: string,
  departmentId: string | null
): Promise<Person> {
  const updates = { department: departmentId };

  // Online path
  const { data, error } = await supabase
    .from("persons")
    .update(updates)
    .eq("id", personId)
    .select("*")
    .maybeSingle();

  if (error) throw mapSupabaseError(error);
  if (!data) throw mapSupabaseError(new Error("person_not_found"));

  // Persist to local mirror (fire & forget — safe to fail)
  void db.persons
    .put({ ...(data as Person), synced: true })
    .catch(() => undefined);

  // Enqueue outbox entry so it syncs when going online later
  const { enqueueOperation } = await import("@/offline/outbox");
  void enqueueOperation({
    entityType: "person",
    entityId: personId,
    operationType: "update_person",
    payload: { department: departmentId ?? null },
  }).catch(() => undefined);

  return data as Person;
}

/** Add a new department. Admin-only in RLS. */
export async function createDepartment(input: {
  id: string;
  name_sw: string;
  name_en: string;
  description?: string;
  color?: string;
}): Promise<DepartmentRow> {
  const { data, error } = await supabase
    .from("departments")
    .insert({
      id: input.id,
      name_sw: input.name_sw.trim(),
      name_en: input.name_en.trim(),
      description: input.description?.trim() ?? null,
      color: input.color ?? null,
      sort_order: 9999,
    })
    .select("*")
    .single();

  if (error) throw mapSupabaseError(error);
  return data as DepartmentRow;
}

/** Rename / edit a department. Admin-only in RLS. */
export async function updateDepartment(
  id: string,
  updates: { name_sw?: string; name_en?: string; description?: string | null }
): Promise<DepartmentRow> {
  const { data, error } = await supabase
    .from("departments")
    .update(updates)
    .eq("id", id)
    .select("*")
    .single();

  if (error) throw mapSupabaseError(error);
  return data as DepartmentRow;
}

/**
 * Remove a department. Registered IDs are NOT deleted — their
 * `persons.department` value simply keeps the old id (shown as unassigned).
 */
export async function deleteDepartment(id: string): Promise<void> {
  const { error } = await supabase
    .from("departments")
    .delete()
    .eq("id", id);

  if (error) throw mapSupabaseError(error);
}
