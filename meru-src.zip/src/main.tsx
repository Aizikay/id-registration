import { createRoot } from "react-dom/client";
import App from "./App";
import "./styles/globals.css";
import { registerServiceWorker } from "./pwa/register-sw";
import { env, isSupabasePlaceholder } from "./lib/env";

// Suppress the common extension-induced insertBefore crash (e.g. Google Translate wrapping text in <font>)
// by logging it instead of unmounting the whole tree. The app remains usable.
window.addEventListener("error", (e) => {
  if (String(e.message).includes("insertBefore") && String(e.message).includes("not a child")) {
    console.warn("Suppressed insertBefore error (likely browser extension):", e.message);
    e.preventDefault();
  }
});
window.addEventListener("unhandledrejection", (e) => {
  if (String(e.reason?.message || e.reason).includes("insertBefore")) {
    console.warn("Suppressed unhandled insertBefore rejection:", e.reason);
    e.preventDefault();
  }
});

/**
 * Warm up the Supabase connection (DNS + TLS) while the app shell boots,
 * so the first auth/profile query has less latency. Failures are harmless.
 */
function preconnectSupabase(): void {
  try {
    if (isSupabasePlaceholder) return;
    const host = new URL(env.supabaseUrl).host;
    for (const rel of ["preconnect", "dns-prefetch"]) {
      const link = document.createElement("link");
      link.rel = rel;
      link.href = `https://${host}`;
      link.crossOrigin = "anonymous";
      document.head.appendChild(link);
    }
  } catch {
    // Never block startup over an optional optimisation.
  }
}

preconnectSupabase();

const rootElement = document.getElementById("root");
if (!rootElement) throw new Error("Root element #root missing from index.html");

createRoot(rootElement).render(<App />);

/*
 * Service worker registration: web build only. Inside the Electron desktop
 * shell the app is loaded from local files and a service worker would just
 * serve stale bundles (the known stale-cache 404 bug), so it is skipped.
 */
import { isDesktop } from "@/lib/desktop";

// Register the service worker only when the browser is idle so it never
// competes with first-paint network requests.
function deferUntilIdle(cb: () => void): void {
  const w = window as Window & {
    requestIdleCallback?: (fn: () => void, opts?: { timeout: number }) => void;
  };
  if (typeof w.requestIdleCallback === "function") {
    w.requestIdleCallback(cb, { timeout: 5000 });
  } else {
    window.setTimeout(cb, 4000);
  }
}
deferUntilIdle(() => {
  if (!isDesktop()) registerServiceWorker();
});
