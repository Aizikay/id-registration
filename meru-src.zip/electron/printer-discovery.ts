import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { createLogger } from "./logger";
import type { NativePrinter } from "../src/types";

const exec = promisify(execFile);
const log = createLogger("printer-discovery");

/**
 * Native printer discovery for Windows.
 *
 * Uses PowerShell's Get-Printer to enumerate every printer the operating
 * system knows about — USB, network (TCP/IP), and wireless — without any
 * manual registration. Connection type is inferred from port/driver names
 * (WSD, TCP/IP, USB patterns) since Windows does not expose it as a field.
 */

export async function listPrinters(): Promise<NativePrinter[]> {
  const ps = [
    "$OutputEncoding = [Console]::OutputEncoding = [Text.Encoding]::UTF8",
    "Get-Printer | ForEach-Object {",
    "  $p = $_",
    "  $status = switch ($p.PrinterStatus) {",
    "    3 { 'online' } 1 { 'offline' } 7 { 'offline' } 5 { 'error' } default { 'unknown' }",
    "  }",
    "  [pscustomobject]@{",
    "    name = $p.Name",
    "    is_default = $p.Default",
    "    status = $status",
    "    driver = $p.DriverName",
    "    port = $p.PortName",
    "    location = $p.Location",
    "  } | ConvertTo-Json -Compress",
    "}",
  ].join("; ");
  try {
    const { stdout } = await exec("powershell.exe", [
      "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", ps,
    ], { timeout: 15_000, windowsHide: true, maxBuffer: 4 * 1024 * 1024 });
    return parsePrinters(stdout);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    log.error(`Get-Printer failed: ${msg}`);
    return [];
  }
}

function parsePrinters(stdout: string): NativePrinter[] {
  const text = stdout.trim();
  if (!text) return [];
  // PowerShell emits one JSON object per line (or a single array when piped).
  let raw: unknown[];
  try {
    const parsed: unknown = JSON.parse(text);
    raw = Array.isArray(parsed) ? parsed : [parsed];
  } catch {
    raw = text
      .split("\n")
      .map((l) => l.trim())
      .filter(Boolean)
      .map((line) => {
        try { return JSON.parse(line) as unknown; } catch { return null; }
      })
      .filter((v): v is Record<string, unknown> => v !== null);
  }
  const now = new Date().toISOString();
  const printers: NativePrinter[] = [];
  for (const item of raw) {
    if (!item || typeof item !== "object") continue;
    const o = item as Record<string, unknown>;
    const name = typeof o.name === "string" ? o.name : null;
    if (!name) continue;
    const port = typeof o.port === "string" ? o.port : "";
    const driver = typeof o.driver === "string" ? o.driver : "";
    printers.push({
      id: name,
      name,
      is_default: o.is_default === true,
      status: normalizeStatus(o.status),
      connection_type: classifyConnection(name, port, driver),
      driver_name: driver || null,
      port_name: port || null,
      location: typeof o.location === "string" && o.location ? o.location : null,
      last_detected_at: now,
    });
  }
  return printers;
}

function normalizeStatus(value: unknown): NativePrinter["status"] {
  if (value === "online" || value === "offline" || value === "error") return value;
  return "unknown";
}

/** Infer USB vs network vs wireless from Windows port/driver naming. */
function classifyConnection(
  name: string,
  port: string,
  driver: string
): NativePrinter["connection_type"] {
  const n = `${name} ${port} ${driver}`.toLowerCase();
  if (/wsd|bluetooth/.test(n)) return "wireless";
  if (/usb|dot4/.test(n)) return "usb";
  if (/tcpip|tcp\/ip|ip_\d|_\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/.test(n)) return "network";
  if (port.startsWith("\\\\")) return "network";
  if (/wifi|wi-fi|wireless|airprint/.test(n)) return "wireless";
  if (/\\\d{1,3}(\.\d{1,3}){3}/.test(name) || /\d{1,3}(\.\d{1,3}){3}/.test(port)) return "network";
  return "unknown";
}
