/**
 * Database shape used by typed Supabase queries.
 * Kept in sync manually with supabase/migrations.
 */

import type {
  IdentificationRecord,
  IssuanceRecord,
  Printer,
  PrintHistoryRecord,
  Profile,
  SyncOperation,
  SystemSetting,
  WorkstationDevice,
  DepartmentRow
} from "./index";

export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export type TableRows<Row, Insert = Partial<Row>, Update = Partial<Row>> = {
  Row: Row;
  Insert: Insert;
  Update: Update;
  Relationships: [];
};

export interface Database {
  public: {
    Tables: {
      profiles: TableRows<Profile>;
      persons: TableRows<
        import("./index").Person,
        Omit<import("./index").Person, "created_at" | "updated_at"> & {
          created_at?: string;
          updated_at?: string;
        },
        Partial<import("./index").Person>
      >;
      identification_records: TableRows<IdentificationRecord>;
      issuance_records: TableRows<IssuanceRecord>;
      printers: TableRows<Printer>;
      sync_operations: TableRows<SyncOperation>;
      workstation_devices: TableRows<WorkstationDevice>;
      system_settings: TableRows<SystemSetting>;
      print_history: TableRows<PrintHistoryRecord>;
      departments: TableRows<DepartmentRow>;
    };
    Views: Record<string, never>;
    Functions: {
      issue_id: {
        Args: {
          p_person_id: string;
          p_identification_record_id: string | null;
          p_issuance_reference: string;
          p_idempotency_key: string;
          p_printer_id: string | null;
          p_workstation_device_id: string | null;
          p_print_job_reference: string | null;
        };
        Returns: Json;
      };
      update_issuance_status: {
        Args: {
          p_issuance_id: string;
          p_new_status: string;
          p_failure_reason: string | null;
          p_print_job_id: string | null;
          p_printer_id: string | null;
        };
        Returns: Json;
      };
      get_dashboard_stats: {
        Args: Record<string, never>;
        Returns: Json;
      };
    };
    Enums: {
      user_role: "admin" | "officer" | "supervisor" | "viewer";
    };
    CompositeTypes: Record<string, never>;
  };
}
