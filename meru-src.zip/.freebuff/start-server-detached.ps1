$ws = 'C:\Users\hp\Pictures\ID Registration & Issuance Management System.(MERU DC) - Copy'
$log = "$ws\.freebuff\preview-185ab75d-b7ac-4e90-8d29-bbede45499ca.log"
$logErr = "$log.err"

$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = 'C:\node.exe'
$psi.Arguments = """$ws\node_modules\vite\bin\vite.js"" --host 0.0.0.0 --port 5174"
$psi.WorkingDirectory = $ws
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true
$psi.UseShellExecute = $false
$psi.CreateNoWindow = $true

$p = [System.Diagnostics.Process]::Start($psi)

$p.Id | Out-File -FilePath "$ws\.freebuff\preview-pid.txt" -Encoding utf8
Write-Output $p.Id
