/**
 * Print history — tracks every print job sent from this application.
 * Records are stored in Supabase `print_history` table for audit and reporting.
 */

import { supabase } from "./supabase-client";
import { mapSupabaseError } from "./errors";
import { db, type CachedPrintHistory } from "@/db/database";
import { enqueueOperation } from "@/offline/outbox";
import type { PrintHistoryRecord, PrintHistoryStatus } from "@/types";

/* ── Insert ──────────────────────────────────────────────────────────────── */

export interface CreatePrintHistoryInput {
  document_name: string;
  printer_name: string;
  printer_connection_type?: string | null;
  person_name?: string | null;
  identification_number?: string | null;
  issued_by?: string | null;
  issued_by_staff_number?: string | null;
  copies?: number;
  paper_size?: string;
  status: PrintHistoryStatus;
  error_message?: string | null;
  agent_job_id?: string | null;
  device_id?: string | null;
}

export async function createPrintHistory(
  input: CreatePrintHistoryInput
): Promise<PrintHistoryRecord> {
  const id = crypto.randomUUID();
  const now = new Date().toISOString();

  // Always save to IndexedDB first (works offline)
  const localRecord: CachedPrintHistory = {
    id,
    document_name: input.document_name,
    printer_name: input.printer_name,
    printer_connection_type: input.printer_connection_type ?? null,
    person_name: input.person_name ?? null,
    identification_number: input.identification_number ?? null,
    issued_by: input.issued_by ?? null,
    issued_by_staff_number: input.issued_by_staff_number ?? null,
    copies: input.copies ?? 1,
    paper_size: input.paper_size ?? "86x54mm",
    status: input.status,
    error_message: input.error_message ?? null,
    agent_job_id: input.agent_job_id ?? null,
    device_id: input.device_id ?? null,
    created_at: now,
    completed_at: null,
    synced: false,
  };
  await db.printHistory.put(localRecord);

  // If online, try to sync to Supabase
  if (navigator.onLine) {
    try {
      const { data, error } = await supabase
        .from("print_history")
        .insert({
          id,
          document_name: input.document_name,
          printer_name: input.printer_name,
          printer_connection_type: input.printer_connection_type ?? null,
          person_name: input.person_name ?? null,
          identification_number: input.identification_number ?? null,
          issued_by: input.issued_by ?? null,
          issued_by_staff_number: input.issued_by_staff_number ?? null,
          copies: input.copies ?? 1,
          paper_size: input.paper_size ?? "86x54mm",
          status: input.status,
          error_message: input.error_message ?? null,
          agent_job_id: input.agent_job_id ?? null,
          device_id: input.device_id ?? null,
        })
        .select("*")
        .single();
      if (!error && data) {
        await db.printHistory.update(id, { synced: true });
        return data as PrintHistoryRecord;
      }
    } catch {
      // Queue for sync later
    }
  }

  // Queue for background sync
  await enqueueOperation({
    entityType: "printer_status",
    entityId: id,
    operationType: "insert_person", // Reuse type for print history inserts
    payload: { ...input, id },
  });

  return localRecord as PrintHistoryRecord;
}

/* ── Update status ────────────────────────────────────────────────────────── */

export async function updatePrintHistoryStatus(
  id: string,
  status: PrintHistoryStatus,
  errorMessage?: string | null
): Promise<void> {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const patch: any = { status };
  if (errorMessage !== undefined) patch.error_message = errorMessage;
  if (status === "completed" || status === "failed") {
    patch.completed_at = new Date().toISOString();
  }
  const { error } = await supabase
    .from("print_history")
    .update(patch)
    .eq("id", id);
  if (error) throw mapSupabaseError(error);
}

/* ── List ─────────────────────────────────────────────────────────────────── */

export interface ListPrintHistoryOptions {
  pageSize?: number;
  page?: number;
  status?: PrintHistoryStatus | "all";
  search?: string;
}

export async function listPrintHistory(
  opts: ListPrintHistoryOptions = {}
): Promise<{ rows: PrintHistoryRecord[]; total: number }> {
  const { pageSize = 50, page = 0, status, search } = opts;

  // Try Supabase first if online
  if (navigator.onLine) {
    try {
      let query = supabase
        .from("print_history")
        .select("*", { count: "exact" });

      if (status && status !== "all") {
        query = query.eq("status", status);
      }

      if (search && search.trim()) {
        const term = search.trim();
        query = query.or(
          `document_name.ilike.%${term}%,printer_name.ilike.%${term}%,person_name.ilike.%${term}%,identification_number.ilike.%${term}%`
        );
      }

      query = query
        .order("created_at", { ascending: false })
        .range(page * pageSize, (page + 1) * pageSize - 1);

      const { data, error, count } = await query;
      if (!error) {
        // Cache results locally
        if (data) {
          for (const row of data) {
            await db.printHistory.put({ ...row, synced: true } as CachedPrintHistory);
          }
        }
        return {
          rows: (data ?? []) as PrintHistoryRecord[],
          total: count ?? 0,
        };
      }
    } catch {
      // Fall through to IndexedDB
    }
  }

  // Offline: read from IndexedDB
  let records = await db.printHistory.toArray();

  // Apply filters
  if (status && status !== "all") {
    records = records.filter((r) => r.status === status);
  }
  if (search && search.trim()) {
    const term = search.trim().toLowerCase();
    records = records.filter(
      (r) =>
        r.document_name.toLowerCase().includes(term) ||
        r.printer_name.toLowerCase().includes(term) ||
        (r.person_name?.toLowerCase().includes(term) ?? false) ||
        (r.identification_number?.toLowerCase().includes(term) ?? false)
    );
  }

  // Sort by created_at descending
  records.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

  // Paginate
  const total = records.length;
  const rows = records.slice(page * pageSize, (page + 1) * pageSize);

  return { rows, total };
}

/* ── Stats ────────────────────────────────────────────────────────────────── */

export async function getPrintHistoryStats(): Promise<{
  total: number;
  completed: number;
  failed: number;
  today: number;
}> {
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString();

  // Try Supabase first if online
  if (navigator.onLine) {
    try {
      const [totalRes, completedRes, failedRes, todayRes] = await Promise.all([
        supabase.from("print_history").select("id", { count: "exact", head: true }),
        supabase.from("print_history").select("id", { count: "exact", head: true }).eq("status", "completed"),
        supabase.from("print_history").select("id", { count: "exact", head: true }).eq("status", "failed"),
        supabase.from("print_history").select("id", { count: "exact", head: true }).gte("created_at", todayStart),
      ]);

      return {
        total: totalRes.count ?? 0,
        completed: completedRes.count ?? 0,
        failed: failedRes.count ?? 0,
        today: todayRes.count ?? 0,
      };
    } catch {
      // Fall through to IndexedDB
    }
  }

  // Offline: calculate from IndexedDB
  const allRecords = await db.printHistory.toArray();
  const todayRecords = allRecords.filter((r) => r.created_at >= todayStart);

  return {
    total: allRecords.length,
    completed: allRecords.filter((r) => r.status === "completed").length,
    failed: allRecords.filter((r) => r.status === "failed").length,
    today: todayRecords.length,
  };
}

/**
 * Graceful version of getPrintHistoryStats that returns zeros on error
 * (e.g. if the print_history table doesn't exist yet).
 */
export async function getPrintHistoryStatsSafe(): Promise<{
  total: number;
  completed: number;
  failed: number;
  today: number;
}> {
  try {
    return await getPrintHistoryStats();
  } catch {
    return { total: 0, completed: 0, failed: 0, today: 0 };
  }
}
