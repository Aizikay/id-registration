import { app } from "electron";
import { join } from "node:path";

/**
 * Runtime wiring for the bundled main process.
 *
 * Bundled code executes from dist-electron/*.cjs as CommonJS, where
 * __dirname and require exist natively. esbuild marks "electron" and
 * "electron-updater" as external so require() resolves them from the app's
 * node_modules (or the packaged asar) at runtime.
 */

declare const __dirname: string;

/** Resolved path of the built renderer (dist/), sibling of dist-electron/. */
export function resolveRendererRoot(): string {
  return join(__dirname, "..", "dist");
}

/** True when running from packaged resources rather than a dev checkout. */
export function isPackagedRuntime(): boolean {
  return app.isPackaged;
}

/**
 * Resolve electron-updater in packaged builds. Returns null in dev or when
 * the module is missing so update checks degrade to a friendly message.
 */
export function resolveElectronUpdater(): unknown | null {
  if (!app.isPackaged) return null;
  try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    return require("electron-updater");
  } catch {
    return null;
  }
}
