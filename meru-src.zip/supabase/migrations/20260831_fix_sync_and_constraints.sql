-- =============================================================
-- FIX: Sync conflict — relaxed constraints + missing columns + RLS
-- =============================================================
-- This migration fixes the "persons_identification_number_format"
-- constraint violation that causes CONFLICT status in the sync outbox.
-- Safe to run multiple times (idempotent).
-- =============================================================

-- 1. RELAX identification_number constraint
--    Old: ^[A-Z0-9]{8,20}$ (requires 8-20 chars, no symbols)
--    New: ^[A-Z0-9/\-]{1,30}$ (allows 1-30 chars, / and -)
-- =============================================================
ALTER TABLE public.persons
  DROP CONSTRAINT IF EXISTS persons_identification_number_format;

ALTER TABLE public.persons
  ADD CONSTRAINT persons_identification_number_format
  CHECK (identification_number ~ '^[A-Z0-9/\-]{1,30}$');

-- 2. ADD missing columns (position, signature_path) if they don't exist
-- =============================================================
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema='public' AND table_name='persons' AND column_name='position'
  ) THEN
    ALTER TABLE public.persons ADD COLUMN position text;
    RAISE NOTICE 'Added column: persons.position';
  ELSE
    RAISE NOTICE 'Column persons.position already exists';
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema='public' AND table_name='persons' AND column_name='signature_path'
  ) THEN
    ALTER TABLE public.persons ADD COLUMN signature_path text;
    RAISE NOTICE 'Added column: persons.signature_path';
  ELSE
    RAISE NOTICE 'Column persons.signature_path already exists';
  END IF;
END $$;

-- 3. DROP old restrictive INSERT policy (requires officer/admin profile)
--    Replace with: any authenticated user can insert
-- =============================================================
DROP POLICY IF EXISTS persons_insert_officer_admin ON public.persons;
DROP POLICY IF EXISTS persons_insert ON public.persons;

CREATE POLICY persons_insert ON public.persons
  FOR INSERT TO authenticated
  WITH CHECK (true);

-- 4. DROP old restrictive UPDATE policy
--    Replace with: any authenticated user can update
-- =============================================================
DROP POLICY IF EXISTS persons_update_officer_admin ON public.persons;
DROP POLICY IF EXISTS persons_update ON public.persons;

CREATE POLICY persons_update ON public.persons
  FOR UPDATE TO authenticated
  USING (true)
  WITH CHECK (true);

-- 5. Ensure DELETE policy exists for supervisor/admin
-- =============================================================
DROP POLICY IF EXISTS persons_delete_supervisor_admin ON public.persons;
DROP POLICY IF EXISTS person_delete_supervisor_admin ON public.persons;
DROP POLICY IF EXISTS delete_people_supervisor_only ON public.persons;
DROP POLICY IF EXISTS "Allow only Supervisors to delete people" ON public.persons;
DROP POLICY IF EXISTS persons_delete_admin ON public.persons;

CREATE POLICY persons_delete_supervisor_admin ON public.persons
  FOR DELETE TO authenticated
  USING (public.auth_profile_role() IN ('supervisor','admin'));

-- 6. Ensure SELECT policy exists
-- =============================================================
DROP POLICY IF EXISTS persons_select_authenticated ON public.persons;
DROP POLICY IF EXISTS "Allow authenticated users to view people" ON public.persons;

CREATE POLICY persons_select_authenticated ON public.persons
  FOR SELECT TO authenticated
  USING (true);

-- 7. Ensure helper functions exist
-- =============================================================
CREATE OR REPLACE FUNCTION public.auth_profile_role()
RETURNS public.user_role
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT p.role FROM public.profiles p WHERE p.user_id = auth.uid() AND p.status = 'active' LIMIT 1;
$$;

CREATE OR REPLACE FUNCTION public.auth_profile_id()
RETURNS uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT p.id FROM public.profiles p WHERE p.user_id = auth.uid() AND p.status = 'active' LIMIT 1;
$$;

-- 8. Verify
-- =============================================================
SELECT '=== COLUMNS ===' as info;
SELECT column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_schema='public' AND table_name='persons'
ORDER BY ordinal_position;

SELECT '=== CONSTRAINTS ===' as info;
SELECT conname, pg_get_constraintdef(oid) as definition
FROM pg_constraint
WHERE conrelid = 'persons'::regclass AND contype = 'c';

SELECT '=== POLICIES ===' as info;
SELECT policyname, cmd, qual
FROM pg_policies
WHERE tablename = 'persons';
