import { useEffect, useRef } from "react";

interface FullscreenPrintProps {
  htmlContent: string;
  onClose: () => void;
}

/**
 * Renders ID card content in a clean fullscreen overlay for printing.
 * Opens in a new window so the user gets a clean print dialog without
 * any app chrome, sidebar, or controls.
 */
export function FullscreenPrint({ htmlContent, onClose }: FullscreenPrintProps) {
  const windowRef = useRef<Window | null>(null);

  useEffect(() => {
    // Open a new window for clean printing
    const printWindow = window.open("", "_blank", "width=900,height=700");
    if (!printWindow) {
      onClose();
      return;
    }
    windowRef.current = printWindow;

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Meru DC — ID Card Print</title>
        <style>
          @page {
            size: 86mm 54mm;
            margin: 0;
          }
          * { margin: 0; padding: 0; box-sizing: border-box; }
          html, body {
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #f1f5f9;
            font-family: Arial, Helvetica, sans-serif;
          }
          .print-card {
            width: 86mm;
            height: 54mm;
            box-shadow: 0 4px 24px rgba(0,0,0,0.15);
            border-radius: 2mm;
            overflow: hidden;
            background: white;
          }
          @media print {
            html, body { background: white !important; }
            .print-card { box-shadow: none !important; border-radius: 0 !important; }
            .no-print { display: none !important; }
          }
        </style>
      </head>
      <body>
        <div class="no-print" style="
          position: fixed; top: 16px; left: 50%; transform: translateX(-50%);
          z-index: 1000; display: flex; gap: 12px; align-items: center;
          background: #065f46; color: white; padding: 12px 24px;
          border-radius: 12px; box-shadow: 0 8px 32px rgba(0,0,0,0.3);
          font-family: system-ui, -apple-system, sans-serif;
        ">
          <span style="font-weight: 600; font-size: 14px;">ID Card Preview</span>
          <button onclick="window.print()" style="
            background: #10b981; color: white; border: none; padding: 8px 20px;
            border-radius: 8px; font-weight: 600; cursor: pointer; font-size: 13px;
          ">🖨️ Print</button>
          <button onclick="window.close()" style="
            background: rgba(255,255,255,0.2); color: white; border: none;
            padding: 8px 16px; border-radius: 8px; cursor: pointer; font-size: 13px;
          ">✕ Close</button>
        </div>
        <div class="print-card" id="print-area">
          ${htmlContent}
        </div>
        <script>
          // Auto-focus for quick Ctrl+P
          document.addEventListener('keydown', (e) => {
            if (e.key === 'p' && (e.ctrlKey || e.metaKey)) {
              e.preventDefault();
              window.print();
            }
            if (e.key === 'Escape') window.close();
          });
        </script>
      </body>
      </html>
    `);
    printWindow.document.close();

    return () => {
      if (windowRef.current && !windowRef.current.closed) {
        windowRef.current.close();
      }
    };
  }, [htmlContent, onClose]);

  return null; // This component renders in a new window
}

/**
 * Generate a clean HTML string of the ID card for fullscreen printing.
 * Supports dual-page (front + back) printing on the same sheet.
 */
export function generateIdCardHtml(options: {
  frontImageSrc: string;
  backImageSrc?: string;
  personName?: string;
  chekiNamba?: string;
  cheo?: string;
  photoUrl?: string;
  signatureUrl?: string;
}): string {
  const { frontImageSrc, backImageSrc, personName, chekiNamba, cheo, photoUrl, signatureUrl } = options;

  const frontPage = `
    <div style="
      width: 86mm; height: 54mm; position: relative; overflow: hidden;
      background: #fef3c7; border-radius: 2mm;
      page-break-after: always; page-break-inside: avoid;
    ">
      <img src="${frontImageSrc}" style="
        width: 100%; height: 100%; object-fit: cover; display: block;
      " crossorigin="anonymous" />
      ${personName ? `<span style="
        position: absolute; left: 28.3%; top: 52.5%;
        font-family: Arial, Arial Narrow, Helvetica, sans-serif;
        font-weight: 700; font-size: 2.8mm; color: #000;
        text-transform: uppercase; letter-spacing: 0;
        white-space: nowrap;
      ">${escapeHtml(personName)}</span>` : ""}
      ${chekiNamba ? `<span style="
        position: absolute; left: 28.3%; top: 44.5%;
        font-family: Arial, Arial Narrow, Helvetica, sans-serif;
        font-weight: 700; font-size: 2.8mm; color: #000;
        text-transform: uppercase; letter-spacing: 0;
        white-space: nowrap;
      ">${escapeHtml(chekiNamba)}</span>` : ""}
      ${cheo ? `<span style="
        position: absolute; left: 28.3%; top: 59.5%;
        font-family: Arial, Arial Narrow, Helvetica, sans-serif;
        font-weight: 700; font-size: 2.8mm; color: #000;
        text-transform: uppercase; letter-spacing: 0;
        white-space: nowrap;
      ">${escapeHtml(cheo)}</span>` : ""}
      ${photoUrl ? `<img src="${photoUrl}" style="
        position: absolute; left: 68%; top: 20%; width: 22%; height: 42%;
        object-fit: cover; border-radius: 1mm;
      " crossorigin="anonymous" />` : ""}
      ${signatureUrl ? `<img src="${signatureUrl}" style="
        position: absolute; left: 28.3%; top: 64%; height: 8%;
        object-fit: contain; background: transparent;
      " crossorigin="anonymous" />` : ""}
    </div>
  `;

  // If no back page, return front only
  if (!backImageSrc) return frontPage;

  // Dual-page: front + back on the same sheet
  const backPage = `
    <div style="
      width: 86mm; height: 54mm; position: relative; overflow: hidden;
      background: white; border-radius: 2mm;
      page-break-after: auto; page-break-inside: avoid;
    ">
      <img src="${backImageSrc}" style="
        width: 100%; height: 100%; object-fit: cover; display: block;
      " crossorigin="anonymous" />
    </div>
  `;

  return frontPage + backPage;
}

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
