import { app } from "electron";
import { appendFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";

/**
 * Minimal file logger for the main process. Logs go to
 * <userData>/logs/main.log so field issues can be diagnosed without a console.
 */

let logDir: string | null = null;

function ensureLogDir(): string {
  if (!logDir) {
    logDir = join(app.getPath("userData"), "logs");
    try {
      mkdirSync(logDir, { recursive: true });
    } catch {
      // fall back to no-op logging
    }
  }
  return logDir;
}

function write(level: "INFO" | "WARN" | "ERROR", scope: string, message: string): void {
  const line = `[${new Date().toISOString()}] [${level}] [${scope}] ${message}\n`;
  // Mirror to stdout (visible with --enable-logging and in dev).
  if (level === "ERROR") console.error(line.trim());
  else console.log(line.trim());
  try {
    appendFileSync(join(ensureLogDir(), "main.log"), line);
  } catch {
    // ignore
  }
}

export function createLogger(scope: string) {
  return {
    info: (msg: string) => write("INFO", scope, msg),
    warn: (msg: string) => write("WARN", scope, msg),
    error: (msg: string) => write("ERROR", scope, msg),
  };
}
