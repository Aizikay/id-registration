import { existsSync, readFileSync, writeFileSync, mkdirSync } from "node:fs";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { STATE_PATH } from "./config.js";

export type JobStatus = "queued" | "printing" | "completed" | "failed";

export interface JobRecord {
  job_id: string;
  idempotency_key: string;
  document_reference: string;
  issuance_reference: string;
  printer_id: string;
  requested_by: string | null;
  person_name: string;
  identification_number: string;
  status: JobStatus;
  error_message?: string;
  created_at: string;
  updated_at: string;
  pages_printed?: number;
}

interface PersistedState {
  deviceId?: string;
  jobs?: Record<string, JobRecord>;
  idempotency?: Record<string, string>; // idempotency_key -> job_id
}

function loadState(): PersistedState {
  try {
    if (!existsSync(STATE_PATH)) return {};
    return JSON.parse(readFileSync(STATE_PATH, "utf-8")) as PersistedState;
  } catch {
    return {};
  }
}

function saveState(jobs: Map<string, JobRecord>, idempotency: Map<string, string>, deviceId: string): void {
  try {
    const dir = path.dirname(STATE_PATH);
    try {
      mkdirSync(dir, { recursive: true });
    } catch {
      // ignore
    }
    // Preserve any unknown keys already in file.
    let existing: PersistedState = {};
    try {
      if (existsSync(STATE_PATH)) existing = JSON.parse(readFileSync(STATE_PATH, "utf-8")) as PersistedState;
    } catch {
      existing = {};
    }
    const out: PersistedState = {
      ...existing,
      deviceId,
      jobs: Object.fromEntries(jobs.entries()),
      idempotency: Object.fromEntries(idempotency.entries())
    };
    writeFileSync(STATE_PATH, JSON.stringify(out, null, 2), "utf-8");
  } catch {
    // persistence is best-effort; jobs live in memory regardless
  }
}

export class JobStore {
  private jobs = new Map<string, JobRecord>();
  private byIdempotency = new Map<string, string>();
  private deviceId: string;

  constructor(deviceId: string) {
    this.deviceId = deviceId;
    const s = loadState();
    if (s.jobs) {
      for (const [k, v] of Object.entries(s.jobs)) this.jobs.set(k, v as JobRecord);
    }
    if (s.idempotency) {
      for (const [k, v] of Object.entries(s.idempotency)) this.byIdempotency.set(k, v);
    }
  }

  private persist(): void {
    saveState(this.jobs, this.byIdempotency, this.deviceId);
  }

  getById(id: string): JobRecord | undefined {
    return this.jobs.get(id);
  }

  getByIdempotency(key: string): JobRecord | undefined {
    const jobId = this.byIdempotency.get(key);
    return jobId ? this.jobs.get(jobId) : undefined;
  }

  /**
   * Create a new job or return the existing one for the same idempotency_key
   * (idempotent replay). The caller should not re-print if a completed job
   * is returned for the same key.
   */
  createOrReplay(input: {
    idempotency_key: string;
    document_reference: string;
    issuance_reference: string;
    printer_id: string;
    requested_by: string | null;
    person_name: string;
    identification_number: string;
  }): { job: JobRecord; isReplay: boolean } {
    const existing = this.getByIdempotency(input.idempotency_key);
    if (existing) return { job: existing, isReplay: true };

    const now = new Date().toISOString();
    const job: JobRecord = {
      job_id: `JOB-${randomUUID().slice(0, 8).toUpperCase()}`,
      idempotency_key: input.idempotency_key,
      document_reference: input.document_reference,
      issuance_reference: input.issuance_reference,
      printer_id: input.printer_id,
      requested_by: input.requested_by,
      person_name: input.person_name,
      identification_number: input.identification_number,
      status: "queued",
      created_at: now,
      updated_at: now
    };
    this.jobs.set(job.job_id, job);
    this.byIdempotency.set(input.idempotency_key, job.job_id);
    this.persist();
    return { job, isReplay: false };
  }

  /** Create a one-off test job (no idempotency_key deduplication). */
  createTestJob(printerId: string, requestedBy: string | null): JobRecord {
    const now = new Date().toISOString();
    const job: JobRecord = {
      job_id: `TEST-${randomUUID().slice(0, 8).toUpperCase()}`,
      idempotency_key: `test-${randomUUID()}`,
      document_reference: `TEST-${Date.now()}`,
      issuance_reference: "TEST-PAGE",
      printer_id: printerId,
      requested_by: requestedBy,
      person_name: "Test Page",
      identification_number: "TEST",
      status: "queued",
      created_at: now,
      updated_at: now
    };
    this.jobs.set(job.job_id, job);
    this.persist();
    return job;
  }

  update(jobId: string, patch: Partial<Pick<JobRecord, "status" | "error_message" | "pages_printed">>): JobRecord | undefined {
    const j = this.jobs.get(jobId);
    if (!j) return undefined;
    const next: JobRecord = { ...j, ...patch, updated_at: new Date().toISOString() };
    this.jobs.set(jobId, next);
    this.persist();
    return next;
  }
}
