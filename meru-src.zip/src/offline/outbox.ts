/**
 * Offline operation queue ("outbox").
 *
 * Every mutation performed while offline is journaled here BEFORE being
 * applied to the local database, so data can never be silently lost.
 * The sync engine drains this queue when connectivity returns using
 * idempotent operation_ids.
 */

import { db, type OutboxEntry } from "@/db/database";

export type { OutboxEntry };
import { newOperationId } from "./device";
import type { SyncEntity, SyncOperationType } from "@/types";

export interface EnqueueInput {
  entityType: SyncEntity;
  entityId: string;
  operationType: SyncOperationType;
  payload: Record<string, unknown>;
}

export async function enqueueOperation(input: EnqueueInput): Promise<OutboxEntry> {
  const entry: OutboxEntry = {
    operation_id: newOperationId(),
    entity_type: input.entityType,
    entity_id: input.entityId,
    operation_type: input.operationType,
    payload: input.payload,
    status: "pending",
    retry_count: 0,
    next_attempt_at: Date.now(),
    error_message: null,
    created_at: new Date().toISOString(),
    processed_at: null
  };
  await db.outbox.add(entry);
  return entry;
}

export function pendingCount(): Promise<number> {
  return db.outbox.filter((e) => e.status === "pending" || e.status === "failed").count();
}

export function conflictCount(): Promise<number> {
  return db.outbox.where("status").equals("conflict").count();
}

export function listOutbox(): Promise<OutboxEntry[]> {
  return db.outbox.orderBy("id").reverse().toArray();
}

export async function markInFlight(id: number): Promise<void> {
  await db.outbox.update(id, { status: "in_flight" });
}

export async function markSynchronized(
  id: number,
  serverEntityIds?: { personId?: string; issuanceId?: string }
): Promise<void> {
  await db.transaction("rw", db.outbox, db.persons, db.issuances, async () => {
    await db.outbox.update(id, {
      status: "synchronized",
      processed_at: new Date().toISOString(),
      error_message: null
    });
  });
  void serverEntityIds;
}

export async function markFailed(id: number, message: string): Promise<void> {
  const entry = await db.outbox.get(id);
  if (!entry) return;
  const retryCount = entry.retry_count + 1;
  // Exponential backoff with jitter: base 5s -> 10s -> 20s ... capped at 10 min
  const backoffMs = Math.min(5000 * Math.pow(2, retryCount - 1), 600_000);
  const jitter = Math.floor(Math.random() * 1000);
  await db.outbox.update(id, {
    status: retryCount >= 8 ? "conflict" : "failed",
    retry_count: retryCount,
    next_attempt_at: Date.now() + backoffMs + jitter,
    error_message: message.slice(0, 500)
  });
}

/** A non-retryable conflict (e.g. server says already issued by someone else). */
export async function markConflict(id: number, message: string): Promise<void> {
  await db.outbox.update(id, {
    status: "conflict",
    error_message: message.slice(0, 500)
  });
}

export async function retryEntry(id: number): Promise<void> {
  await db.outbox.update(id, {
    status: "pending",
    retry_count: 0,
    next_attempt_at: Date.now(),
    error_message: null
  });
}

/** Reset ALL conflict entries back to pending so the sync engine retries them. */
export async function retryAllConflicts(): Promise<number> {
  const conflicts = await db.outbox
    .where("status")
    .equals("conflict")
    .toArray();
  let count = 0;
  for (const entry of conflicts) {
    await db.outbox.update(entry.id!, {
      status: "pending",
      retry_count: 0,
      next_attempt_at: Date.now(),
      error_message: null
    });
    count++;
  }
  return count;
}
