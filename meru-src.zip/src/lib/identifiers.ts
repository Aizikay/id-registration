/**
 * Identifier and reference generation.
 *
 * All identifiers are generated client-side where possible so that offline
 * operations can be created deterministically and synchronized idempotently.
 */

import { v4 as fallbackUuid } from "@/utils/uuid-fallback";

/** RFC4122 v4 UUID via crypto API, with fallback for http://192.168... (non-secure context). */
export function uuid(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    try {
      return crypto.randomUUID();
    } catch {
      // fall through to fallback
    }
  }
  // crypto.getRandomValues is available even in non-secure contexts
  return fallbackUuid();
}

const REF_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ"; // excludes I,O for legibility
const REF_DIGITS = "0123456789";

function randomFrom(alphabet: string, length: number): string {
  const bytes = new Uint32Array(length);
  crypto.getRandomValues(bytes);
  let out = "";
  for (let i = 0; i < length; i++) {
    out += alphabet[bytes[i]! % alphabet.length];
  }
  return out;
}

/**
 * Issuance reference format: MRU-<YYYYMMDD>-<6 chars>
 * Example: MRU-20260823-K7XQ2M
 * Uniqueness is enforced by a database UNIQUE constraint; collisions are
 * retried by callers.
 */
export function generateIssuanceReference(now: Date = new Date()): string {
  const y = now.getFullYear().toString().padStart(4, "0");
  const m = (now.getMonth() + 1).toString().padStart(2, "0");
  const d = now.getDate().toString().padStart(2, "0");
  const rand =
    randomFrom(REF_ALPHABET, 3) + randomFrom(REF_DIGITS, 3);
  return `MRU-${y}${m}${d}-${rand}`;
}

/**
 * Print job reference: PRT-<unix-ms base36>-<4 random>
 */
export function generatePrintJobReference(): string {
  const t = Date.now().toString(36).toUpperCase();
  return `PRT-${t}-${randomFrom(REF_DIGITS, 4)}`;
}
