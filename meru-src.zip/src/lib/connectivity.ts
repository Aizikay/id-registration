/**
 * Connectivity helper kept separate so tests can stub it without touching
 * the global navigator.
 */

export function navigatorOnLine(): boolean {
  return typeof navigator === "undefined" ? true : navigator.onLine;
}
