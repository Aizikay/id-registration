-- ============================================================================
-- Migration 00003: Row Level Security policies
--
-- Principles:
--   * Every table has RLS ENABLED — no exceptions.
--   * Least privilege per role; viewer is read-only.
--   * audit_logs are APPEND-ONLY for everyone (no UPDATE/DELETE policy exists).
--   * Frontend role checks are UX only; these policies are the real gate.
-- ============================================================================

alter table public.profiles               enable row level security;
alter table public.persons                enable row level security;
alter table public.identification_records enable row level security;
alter table public.issuance_records       enable row level security;
alter table public.printers               enable row level security;
alter table public.audit_logs             enable row level security;
alter table public.sync_operations        enable row level security;
alter table public.workstation_devices    enable row level security;
alter table public.system_settings        enable row level security;

-- ---------------------------------------------------------------------------
-- profiles
-- ---------------------------------------------------------------------------
create policy profiles_select_own_or_admin on public.profiles
  for select to authenticated
  using (
    user_id = auth.uid()
    or public.auth_profile_role() = 'admin'
    or public.auth_profile_role() = 'supervisor'
  );

create policy profiles_update_self_limited on public.profiles
  for update to authenticated
  using (user_id = auth.uid())
  with check (
    user_id = auth.uid()
    -- A user may edit own contact info but never own role/status/staff_number
    and role   = (select p.role from public.profiles p where p.user_id = auth.uid())
    and status = (select p.status from public.profiles p where p.user_id = auth.uid())
    and staff_number = (select p.staff_number from public.profiles p where p.user_id = auth.uid())
  );

create policy profiles_manage_admin on public.profiles
  for all to authenticated
  using (public.auth_profile_role() = 'admin')
  with check (public.auth_profile_role() = 'admin');

-- ---------------------------------------------------------------------------
-- persons
-- ---------------------------------------------------------------------------
create policy persons_select_authenticated on public.persons
  for select to authenticated using (true);

create policy persons_insert_officer_admin on public.persons
  for insert to authenticated
  with check (public.auth_profile_role() in ('officer','admin'));

create policy persons_update_officer_admin on public.persons
  for update to authenticated
  using (public.auth_profile_role() in ('officer','admin'))
  with check (public.auth_profile_role() in ('officer','admin'));

-- No DELETE policy: person records cannot be deleted by application users.
-- Corrections are made via UPDATE so history remains intact.

-- ---------------------------------------------------------------------------
-- identification_records
-- ---------------------------------------------------------------------------
create policy identification_select_authenticated on public.identification_records
  for select to authenticated using (true);

create policy identification_insert_officer_admin on public.identification_records
  for insert to authenticated
  with check (public.auth_profile_role() in ('officer','admin'));

create policy identification_update_admin on public.identification_records
  for update to authenticated
  using (public.auth_profile_role() = 'admin');

-- ---------------------------------------------------------------------------
-- issuance_records
-- ---------------------------------------------------------------------------
create policy issuance_select_authenticated on public.issuance_records
  for select to authenticated using (true);

-- Direct INSERT is intentionally NOT granted: issuance must go through the
-- issue_id() RPC which enforces duplicate checks + idempotency atomically.
create policy issuance_no_direct_insert on public.issuance_records
  for insert to authenticated
  with check (false);

create policy issuance_update_via_rpc_only on public.issuance_records
  for update to authenticated
  using (public.auth_profile_role() in ('supervisor','admin'))
  with check (public.auth_profile_role() in ('supervisor','admin'));

-- ---------------------------------------------------------------------------
-- printers
-- ---------------------------------------------------------------------------
create policy printers_select_staff on public.printers
  for select to authenticated
  using (public.auth_profile_role() is not null);

create policy printers_manage_admin on public.printers
  for all to authenticated
  using (public.auth_profile_role() = 'admin')
  with check (public.auth_profile_role() = 'admin');

-- Print agents authenticate with a dedicated JWT (device-bound service user);
-- they may update printer heartbeat/status only.
create policy printers_agent_heartbeat on public.printers
  for update to authenticated
  using (public.auth_profile_role() = 'viewer' and enabled)
  with check (true);

-- ---------------------------------------------------------------------------
-- audit_logs — APPEND ONLY
-- ---------------------------------------------------------------------------
create policy audit_select_supervisor_admin on public.audit_logs
  for select to authenticated
  using (public.auth_profile_role() in ('admin','supervisor'));

-- Any active staff may append audit rows (the RPCs do it server-side too),
-- but NOBODY except the platform/service role can modify or delete them:
create policy audit_insert_any_active on public.audit_logs
  for insert to authenticated
  with check (
    actor_user_id is null or actor_user_id = public.auth_profile_id()
  );
-- NOTE: no UPDATE / DELETE policy => denied by default even for admins.

-- ---------------------------------------------------------------------------
-- sync_operations
-- ---------------------------------------------------------------------------
create policy sync_select_own_or_admin on public.sync_operations
  for select to authenticated
  using (
    device_id in (
      select wd.device_id from public.workstation_devices wd
      where wd.status = 'active'
        and (wd.assigned_to = public.auth_profile_id()
             or public.auth_profile_role() = 'admin')
    )
    or public.auth_profile_role() = 'admin'
  );

create policy sync_insert_own_device on public.sync_operations
  for insert to authenticated
  with check (
    device_id in (
      select wd.device_id from public.workstation_devices wd
      where wd.status = 'active'
        and (wd.assigned_to = public.auth_profile_id()
             or public.auth_profile_role() = 'admin')
    )
  );

create policy sync_update_own_device on public.sync_operations
  for update to authenticated
  using (
    device_id in (
      select wd.device_id from public.workstation_devices wd
      where wd.status = 'active'
        and (wd.assigned_to = public.auth_profile_id()
             or public.auth_profile_role() = 'admin')
    )
  )
  with check (
    device_id in (
      select wd.device_id from public.workstation_devices wd
      where wd.status = 'active'
        and (wd.assigned_to = public.auth_profile_id()
             or public.auth_profile_role() = 'admin')
    )
  );

-- ---------------------------------------------------------------------------
-- workstation_devices
-- ---------------------------------------------------------------------------
create policy devices_select_own_or_admin on public.workstation_devices
  for select to authenticated
  using (
    assigned_to = public.auth_profile_id()
    or registered_by = public.auth_profile_id()
    or public.auth_profile_role() in ('admin','supervisor')
  );

create policy devices_insert_authenticated on public.workstation_devices
  for insert to authenticated
  with check (registered_by = public.auth_profile_id());

create policy devices_update_own_or_admin on public.workstation_devices
  for update to authenticated
  using (
    assigned_to = public.auth_profile_id()
    or public.auth_profile_role() = 'admin'
  )
  with check (
    assigned_to = public.auth_profile_id()
    or public.auth_profile_role() = 'admin'
  );

-- Revocation removes operational capability; only admins can set revoked.
create policy devices_revoke_admin on public.workstation_devices
  for update to authenticated
  using (public.auth_profile_role() = 'admin')
  with check (public.auth_profile_role() = 'admin');

-- ---------------------------------------------------------------------------
-- system_settings
-- ---------------------------------------------------------------------------
create policy settings_read_authenticated on public.system_settings
  for select to authenticated using (true);

create policy settings_write_admin on public.system_settings
  for all to authenticated
  using (public.auth_profile_role() = 'admin')
  with check (public.auth_profile_role() = 'admin');
