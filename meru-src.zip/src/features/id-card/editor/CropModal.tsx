/**
 * CropModal — Compact image crop with zoom, pan, rotate, and always-visible buttons.
 */

import { useState, useRef, useCallback, useEffect } from "react";
import { Modal } from "@/components/ui/modal";
import { GlassCheckbox } from "@/components/GlassCheckbox";

export interface ImageTransform {
  zoom: number;
  rotation: number;
  x: number;
  y: number;
}

interface Props {
  open: boolean;
  onClose: () => void;
  onApply: (img: HTMLImageElement, transform: ImageTransform) => void;
  aspect?: "photo" | "signature";
  removeBgOption?: boolean;
  initialFile?: File | null;
}

export function CropModal({
  open,
  onClose,
  onApply,
  aspect = "photo",
  removeBgOption = false,
  initialFile = null,
}: Props) {
  const [img, setImg] = useState<HTMLImageElement | null>(null);
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [dragging, setDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [removeBg, setRemoveBg] = useState(false);
  const [previewSrc, setPreviewSrc] = useState<string | null>(null);

  const areaRef = useRef<HTMLDivElement>(null);

  const aspectRatio = aspect === "photo" ? 3 / 4 : 3 / 1;

  const loadFile = useCallback(
    (file: File) => {
      if (file.size > (aspect === "photo" ? 10 : 5) * 1024 * 1024) {
        alert(`File too large. Max ${aspect === "photo" ? "10MB" : "5MB"}.`);
        return;
      }
      const reader = new FileReader();
      reader.onload = (e) => {
        const image = new Image();
        image.onload = () => {
          setImg(image);
          setPreviewSrc(e.target?.result as string);
          setZoom(1);
          setRotation(0);
          setOffset({ x: 0, y: 0 });
        };
        image.src = e.target!.result as string;
      };
      reader.readAsDataURL(file);
    },
    [aspect]
  );

  const handleFileInput = useCallback(() => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/jpeg,image/png,image/webp,image/jpg";
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) loadFile(file);
    };
    input.click();
  }, [loadFile]);

  const onPointerDown = useCallback(
    (e: React.PointerEvent) => {
      if (!img) return;
      setDragging(true);
      setDragStart({ x: e.clientX - offset.x, y: e.clientY - offset.y });
      e.preventDefault();
    },
    [img, offset]
  );

  const onPointerMove = useCallback(
    (e: React.PointerEvent) => {
      if (!dragging) return;
      setOffset({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y,
      });
      e.preventDefault();
    },
    [dragging, dragStart]
  );

  const onPointerUp = useCallback(() => {
    setDragging(false);
  }, []);

  const resetCrop = () => {
    setZoom(1);
    setRotation(0);
    setOffset({ x: 0, y: 0 });
  };

  const getPreviewStyle = (): React.CSSProperties => {
    if (!img || !previewSrc) return {};
    const area = areaRef.current;
    if (!area) return {};

    const areaRect = area.getBoundingClientRect();
    const fitScale = Math.min(
      areaRect.width / (img.naturalWidth || 1),
      areaRect.height / (img.naturalHeight || 1)
    );
    const s = fitScale * zoom;
    const w = (img.naturalWidth || 1) * s;
    const h = (img.naturalHeight || 1) * s;
    const x = (areaRect.width - w) / 2 + offset.x;
    const y = (areaRect.height - h) / 2 + offset.y;

    return {
      position: "absolute",
      left: x,
      top: y,
      width: w,
      height: h,
      transform: `rotate(${rotation}deg)`,
      transformOrigin: "center center",
      pointerEvents: "none" as const,
    };
  };

  const handleApply = () => {
    if (!img) return;

    let finalImg = img;
    if (removeBg && removeBgOption) {
      finalImg = removeWhiteBackground(img);
    }

    onApply(finalImg, { zoom, rotation, x: offset.x, y: offset.y });
    resetState();
  };

  const resetState = () => {
    setImg(null);
    setPreviewSrc(null);
    setZoom(1);
    setRotation(0);
    setOffset({ x: 0, y: 0 });
    setDragging(false);
    setRemoveBg(false);
  };

  const handleClose = () => {
    resetState();
    onClose();
  };

  useEffect(() => {
    if (open && !img) {
      if (initialFile) {
        loadFile(initialFile);
      } else {
        const timer = setTimeout(() => handleFileInput(), 100);
        return () => clearTimeout(timer);
      }
    }
  }, [open, initialFile]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <Modal
      open={open}
      onClose={handleClose}
      title={aspect === "photo" ? "📸 Crop Photo" : "✍️ Crop Signature"}
      size="md"
    >
      <div className="max-h-[55vh] overflow-y-auto">
        <div className="space-y-3">
          {!previewSrc ? (
            <div
              className="flex cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed border-gray-300 bg-gray-50 p-8 transition-all hover:border-[var(--accent)] hover:bg-emerald-50"
              onClick={handleFileInput}
            >
              <div className="mb-3 text-3xl">📁</div>
              <p className="text-sm font-semibold text-gray-700">Click to select an image</p>
              <p className="mt-1 text-xs text-gray-500">
                JPG, PNG, WebP · Max {aspect === "photo" ? "10MB" : "5MB"}
              </p>
            </div>
          ) : (
            <>
              {/* Crop area */}
              <div
                ref={areaRef}
                className="relative w-full cursor-grab touch-none overflow-hidden rounded-xl bg-gray-900 shadow-inner"
                style={{ maxHeight: "35vh", aspectRatio: aspectRatio }}
                onPointerDown={onPointerDown}
                onPointerMove={onPointerMove}
                onPointerUp={onPointerUp}
                onPointerLeave={onPointerUp}
              >
                <img
                  src={previewSrc}
                  alt="Crop preview"
                  draggable={false}
                  style={getPreviewStyle()}
                />
                <div
                  className="pointer-events-none absolute border-2 border-white/60"
                  style={{ inset: aspect === "photo" ? 8 : 6, borderRadius: 4 }}
                />
                {/* Crosshair guides */}
                <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-15">
                  <div className="h-px w-3/5 bg-white" />
                </div>
                <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-15">
                  <div className="h-3/5 w-px bg-white" />
                </div>
              </div>

              {/* Zoom slider */}
              <div className="flex items-center gap-3">
                <span className="w-12 text-xs font-semibold text-gray-600">Zoom</span>
                <input
                  type="range"
                  min={0.2}
                  max={5}
                  step={0.01}
                  value={zoom}
                  onChange={(e) => setZoom(parseFloat(e.target.value))}
                  className="slider flex-1"
                  style={{
                    '--progress': `${((zoom - 0.2) / 4.8) * 100}%`
                  } as React.CSSProperties}
                />
                <span className="w-10 text-right text-xs font-mono text-gray-600">{Math.round(zoom * 100)}%</span>
              </div>

              {/* Rotation slider */}
              <div className="flex items-center gap-3">
                <span className="w-12 text-xs font-semibold text-gray-600">Rotate</span>
                <input
                  type="range"
                  min={-180}
                  max={180}
                  step={1}
                  value={rotation}
                  onChange={(e) => setRotation(parseFloat(e.target.value))}
                  className="slider flex-1"
                  style={{
                    '--progress': `${((rotation + 180) / 360) * 100}%`
                  } as React.CSSProperties}
                />
                <span className="w-10 text-right text-xs font-mono text-gray-600">{Math.round(rotation)}°</span>
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-2 pt-1">
                <button
                  onClick={resetCrop}
                  className="rounded-lg border-2 border-gray-200 bg-white px-3 py-1.5 text-xs font-semibold text-gray-600 transition-all hover:border-gray-300 hover:bg-gray-50 active:scale-95"
                >
                  ↺ Reset
                </button>
                <button
                  onClick={handleFileInput}
                  className="rounded-lg border-2 border-gray-200 bg-white px-3 py-1.5 text-xs font-semibold text-gray-600 transition-all hover:border-gray-300 hover:bg-gray-50 active:scale-95"
                >
                  📁 Change
                </button>
                {removeBgOption && (
                  <label className="flex items-center gap-1.5 rounded-lg border-2 border-gray-200 bg-white px-3 py-1.5 text-xs font-semibold text-gray-600 cursor-pointer transition-all hover:border-gray-300 hover:bg-gray-50">
                    <GlassCheckbox
                      checked={removeBg}
                      onChange={(e) => setRemoveBg(e.target.checked)}
                    />
                    Remove BG
                  </label>
                )}
              </div>
            </>
          )}
        </div>
      </div>

      {/* Always visible footer with Apply/Cancel */}
      <div className="mt-3 flex justify-end gap-2 border-t border-gray-100 pt-3">
        <button
          onClick={handleClose}
          className="rounded-lg border-2 border-gray-200 bg-white px-4 py-2 text-sm font-semibold text-gray-700 transition-all hover:border-gray-300 hover:bg-gray-50 active:scale-95"
        >
          Cancel
        </button>
        <button
          onClick={handleApply}
          disabled={!previewSrc}
          className="rounded-lg border-2 border-[var(--accent)] bg-[var(--accent)] px-5 py-2 text-sm font-semibold text-white transition-all hover:shadow-lg hover:shadow-[var(--accent)]/30 active:scale-95 disabled:cursor-not-allowed disabled:border-gray-300 disabled:bg-gray-200 disabled:text-gray-400 disabled:shadow-none"
        >
          ✓ Apply
        </button>
      </div>
    </Modal>
  );
}

function removeWhiteBackground(img: HTMLImageElement): HTMLImageElement {
  const canvas = document.createElement("canvas");
  canvas.width = img.naturalWidth;
  canvas.height = img.naturalHeight;
  const ctx = canvas.getContext("2d");
  if (!ctx) return img;
  ctx.drawImage(img, 0, 0);

  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const threshold = 220;

  for (let i = 0; i < imageData.data.length; i += 4) {
    const r = imageData.data[i] ?? 0;
    const g = imageData.data[i + 1] ?? 0;
    const b = imageData.data[i + 2] ?? 0;
    if (r > threshold && g > threshold && b > threshold) {
      imageData.data[i + 3] = 0;
    }
  }

  ctx.putImageData(imageData, 0, 0);

  const dataUrl = canvas.toDataURL("image/png");
  const result = new Image();
  result.src = dataUrl;
  return result;
}
