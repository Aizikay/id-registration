/**
 * Synchronization Engine
 *
 * Drains the offline outbox to Supabase when connectivity returns.
 * Guarantees:
 *   - Idempotency: every operation carries an operation_id; replays are safe.
 *   - Ordering: operations are applied in journal order per device.
 *   - Backoff: failures retry with exponential backoff and jitter.
 *   - Conflict safety: server-authoritative rejections (e.g. "already_issued")
 *     are marked as CONFLICT and surfaced to supervisors — never overwritten.
 */

import { db } from "@/db/database";
import {
  markConflict,
  markFailed,
  markInFlight,
  markSynchronized
} from "@/offline/outbox";
import type { OutboxEntry } from "@/offline/outbox";
import { supabase } from "@/services/supabase-client";
import { mapSupabaseError } from "@/services/errors";

export type SyncEngineState = {
  running: boolean;
  online: boolean;
  lastSyncAt: string | null;
  lastError: string | null;
};

type Listener = () => void;

const MAX_BATCH = 10;

class SyncEngineImpl {
  private state: SyncEngineState = {
    running: false,
    online: typeof navigator !== "undefined" ? navigator.onLine : true,
    lastSyncAt: null,
    lastError: null
  };

  private listeners = new Set<Listener>();
  private retryTimer: number | null = null;
  private started = false;

  getState(): SyncEngineState {
    return this.state;
  }

  subscribe(listener: Listener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify(): void {
    for (const l of this.listeners) l();
  }

  private setState(patch: Partial<SyncEngineState>): void {
    this.state = { ...this.state, ...patch };
    this.notify();
  }

  setOnline(online: boolean): void {
    this.setState({ online });
    if (online) {
      void this.sync();
    }
  }

  start(): void {
    if (this.started || typeof window === "undefined") return;
    this.started = true;

    window.addEventListener("online", () => this.setOnline(true));
    window.addEventListener("offline", () => this.setOnline(false));

    // Periodic sweep: retries backoff-scheduled entries.
    const tick = (): void => {
      if (navigator.onLine) void this.sync();
      this.retryTimer = window.setTimeout(tick, 30_000);
    };
    this.retryTimer = window.setTimeout(tick, 5_000);
  }

  stop(): void {
    if (this.retryTimer !== null) {
      window.clearTimeout(this.retryTimer);
      this.retryTimer = null;
    }
    this.started = false;
  }

  /** Drain as many queued operations as possible. Returns processed count. */
  async sync(): Promise<{ processed: number; conflicts: number; failures: number }> {
    if (this.state.running || !navigator.onLine) {
      return { processed: 0, conflicts: 0, failures: 0 };
    }
    this.setState({ running: true });

    let processed = 0;
    let conflicts = 0;
    let failures = 0;

    try {
      // eslint-disable-next-line no-constant-condition
      while (true) {
        const now = Date.now();
        const due = await db.outbox
          .orderBy("id")
          .filter(
            (e) =>
              (e.status === "pending" || e.status === "failed") &&
              e.next_attempt_at <= now
          )
          .limit(MAX_BATCH)
          .toArray();

        if (due.length === 0) break;

        for (const entry of due) {
          const result = await this.processEntry(entry);
          if (result === "ok") processed++;
          else if (result === "conflict") conflicts++;
          else failures++;
        }
      }

      await db.meta.put({
        key: "last_sync_at",
        value: new Date().toISOString()
      });
      this.setState({ lastSyncAt: new Date().toISOString(), lastError: null });

    } catch (err) {
      const message =
        err instanceof Error ? err.message : "Unknown synchronization error";
      this.setState({ lastError: message });
    } finally {
      this.setState({ running: false });
    }

    return { processed, conflicts, failures };
  }

  private async processEntry(
    entry: OutboxEntry
  ): Promise<"ok" | "conflict" | "fail"> {
    await markInFlight(entry.id!);
    try {
      switch (entry.operation_type) {
        case "insert_person": {
          const payload = entry.payload as Record<string, unknown> & {
            local_id?: string;
          };
          // Strip ALL non-DB columns: local_id, id, synced, created_at, updated_at, created_by
          const { local_id: _localId, id: _id, synced: _synced, created_at: _cat, updated_at: _uat, created_by: _cb, ...raw } = payload;
          // Only include columns that exist in the persons table
          const PERSON_COLS = [
            "identification_number","full_name","date_of_birth","gender",
            "nationality","address","phone","position","department","photo_path",
            "signature_path","registration_status"
          ];
          const row: Record<string, unknown> = {};
          for (const col of PERSON_COLS) {
            if (col in raw) row[col] = raw[col];
          }
          const { error, data } = await (supabase
            .from("persons") as unknown as {
            upsert: (
              v: Record<string, unknown>,
              o: { onConflict: string }
            ) => { select: (c: string) => { single: () => Promise<{ error: unknown; data: { id: string } | null }> } };
          }).upsert(row, { onConflict: "identification_number" })
            .select("id")
            .single();
          if (error) throw error;
          // Re-key local rows to the server-assigned uuid.
          if (data?.id && entry.entity_id !== data.id) {
            await this.rekeyPerson(entry.entity_id, data.id);
          }
          break;
        }
        case "update_person": {
          // Strip non-DB columns from the update payload
          const rawPayload = entry.payload as Record<string, unknown>;
          const PERSON_COLS = [
            "identification_number","full_name","date_of_birth","gender",
            "nationality","address","phone","position","department","photo_path",
            "signature_path","registration_status"
          ];
          const clean: Record<string, unknown> = {};
          for (const col of PERSON_COLS) {
            if (col in rawPayload) clean[col] = rawPayload[col];
          }
          if (Object.keys(clean).length === 0) break; // nothing to update
          const { error } = await (supabase.from("persons") as unknown as {
            update: (v: Record<string, unknown>) => { eq: (c: string, v: string) => Promise<{ error: unknown }> };
          })
            .update(clean)
            .eq("id", entry.entity_id);
          if (error) throw error;
          break;
        }
        case "insert_issuance": {
          const p = entry.payload as {
            person_id: string;
            identification_record_id: string | null;
            issuance_reference: string;
            idempotency_key: string;
            printer_id: string | null;
            workstation_device_id: string | null;
            print_job_reference: string | null;
          };
          const { error, data } = await supabase.rpc("issue_id", {
            p_person_id: p.person_id,
            p_identification_record_id: p.identification_record_id,
            p_issuance_reference: p.issuance_reference,
            p_idempotency_key: p.idempotency_key,
            p_printer_id: p.printer_id,
            p_workstation_device_id: p.workstation_device_id,
            p_print_job_reference: p.print_job_reference
          });
          if (error) throw error;
          // Server may have assigned its own uuid — adopt it locally.
          const rec = (data as { record?: Record<string, unknown> })?.record;
          if (
            rec &&
            typeof rec.id === "string" &&
            typeof rec.created_at === "string" &&
            entry.entity_id !== rec.id
          ) {
            await this.rekeyIssuance(entry.entity_id, rec.id, rec.created_at);
          }
          break;
        }
        case "update_issuance_status": {
          const p = entry.payload as {
            issuance_id: string;
            new_status: string;
            failure_reason: string | null;
            print_job_id: string | null;
            printer_id: string | null;
          };
          const { error } = await supabase.rpc("update_issuance_status", {
            p_issuance_id: p.issuance_id,
            p_new_status: p.new_status,
            p_failure_reason: p.failure_reason,
            p_print_job_id: p.print_job_id,
            p_printer_id: p.printer_id
          });
          if (error) throw error;
          break;
        }

      }

      // Mark local entity as synced.
      if (entry.entity_type === "person") {
        await db.persons.update(entry.entity_id, { synced: true });
      } else if (entry.entity_type === "issuance") {
        await db.issuances.update(entry.entity_id, { synced: true });
      }
      await markSynchronized(entry.id!);
      return "ok";
    } catch (rawError) {
      const appError = mapSupabaseError(rawError);
      // Server-authoritative rejections are permanent conflicts:
      switch (appError.code) {
        case "already_issued":
        case "duplicate_identification":
        case "conflict_detected":
        case "invalid_transition":
        case "not_found":
          await markConflict(entry.id!, appError.detail ?? appError.code);
          if (entry.entity_type === "person") {
            await db.persons.update(entry.entity_id, { synced: false }).catch(() => undefined);
          }

          return "conflict";
        default:
          await markFailed(entry.id!, appError.detail ?? appError.userMessage);
          return "fail";
      }
    }
  }

  private async rekeyPerson(localId: string, serverId: string): Promise<void> {
    await db.transaction("rw", db.persons, db.outbox, async () => {
      const local = await db.persons.get(localId);
      if (!local) return;
      await db.persons.delete(localId);
      await db.persons.put({ ...local, id: serverId, synced: true });
      // Point future references at the server id.
      const refs = await db.outbox
        .where("entity_id")
        .equals(localId)
        .filter((e) => e.status === "pending" || e.status === "failed")
        .toArray();
      for (const ref of refs) {
        const payload = { ...ref.payload };
        if (payload.person_id === localId) payload.person_id = serverId;
        if (payload.local_id === localId) payload.local_id = serverId;
        if (ref.entity_type === "issuance" && payload.person_id === serverId) {
          payload.person_id = serverId;
        }
        await db.outbox.update(ref.id!, {
          entity_id: ref.entity_type === "person" ? serverId : ref.entity_id,
          payload
        });
      }
    });
  }

  private async rekeyIssuance(
    localId: string,
    serverId: string,
    createdAt: string
  ): Promise<void> {
    await db.transaction("rw", db.issuances, async () => {
      const local = await db.issuances.get(localId);
      if (!local) return;
      await db.issuances.delete(localId);
      await db.issuances.put({
        ...local,
        id: serverId,
        synced: true,
        created_at: createdAt
      });
    });
  }


}

export const SyncEngine = new SyncEngineImpl();
