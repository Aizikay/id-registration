$ErrorActionPreference = "Stop"
Set-Location "C:\Users\hp\Pictures\ID Registration & Issuance Management System.(MERU DC) - Copy"
node ./node_modules/vitest/vitest.mjs run src/lib/validation.test.ts
