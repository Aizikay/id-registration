import "./GlassCheckbox.css";

interface GlassCheckboxProps {
  checked?: boolean;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  disabled?: boolean;
  className?: string;
}

export function GlassCheckbox({
  checked,
  onChange,
  disabled,
  className,
}: GlassCheckboxProps) {
  return (
    <div className={`glass-cb ${className ?? ""}`}>
      <label className="glass-cb__container">
        <input
          type="checkbox"
          checked={checked}
          onChange={onChange}
          disabled={disabled}
        />
        <div className="glass-cb__check" />
      </label>
    </div>
  );
}
