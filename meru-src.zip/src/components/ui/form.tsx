import {
  forwardRef,
  useId,
  useState,
  type InputHTMLAttributes,
  type SelectHTMLAttributes,
  type TextareaHTMLAttributes,
} from "react";
import { cn } from "@/lib/cn";
import { Icon } from "@/components/icons/icon";

export interface FieldWrapperProps {
  label?: string;
  hint?: string;
  error?: string;
  required?: boolean;
  children: (id: string) => React.ReactNode;
}

export function Field({
  label,
  hint,
  error,
  required,
  children,
}: FieldWrapperProps) {
  const id = useId();
  const errorId = `${id}-error`;
  const hintId = `${id}-hint`;
  return (
    <div className="w-full">
      {label && (
        <label
          htmlFor={id}
          className="mb-1.5 block text-[13px] font-medium text-surface-600"
        >
          {label}
          {required && (
            <span className="ml-0.5 text-danger-500" aria-hidden="true">
              *
            </span>
          )}
        </label>
      )}
      {children(id)}
      {hint && !error && (
        <p id={hintId} className="mt-1.5 text-xs text-surface-400">
          {hint}
        </p>
      )}
      {error && (
        <p
          id={errorId}
          role="alert"
          className="mt-1.5 flex items-center gap-1.5 text-xs font-medium text-danger-600"
        >
          <Icon name="alert-circle" className="h-3.5 w-3.5 shrink-0" />
          {error}
        </p>
      )}
    </div>
  );
}

export interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  hint?: string;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  function Input({ label, error, hint, className, required, ...props }, ref) {
    return (
      <Field label={label} hint={hint} error={error} required={required}>
        {(id) => (
          <input
            ref={ref}
            id={id}
            aria-invalid={error ? true : undefined}
            aria-describedby={
              error ? `${id}-error` : hint ? `${id}-hint` : undefined
            }
            className={cn(
              "input-base",
              error &&
                "border-danger-300 focus:border-danger-500 focus:ring-danger-500/20",
              className
            )}
            {...props}
          />
        )}
      </Field>
    );
  }
);

export interface PasswordInputProps extends Omit<InputProps, "type"> {}

export function PasswordInput(props: PasswordInputProps) {
  const [visible, setVisible] = useState(false);
  return (
    <Field
      label={props.label}
      hint={props.hint}
      error={props.error}
      required={props.required}
    >
      {(id) => (
        <div className="relative group">
          <input
            {...props}
            id={id}
            type={visible ? "text" : "password"}
            aria-invalid={props.error ? true : undefined}
            autoComplete={props.autoComplete ?? "current-password"}
            className={cn(
              "input-base pr-11",
              props.className,
              props.error &&
                "border-danger-300 focus:border-danger-500 focus:ring-danger-500/20"
            )}
          />
          <button
            type="button"
            onClick={() => setVisible((v) => !v)}
            aria-label={visible ? "Hide password" : "Show password"}
            className={cn(
              "absolute inset-y-0 right-0 flex w-11 items-center justify-center rounded-r-xl",
              "text-surface-400 transition-all duration-200",
              "hover:bg-surface-50 hover:text-surface-600",
              "active:scale-95"
            )}
          >
            <Icon name={visible ? "eye-off" : "eye"} className="h-4 w-4" />
          </button>
        </div>
      )}
    </Field>
  );
}

export interface SelectProps
  extends SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  error?: string;
  hint?: string;
  options: readonly { value: string; label: string }[];
  placeholder?: string;
}

export const Select = forwardRef<HTMLSelectElement, SelectProps>(
  function Select(
    {
      label,
      error,
      hint,
      options,
      placeholder,
      className,
      required,
      ...props
    },
    ref
  ) {
    return (
      <Field label={label} hint={hint} error={error} required={required}>
        {(id) => (
          <div className="relative">
            <select
              ref={ref}
              id={id}
              aria-invalid={error ? true : undefined}
              className={cn(
                "input-base appearance-none pr-10",
                error &&
                  "border-danger-300 focus:border-danger-500 focus:ring-danger-500/20",
                className
              )}
              {...props}
            >
              {placeholder && (
                <option value="" disabled>
                  {placeholder}
                </option>
              )}
              {options.map((o) => (
                <option key={o.value} value={o.value}>
                  {o.label}
                </option>
              ))}
            </select>
            <Icon
              name="chevron-down"
              className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-surface-400 transition-transform duration-200"
            />
          </div>
        )}
      </Field>
    );
  }
);

export interface TextareaProps
  extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  error?: string;
  hint?: string;
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(
  function Textarea(
    { label, error, hint, className, required, rows = 3, ...props },
    ref
  ) {
    return (
      <Field label={label} hint={hint} error={error} required={required}>
        {(id) => (
          <textarea
            ref={ref}
            id={id}
            rows={rows}
            aria-invalid={error ? true : undefined}
            className={cn(
              "input-base resize-y",
              error &&
                "border-danger-300 focus:border-danger-500 focus:ring-danger-500/20",
              className
            )}
            {...props}
          />
        )}
      </Field>
    );
  }
);
