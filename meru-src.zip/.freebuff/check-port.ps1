$conn = Get-NetTCPConnection -LocalPort 5174 -ErrorAction SilentlyContinue
if ($conn) {
  Write-Output "PORT 5174 LISTENING (PID $($conn.OwningProcess))"
} else {
  Write-Output "PORT 5174 NOT LISTENING"
}

$proc = Get-Process -Name node -ErrorAction SilentlyContinue
Write-Output "Node processes: $($proc.Count)"
$proc | Format-Table Id, ProcessName, StartTime -AutoSize
