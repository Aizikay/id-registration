import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";

interface ThemeContextType {
  isDark: boolean;
  toggleTheme: () => void;
}

const ThemeContext = createContext<ThemeContextType>({
  isDark: true,
  toggleTheme: () => {},
});

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [isDark, setIsDark] = useState(() => {
    return document.documentElement.classList.contains("dark");
  });

  const toggleTheme = useCallback(() => {
    setIsDark((prev) => {
      const next = !prev;
      const root = document.documentElement;
      root.classList.remove("light", "dark");
      root.classList.add(next ? "dark" : "light");
      document.body.classList.remove("light", "dark");
      document.body.classList.add(next ? "dark" : "light");
      localStorage.setItem("app-theme", next ? "dark" : "light");
      return next;
    });
  }, []);

  useEffect(() => {
    const saved = localStorage.getItem("app-theme");
    const initial = saved ? saved === "dark" : true;
    const root = document.documentElement;
    root.classList.remove("light", "dark");
    root.classList.add(initial ? "dark" : "light");
    document.body.classList.remove("light", "dark");
    document.body.classList.add(initial ? "dark" : "light");
    setIsDark(initial);
  }, []);

  return (
    <ThemeContext.Provider value={{ isDark, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  return useContext(ThemeContext);
}
