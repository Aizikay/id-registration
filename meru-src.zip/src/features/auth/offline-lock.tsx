/**
 * Shown when a device attempts a restricted action while offline without a
 * valid offline grant. Forces reconnection & re-authentication.
 */
export function OfflineLock() {
  return (
    <div className="flex h-full flex-col items-center justify-center gap-4 p-10 text-center">
      <div className="rounded-full bg-amber-50 p-4">
        <svg className="h-8 w-8 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5} aria-hidden="true">
          <path strokeLinecap="round" strokeLinejoin="round" d="M8.288 15.038a5.25 5.25 0 017.424 0M5.106 11.856c3.807-3.808 9.98-3.808 13.788 0M1.924 8.674c5.565-5.565 14.587-5.565 20.152 0M12.53 18.22l-.53.53-.53-.53a.75.75 0 011.06 0z" />
        </svg>
      </div>
      <h2 className="text-lg font-semibold text-slate-800">
        Offline Access Restricted
      </h2>
      <p className="max-w-md text-sm text-slate-500">
        This action requires re-authentication. Reconnect to the internet and
        sign in again to continue.
      </p>
    </div>
  );
}
