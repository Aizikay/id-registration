import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { sendPasswordReset } from "@/services/users-service";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/form";
import { AppFooter } from "@/components/branding/footer";
import { OrganizationHeader } from "@/components/branding/logo";
import { useToast } from "@/components/ui/toast";
import { mapSupabaseError } from "@/services/errors";

export function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const toast = useToast();
  const navigate = useNavigate();

  const submit = async (e: React.FormEvent): Promise<void> => {
    e.preventDefault();
    setSending(true);
    try {
      await sendPasswordReset(email.trim());
      setSent(true);
    } catch (err) {
      toast.error("Could not send reset email", mapSupabaseError(err).userMessage);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="flex min-h-screen flex-col bg-slate-100">
      <div className="flex h-1.5" aria-hidden="true">
        <div className="h-full w-1/3 bg-[#1eb53a]" />
        <div className="h-full flex-1 bg-[#fcd116]" />
        <div className="h-full w-1/3 bg-[#00a3dd]" />
      </div>
      <div className="flex flex-1 items-center justify-center px-4 py-10">
        <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-8 shadow-card">
          <div className="mb-6 flex justify-center">
            <OrganizationHeader compact />
          </div>
          {sent ? (
            <div className="space-y-5 text-center">
              <h1 className="text-lg font-bold text-slate-900">Check your email</h1>
              <p className="text-sm text-slate-500">
                If an account exists for <strong>{email}</strong>, a password
                reset link has been sent. The link expires shortly for
                security.
              </p>
              <Button variant="outline" onClick={() => navigate("/login")} className="w-full">
                Back to sign in
              </Button>
            </div>
          ) : (
            <>
              <h1 className="mb-1 text-center text-lg font-bold text-slate-900">
                Reset your password
              </h1>
              <p className="mb-6 text-center text-xs text-slate-500">
                Enter the email linked to your staff account.
              </p>
              <form onSubmit={submit} className="space-y-4">
                <Input
                  label="Email address"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  autoComplete="username"
                />
                <Button type="submit" size="lg" loading={sending} disabled={!email.trim()} className="w-full">
                  Send reset link
                </Button>
              </form>
              <p className="mt-4 text-center text-xs text-slate-500">
                <Link to="/login" className="font-medium text-council-700 hover:underline">
                  Back to sign in
                </Link>
              </p>
            </>
          )}
        </div>
      </div>
      <AppFooter />
    </div>
  );
}
