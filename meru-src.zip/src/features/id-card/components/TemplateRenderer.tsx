/**
 * TemplateRenderer — Multi-format template rendering engine.
 */

import { useEffect, useRef, useState, useCallback } from "react";
import type { CustomTemplate, CustomFieldConfig } from "../template-manager";

interface Props {
  template: CustomTemplate;
  data: Record<string, string>;
  scale?: number;
  showGuides?: boolean;
  selectedField?: string | null;
  onFieldClick?: (fieldId: string) => void;
  printMode?: boolean;
}

export function TemplateRenderer({
  template,
  data,
  scale = 1.2,
  showGuides: _showGuides = false,
  selectedField,
  onFieldClick,
  printMode = false,
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [renderError, setRenderError] = useState<string | null>(null);

  const fieldValue = (field: CustomFieldConfig): string => {
    if (field.dataKey && data[field.dataKey]) {
      let val = data[field.dataKey] ?? "";
      if (field.style.textTransform === "uppercase") val = val.toUpperCase();
      return val;
    }
    return field.staticText ?? "";
  };

  const renderPlaceholder = useCallback(() => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const w = template.width * scale;
    const h = template.height * scale;
    canvas.width = w;
    canvas.height = h;

    ctx.fillStyle = "#f8f9fa";
    ctx.fillRect(0, 0, w, h);

    ctx.strokeStyle = "#dee2e6";
    ctx.lineWidth = 2;
    ctx.setLineDash([8, 4]);
    ctx.strokeRect(4, 4, w - 8, h - 8);

    ctx.setLineDash([]);
    ctx.fillStyle = "#6c757d";
    ctx.font = `${14 * scale}px sans-serif`;
    ctx.textAlign = "center";
    ctx.fillText(template.fileName, w / 2, h / 2 - 10);
    ctx.font = `${10 * scale}px sans-serif`;
    ctx.fillStyle = "#adb5bd";
    ctx.fillText(`${template.width} × ${template.height} px`, w / 2, h / 2 + 10);
  }, [template.width, template.height, template.fileName, scale]);

  const renderPdf = useCallback(async () => {
    if (!canvasRef.current) return;
    try {
      const { default: pdfjsLib } = await import("pdfjs-dist");
      const pdfWorkerSrc = (await import("pdfjs-dist/build/pdf.worker.mjs?url")).default;
      if (!pdfjsLib.GlobalWorkerOptions.workerSrc) {
        pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorkerSrc;
      }

      const loadingTask = pdfjsLib.getDocument(template.fileDataUrl);
      const pdf = await loadingTask.promise;
      const page = await pdf.getPage(1);
      const viewport = page.getViewport({ scale: scale * 1.5 });
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      canvas.width = viewport.width;
      canvas.height = viewport.height;
      await page.render({ canvasContext: ctx, viewport }).promise;
      setRenderError(null);
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      setRenderError(msg.slice(0, 300));
      renderPlaceholder();
    }
  }, [template.fileDataUrl, scale, renderPlaceholder]);

  const renderImage = useCallback(async () => {
    if (!canvasRef.current) return;
    try {
      const img = new Image();
      await new Promise<void>((resolve, reject) => {
        img.onload = () => resolve();
        img.onerror = () => reject(new Error("Failed to load image"));
        img.src = template.fileDataUrl;
      });

      const canvas = canvasRef.current;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      const renderWidth = img.naturalWidth * scale;
      const renderHeight = img.naturalHeight * scale;
      canvas.width = renderWidth;
      canvas.height = renderHeight;
      ctx.drawImage(img, 0, 0, renderWidth, renderHeight);
      setRenderError(null);
    } catch (e) {
      setRenderError(e instanceof Error ? e.message : "Failed to render image");
renderPlaceholder();
    }
  }, [template.fileDataUrl, scale, renderPlaceholder]);

  useEffect(() => {
    if (template.sourceType === "image") {
      void renderImage();
    } else {
      void renderPdf();
    }
  }, [template, scale, renderImage, renderPdf]);

  const displayWidth = template.width * scale;
  const displayHeight = template.height * scale;

  const overlayBaseStyle: React.CSSProperties = {
    position: "absolute",
    top: 0,
    left: 0,
    width: template.width,
    height: template.height,
    transform: `scale(${scale})`,
    transformOrigin: "top left",
    pointerEvents: onFieldClick ? "auto" : "none",
  };

  return (
    <div
      style={{
        width: displayWidth,
        height: displayHeight,
        position: "relative",
        overflow: "hidden",
        flexShrink: 0,
        borderRadius: printMode ? 0 : 8,
        boxShadow: printMode ? "none" : "0 4px 20px rgba(0,0,0,0.1)",
      }}
    >
      <canvas
        ref={canvasRef}
        style={{
          display: "block",
          width: displayWidth,
          height: displayHeight,
        }}
      />

      {renderError && (
        <div className="absolute inset-0 flex items-center justify-center bg-amber-50/90 p-4">
          <div className="text-center">
            <p className="text-sm font-medium text-amber-800">Template render issue</p>
            <p className="mt-1 max-w-xs text-xs text-amber-600">{renderError}</p>
          </div>
        </div>
      )}

      <div style={overlayBaseStyle} className="id-card-overlays">
        {/* Masks */}
        {!printMode &&
          template.masks.map((m) => (
            <div
              key={m.id}
              style={{
                position: "absolute",
                left: `${m.position.xPct}%`,
                top: `${m.position.yPct}%`,
                width: `${m.position.wPct}%`,
                height: `${m.position.hPct}%`,
                background: m.color,
                opacity: 0.95,
                borderRadius: 2,
              }}
            />
          ))}

        {/* Photo area */}
        {template.photo.enabled && (
          <div
            style={{
              position: "absolute",
              left: `${template.photo.position.xPct}%`,
              top: `${template.photo.position.yPct}%`,
              width: `${template.photo.position.wPct}%`,
              height: `${template.photo.position.hPct}%`,
              borderRadius: template.photo.borderRadius,
              border: `1px solid ${template.photo.borderColor}`,
              background: template.photo.background,
              overflow: "hidden",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <span style={{ fontSize: 10 * scale, color: "#999" }}>Photo</span>
          </div>
        )}

        {/* Signature areas */}
        {template.signatures
          .filter((s) => s.enabled)
          .map((sig) => (
            <div
              key={sig.label}
              style={{
                position: "absolute",
                left: `${sig.position.xPct}%`,
                top: `${sig.position.yPct}%`,
                width: `${sig.position.wPct}%`,
                height: `${sig.position.hPct}%`,
                borderBottom: `1px solid ${sig.borderColor}`,
                display: "flex",
                alignItems: "flex-end",
                justifyContent: "center",
                paddingBottom: 2,
              }}
            >
              <span style={{ fontSize: 8 * scale, color: "#999" }}>
                {sig.label}
              </span>
            </div>
          ))}

        {/* Editable text fields */}
        {template.fields
          .filter((f) => f.visible)
          .map((field) => {
            const isSelected = selectedField === field.id;
            const value = fieldValue(field);
            return (
              <div
                key={field.id}
                onClick={() => onFieldClick?.(field.id)}
                style={{
                  position: "absolute",
                  left: `${field.position.xPct}%`,
                  top: `${field.position.yPct}%`,
                  width: `${field.position.wPct}%`,
                  height: `${field.position.hPct}%`,
                  cursor: onFieldClick ? "pointer" : "default",
                  outline: isSelected && !printMode ? "2px solid #0c4b36" : "none",
                  background: isSelected && !printMode ? "rgba(12,75,54,0.08)" : "transparent",
                  display: "flex",
                  alignItems: "center",
                  padding: "0 2px",
                }}
              >
                <span
                  style={{
                    fontSize: field.style.fontSizePt,
                    fontWeight: field.style.fontWeight,
                    fontFamily: field.style.fontFamily,
                    letterSpacing: `${field.style.letterSpacingEm}em`,
                    lineHeight: field.style.lineHeight,
                    color: field.style.color,
                    textAlign: field.style.textAlign,
                    textTransform: field.style.textTransform,
                    whiteSpace: "nowrap",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    width: "100%",
                  }}
                >
                  {value}
                </span>
              </div>
            );
          })}
      </div>

      {!printMode && (
        <div className="absolute bottom-2 right-2 rounded-full bg-white/90 px-2 py-0.5 text-[10px] font-medium text-surface-500 shadow-sm backdrop-blur-sm">
          {Math.round(scale * 100)}%
        </div>
      )}
    </div>
  );
}
