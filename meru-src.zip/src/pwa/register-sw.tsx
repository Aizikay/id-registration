import { createElement } from "react";
import { createRoot } from "react-dom/client";

/**
 * PWA update flow: when a new service worker is available, show a
 * professional in-app prompt instead of silently reloading.
 */
export function registerServiceWorker(): void {
  if (!("serviceWorker" in navigator)) return;
  if (import.meta.env.DEV) return;
  if (location.protocol !== "https:" && !["localhost", "127.0.0.1"].includes(location.hostname)) return;

  window.addEventListener("load", () => {
    void navigator.serviceWorker
      .register("/sw.js", { scope: "/" })
      .then((registration) => {
        registration.addEventListener("updatefound", () => {
          const installing = registration.installing;
          if (!installing) return;
          installing.addEventListener("statechange", () => {
            if (installing.state === "installed" && navigator.serviceWorker.controller) {
              showUpdatePrompt(() => {
                installing.postMessage({ type: "SKIP_WAITING" });
              });
            }
          });
        });
      })
      .catch(() => {
        // SW is an enhancement; app still works without it.
      });

    let refreshing = false;
    void navigator.serviceWorker.addEventListener("controllerchange", () => {
      if (refreshing) return;
      refreshing = true;
      window.location.reload();
    });
  });
}

function showUpdatePrompt(onApply: () => void): void {
  if (document.getElementById("sw-update-prompt")) return;
  const host = document.createElement("div");
  host.id = "sw-update-prompt";
  // Append outside React's root to avoid insertBefore conflicts with StrictMode / extensions
  if (document.body) document.body.appendChild(host);
  else return;
  const root = createRoot(host);
  import("react").then((React) => {
    root.render(
      createElement(
        "div",
        {
          role: "alert",
          style: {
            position: "fixed",
            bottom: "16px",
            left: "50%",
            transform: "translateX(-50%)",
            zIndex: 70,
            display: "flex",
            alignItems: "center",
            gap: "12px",
            background: "#0f3d2e",
            color: "white",
            padding: "12px 18px",
            borderRadius: "12px",
            boxShadow: "0 10px 30px rgba(0,0,0,.25)",
            fontSize: "13px",
            maxWidth: "92vw"
          }
        },
        React.createElement("span", null, "A new version of the system is ready."),
        React.createElement(
          "button",
          {
            onClick: () => {
              onApply();
              root.unmount();
              host.remove();
            },
            style: {
              background: "#d98e24",
              border: "none",
              color: "#08241c",
              fontWeight: 700,
              fontSize: "12px",
              padding: "7px 14px",
              borderRadius: "8px",
              cursor: "pointer",
              whiteSpace: "nowrap"
            }
          },
          "Update now"
        )
      )
    );
  });
}
