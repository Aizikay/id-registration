@echo off
cd /d "C:\Users\hp\Pictures\ID Registration & Issuance Management System.(MERU DC) - Copy"
start /B "node.exe" "C:\node.exe" "node_modules\vite\bin\vite.js" --host 0.0.0.0 --port 5174 > ".freebuff\preview-185ab75d-b7ac-4e90-8d29-bbede45499ca.log" 2> ".freebuff\preview-185ab75d-b7ac-4e90-8d29-bbede45499ca.log.err"
echo %errorlevel% > ".freebuff\preview-start.result"
