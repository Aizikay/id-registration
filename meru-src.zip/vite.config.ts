import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { VitePWA } from "vite-plugin-pwa";
import path from "node:path";

export default defineConfig({
  // Desktop (Electron) builds load the renderer from file://, which requires
  // relative asset URLs. The web build keeps the default absolute base.
  base: process.env.VITE_BASE || "/",
  plugins: [
    react(),
    VitePWA({
      registerType: "prompt",
      injectRegister: "auto",
      includeAssets: ["branding/README.md"],
      manifest: {
        name: "Meru District Council — ID Registration & Issuance System",
        short_name: "Meru ID",
        description:
          "Identification Registration & Issuance Management System for Halmashauri ya Wilaya ya Meru (Meru District Council)",
        lang: "sw-TZ",
        dir: "ltr",
        start_url: "/",
        scope: "/",
        display: "standalone",
        orientation: "any",
        background_color: "#f8fafc",
        theme_color: "#0f3d2e",
        categories: ["government", "productivity", "business"],
        icons: [
          {
            src: "/branding/app-icon-192.png",
            sizes: "192x192",
            type: "image/png",
            purpose: "any"
          },
          {
            src: "/branding/app-icon-512.png",
            sizes: "512x512",
            type: "image/png",
            purpose: "any"
          },
          {
            src: "/branding/app-icon-maskable-512.png",
            sizes: "512x512",
            type: "image/png",
            purpose: "maskable"
          }
        ]
      },
      workbox: {
        // Cache app shell assets only. Never cache Supabase API responses or
        // personal data — sensitive data lives under controlled storage.
        globPatterns: ["**/*.{js,css,html,svg,png,ico,woff,woff2}"],
        navigateFallback: "/index.html",
        navigateFallbackDenylist: [/^\/api\//],
        runtimeCaching: [],
        cleanupOutdatedCaches: true,
        clientsClaim: false,
        skipWaiting: false,
        maximumFileSizeToCacheInBytes: 4 * 1024 * 1024
      },
      devOptions: {
        enabled: false
      }
    })
  ],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src")
    }
  },
  build: {
    sourcemap: false,
    target: "es2022",
    chunkSizeWarningLimit: 800,
    rollupOptions: {
      output: {
        manualChunks: {
          react: ["react", "react-dom", "react-router-dom"],
          supabase: ["@supabase/supabase-js"],
          offline: ["dexie", "dexie-react-hooks"],
          pdf: ["pdf-lib", "pdfjs-dist"]
        }
      }
    }
  },
  server: {
    port: 5173,
    strictPort: true,
    host: "0.0.0.0",
    fs: { strict: false }
  },
  test: {
    globals: true,
    environment: "jsdom",
    setupFiles: "./src/test/setup.ts",
    include: ["src/**/*.{test,spec}.{ts,tsx}"],
    css: true
  }
});
