#!/usr/bin/env node
/**
 * Bundles electron/main.ts + electron/preload.ts into dist-electron/*.cjs
 * using esbuild (no emit from tsc — the main process must be CommonJS with
 * electron/electron-updater kept external so they resolve at runtime).
 */
import { build } from "esbuild";
import { mkdirSync, writeFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const root = dirname(fileURLToPath(import.meta.url)) + "/..";
const outDir = join(root, "dist-electron");
mkdirSync(outDir, { recursive: true });

const common = {
  bundle: true,
  platform: "node",
  format: "cjs",
  target: "node20",
  sourcemap: false,
  minify: false,
  external: ["electron", "electron-updater"],
  logLevel: "info",
};

await build({
  ...common,
  entryPoints: [join(root, "electron/main.ts")],
  outfile: join(outDir, "main.cjs"),
});

await build({
  ...common,
  entryPoints: [join(root, "electron/preload.ts")],
  outfile: join(outDir, "preload.cjs"),
});

// Stamp the app version so preload can report it without importing app metadata.
try {
  const pkg = JSON.parse(await import("node:fs/promises").then((m) => m.readFile(join(root, "package.json"), "utf8")));
  writeFileSync(
    join(outDir, "version.json"),
    JSON.stringify({ version: pkg.version ?? "1.0.0" }),
    "utf8"
  );
} catch {
  // non-fatal
}

console.log("dist-electron ready.");
