/**
 * Domain types shared across the application.
 * These mirror the PostgreSQL schema defined in supabase/migrations.
 */

/* ─── Electron desktop bridge (window.meru) ─────────────────── */

/** A printer discovered by the desktop main process (native enumeration). */
export interface NativePrinter {
  id: string;
  name: string;
  is_default: boolean;
  status: "online" | "offline" | "unknown" | "error";
  connection_type: "usb" | "network" | "wireless" | "unknown";
  driver_name?: string | null;
  port_name?: string | null;
  location?: string | null;
  last_detected_at: string;
}

/** Options for a native desktop print job. */
export interface NativePrintJob {
  /** Unique idempotency reference for the job. */
  job_ref: string;
  printer_name: string;
  /** Document image(s): data URI or file:// URL. Front only, or front+back. */
  front_image_src: string;
  back_image_src?: string;
  copies?: number;
  paper_size?: string;
  orientation?: "portrait" | "landscape";
  margins?: string;
  /** True → print front and back on the two sides of the same sheet. */
  duplex?: boolean;
  color?: boolean;
}

export interface NativePrintResult {
  ok: boolean;
  job_id: string;
  status: "completed" | "failed";
  error_message?: string;
  pages_printed?: number;
}

/** Shape exposed on `window.meru` by electron/preload.ts (undefined in web). */
export interface MeruDesktopBridge {
  isDesktop: true;
  platform: NodeJS.Platform;
  appVersion: string;
  listPrinters(): Promise<NativePrinter[]>;
  print(job: NativePrintJob): Promise<NativePrintResult>;
  printPdf(payload: {
    job_ref: string;
    printer_name: string;
    pdf_base64: string;
    copies?: number;
    duplex?: boolean;
  }): Promise<NativePrintResult>;
  renderPdfFromHtml(payload: {
    html: string;
    paper_width_in?: number;
    paper_height_in?: number;
    landscape?: boolean;
    margins_in?: number;
  }): Promise<{ pdf_base64: string; pages: number }>;
  openDataFolder(): Promise<void>;
  backupNow(): Promise<{ ok: boolean; path?: string; error?: string }>;
  restoreBackup(): Promise<{ ok: boolean; path?: string; error?: string }>;
  getDataFolderPath(): Promise<string>;
  getAppPaths(): Promise<{ userData: string; temp: string; exe: string }>;
  getAppVersion(): Promise<string>;
  checkForUpdates(): Promise<{ ok: boolean; message: string }>;
}

export type UserRole = "admin" | "officer" | "supervisor" | "viewer";

export type UserStatus = "active" | "disabled";

export type Profile = {
  id: string;
  user_id: string;
  staff_number: string;
  full_name: string;
  phone: string | null;
  role: UserRole;
  department: string | null;
  status: UserStatus;
  created_at: string;
  updated_at: string;
}

export type RegistrationStatus = "registered" | "under_review";

export type Gender = "male" | "female";

export type Person = {
  id: string;
  identification_number: string;
  full_name: string;
  date_of_birth: string; // ISO date (yyyy-mm-dd)
  gender: Gender;
  nationality: string;
  address: string;
  phone: string | null;
  position: string | null;
  department: string | null;
  photo_path: string | null;
  signature_path: string | null;
  registration_status: RegistrationStatus;
  created_at: string;
  updated_at: string;
  created_by: string | null;
}

export type IdentificationRecordStatus =
  | "active"
  | "suspended"
  | "revoked"
  | "replaced";

export type IdentificationRecord = {
  id: string;
  person_id: string;
  identification_number: string;
  status: IdentificationRecordStatus;
  created_at: string;
  updated_at: string;
}

export type IssuanceStatus =
  | "pending"
  | "printing"
  | "issued"
  | "failed"
  | "cancelled"
  | "reprint_requested";

export type IssuanceRecord = {
  id: string;
  person_id: string;
  identification_record_id: string | null;
  issuance_reference: string;
  issued_by: string | null;
  issued_by_staff_number: string | null;
  issued_at: string | null;
  printer_id: string | null;
  workstation_id: string | null;
  print_job_id: string | null;
  status: IssuanceStatus;
  /** Client-generated idempotency key — unique across the system. */
  idempotency_key: string;
  failure_reason: string | null;
  created_at: string;
  updated_at: string;
}

export type PrinterStatus = "online" | "offline" | "unknown" | "error";
export type PrinterEnabled = true | false;

export type Printer = {
  id: string;
  printer_name: string;
  printer_identifier: string;
  location: string | null;
  status: PrinterStatus;
  workstation_id: string | null;
  last_seen_at: string | null;
  enabled: boolean;
  current_job_id: string | null;
  created_at: string;
  updated_at: string;
}

export type SyncOperationType =
  | "insert_person"
  | "update_person"
  | "insert_issuance"
  | "update_issuance_status";

export type SyncOperationStatus =
  | "pending"
  | "in_flight"
  | "synchronized"
  | "failed"
  | "conflict";

export type SyncEntity = "person" | "issuance" | "printer_status";

export type SyncOperation<TPayload = Record<string, unknown>> = {
  /** Server-side record id (uuid) once uploaded; client uuid before that. */
  id: string;
  device_id: string;
  operation_id: string; // client-generated unique id — idempotency
  entity_type: SyncEntity;
  entity_id: string;
  operation_type: SyncOperationType;
  payload: TPayload;
  status: SyncOperationStatus;
  retry_count: number;
  last_attempted_at: string | null;
  error_message: string | null;
  created_at: string;
  processed_at: string | null;
};

export type DeviceStatus = "active" | "revoked";

export type WorkstationDevice = {
  id: string;
  device_id: string; // stable client-generated identifier
  device_name: string;
  location: string | null;
  assigned_to: string | null; // profile.id of primary user
  status: DeviceStatus;
  last_sync_at: string | null;
  last_online_at: string | null;
  registered_by: string | null;
  created_at: string;
  updated_at: string;
}

export type PrintJobStatus =
  | "queued"
  | "sent_to_agent"
  | "printing"
  | "completed"
  | "failed"
  | "cancelled";

export type PrintJob = {
  id: string;
  issuance_id: string;
  printer_id: string | null;
  agent_device_id: string | null;
  document_reference: string;
  idempotency_key: string;
  status: PrintJobStatus;
  requested_by: string | null;
  error_message: string | null;
  pages_printed: number | null;
  created_at: string;
  completed_at: string | null;
}

export type SystemSetting = {
  key: string;
  value: Record<string, unknown>;
  description: string | null;
  updated_by: string | null;
  updated_at: string;
}

/* ── Departments ──────────────────────────────────────────────────────────── */

/**
 * A council department. Registered IDs are filed under a department via
 * `persons.department` (free text id, resolved against this table for labels).
 */
export type DepartmentRow = {
  id: string;
  name_sw: string;
  name_en: string;
  description: string | null;
  color: string | null;
  sort_order: number;
  created_at: string;
  updated_at: string;
};

/* ── Print History ────────────────────────────────────────────────────────── */

export type PrintHistoryStatus =
  | "queued"
  | "printing"
  | "completed"
  | "failed"
  | "cancelled";

export type PrintHistoryRecord = {
  id: string;
  document_name: string;
  printer_name: string;
  printer_connection_type: string | null;
  person_name: string | null;
  identification_number: string | null;
  issued_by: string | null;
  issued_by_staff_number: string | null;
  copies: number;
  paper_size: string;
  status: PrintHistoryStatus;
  error_message: string | null;
  agent_job_id: string | null;
  device_id: string | null;
  created_at: string;
  completed_at: string | null;
};
