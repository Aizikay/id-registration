$connections = Get-NetTCPConnection -LocalPort 5174 -State Listen -ErrorAction SilentlyContinue
if ($connections) {
  foreach ($conn in $connections) {
    Write-Output "PID: $($conn.OwningProcess)"
  }
} else {
  Write-Output "No process on port 5174"
}
