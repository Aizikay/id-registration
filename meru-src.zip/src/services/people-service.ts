/**
 * People service — registration, search, profile.
 *
 * Read strategy:
 *   Online  -> Supabase with pagination (never loads whole table), then
 *              mirrors fetched pages into IndexedDB for later offline use.
 *   Offline -> IndexedDB search using local indexes.
 *
 * Write strategy:
 *   Online  -> direct insert; on network failure transparently falls back to
 *              the offline queue so no data can be lost mid-action.
 *   Offline -> local insert + outbox entry, marked "PENDING SYNC" in UI.
 */

import { supabase } from "./supabase-client";
import { mapSupabaseError, AppError } from "./errors";
import { navigatorOnLine } from "@/lib/connectivity";
import { db, type CachedPerson } from "@/db/database";
import { enqueueOperation } from "@/offline/outbox";
import { authProfileCache } from "./audit-service";
import type { Person } from "@/types";

export interface RegisterPersonInput {
  id: string;
  identification_number: string;
  full_name: string;
  date_of_birth: string;
  gender: Person["gender"];
  nationality: string;
  address: string;
  phone: string | null;
  position?: string | null;
  department?: string | null;
  photo_path?: string | null;
  signature_path?: string | null;
}

export interface PersonQuery {
  search?: string;
  department?: string | null;
  page?: number;
  pageSize?: number;
}

const PERSON_COLUMNS =
  "id, identification_number, full_name, date_of_birth, gender, nationality, address, phone, position, department, photo_path, signature_path, registration_status, created_at, updated_at, created_by";

/** Only columns that exist in the Supabase persons table. */
const PERSON_DB_COLUMNS = [
  "identification_number",
  "full_name",
  "date_of_birth",
  "gender",
  "nationality",
  "address",
  "phone",
  "position",
  "department",
  "photo_path",
  "signature_path",
  "registration_status",
] as const;

/** Build a clean insert payload with ONLY valid DB columns. */
function buildPersonPayload(input: RegisterPersonInput) {
  const now = new Date().toISOString();
  return {
    identification_number: input.identification_number.trim().toUpperCase(),
    full_name: input.full_name.trim().toUpperCase(),
    date_of_birth: input.date_of_birth,
    gender: input.gender,
    nationality: input.nationality.trim() || "Tanzanian",
    address: input.address.trim() || "Not specified",
    phone: input.phone ?? null,
    position: input.position ?? null,
    department: input.department ?? null,
    photo_path: input.photo_path ?? null,
    signature_path: input.signature_path ?? null,
    registration_status: "registered" as const,
    created_at: now,
    updated_at: now,
    created_by: authProfileCache.profileId ?? null,
  };
}

export async function registerPerson(
  input: RegisterPersonInput
): Promise<{ person: CachedPerson; offline: boolean }> {
  const row = buildPersonPayload(input);

  // Build the full CachedPerson for local storage (includes id + synced)
  const localPerson: CachedPerson = {
    id: input.id,
    ...row,
    synced: false
  };

  if (navigatorOnLine()) {
    try {
      // Include id for the Supabase typed client (server will use it or generate its own)
      const insertPayload = { ...row, id: input.id };
      const { data, error } = await supabase
        .from("persons")
        .insert(insertPayload as any)
        .select(PERSON_COLUMNS)
        .single();
      if (error) throw error;

      const person = { ...(data as Person), synced: true };
      // Mirror to local DB for offline availability.
      await db.persons.put(person);
      return { person, offline: false };
    } catch (err) {
      const mapped = mapSupabaseError(err);
      console.error("[registerPerson] online insert failed:", mapped.code, mapped.detail, err);
      if (
        mapped.code === "duplicate_identification" ||
        mapped.code === "session_expired" ||
        mapped.code === "auth_failed"
      ) {
        throw mapped;
      }
      // Network-level or RLS failure: fall through to the offline path below.
    }
  }

  // ---- Offline path ------------------------------------------------------
  await db.persons.put(localPerson);

  // Enqueue ONLY DB-safe columns (no id, synced, or internal fields)
  await enqueueOperation({
    entityType: "person",
    entityId: localPerson.id,
    operationType: "insert_person",
    payload: {
      identification_number: row.identification_number,
      full_name: row.full_name,
      date_of_birth: row.date_of_birth,
      gender: row.gender,
      nationality: row.nationality,
      address: row.address,
      phone: row.phone,
      position: row.position,
      department: row.department,
      photo_path: row.photo_path,
      signature_path: row.signature_path,
      registration_status: row.registration_status,
      local_id: localPerson.id,
    }
  });

  return { person: localPerson, offline: true };
}

export async function deletePerson(id: string, force = false): Promise<void> {
  // When force=true (supervisor mode), bypass the active-issuance check and
  // cascade-delete related records before removing the person.
  if (!force) {
    // Business rule: block if an occupying issuance exists
    const { data: occupying, error: occErr } = await supabase
      .from("issuance_records")
      .select("id,status")
      .eq("person_id", id)
      .in("status", ["pending", "printing", "issued", "reprint_requested"])
      .limit(1)
      .maybeSingle();
    if (occErr) throw mapSupabaseError(occErr);
    if (occupying) {
      throw new AppError(
        "conflict_detected",
        "Cannot delete: this person has an active or issued ID. Cancel or correct the record instead."
      );
    }
  }

  if (navigatorOnLine()) {
    if (force) {
      // Supervisor force mode: cascade-delete related issuance records first
      await supabase.from("issuance_records").delete().eq("person_id", id);
    }
    const { data, error } = await supabase.from("persons").delete().eq("id", id).select("id").maybeSingle();
    if (error) throw mapSupabaseError(error);
    if (!data) {
      throw new AppError("permission_denied", "Delete blocked by policy — ensure RLS policies are applied and you are admin/supervisor.");
    }
  }

  // Always clean local mirror, pending outbox ops, and related records
  await db.persons.delete(id).catch(() => undefined);
  await db.outbox.where("entity_id").equals(id).delete().catch(() => undefined);
  await db.issuances.where("person_id").equals(id).delete().catch(() => undefined);
}

export async function updatePerson(
  id: string,
  patch: Partial<Person>
): Promise<Person> {
  // Only send DB-safe columns
  const updates: Record<string, unknown> = { updated_at: new Date().toISOString() };
  for (const col of PERSON_DB_COLUMNS) {
    if (col in patch) updates[col] = (patch as Record<string, unknown>)[col];
  }

  if (navigatorOnLine()) {
    try {
      const { data, error } = await supabase
        .from("persons")
        .update(updates as any)
        .eq("id", id)
        .select(PERSON_COLUMNS)
        .single();
      if (error) throw error;
      const person = data as Person;
      await db.persons.put({ ...person, synced: true });
      return person;
    } catch (err) {
      throw mapSupabaseError(err);
    }
  }

  const existing = await db.persons.get(id);
  if (!existing) throw mapSupabaseError(new Error("person_not_found"));
  const merged: CachedPerson = { ...existing, ...patch, synced: false };
  await db.persons.put(merged);
  await enqueueOperation({
    entityType: "person",
    entityId: id,
    operationType: "update_person",
    payload: updates
  });
  return merged;
}

export async function searchPersonsOnline(
  query: PersonQuery
): Promise<{ rows: Person[]; total: number }> {
  const page = Math.max(query.page ?? 0, 0);
  const pageSize = Math.min(Math.max(query.pageSize ?? 20, 1), 100);
  const from = page * pageSize;
  const to = from + pageSize - 1;

  let request = supabase
    .from("persons")
    .select(PERSON_COLUMNS, { count: "exact" })
    .order("created_at", { ascending: false })
    .range(from, to);

  const term = query.search?.trim();
  if (term) {
    // Uses pg_trgm GIN index for name; exact/prefix for numbers & phone.
    request = request.or(
      [
        `full_name.ilike.%${escapeLike(term)}%`,
        `identification_number.eq.${term.toUpperCase()}`,
        `phone.ilike.%${term}%`
      ].join(",")
    );
  }

  if (query.department !== undefined) {
    if (query.department === null) {
      request = request.is("department", null);
    } else {
      request = request.eq("department", query.department);
    }
  }

  const { data, error, count } = await request;
  if (error) throw mapSupabaseError(error);

  const rows = (data ?? []) as Person[];
  // Mirror page into local cache (fire and forget).
  void Promise.all(
    rows.map((p) => db.persons.put({ ...p, synced: true }))
  ).catch(() => undefined);

  return { rows, total: count ?? 0 };
}

export async function searchPersonsOffline(
  term: string,
  limit = 50
): Promise<CachedPerson[]> {
  const t = term.trim();
  if (!t) {
    return db.persons.orderBy("created_at").reverse().limit(limit).toArray();
  }
  const upper = t.toUpperCase();
  const lower = t.toLowerCase();

  const results = new Map<string, CachedPerson>();

  const [byIdNum, byPhone] = await Promise.all([
    db.persons.where("identification_number").equals(upper).toArray(),
    db.persons.where("phone").startsWithIgnoreCase(t).toArray()
  ]);
  byIdNum.forEach((p) => results.set(p.id, p));
  byPhone.forEach((p) => results.set(p.id, p));

  if (results.size < limit) {
    const byName = await db.persons
      .where("full_name")
      .startsWithAnyOfIgnoreCase([lower, upper])
      .limit(limit)
      .toArray();
    byName.forEach((p) => results.set(p.id, p));
  }

  if (results.size < limit) {
    // Substring fallback across name fields.
    const all = await db.persons.limit(2000).toArray();
    for (const p of all) {
      if (results.size >= limit) break;
      if (p.full_name.toLowerCase().includes(lower)) {
        results.set(p.id, p);
      }
    }
  }

  return Array.from(results.values()).slice(0, limit);
}

export async function getPersonById(
  id: string
): Promise<CachedPerson | null> {
  if (navigatorOnLine()) {
    try {
      const { data, error } = await supabase
        .from("persons")
        .select(PERSON_COLUMNS)
        .eq("id", id)
        .maybeSingle();
      if (error) throw error;
      if (data) {
        const cached: CachedPerson = { ...(data as Person), synced: true };
        await db.persons.put(cached);
        return cached;
      }
    } catch (err) {
      const mapped = mapSupabaseError(err);
      if (mapped.code !== "network_unavailable") throw mapped;
    }
  }
  return (await db.persons.get(id)) ?? null;
}

export async function findDuplicateIdentification(
  identificationNumber: string,
  excludeId?: string
): Promise<Person | null> {
  const num = identificationNumber.trim().toUpperCase();

  // Check server first when online.
  if (navigatorOnLine()) {
    try {
      let req = supabase
        .from("persons")
        .select(PERSON_COLUMNS)
        .eq("identification_number", num)
        .limit(2);
      if (excludeId) req = req.neq("id", excludeId);
      const { data, error } = await req.maybeSingle();
      if (!error && data) return data as Person;
      if (error && !isNetworkError(error)) throw error;
    } catch (err) {
      if (!isNetworkError(err)) throw err;
    }
  }

  // Local fallback.
  const local = await db.persons
    .where("identification_number")
    .equals(num)
    .first();
  if (local && local.id !== excludeId) return local;
  return null;
}

function isNetworkError(err: unknown): boolean {
  const msg = String((err as { message?: string })?.message ?? "").toLowerCase();
  return !navigatorOnLine() || msg.includes("fetch") || msg.includes("network");
}

/** Escape user input used inside an ilike filter. */
function escapeLike(term: string): string {
  return term.replace(/[%_,()]/g, " ").trim();
}

/** Check which person IDs have an issued or active ID card. */
export async function checkIssuanceStatus(
  personIds: string[]
): Promise<Set<string>> {
  if (personIds.length === 0) return new Set();
  try {
    const { data, error } = await supabase
      .from("issuance_records")
      .select("person_id")
      .in("person_id", personIds)
      .in("status", ["issued", "pending", "printing"]);
    if (error) throw error;
    return new Set((data ?? []).map((r: { person_id: string }) => r.person_id));
  } catch {
    return new Set();
  }
}
