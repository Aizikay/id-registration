/**
 * Application error taxonomy.
 *
 * Every failure mode from the spec maps to a typed error so callers can
 * branch reliably and the UI can present actionable messages without
 * leaking internal details.
 */

export type AppErrorCode =
  | "network_unavailable"
  | "auth_failed"
  | "session_expired"
  | "permission_denied"
  | "duplicate_identification"
  | "already_issued"
  | "issuance_in_progress"
  | "invalid_transition"
  | "printer_unavailable"
  | "print_failed"
  | "agent_unreachable"
  | "device_revoked"
  | "sync_failed"
  | "conflict_detected"
  | "validation_failed"
  | "not_found"
  | "database_error"
  | "rate_limited"
  | "unknown";

const USER_MESSAGES: Record<AppErrorCode, string> = {
  network_unavailable:
    "No internet connection. The operation was saved offline and will sync automatically.",
  auth_failed: "Invalid credentials or account disabled.",
  session_expired: "Your session has expired. Please sign in again.",
  permission_denied: "You do not have permission to perform this action.",
  duplicate_identification:
    "A person with this identification number already exists.",
  already_issued:
    "This ID has already been issued. Duplicate issuance is blocked.",
  issuance_in_progress:
    "An issuance is already in progress for this person.",
  invalid_transition: "That status change is not allowed.",
  printer_unavailable: "The printer is unavailable or offline.",
  print_failed: "Printing failed. The record was kept and can be retried.",
  agent_unreachable:
    "Cannot reach the local Print Agent. Ensure it is running on this workstation.",
  device_revoked:
    "This device has been revoked by an administrator. Sign in is disabled.",
  sync_failed:
    "Synchronization failed. Your changes remain safely stored locally.",
  conflict_detected:
    "A conflicting change exists on the server. A supervisor must review it.",
  validation_failed: "Please correct the highlighted fields.",
  not_found: "The requested record was not found.",
  database_error: "A database error occurred. Please try again.",
  rate_limited: "Too many attempts. Please wait a moment and try again.",
  unknown: "Something went wrong. Please try again."
}

export class AppError extends Error {
  readonly code: AppErrorCode;
  /** Optional structured detail for logging — never shown to end users raw. */
  readonly detail?: string;
  readonly userMessage: string;

  constructor(code: AppErrorCode, detail?: string) {
    super(detail ? `${code}: ${detail}` : code);
    this.name = "AppError";
    this.code = code;
    this.detail = detail;
    this.userMessage = USER_MESSAGES[code];
  }
}

export function isAppError(e: unknown): e is AppError {
  return e instanceof AppError;
}

/**
 * Translate a Supabase/Postgres error into a typed AppError.
 * Postgres error codes we deliberately recognize:
 *   23505 unique_violation, 42501 insufficient_privilege,
 *   P0001 raise_exception, P0002 no_data_found, 23514 check_violation
 */
export function mapSupabaseError(error: unknown): AppError {
  if (isAppError(error)) return error;

  const err = error as { code?: string; message?: string } | null;
  const code = err?.code ?? "";
  const message = (err?.message ?? "").toLowerCase();

  if (!navigator.onLine || message.includes("fetch failed") || message.includes("network")) {
    return new AppError("network_unavailable", err?.message);
  }
  if (message.includes("jwt expired") || message.includes("invalid claim") ||
      message.includes("refresh_token_not_found")) {
    return new AppError("session_expired", err?.message);
  }
  if (code === "42501" || message.includes("row-level security") || message.includes("permission denied")) {
    return new AppError("permission_denied", err?.message);
  }
  if (message.includes("already_issued")) {
    return new AppError("already_issued", err?.message);
  }
  if (message.includes("issuance_in_progress")) {
    return new AppError("issuance_in_progress", err?.message);
  }
  if (message.includes("person_not_found") || code === "P0002") {
    return new AppError("not_found", err?.message);
  }
  if (message.includes("invalid_transition")) {
    return new AppError("invalid_transition", err?.message);
  }
  if (code === "23505" || message.includes("duplicate key")) {
    if (message.includes("identification_number") || message.includes("persons_")) {
      return new AppError("duplicate_identification", err?.message);
    }
    return new AppError("conflict_detected", err?.message);
  }
  if (code === "P0001" && message.includes("unauthorized")) {
    return new AppError("auth_failed", err?.message);
  }
  if (code === "P0001" && message.includes("forbidden")) {
    return new AppError("permission_denied", err?.message);
  }
  if (code === "23514" || message.includes("check constraint") || message.includes("invalid_transition")) {
    return new AppError("invalid_transition", err?.message);
  }
  if (code === "5xx" || message.includes("too many requests") || code === "429") {
    return new AppError("rate_limited", err?.message);
  }
  return new AppError("database_error", err?.message ?? String(error));
}
