$c = Get-NetTCPConnection -LocalPort 5174 -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
if ($c) {
  $p = Get-Process -Id $c.OwningProcess -ErrorAction SilentlyContinue
  Write-Output "PORT_5174: LISTENING pid=$($c.OwningProcess) name=$($p.ProcessName)"
} else {
  Write-Output "PORT_5174: FREE"
}
