-- ============================================================================
-- Migration 20260914: Departments
--
-- Adds:
--   1. public.departments      — registry of council departments (admin-managed)
--   2. public.persons.department — text column filing each registered ID
--   3. Index + RLS policies
--
-- `persons.department` is free text (not an FK) so records stay valid even if
-- a department is later removed; the UI resolves labels from the departments
-- table only — there is no built-in catalogue. The list is 100% user-registered.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- 1. persons.department — file each registered ID under a department
-- ---------------------------------------------------------------------------
alter table public.persons
  add column if not exists department text;

create index if not exists persons_department_idx
  on public.persons (department);

-- ---------------------------------------------------------------------------
-- 2. departments table
-- ---------------------------------------------------------------------------
create table if not exists public.departments (
  id          text primary key,
  name_sw     text not null,
  name_en     text not null,
  description text,
  color       text,
  sort_order  integer not null default 9999,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  constraint departments_name_sw_unique unique (name_sw),
  constraint departments_id_format check (id ~ '^[a-z0-9-]{2,60}$')
);

-- No seed data: the departments list is built exclusively by the user via
-- "Register Department". If a previous run of this migration seeded the 12
-- built-in council departments, remove them (their registered IDs are kept —
-- those persons keep their `department` value and show as unassigned).
delete from public.departments
where id in (
  'mkurugenzi','utawala','fedha','elimu','afya','kilimo','ujenzi',
  'maji','maliasili','ushirika','habari','ngazi-chini'
);

create trigger trg_departments_updated before update on public.departments
  for each row execute function public.set_updated_at();

create index departments_sort_idx on public.departments (sort_order asc);

-- ---------------------------------------------------------------------------
-- 3. Row Level Security
-- ---------------------------------------------------------------------------
alter table public.departments enable row level security;

-- All authenticated staff may view the department list
create policy departments_select_authenticated on public.departments
  for select to authenticated
  using (true);

-- Only administrators may register, update, or remove departments
create policy departments_manage_admin on public.departments
  for all to authenticated
  using (public.auth_profile_role() = 'admin')
  with check (public.auth_profile_role() = 'admin');

-- Persons department reassignment rides on the existing
-- persons_update_officer_admin policy — no extra policy needed.
--
-- NOTE: if you already ran the earlier version of this file (with the 12
-- built-in departments seeded), re-running this migration is safe: the delete
-- above removes the seeded rows and your own registered departments remain.
