import { useEffect, useRef, useState, useCallback } from "react";
import * as pdfjs from "pdfjs-dist";
import type { EmployeeData, IdCardTemplate } from "../template";

// Vite: pdfjs worker
import pdfWorker from "pdfjs-dist/build/pdf.worker.mjs?url";

// Configure worker once
if (typeof window !== "undefined" && !pdfjs.GlobalWorkerOptions.workerSrc) {
  pdfjs.GlobalWorkerOptions.workerSrc = pdfWorker;
}

interface Props {
  template: IdCardTemplate;
  data: EmployeeData;
  scale?: number;
  showGuides?: boolean;
  onFieldClick?: (fieldId: string) => void;
  selectedField?: string | null;
  printMode?: boolean;
}

export function PdfIdCardPreview({ template, data, scale = 1.2, onFieldClick, selectedField, printMode = false }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [pdfError, setPdfError] = useState<string | null>(null);
  const [pageSize, setPageSize] = useState({ width: 595, height: 842 });
  const [renderScale, setRenderScale] = useState(1.5);

  const fieldValue = (key: keyof EmployeeData): string => {
    const v = data[key];
    if (typeof v === "string" && v.trim()) return v;
    return "—";
  };

  const renderPdf = useCallback(async () => {
    if (!canvasRef.current) return;
    try {
      const loadingTask = pdfjs.getDocument(template.pdfSrc);
      const pdf = await loadingTask.promise;
      const page = await pdf.getPage(1);
      const viewport = page.getViewport({ scale: renderScale });
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      canvas.width = viewport.width;
      canvas.height = viewport.height;
      setPageSize({ width: viewport.width, height: viewport.height });
      await page.render({ canvasContext: ctx, viewport }).promise;
      setPdfError(null);
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      if (msg.includes("404") || msg.includes("Failed to fetch") || msg.includes("Missing PDF")) {
        setPdfError(`Original PDF not found at ${template.pdfSrc}\n\nPlace ELIZABETH MGOMBELO ID.pdf at:\npublic/branding/meru-employee-id-template.pdf`);
      } else {
        setPdfError(msg.slice(0, 500));
      }
    }
  }, [template.pdfSrc, renderScale]);

  useEffect(() => {
    void renderPdf();
  }, [renderPdf]);

  // Re-render on scale/template change
  useEffect(() => {
    const handler = () => { void renderPdf(); };
    window.addEventListener("resize", handler);
    return () => window.removeEventListener("resize", handler);
  }, [renderPdf]);

  if (pdfError) {
    return (
      <div className="flex flex-col items-center justify-center rounded-xl border-2 border-dashed border-amber-300 bg-amber-50 p-8 text-center" style={{ width: 400 * scale, height: 250 * scale }}>
        <p className="text-sm font-semibold text-amber-800">Original PDF not available</p>
        <p className="mt-2 max-w-sm whitespace-pre-wrap font-mono text-xs text-amber-700">{pdfError}</p>
        <p className="mt-3 text-xs text-slate-500">The designer will show a placeholder. Place the PDF and hard refresh (Ctrl+Shift+R).</p>
        <div className="mt-4 w-full rounded-lg border border-slate-200 bg-white p-3 text-left">
          <p className="text-xs font-semibold text-slate-700">Expected location:</p>
          <code className="mt-1 block rounded bg-slate-100 px-2 py-1 font-mono text-xs">public/branding/meru-employee-id-template.pdf</code>
          <p className="mt-2 text-xs text-slate-500">Source: ELIZABETH MGOMBELO ID.pdf (provided). Do not hard-code ELIZABETH R. MGOMBELO / 8973229 / AFISA ELIMU KATA / HW/MER/PF/17358 — these are sample data.</p>
        </div>
      </div>
    );
  }

  const overlayBaseStyle: React.CSSProperties = {
    position: "absolute",
    inset: 0,
    width: pageSize.width,
    height: pageSize.height,
    transform: `scale(${scale / renderScale})`,
    transformOrigin: "top left",
    pointerEvents: onFieldClick ? "auto" : "none"
  };

  const wrapperStyle: React.CSSProperties = printMode
    ? { display: "flex", justifyContent: "center", padding: 16 }
    : { width: pageSize.width * (scale / renderScale), height: pageSize.height * (scale / renderScale), position: "relative", overflow: "hidden", flexShrink: 0 };

  return (
    <div ref={containerRef} style={wrapperStyle} className={printMode ? "id-card-pdf-print-wrapper" : ""}>
      <canvas ref={canvasRef} style={{ display: "block", width: pageSize.width * (scale / renderScale), height: pageSize.height * (scale / renderScale) }} />
      {/* Overlay layers */}
      <div style={overlayBaseStyle} className="id-card-pdf-overlays">
        {/* Layer 2: Masks */}
        {!printMode &&
          template.masks.map((m) => (
            <div
              key={m.id}
              style={{
                position: "absolute",
                left: `${m.position.xPct}%`,
                top: `${m.position.yPct}%`,
                width: `${m.position.wPct}%`,
                height: `${m.position.hPct}%`,
                background: m.color,
                opacity: 0.95,
                borderRadius: 1
              }}
            />
          ))}
        {printMode &&
          template.masks.map((m) => (
            <div
              key={m.id}
              style={{
                position: "absolute",
                left: `${m.position.xPct}%`,
                top: `${m.position.yPct}%`,
                width: `${m.position.wPct}%`,
                height: `${m.position.hPct}%`,
                background: m.color
              }}
            />
          ))}

        {/* Layer 2b: Photo mask + photo */}
        <div
          style={{
            position: "absolute",
            left: `${template.photo.position.xPct}%`,
            top: `${template.photo.position.yPct}%`,
            width: `${template.photo.position.wPct}%`,
            height: `${template.photo.position.hPct}%`,
            borderRadius: template.photo.radiusPt,
            border: `${template.photo.borderWidthPt}px solid ${template.photo.borderColor}`,
            background: template.photo.background,
            overflow: "hidden",
            display: "flex",
            alignItems: "center",
            justifyContent: "center"
          }}
        >
          {data.photoCroppedUrl || data.photoUrl ? (
            <img
              src={data.photoCroppedUrl ?? data.photoUrl ?? ""}
              alt={data.fullName || "Employee"}
              style={{ width: "100%", height: "100%", objectFit: template.photo.objectFit as React.CSSProperties["objectFit"] }}
              draggable={false}
            />
          ) : (
            <div style={{ fontSize: 10, color: "#8d6e63", textAlign: "center" }}>Picha</div>
          )}
        </div>
        {/* Extra mask to ensure sample photo is hidden: solid cover */}
        {(data.photoCroppedUrl || data.photoUrl) && (
          <div
            style={{
              position: "absolute",
              left: `${template.photo.position.xPct}%`,
              top: `${template.photo.position.yPct}%`,
              width: `${template.photo.position.wPct}%`,
              height: `${template.photo.position.hPct}%`,
              background: "transparent",
              pointerEvents: "none",
              borderRadius: template.photo.radiusPt
            }}
          />
        )}

        {/* Layer 3: Dynamic text */}
        {template.fields
          .filter((f) => f.visible)
          .map((field) => {
            const isSelected = selectedField === field.id;
            const value = field.dataKey ? fieldValue(field.dataKey) : field.staticText ?? "";
            return (
              <div
                key={field.id}
                onClick={() => onFieldClick?.(field.id)}
                style={{
                  position: "absolute",
                  left: `${field.position.xPct}%`,
                  top: `${field.position.yPct}%`,
                  width: `${field.position.wPct}%`,
                  height: `${field.position.hPct}%`,
                  cursor: onFieldClick ? "pointer" : "default",
                  outline: isSelected && !printMode ? "1px dashed #0f4c5c" : undefined,
                  background: isSelected && !printMode ? "rgba(15,76,92,0.08)" : "transparent",
                  display: "flex",
                  alignItems: "center",
                  padding: "0 2px"
                }}
              >
                <span
                  style={{
                    fontSize: field.style.fontSizePt,
                    fontWeight: field.style.fontWeight,
                    fontFamily: field.style.fontFamily,
                    letterSpacing: `${field.style.letterSpacingEm}em`,
                    lineHeight: field.style.lineHeight,
                    color: field.style.color,
                    textAlign: field.style.textAlign,
                    textTransform: field.style.textTransform,
                    whiteSpace: "nowrap",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    width: "100%"
                  }}
                >
                  {value}
                </span>
              </div>
            );
          })}
      </div>

      {/* Zoom controls (not printed) */}
      {!printMode && (
        <div className="absolute bottom-2 right-2 flex items-center gap-1 rounded-full bg-white/90 px-2 py-1 shadow">
          <button onClick={() => setRenderScale((s) => Math.max(0.8, s - 0.2))} className="rounded p-1 text-xs hover:bg-slate-100">
            −
          </button>
          <span className="font-mono text-xs">{Math.round(renderScale * 100)}%</span>
          <button onClick={() => setRenderScale((s) => Math.min(3, s + 0.2))} className="rounded p-1 text-xs hover:bg-slate-100">
            +
          </button>
        </div>
      )}
    </div>
  );
}
