-- =============================================================
-- MERU DISTRICT COUNCIL — PRINT HISTORY TABLE
-- Run this in Supabase SQL Editor.
-- =============================================================

-- 1. Print History table
CREATE TABLE IF NOT EXISTS public.print_history (
  id                       uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  document_name            text NOT NULL,
  printer_name             text NOT NULL,
  printer_connection_type  text,                      -- 'usb', 'wireless', 'network', 'unknown'
  person_name              text,
  identification_number    text,
  issued_by                text,
  issued_by_staff_number   text,
  copies                   integer NOT NULL DEFAULT 1 CHECK (copies >= 1 AND copies <= 10),
  paper_size               text NOT NULL DEFAULT '86x54mm',
  status                   text NOT NULL DEFAULT 'queued'
                             CHECK (status IN ('queued','printing','completed','failed','cancelled')),
  error_message            text,
  agent_job_id             text,
  device_id                text,
  created_at               timestamptz NOT NULL DEFAULT now(),
  completed_at             timestamptz
);

-- 2. Indexes for common queries
CREATE INDEX IF NOT EXISTS idx_print_history_status ON public.print_history (status);
CREATE INDEX IF NOT EXISTS idx_print_history_created ON public.print_history (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_print_history_printer ON public.print_history (printer_name);
CREATE INDEX IF NOT EXISTS idx_print_history_doc ON public.print_history USING gin (document_name gin_trgm_ops);

-- 3. Enable RLS
ALTER TABLE public.print_history ENABLE ROW LEVEL SECURITY;

-- 4. RLS Policies
-- Anyone authenticated can read print history (for the page)
DROP POLICY IF EXISTS print_history_select_authenticated ON public.print_history;
CREATE POLICY print_history_select_authenticated ON public.print_history
  FOR SELECT TO authenticated
  USING (true);

-- Anyone authenticated can insert print history records
DROP POLICY IF EXISTS print_history_insert_authenticated ON public.print_history;
CREATE POLICY print_history_insert_authenticated ON public.print_history
  FOR INSERT TO authenticated
  WITH CHECK (true);

-- Officers, supervisors, and admins can update (e.g. mark completed/failed)
DROP POLICY IF EXISTS print_history_update_roles ON public.print_history;
CREATE POLICY print_history_update_roles ON public.print_history
  FOR UPDATE TO authenticated
  USING (auth_profile_role() IN ('officer','supervisor','admin'))
  WITH CHECK (auth_profile_role() IN ('officer','supervisor','admin'));

-- Only supervisors and admins can delete
DROP POLICY IF EXISTS print_history_delete_supervisor ON public.print_history;
CREATE POLICY print_history_delete_supervisor ON public.print_history
  FOR DELETE TO authenticated
  USING (auth_profile_role() IN ('supervisor','admin'));

-- 5. Verify
SELECT
  column_name,
  data_type,
  is_nullable,
  column_default
FROM information_schema.columns
WHERE table_name = 'print_history'
ORDER BY ordinal_position;

SELECT
  policyname,
  cmd,
  roles
FROM pg_policies
WHERE tablename = 'print_history';
