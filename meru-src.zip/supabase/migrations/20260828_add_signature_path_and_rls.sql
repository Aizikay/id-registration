-- =============================================================
-- Migration: Add signature_path + Supervisor-only DELETE policy
-- Date: 2026-08-28
-- =============================================================
-- NOTE: Originally referenced a `user_roles` table that this project
-- never creates, which made the migration fail on a fresh/hosted DB.
-- Rewritten to be minimal, idempotent, and to reuse the existing
-- auth_profile_role() helper (same one used by every other policy).

-- 1. Add signature_path column to persons table
ALTER TABLE public.persons
  ADD COLUMN IF NOT EXISTS signature_path text;

-- 2. Enable Row Level Security (if not already enabled)
ALTER TABLE public.persons ENABLE ROW LEVEL SECURITY;

-- 3. Replace the DELETE policy so admin AND supervisor can delete.
--    Drops both the legacy admin-only policy (00004) and these
--    policy names in case a previous version of this migration ran.
DROP POLICY IF EXISTS "Allow only Supervisors to delete people" ON public.persons;
DROP POLICY IF EXISTS "delete_people_supervisor_only" ON public.persons;
DROP POLICY IF EXISTS "persons_delete_admin" ON public.persons;
DROP POLICY IF EXISTS "person_delete_supervisor_admin" ON public.persons;

CREATE POLICY "person_delete_supervisor_admin" ON public.persons
  FOR DELETE TO authenticated
  USING (public.auth_profile_role() IN ('supervisor', 'admin'));

-- 4. Recreate the canonical read/write policies to make re-runs safe.
DROP POLICY IF EXISTS "Allow authenticated users to view people" ON public.persons;
CREATE POLICY "Allow authenticated users to view people"
  ON public.persons FOR SELECT
  TO authenticated
  USING (true);

DROP POLICY IF EXISTS "Allow authenticated users to insert people" ON public.persons;
CREATE POLICY "Allow authenticated users to insert people"
  ON public.persons FOR INSERT
  TO authenticated
  WITH CHECK (true);

DROP POLICY IF EXISTS "Allow authenticated users to update people" ON public.persons;
CREATE POLICY "Allow authenticated users to update people"
  ON public.persons FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);