-- =============================================================
-- FIX: Relax identification_number check constraint
-- Old: ^[A-Z0-9]{8,20}$ (8-20 uppercase alphanumeric only)
-- New: ^[A-Z0-9/\-]{1,30}$ (1-30 chars, allow / and -)
-- =============================================================

-- Drop the old restrictive constraint
ALTER TABLE public.persons
  DROP CONSTRAINT IF EXISTS persons_identification_number_format;

-- Add the new relaxed constraint
ALTER TABLE public.persons
  ADD CONSTRAINT persons_identification_number_format
  CHECK (identification_number ~ '^[A-Z0-9/\-]{1,30}$');

-- Also ensure position and signature_path columns exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'persons'
      AND column_name = 'position'
  ) THEN
    ALTER TABLE public.persons ADD COLUMN position text;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'persons'
      AND column_name = 'signature_path'
  ) THEN
    ALTER TABLE public.persons ADD COLUMN signature_path text;
  END IF;
END $$;
