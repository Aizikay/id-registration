import { describe, it, expect, beforeEach } from "vitest";
import { db } from "@/db/database";
import { enqueueOperation, markFailed, markConflict, retryEntry, pendingCount, conflictCount } from "./outbox";

beforeEach(async () => {
  await db.outbox.clear();
});

describe("enqueueOperation", () => {
  it("creates a pending entry with operation_id and next_attempt_at ~ now", async () => {
    const before = Date.now();
    const entry = await enqueueOperation({
      entityType: "person",
      entityId: "p-1",
      operationType: "insert_person",
      payload: { full_name: "Test" }
    });
    const after = Date.now();
    expect(entry.status).toBe("pending");
    expect(entry.operation_id).toMatch(/^[0-9a-f-]{36}$/i);
    expect(entry.retry_count).toBe(0);
    expect(entry.next_attempt_at).toBeGreaterThanOrEqual(before);
    expect(entry.next_attempt_at).toBeLessThanOrEqual(after + 1000);
    expect(await pendingCount()).toBe(1);
  });
});

describe("markFailed", () => {
  it("increments retry_count and sets exponential backoff", async () => {
    const entry = await enqueueOperation({
      entityType: "person",
      entityId: "p-2",
      operationType: "insert_person",
      payload: {}
    });
    const id = entry.id!;
    await markFailed(id, "network_error");
    let row = await db.outbox.get(id);
    expect(row!.retry_count).toBe(1);
    expect(row!.status).toBe("failed");
    expect(row!.next_attempt_at).toBeGreaterThan(Date.now() + 4000); // ~5s backoff

    await markFailed(id, "network_error again");
    row = await db.outbox.get(id);
    expect(row!.retry_count).toBe(2);
    // second retry ~10s backoff
    expect(row!.next_attempt_at).toBeGreaterThan(Date.now() + 9000);
  });

  it("escalates to conflict after 8 retries", async () => {
    const entry = await enqueueOperation({
      entityType: "issuance",
      entityId: "i-1",
      operationType: "insert_issuance",
      payload: {}
    });
    const id = entry.id!;
    for (let i = 0; i < 8; i++) await markFailed(id, "x");
    const row = await db.outbox.get(id);
    expect(row!.status).toBe("conflict");
    expect(row!.retry_count).toBe(8);
    expect(await conflictCount()).toBe(1);
  });

  it("caps backoff at 10 minutes", async () => {
    const entry = await enqueueOperation({
      entityType: "person",
      entityId: "p-3",
      operationType: "insert_person",
      payload: {}
    });
    const id = entry.id!;
    // Drive to retry 7 (backoff would be 5s * 2^6 = 320s without cap)
    for (let i = 0; i < 7; i++) await markFailed(id, "x");
    const row = await db.outbox.get(id);
    const backoff = row!.next_attempt_at - Date.now();
    expect(backoff).toBeLessThanOrEqual(601_000); // 600s + 1s jitter
    expect(backoff).toBeGreaterThan(300_000);
  });
});

describe("markConflict / retryEntry", () => {
  it("marks conflict and retryEntry resets to pending", async () => {
    const entry = await enqueueOperation({
      entityType: "person",
      entityId: "p-4",
      operationType: "insert_person",
      payload: {}
    });
    const id = entry.id!;
    await markConflict(id, "already_issued");
    expect((await db.outbox.get(id))!.status).toBe("conflict");
    expect(await conflictCount()).toBe(1);

    await retryEntry(id);
    const retried = await db.outbox.get(id);
    expect(retried!.status).toBe("pending");
    expect(retried!.retry_count).toBe(0);
    expect(retried!.error_message).toBeNull();
  });
});
