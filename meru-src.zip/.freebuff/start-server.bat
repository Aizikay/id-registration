@echo off
cd /d "C:\Users\hp\Pictures\ID Registration & Issuance Management System.(MERU DC) - Copy"
call node_modules\.bin\vite.cmd --port 5173