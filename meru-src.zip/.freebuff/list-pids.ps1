$procs = Get-Process -Name node -ErrorAction SilentlyContinue
foreach ($p in $procs) {
  Write-Output "PID=$($p.Id) START=$($p.StartTime)"
}
