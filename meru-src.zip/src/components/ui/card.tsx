import { cn } from "@/lib/cn";

export function Card({
  className,
  children,
}: {
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <div className={cn("card-surface group", className)}>{children}</div>
  );
}

export function CardHeader({
  title,
  subtitle,
  actions,
  icon,
  className,
}: {
  title: React.ReactNode;
  subtitle?: React.ReactNode;
  actions?: React.ReactNode;
  icon?: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex flex-wrap items-center justify-between gap-3 px-5 py-4",
        "border-b border-surface-100/80 dark:border-slate-700/80",
        "bg-gradient-to-b from-surface-50/50 dark:from-slate-800/50 to-transparent",
        className
      )}
    >
      <div className="flex min-w-0 items-start gap-3">
        {icon && (
          <div
            className={cn(
              "rounded-xl bg-council-50/80 dark:bg-emerald-950/40 p-2 text-council-600 dark:text-emerald-400",
              "border border-council-100/80 dark:border-emerald-800/50 shadow-glass-sm",
              "transition-all duration-200 group-hover:bg-council-100 group-hover:shadow-glass"
            )}
          >
            {icon}
          </div>
        )}
        <div className="min-w-0">
          <h3 className="truncate font-display text-sm font-medium text-surface-700 dark:text-slate-200">
            {title}
          </h3>
          {subtitle && (
            <p className="mt-0.5 text-xs text-surface-400 dark:text-slate-500">
              {subtitle}
            </p>
          )}
        </div>
      </div>
      {actions && (
        <div className="flex items-center gap-2">{actions}</div>
      )}
    </div>
  );
}

export function CardBody({
  className,
  children,
}: {
  className?: string;
  children: React.ReactNode;
}) {
  return <div className={cn("p-5", className)}>{children}</div>;
}

export function PageHeader({
  title,
  subtitle,
  actions,
}: {
  title: string;
  subtitle?: string;
  actions?: React.ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4 animate-fade-in">
      <div>
        <h1 className="font-display text-xl font-semibold tracking-tight text-surface-800 dark:text-slate-100 sm:text-2xl">
          {title}
        </h1>
        {subtitle && (
          <p className="mt-1 text-sm text-surface-400 dark:text-slate-500">
            {subtitle}
          </p>
        )}
      </div>
      {actions && (
        <div className="flex flex-wrap items-center gap-2">{actions}</div>
      )}
    </div>
  );
}
