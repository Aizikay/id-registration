# PROMPT: Convert the Meru DC ID Registry web app into a Windows Desktop Application (.exe)

Copy everything below this line and paste it into your AI coding agent.

---

## Task

Convert my existing **Meru District Council ID Registration & Issuance Management System** from a browser-based React PWA into a **native Windows desktop application (.exe)** with a proper installer, full **local data storage**, **native OS printing**, and **automatic cloud sync whenever internet is available**. The desktop app must work 100% offline — login, person registration, ID card design, printing, departments, and reports must all function with **zero internet connection** — and silently sync everything to Supabase when a connection exists.

## Current Stack (do not change the core)

- React 18 + Vite 5 + TypeScript (strict) + TailwindCSS 3
- React Router v6 with `React.lazy()` route-level code splitting
- Offline-first data layer: **Dexie / IndexedDB** (`src/db/database.ts`) + outbox sync engine (`src/sync/engine.ts`) that drains queued operations to Supabase
- Supabase: auth (with offline-capable, HMAC-signed login), Postgres DB, Storage for photos/signatures
- Custom Node "Print Agent" HTTP service on `localhost:8377` that sends print jobs to real printers
- Features that MUST all keep working: Login, Dashboard, People Registry, ID Card Designer (canvas front/back, presets, export PNG/PDF), Print Preview, Printers page with print history, Departments (user-registered), Reports, Sync & Conflicts, Settings (theme, text size), PWA manifest/service worker (web-only)

## 1. Architecture Decision

Use **Electron (latest stable, 30+)** with `electron-vite` (or `vite-plugin-electron`) for a single dev/build pipeline. Justification to document in the README: the ID card designer depends on Chromium canvas rendering, and the existing print-agent is Node code we can absorb into the main process. **Do not** suggest a full rewrite (e.g., Tauri/Qt) unless you first present a concrete migration cost comparison and a recommendation — default to Electron.

- `src/` stays **untouched** as the renderer (except the small integration points listed below).
- New `electron/` folder for main-process code.

## 2. Required Project Structure

```
electron/
  main.ts                    # app lifecycle, window mgmt, single-instance lock, tray
  preload.ts                 # typed contextBridge API (NO nodeIntegration in renderer)
  services/
    printer-discovery.ts     # enumerate real Windows printers (USB + network + OS)
    print-service.ts         # native printing pipeline (absorbs the old print agent)
    local-store.ts           # local data paths, backup/restore, cache cleanup
    updater.ts               # electron-updater wiring (optional/behind setting)
    menu.ts                  # minimal app menu
```

## 3. Native Printer Integration (replaces the external print agent)

The browser could not enumerate printers, which is why a separate localhost agent existed. In the desktop app, the **main process** handles printing natively:

- **Auto-discovery:** enumerate installed Windows printers at startup and on "Refresh" (via PowerShell `Get-Printer` / WMI from the main process). Show: name, status (Online/Offline/Error/Ready), connection type (USB / Network / Wi-Fi), whether it's the **default** printer, last-detected time. No manual "register printer" forms — detected printers only, exactly like the current Printers page UX.
- **Printing pipeline:** render the ID front/back (or any document) with a hidden `BrowserWindow` → `printToPDF` → spool to the selected real printer with options: copies, paper size, orientation, margins, **duplex (short-edge binding) so front + back land on the same sheet**, color/grayscale. Use a bundled silent-print helper (e.g., SumatraPDF `-print-to` silent mode) or the Windows `printto` shell verb — your choice, but it must work on a clean Windows machine with no extra user setup.
- **Real results only:** success/failure per job, error message captured, print history rows written to the existing `print_history` store. Never simulate success.
- Remove the dependency on starting a separate print-agent process; keep the web build's agent fallback for the browser version.

## 4. Local Storage (the core ask)

- All data must persist **locally on the machine** in `%APPDATA%/MeruDC-IDRegistry/`: Dexie/IndexedDB persists automatically in Chromium — keep it, and additionally:
- Show the local data folder path in **Settings → System Info** with buttons: "Open Data Folder", "Backup Now" (zip the local DB + settings to a user-chosen location), "Restore from Backup", "Clear Local Cache".
- On first run, if a previous browser session's IndexedDB data exists (same user), import/migrate it so nothing is lost when switching from the web app.
- Sync behavior stays exactly as today: outbox queue drains to Supabase when online; conflicts surface in the Sync & Conflicts panel; the header shows ONLINE / OFFLINE / SYNCING.

## 5. Offline Login

Keep the existing HMAC-signed offline capability: after one successful online login, the app must open, authenticate locally, and remain usable offline for the configured window (currently 7 days). The login screen's SYSTEM ONLINE/OFFLINE indicator must reflect real connectivity.

## 6. PWA Cleanup (desktop build only)

Disable/unregister the service worker and manifest in the desktop build (they cause stale-cache bugs and are pointless inside Electron). Keep them fully active in the web build — gate via a build flag (`import.meta.env.DESKTOP` or equivalent).

## 7. Security (non-negotiable)

- `contextIsolation: true`, `nodeIntegration: false`, sandboxed preload.
- Expose a **minimal typed API** via `contextBridge`, e.g. `window.meru.native.listPrinters()`, `.print(job)`, `.openDataFolder()`, `.backupNow()`, `.getAppVersion()`.
- No loading of remote URLs in the window; CSP headers set; validate every IPC argument type in the main process.

## 8. Window & UX

- Min window 1280×800, remembers size/position; dark titlebar matching the current dark theme.
- App icon generated from `/branding/meru-logo.jpeg` → all required `.ico` sizes + tray icon.
- Single-instance lock (second launch focuses the existing window).
- Minimize-to-tray with a confirm on close while jobs are queued; tray menu: Open, Sync Now, Quit.
- Title: "Meru DC ID Registry — Halmashauri ya Wilaya ya Meru".

## 9. Packaging & Distribution

- `electron-builder` with `electron-builder.yml`: appId `go.tz.council.meru.idregistry`, productName `Meru DC ID Registry`.
- Targets: **NSIS installer** (one-click, per-user, allows per-machine option) **+ portable .exe**. Artifact name `MeruDC-IDRegistry-Setup-<version>.exe`.
- Wire `electron-updater` behind a Settings "Check for Updates" button (publish config can be a placeholder for now).
- Keep `npm run dev` (web) working unchanged; add:
  - `npm run desktop:dev`
  - `npm run desktop:build` (installer)
  - `npm run desktop:build:portable`

## 10. Hard Constraints

- Do NOT modify the Supabase schema or remove any existing page, route, feature, or theme.
- Do NOT break the web build — it must still run with `npm run dev` and build with `npm run build`.
- TypeScript strict must pass with zero errors; no console errors on launch.
- All existing branding (Meru crest, coat of arms, LOGIN screen, emerald/dark theme) preserved.
- No fake/demo data anywhere; printing errors are real errors.

## 11. Deliverables

1. Full code for every new/modified file (complete files, no `...` placeholders).
2. Updated `package.json` + `electron-builder.yml` + build flags.
3. `README-DESKTOP.md`: how to run in dev, how to build the installer, where data is stored, how backup/restore works.
4. An acceptance checklist I can follow on a clean Windows PC: install → launch → login online once → disconnect internet → register a person → design & print an ID to a real USB printer → reconnect → verify sync completes and print history is in Supabase.

---
