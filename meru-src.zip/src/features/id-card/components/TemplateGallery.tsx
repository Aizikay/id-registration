/**
 * TemplateGallery — Browse and manage uploaded ID card templates.
 */

import { useState, useEffect, useCallback } from "react";
import { Card, CardBody } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Icon } from "@/components/icons/icon";
import { useToast } from "@/components/ui/toast";
import {
  getAllTemplates,
  setActiveTemplate,
  deleteTemplate,
  duplicateTemplate,
  type CustomTemplate,
} from "../template-manager";
import { ConfirmDialog } from "@/components/ui/modal";

interface Props {
  onSelectTemplate: (template: CustomTemplate) => void;
  onUploadNew: () => void;
  onCreateDefault: () => void;
  currentTemplateId?: string;
}

export function TemplateGallery({
  onSelectTemplate,
  onUploadNew,
  onCreateDefault,
  currentTemplateId,
}: Props) {
  const toast = useToast();
  const [templates, setTemplates] = useState<CustomTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [confirmDelete, setConfirmDelete] = useState<CustomTemplate | null>(null);
  const [deleting, setDeleting] = useState(false);

  const loadTemplates = useCallback(async () => {
    setLoading(true);
    try {
      const all = await getAllTemplates();
      setTemplates(all);
    } catch {
      toast.error("Error", "Failed to load templates");
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    void loadTemplates();
  }, [loadTemplates]);

  const handleSetActive = async (template: CustomTemplate) => {
    await setActiveTemplate(template.id);
    toast.success("Active", `"${template.name}" is now the active template`);
    await loadTemplates();
    onSelectTemplate(template);
  };

  const handleDelete = async () => {
    if (!confirmDelete) return;
    setDeleting(true);
    try {
      await deleteTemplate(confirmDelete.id);
      toast.success("Deleted", `"${confirmDelete.name}" has been removed`);
      setConfirmDelete(null);
      await loadTemplates();
    } catch {
      toast.error("Error", "Failed to delete template");
    } finally {
      setDeleting(false);
    }
  };

  const handleDuplicate = async (template: CustomTemplate) => {
    const dupe = await duplicateTemplate(template.id, `${template.name} (Copy)`);
    if (dupe) {
      toast.success("Duplicated", `Created "${dupe.name}"`);
      await loadTemplates();
    }
  };

  const formatDate = (iso: string) => {
    return new Date(iso).toLocaleDateString("en-GB", {
      day: "numeric",
      month: "short",
      year: "numeric",
    });
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "pdf": return "file-text";
      case "ai": return "image";
      case "image": return "image";
      default: return "file-text";
    }
  };

  const getTypeBadge = (type: string) => {
    const colors: Record<string, string> = {
      pdf: "bg-red-100 text-red-700",
      ai: "bg-purple-100 text-purple-700",
      image: "bg-blue-100 text-blue-700",
    };
    return colors[type] || "bg-surface-100 text-surface-600";
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-display text-lg font-semibold text-surface-800">
            Template Gallery
          </h3>
          <p className="text-sm text-surface-400">
            {templates.length} template{templates.length !== 1 ? "s" : ""} uploaded
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={onCreateDefault}
            icon={<Icon name="refresh" className="h-4 w-4" />}
          >
            Reset to Default
          </Button>
          <Button
            size="sm"
            onClick={onUploadNew}
            icon={<Icon name="upload" className="h-4 w-4" />}
          >
            Upload Template
          </Button>
        </div>
      </div>

      {/* Default template */}
      <Card className="border-2 border-dashed border-council-200">
        <CardBody className="flex items-center gap-4">
          <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-council-100 to-council-200">
            <Icon name="id-card" className="h-8 w-8 text-council-600" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <h4 className="font-medium text-surface-800">Default Template</h4>
              {!currentTemplateId && (
                <span className="rounded-full bg-council-100 px-2 py-0.5 text-[10px] font-medium text-council-700">
                  Active
                </span>
              )}
            </div>
            <p className="text-sm text-surface-400">
              Original ELIZABETH MGOMBELO PDF-based template
            </p>
          </div>
          <Button
            variant={currentTemplateId ? "outline" : "secondary"}
            size="sm"
            onClick={onCreateDefault}
          >
            {currentTemplateId ? "Use" : "Active"}
          </Button>
        </CardBody>
      </Card>

      {/* Uploaded templates */}
      {loading ? (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3].map((i) => (
            <div
              key={i}
              className="h-48 shimmer rounded-2xl"
              style={{ animationDelay: `${i * 100}ms` }}
            />
          ))}
        </div>
      ) : templates.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-surface-200 bg-surface-50/50 p-12 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-surface-100 text-surface-300">
            <Icon name="upload" className="h-8 w-8" />
          </div>
          <h4 className="font-display text-lg font-semibold text-surface-700">
            No templates uploaded yet
          </h4>
          <p className="mt-2 max-w-sm mx-auto text-sm text-surface-400">
            Upload a PDF, Adobe Illustrator file, or screenshot to create your
            own ID card template.
          </p>
          <Button
            className="mt-4"
            onClick={onUploadNew}
            icon={<Icon name="upload" className="h-4 w-4" />}
          >
            Upload Your First Template
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {templates.map((template) => (
            <div
              key={template.id}
              className={`group cursor-pointer rounded-2xl transition-all duration-200 hover:-translate-y-0.5 hover:shadow-elevated-2 ${
                currentTemplateId === template.id
                  ? "ring-2 ring-council-500 ring-offset-2"
                  : ""
              }`}
              onClick={() => onSelectTemplate(template)}
            >
              <Card>
                <CardBody className="p-4">
                  {/* Thumbnail */}
                  <div className="relative mb-3 aspect-[502/325] overflow-hidden rounded-xl bg-surface-100">
                    {template.sourceType === "image" && template.fileDataUrl ? (
                      <img
                        src={template.fileDataUrl}
                        alt={template.name}
                        className="h-full w-full object-cover"
                        loading="lazy"
                      />
                    ) : (
                      <div className="flex h-full items-center justify-center">
                        <Icon
                          name={getTypeIcon(template.sourceType)}
                          className="h-12 w-12 text-surface-300"
                        />
                      </div>
                    )}

                    {currentTemplateId === template.id && (
                      <div className="absolute top-2 right-2 rounded-full bg-council-500 px-2 py-0.5 text-[10px] font-medium text-white shadow-lg">
                        Active
                      </div>
                    )}

                    <div className={`absolute top-2 left-2 rounded-full px-2 py-0.5 text-[10px] font-medium ${getTypeBadge(template.sourceType)}`}>
                      {template.sourceType.toUpperCase()}
                    </div>

                    <div className="absolute inset-0 flex items-center justify-center bg-black/0 transition-colors group-hover:bg-black/20">
                      <Button
                        variant="primary"
                        size="sm"
                        className="opacity-0 transition-opacity group-hover:opacity-100"
                        onClick={(e: React.MouseEvent) => {
                          e.stopPropagation();
                          onSelectTemplate(template);
                        }}
                      >
                        Edit Template
                      </Button>
                    </div>
                  </div>

                  {/* Info */}
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <h4 className="truncate text-sm font-medium text-surface-800">
                        {template.name}
                      </h4>
                      <p className="text-xs text-surface-400">
                        {template.fields.length} fields · {formatDate(template.createdAt)}
                      </p>
                    </div>

                    <div className="flex shrink-0 items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                      <button
                        onClick={(e: React.MouseEvent) => {
                          e.stopPropagation();
                          void handleSetActive(template);
                        }}
                        className="rounded-lg p-1.5 text-surface-400 hover:bg-council-50 hover:text-council-600"
                        title="Set as active"
                      >
                        <Icon name="check" className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={(e: React.MouseEvent) => {
                          e.stopPropagation();
                          void handleDuplicate(template);
                        }}
                        className="rounded-lg p-1.5 text-surface-400 hover:bg-surface-100 hover:text-surface-600"
                        title="Duplicate"
                      >
                        <Icon name="refresh" className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={(e: React.MouseEvent) => {
                          e.stopPropagation();
                          setConfirmDelete(template);
                        }}
                        className="rounded-lg p-1.5 text-surface-400 hover:bg-red-50 hover:text-red-600"
                        title="Delete"
                      >
                        <Icon name="trash" className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                </CardBody>
              </Card>
            </div>
          ))}
        </div>
      )}

      <ConfirmDialog
        open={!!confirmDelete}
        options={{
          title: "Delete Template",
          message: (
            <span>
              Are you sure you want to delete <strong>{confirmDelete?.name}</strong>?
              This action cannot be undone.
            </span>
          ),
          confirmLabel: "Delete",
          danger: true,
          loading: deleting,
          onConfirm: handleDelete,
        }}
        onCancel={() => setConfirmDelete(null)}
      />
    </div>
  );
}
