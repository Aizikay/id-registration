Set-Location 'C:\Users\hp\Pictures\ID Registration & Issuance Management System.(MERU DC) - Copy'
Write-Output "Installing dev deps (electron, electron-builder)..."
& C:\npm.cmd install --save-dev electron electron-builder --no-audit --no-fund 2>&1 | Select-Object -Last 12
Write-Output "DEV_EXIT=$LASTEXITCODE"
Write-Output "Installing electron-updater..."
& C:\npm.cmd install electron-updater --no-audit --no-fund 2>&1 | Select-Object -Last 8
Write-Output "UPDATER_EXIT=$LASTEXITCODE"
& C:\node.exe -e "const p=require('./package.json'); console.log('electron:', p.devDependencies.electron, '| builder:', p.devDependencies['electron-builder'], '| updater:', p.dependencies['electron-updater'])"
