import { useEffect, useState } from "react";
import { Card, CardHeader, PageHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/form";
import {
  ErrorState,
  SkeletonRows,
  TBody,
  TD,
  TH,
  THead,
  TR,
  Table
} from "@/components/ui/data-table";
import { Icon } from "@/components/icons/icon";
import {
  fetchStaffActivity,
  type StaffActivityRow
} from "@/services/reports-service";
import { queryIssuancesOnline } from "@/services/issuance-service";
import type { CachedIssuance } from "@/db/database";
import { mapSupabaseError } from "@/services/errors";
import { formatDateTime, humanize } from "@/lib/format";

type Tab = "issuance" | "staff" | "duplicates" | "failed_prints";

const TABS: readonly { id: Tab; label: string; icon: Parameters<typeof Icon>[0]["name"] }[] = [
  { id: "issuance", label: "Daily issuance", icon: "id-card" },
  { id: "staff", label: "Staff activity", icon: "users" },
  { id: "failed_prints", label: "Failed prints", icon: "alert-triangle" }
];

export function ReportsPage() {
  const [tab, setTab] = useState<Tab>("issuance");
  const [from, setFrom] = useState(firstOfMonth());
  const [to, setTo] = useState(today());

  return (
    <div className="animate-fade-in">
      <PageHeader
        title="Reports"
        subtitle="Operational reporting for supervisors and administrators"
        actions={
          <div className="flex items-end gap-2">
            <Input
              aria-label="From date"
              type="date"
              value={from}
              onChange={(e) => setFrom(e.target.value)}
              className="w-40"
            />
            <Input
              aria-label="To date"
              type="date"
              value={to}
              onChange={(e) => setTo(e.target.value)}
              className="w-40"
            />
          </div>
        }
      />

      <div className="mb-4 flex flex-wrap gap-1.5" role="tablist" aria-label="Report sections">
        {TABS.map((t) => (
          <button
            key={t.id}
            role="tab"
            aria-selected={tab === t.id}
            onClick={() => setTab(t.id)}
            className={`inline-flex items-center gap-2 rounded-lg border px-3.5 py-2 text-xs font-semibold transition-colors ${
              tab === t.id
                ? "border-council-800 bg-council-800 text-white shadow-sm"
                : "border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700"
            }`}
          >
            <Icon name={t.icon} className="h-4 w-4" strokeWidth={1.75} />
            {t.label}
          </button>
        ))}
      </div>

      {tab === "issuance" && <IssuanceReport from={from} to={to} />}
      {tab === "staff" && <StaffActivityReport from={from} to={to} />}
      {tab === "failed_prints" && <FailedPrintsReport from={from} to={to} />}
    </div>
  );
}

function IssuanceReport({ from, to }: { from: string; to: string }) {
  const [rows, setRows] = useState<(CachedIssuance & { persons?: { full_name: string } })[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    queryIssuancesOnline({
      page: 0,
      pageSize: 100,
      from: new Date(from).toISOString(),
      to: new Date(`${to}T23:59:59`).toISOString()
    })
      .then((r: { rows: (CachedIssuance & { persons?: { full_name: string } })[]; total: number }) => {
        if (!cancelled) {
          setRows(r.rows);
          setTotal(r.total);
        }
      })
      .catch((err: unknown) => !cancelled && setError(mapSupabaseError(err).userMessage))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [from, to]);

  const exportCsv = (): void => {
    const header = "Reference,Person,ID Number,Status,Issued By,Issued At\n";
    const body = rows
      .map(
        (r) =>
          `${r.issuance_reference},"${r.persons?.full_name ?? ""}",${r.identification_number ?? ""},${r.status},${r.issued_by_staff_number ?? ""},${r.issued_at ?? ""}`
      )
      .join("\n");
    downloadFile(`daily-issuance-${from}-to-${to}.csv`, header + body);
  };

  return (
    <Card className="overflow-hidden">
      <CardHeader
        title={`Issuance records — ${formatDateTime(from)} → ${to}`}
        subtitle={`${total.toLocaleString()} record(s)`}
        actions={
          <Button size="sm" variant="outline" onClick={exportCsv} disabled={rows.length === 0}>
            <Icon name="download" className="h-4 w-4" /> Export CSV
          </Button>
        }
      />
      <ReportTable loading={loading} error={error} isEmpty={rows.length === 0} emptyLabel="No issuances in this period">
        <THead>
          <TR>
            <TH>Reference</TH>
            <TH>Person</TH>
            <TH>Staff</TH>
            <TH>Date</TH>
          </TR>
        </THead>
        <TBody>
          {rows.map((r) => (
            <TR key={r.id}>
              <TD className="font-mono text-xs">{r.issuance_reference}</TD>
              <TD>{r.persons?.full_name ?? r.person_name ?? "—"}</TD>
              <TD className="font-mono text-xs">{r.issued_by_staff_number ?? "—"}</TD>
              <TD className="text-xs">{formatDateTime(r.issued_at ?? r.created_at)}</TD>
            </TR>
          ))}
        </TBody>
      </ReportTable>
    </Card>
  );
}

function StaffActivityReport({ from, to }: { from: string; to: string }) {
  const [rows, setRows] = useState<StaffActivityRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    fetchStaffActivity(new Date(from).toISOString(), new Date(`${to}T23:59:59`).toISOString())
      .then((r: StaffActivityRow[]) => !cancelled && setRows(r))
      .catch((err: unknown) => !cancelled && setError(mapSupabaseError(err).userMessage))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [from, to]);

  const max = Math.max(...rows.map((r) => r.issuances), 1);

  return (
    <Card className="overflow-hidden">
      <CardHeader title="Staff activity — issuances per officer" subtitle={`${from} → ${to}`} />
      <ReportTable loading={loading} error={error} isEmpty={rows.length === 0} emptyLabel="No staff activity in this period">
        <THead>
          <TR>
            <TH>Staff №</TH>
            <TH>Name</TH>
            <TH>Role</TH>
            <TH className="w-1/3">Issuances</TH>
          </TR>
        </THead>
        <TBody>
          {rows.map((r) => (
            <TR key={r.staff_number}>
              <TD className="font-mono text-xs font-semibold">{r.staff_number}</TD>
              <TD>{r.full_name}</TD>
              <TD className="text-xs capitalize">{humanize(r.role)}</TD>
              <TD>
                <div className="flex items-center gap-2">
                  <div className="h-2.5 flex-1 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-700">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-council-600 to-council-400"
                      style={{ width: `${(r.issuances / max) * 100}%` }}
                    />
                  </div>
                  <span className="w-8 text-right text-xs font-bold tabular-nums">{r.issuances}</span>
                </div>
              </TD>
            </TR>
          ))}
        </TBody>
      </ReportTable>
    </Card>
  );
}

function FailedPrintsReport({ from, to }: { from: string; to: string }) {
  const [rows, setRows] = useState<(CachedIssuance & { persons?: { full_name: string } })[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    queryIssuancesOnline({
      page: 0,
      pageSize: 100,
      status: "failed",
      from: new Date(from).toISOString(),
      to: new Date(`${to}T23:59:59`).toISOString()
    })
      .then((r: { rows: (CachedIssuance & { persons?: { full_name: string } })[]; total: number }) => {
        if (!cancelled) {
          setRows(r.rows);
          setTotal(r.total);
        }
      })
      .catch((err: unknown) => !cancelled && setError(mapSupabaseError(err).userMessage))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [from, to]);

  return (
    <Card className="overflow-hidden">
      <CardHeader title="Failed print jobs" subtitle={`${total.toLocaleString()} failed job(s) in period`} />
      <ReportTable loading={loading} error={error} isEmpty={rows.length === 0} emptyLabel="No failed prints in this period">
        <THead>
          <TR>
            <TH>Reference</TH>
            <TH>Person</TH>
            <TH>Reason</TH>
            <TH>When</TH>
          </TR>
        </THead>
        <TBody>
          {rows.map((r) => (
            <TR key={r.id}>
              <TD className="font-mono text-xs">{r.issuance_reference}</TD>
              <TD>{r.persons?.full_name ?? "—"}</TD>
              <TD className="max-w-[240px] truncate text-xs text-red-600" title={r.failure_reason ?? ""}>
                {r.failure_reason ?? "—"}
              </TD>
              <TD className="text-xs">{formatDateTime(r.updated_at)}</TD>
            </TR>
          ))}
        </TBody>
      </ReportTable>
    </Card>
  );
}

function ReportTable({
  loading,
  error,
  isEmpty,
  emptyLabel,
  children
}: {
  loading: boolean;
  error: string | null;
  isEmpty: boolean;
  emptyLabel: string;
  children: React.ReactNode;
}) {
  if (error) return <ErrorState message={error} onRetry={() => window.location.reload()} />;
  if (loading)
    return (
      <Table>
        <SkeletonRows rows={6} cols={4} />
      </Table>
    );
  if (isEmpty) {
    return (
      <div className="px-6 py-10 text-center text-sm text-slate-500 dark:text-slate-400">
        {emptyLabel}
      </div>
    );
  }
  return children;
}

function downloadFile(filename: string, content: string): void {
  const blob = new Blob([content], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function today(): string {
  return new Date().toISOString().slice(0, 10);
}

function firstOfMonth(): string {
  const d = new Date();
  return new Date(d.getFullYear(), d.getMonth(), 1).toISOString().slice(0, 10);
}
