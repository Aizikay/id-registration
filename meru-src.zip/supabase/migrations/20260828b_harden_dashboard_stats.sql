-- =============================================================
-- Migration: Harden dashboard stats RPC
-- Date: 2026-08-28
-- =============================================================
-- The hosted DB's get_dashboard_stats() was callable by the anon
-- role (security definer + no revoke), leaking registry-wide
-- statistics to unauthenticated users, and its daily_last_7_days
-- key (`issued`) did not match the app (`issued_count`).
-- This replaces it with the canonical definition (00002) and
-- restricts EXECUTE to authenticated only.

create or replace function public.get_dashboard_stats()
returns jsonb
language sql
stable
security definer
set search_path = public
as $$
  select jsonb_build_object(
    'total_registered', (select count(*) from public.persons),
    'total_issued', (select count(*) from public.issuance_records where status = 'issued'),
    'total_pending', (select count(*) from public.issuance_records where status in ('pending','printing','reprint_requested')),
    'total_failed_prints', (select count(*) from public.issuance_records where status = 'failed'),
    'today_issued', (select count(*) from public.issuance_records where status='issued' and issued_at >= date_trunc('day', now())),
    'online_devices', (select count(*) from public.workstation_devices where status='active' and last_online_at > now() - interval '15 minutes'),
    'printers_online', (select count(*) from public.printers where status='online' and enabled),
    'printers_total', (select count(*) from public.printers where enabled),
    'recent_issuances', (
      select coalesce(jsonb_agg(x), '[]'::jsonb) from (
        select i.issuance_reference, i.issued_at, i.status, pr.full_name as person_name,
               pr.identification_number, pf.staff_number as issued_by_staff
        from public.issuance_records i
        join public.persons pr on pr.id = i.person_id
        left join public.profiles pf on pf.id = i.issued_by
        order by coalesce(i.issued_at, i.created_at) desc
        limit 10
      ) x
    ),
    'daily_last_7_days', (
      select coalesce(jsonb_agg(x order by x.day), '[]'::jsonb) from (
        select d::date as day,
               (select count(*) from public.issuance_records
                 where status='issued' and issued_at >= d and issued_at < d + interval '1 day') as issued_count
        from generate_series(date_trunc('day', now()) - interval '6 days', date_trunc('day', now()), interval '1 day') d
      ) x
    )
  );
$$;

-- Only authenticated staff may read the aggregate; no anon access.
revoke execute on function public.get_dashboard_stats() from anon;
grant execute on function public.get_dashboard_stats() to authenticated;