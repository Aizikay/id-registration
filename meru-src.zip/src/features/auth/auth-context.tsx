/**
 * Authentication context.
 *
 * - Supabase Auth for credentials/sessions (no custom password handling).
 * - Loads the staff profile + role and exposes permission checks.
 * - Supports a strictly-bounded OFFLINE SESSION: after a successful online
 *   sign-in we store a signed capability (HMAC of device id + expiry using
 *   WebCrypto). It permits previously-authorized operation while offline but
 *   never stores passwords and always expires per admin policy.
 */

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode
} from "react";
import type { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/services/supabase-client";
import { mapSupabaseError } from "@/services/errors";
import type { Profile } from "@/types";
import { env, isSupabasePlaceholder } from "@/lib/env";
import { getDeviceId } from "@/offline/device";
import { purgeLocalData } from "@/db/database";
import { SyncEngine } from "@/sync/engine";
import {
  authProfileCache
} from "@/services/audit-service";
import { can as canImpl, type Permission } from "@/lib/permissions";

export interface AuthState {
  /** null = initial load; otherwise resolved */
  loading: boolean;
  session: Session | null;
  user: User | null;
  profile: Profile | null;
  online: boolean;
  /** true when offline access is granted via bounded offline capability */
  offlineSession: boolean;
}

export interface AuthActions {
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  can: (permission: Permission) => boolean;
}

const AuthContext = createContext<(AuthState & AuthActions) | null>(null);

const OFFLINE_CAP_KEY = "meru_offline_cap_v1";

interface OfflineCapability {
  userId: string;
  profileId: string;
  staffNumber: string;
  issuedAt: number;
  expiresAt: number;
  hmac: string;
}

async function hmacSign(payload: string): Promise<string> {
  // Device-bound key material: derived from random secret generated on this
  // device at first run and stored in IndexedDB meta. An attacker copying the
  // capability to another device cannot validate it without that key.
  const encoder = new TextEncoder();
  const deviceId = await getDeviceId();
  const keyMaterial = await crypto.subtle.importKey(
    "raw",
    encoder.encode(`meru-id-offline-cap:${deviceId}`),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", keyMaterial, encoder.encode(payload));
  return Array.from(new Uint8Array(sig), (b) =>
    b.toString(16).padStart(2, "0")
  ).join("");
}

async function issueOfflineCapability(
  user: User,
  profile: Profile
): Promise<void> {
  const now = Date.now();
  const expiresAt = now + env.maxOfflineHours * 3_600_000;
  const base = JSON.stringify({
    userId: user.id,
    profileId: profile.id,
    staffNumber: profile.staff_number,
    issuedAt: now,
    expiresAt
  });
  const cap: OfflineCapability = {
    userId: user.id,
    profileId: profile.id,
    staffNumber: profile.staff_number,
    issuedAt: now,
    expiresAt,
    hmac: await hmacSign(base)
  };
  await purgeStaleCapabilityIfAny();
  localStorage.setItem(OFFLINE_CAP_KEY, base);
  sessionStorage.setItem(`${OFFLINE_CAP_KEY}:sig`, cap.hmac);
}

async function purgeStaleCapabilityIfAny(): Promise<void> {
  localStorage.removeItem(OFFLINE_CAP_KEY);
  sessionStorage.removeItem(`${OFFLINE_CAP_KEY}:sig`);
}

/** Validate any stored offline capability. Returns profile id if valid. */
async function readOfflineCapability(): Promise<OfflineCapability | null> {
  const base = localStorage.getItem(OFFLINE_CAP_KEY);
  const sig = sessionStorage.getItem(`${OFFLINE_CAP_KEY}:sig`);
  if (!base || !sig) return null;

  let parsed: Omit<OfflineCapability, "hmac">;
  try {
    parsed = JSON.parse(base);
  } catch {
    await purgeStaleCapabilityIfAny();
    return null;
  }
  if (Date.now() > parsed.expiresAt) {
    await purgeStaleCapabilityIfAny();
    return null;
  }
  const expected = await hmacSign(base);
  if (expected !== sig) {
    await purgeStaleCapabilityIfAny(); // tampered or moved device
    return null;
  }
  return { ...parsed, hmac: sig };
}

function cacheAuthIdentity(profile: Profile | null): void {
  authProfileCache.profileId = profile?.id ?? null;
  authProfileCache.staffNumber = profile?.staff_number ?? null;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [loading, setLoading] = useState(true);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [online, setOnline] = useState(navigator.onLine);
  const [offlineSession, setOfflineSession] = useState(false);
  const bootstrapped = useRef(false);

  const loadProfile = useCallback(async (userId: string): Promise<Profile | null> => {
    const { data, error } = await supabase
      .from("profiles")
      .select("*")
      .eq("user_id", userId)
      .maybeSingle();
    if (error && mapSupabaseError(error).code !== "network_unavailable") {
      throw mapSupabaseError(error);
    }
    const prof = (data as Profile | null) ?? null;
    if (
      prof &&
      prof.status === "disabled" &&
      navigator.onLine
    ) {
      // Disabled account: hard stop.
      await supabase.auth.signOut();
      await purgeLocalData();
      return null;
    }
    return prof;
  }, []);

  useEffect(() => {
    if (bootstrapped.current) return;
    bootstrapped.current = true;

    let mounted = true;

    const bootstrap = async () => {
      // Fail fast when Supabase is not configured — don't hang on DNS timeout.
      if (isSupabasePlaceholder) {
        if (mounted) setLoading(false);
        return;
      }
      try {
        // Race getSession against a 4s timeout so a dead placeholder host never blocks UI.
        const sessionResult = await Promise.race([
          supabase.auth.getSession(),
          new Promise<{ data: { session: null } }>((resolve) =>
            setTimeout(() => resolve({ data: { session: null } }), 4000)
          )
        ]);
        const currentSession = (sessionResult as { data: { session: Session | null } }).data.session;
        if (mounted) setSession(currentSession);

        if (currentSession?.user) {
          const prof = await Promise.race([
            loadProfile(currentSession.user.id),
            new Promise<Profile | null>((resolve) => setTimeout(() => resolve(null), 4000))
          ]);
          if (mounted) {
            setProfile(prof);
            cacheAuthIdentity(prof);
          }
          if (prof) await issueOfflineCapability(currentSession.user, prof);
        } else {
          // Possibly an offline session with a valid capability.
          const cap = await readOfflineCapability();
          if (cap && !navigator.onLine) {
            if (mounted) setOfflineSession(true);
          }
        }
      } catch {
        // Supabase unreachable — allow UI to render (will redirect to /login with hint)
      } finally {
        if (mounted) setLoading(false);
      }

      supabase.auth.onAuthStateChange((event, newSession) => {
        if (!mounted) return;
        setSession(newSession);
        if (event === "SIGNED_OUT") {
          setProfile(null);
          cacheAuthIdentity(null);
          setOfflineSession(false);
          void purgeLocalData();
        }
        if (event === "TOKEN_REFRESHED" && newSession?.user && profile === null) {
          void loadProfile(newSession.user.id).then((prof) => {
            if (prof) {
              setProfile(prof);
              cacheAuthIdentity(prof);
            }
          });
        }
      });
    };

    void bootstrap();

    const goOnline = () => {
      setOnline(true);
      SyncEngine.setOnline(true);
    };
    const goOffline = () => {
      setOnline(false);
      SyncEngine.setOnline(false);
    };
    window.addEventListener("online", goOnline);
    window.addEventListener("offline", goOffline);

    return () => {
      mounted = false;
      window.removeEventListener("online", goOnline);
      window.removeEventListener("offline", goOffline);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Register this workstation once authenticated — temporarily disabled to avoid
  // blank-screen race when workstation_devices RLS/table is misconfigured on cloud.
  // The sync engine and manual device registration via /app/devices still work.
  void profile;
  void getDeviceId;

  const signIn = useCallback(
    async (email: string, password: string) => {
      const { error, data } = await supabase.auth.signInWithPassword({
        email,
        password
      });
      if (error) {
        const mapped =
          error.message.toLowerCase().includes("invalid login") ||
          error.message.toLowerCase().includes("email not confirmed")
            ? mapSupabaseError({ code: "auth_failed", message: error.message })
            : mapSupabaseError(error);
        throw mapped;
      }
      if (data.session && data.user) {
        const prof = await loadProfile(data.user.id);
        setProfile(prof);
        cacheAuthIdentity(prof);
        if (prof) await issueOfflineCapability(data.user, prof);
        SyncEngine.start();
        void SyncEngine.sync();
      }
    },
    [loadProfile]
  );

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
    await purgeLocalData();
    setProfile(null);
    setSession(null);
    cacheAuthIdentity(null);
    setOfflineSession(false);
    SyncEngine.stop();
  }, []);

  const can = useCallback(
    (permission: Permission) =>
      profile !== null && canImpl(profile.role, permission),
    [profile]
  );

  const value = useMemo(
    () => ({
      loading,
      session,
      user: session?.user ?? null,
      profile,
      online,
      offlineSession,
      signIn,
      signOut,
      refreshProfile: async () => {
        if (session?.user) {
          const prof = await loadProfile(session.user.id);
          setProfile(prof);
          cacheAuthIdentity(prof);
        }
      },
      can
    }),
    [loading, session, profile, online, offlineSession, signIn, signOut, can, loadProfile]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthState & AuthActions {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within <AuthProvider>");
  return ctx;
}
