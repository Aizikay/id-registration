import { describe, it, expect } from "vitest";
import { can, permissionsFor } from "./permissions";

describe("can", () => {
  it("returns false for null role", () => expect(can(null, "people.view")).toBe(false));
  it("returns false for undefined role", () => expect(can(undefined, "people.view")).toBe(false));

  it("admin has all critical permissions", () => {
    expect(can("admin", "people.create")).toBe(true);
    expect(can("admin", "issuance.create")).toBe(true);
    expect(can("admin", "users.manage")).toBe(true);
    expect(can("admin", "printers.manage")).toBe(true);
    expect(can("admin", "settings.manage")).toBe(true);
    expect(can("admin", "conflicts.resolve")).toBe(true);
  });

  it("officer can register and issue but not manage users", () => {
    expect(can("officer", "people.create")).toBe(true);
    expect(can("officer", "issuance.create")).toBe(true);
    expect(can("officer", "print.request")).toBe(true);
    expect(can("officer", "users.manage")).toBe(false);
    expect(can("officer", "print.reprint")).toBe(false);
  });

  it("supervisor can reprint but not create issuances", () => {
    expect(can("supervisor", "print.reprint")).toBe(true);
    expect(can("supervisor", "reports.export")).toBe(true);
    expect(can("supervisor", "issuance.create")).toBe(false);
    expect(can("supervisor", "people.create")).toBe(false);
  });

  it("viewer is read-only", () => {
    expect(can("viewer", "people.view")).toBe(true);
    expect(can("viewer", "issuance.view")).toBe(true);
    expect(can("viewer", "people.create")).toBe(false);
    expect(can("viewer", "reports.view")).toBe(false);
  });
});

describe("permissionsFor", () => {
  it("admin has the largest permission set", () => {
    const adminCount = permissionsFor("admin").length;
    expect(adminCount).toBeGreaterThan(permissionsFor("officer").length);
    expect(adminCount).toBeGreaterThan(permissionsFor("viewer").length);
  });
});
