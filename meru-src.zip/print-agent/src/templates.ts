/**
 * Printable ID card document.
 * The agent renders this HTML to a temporary file and asks Windows to print it.
 * Keep the design self-contained (inline styles, no external assets) so printing
 * works offline and without additional dependencies.
 */

export interface CardData {
  personName: string;
  identificationNumber: string;
  issuedByStaffNumber: string | null;
  issuedAtIso: string;
  issuanceReference: string;
  documentReference: string;
  councilNameSw: string;
  councilNameEn: string;
}

/** Dual-page card data — front and back rendered on the same sheet. */
export interface DualPageCardData extends CardData {
  /** Base64 data URI or URL of the front page image. */
  frontImageSrc: string;
  /** Base64 data URI or URL of the back page image. */
  backImageSrc: string;
  /** Optional: editable text overlays for the front page. */
  frontOverlays?: {
    chekiNamba?: string;
    jina?: string;
    cheo?: string;
    photoSrc?: string;
    signatureSrc?: string;
  };
}

function esc(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

export function renderIdCardHtml(d: CardData): string {
  const issuedAt = (() => {
    try {
      return new Date(d.issuedAtIso).toLocaleString("en-GB", {
        year: "numeric",
        month: "long",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit"
      });
    } catch {
      return d.issuedAtIso;
    }
  })();

  return `<!doctype html>
<html lang="en">
<meta charset="utf-8">
<title>ID Card — ${esc(d.identificationNumber)}</title>
<style>
  @page { size: A4; margin: 12mm; }
  * { box-sizing: border-box; }
  body { font-family: "Segoe UI", Arial, Helvetica, sans-serif; color: #0f172a; margin: 0; }
  .page { width: 86mm; margin: 0 auto; border: 2px solid #0f4c5c; border-radius: 10px; overflow: hidden; }
  .header { background: #0f4c5c; color: #fff; text-align: center; padding: 10px 12px; }
  .header h1 { margin: 0; font-size: 11px; letter-spacing: 0.08em; font-weight: 800; }
  .header p { margin: 2px 0 0; font-size: 9px; opacity: 0.9; }
  .body { padding: 14px 14px 10px; }
  .photo { width: 28mm; height: 34mm; border: 1px solid #cbd5e1; border-radius: 6px; background: #f1f5f9; display: flex; align-items: center; justify-content: center; color: #94a3b8; font-size: 9px; float: right; margin: 0 0 8px 10px; }
  .field { margin: 7px 0; }
  .label { font-size: 7px; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase; color: #64748b; }
  .value { font-size: 11px; font-weight: 700; margin-top: 1px; word-break: break-all; }
  .value.mono { font-family: "Consolas", "Courier New", monospace; font-size: 10px; }
  .divider { border: none; border-top: 1px dashed #cbd5e1; margin: 10px 0; }
  .footer { background: #f8fafc; border-top: 1px solid #e2e8f0; padding: 8px 14px; font-size: 7px; color: #64748b; text-align: center; }
  .badge { display: inline-block; background: #0ea5e9; color: #fff; font-size: 7px; font-weight: 800; letter-spacing: 0.06em; padding: 2px 6px; border-radius: 99px; margin-top: 6px; }
</style>
<div class="page">
  <div class="header">
    <h1>${esc(d.councilNameSw)}</h1>
    <p>${esc(d.councilNameEn)} &middot; ${esc(d.issuanceReference)}</p>
  </div>
  <div class="body">
    <div class="photo">PHOTO</div>
    <div class="field"><div class="label">Full Name</div><div class="value">${esc(d.personName)}</div></div>
    <div class="field"><div class="label">Identification Number</div><div class="value mono">${esc(d.identificationNumber)}</div></div>
    <div class="field"><div class="label">Document Reference</div><div class="value mono">${esc(d.documentReference)}</div></div>
    <hr class="divider">
    <div class="field"><div class="label">Issued At</div><div class="value">${esc(issuedAt)}</div></div>
    <div class="field"><div class="label">Issued By</div><div class="value">${esc(d.issuedByStaffNumber ?? "—")}</div></div>
    <span class="badge">MERU DC &middot; ARUSHA, TANZANIA</span>
  </div>
  <div class="footer">
    This card is the property of ${esc(d.councilNameEn)}. If found, return to the nearest Meru District Council office.
    &middot; Ref ${esc(d.issuanceReference)}
  </div>
</div>
<script>window.onload = function(){ try{ window.print(); }catch(e){} };</script>
</html>`;
}

export function renderDualPageIdCardHtml(d: DualPageCardData): string {
  const issuedAt = (() => {
    try {
      return new Date(d.issuedAtIso).toLocaleString("en-GB", {
        year: "numeric",
        month: "long",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit"
      });
    } catch {
      return d.issuedAtIso;
    }
  })();

  const o = d.frontOverlays ?? {};

  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>ID Card — ${esc(d.identificationNumber)}</title>
<style>
  @page { size: 86mm 54mm; margin: 0; }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: "Segoe UI", Arial, Helvetica, sans-serif; color: #0f172a; background: white; }

  .card-page {
    width: 86mm;
    height: 54mm;
    position: relative;
    overflow: hidden;
    page-break-after: always;
    page-break-inside: avoid;
  }
  .card-page:last-child {
    page-break-after: auto;
  }

  .card-page img.bg {
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
  }

  /* Front page text overlays — positioned exactly over the template fields */
  .overlay-text {
    position: absolute;
    font-family: "Arial Narrow", Arial, Helvetica, sans-serif;
    font-weight: 700;
    color: #000;
    text-transform: uppercase;
    letter-spacing: 0;
    line-height: 1;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .overlay-photo {
    position: absolute;
    object-fit: cover;
    border-radius: 1mm;
  }
  .overlay-signature {
    position: absolute;
    object-fit: contain;
  }

  /* Back page — full bleed image, no overlays */

  @media print {
    body { margin: 0; padding: 0; }
    .card-page { box-shadow: none; border-radius: 0; margin: 0; }
  }
</style>
</head>
<body>

  <!-- ═══════════ FRONT PAGE ═══════════ -->
  <div class="card-page">
    <img class="bg" src="${d.frontImageSrc}" alt="ID Card Front" />

    ${o.chekiNamba ? `<span class="overlay-text" style="left:28.3%;top:44.5%;font-size:2.8mm;">${esc(o.chekiNamba)}</span>` : ""}
    ${o.jina ? `<span class="overlay-text" style="left:28.3%;top:52.5%;font-size:2.8mm;">${esc(o.jina)}</span>` : ""}
    ${o.cheo ? `<span class="overlay-text" style="left:28.3%;top:59.5%;font-size:2.8mm;">${esc(o.cheo)}</span>` : ""}
    ${o.photoSrc ? `<img class="overlay-photo" src="${o.photoSrc}" style="left:68%;top:20%;width:22%;height:42%;" />` : ""}
    ${o.signatureSrc ? `<img class="overlay-signature" src="${o.signatureSrc}" style="left:28.3%;top:64%;height:8%;" />` : ""}
  </div>

  <!-- ═══════════ BACK PAGE ═══════════ -->
  <div class="card-page">
    <img class="bg" src="${d.backImageSrc}" alt="ID Card Back" />
  </div>

  <script>window.onload=function(){try{window.print()}catch(e){}}</script>
</body>
</html>`;
}

export function renderTestPageHtml(printerName: string): string {
  return `<!doctype html><meta charset="utf-8"><title>Test Page</title>
<style>body{font-family:"Segoe UI",Arial,sans-serif;padding:24px;color:#0f172a}.box{border:2px solid #0f4c5c;border-radius:12px;padding:24px;max-width:480px}h1{margin:0 0 6px;font-size:18px;color:#0f4c5c}p{margin:4px 0;color:#334155}.mono{font-family:Consolas,monospace}hr{border:none;border-top:1px dashed #cbd5e1;margin:16px 0}</style>
<div class="box">
  <h1>Meru District Council — Print Agent Test Page</h1>
  <p>Printer: <strong class="mono">${esc(printerName)}</strong></p>
  <p>Generated: ${esc(new Date().toLocaleString())}</p>
  <hr>
  <p style="font-size:13px">If you can read this, the printer is reachable from the Print Agent (localhost:8377) and Windows printing is configured correctly.</p>
  <p style="font-size:11px;color:#64748b">Agent version 1.0.0 &middot; This page was sent via POST /test.</p>
</div>
<script>window.onload=function(){try{window.print()}catch(e){}}</script>`;
}
