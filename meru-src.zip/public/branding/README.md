# Branding Assets — Meru District Council

Place **authorized, official** image files in this directory. The application never ships fabricated logos; when a file is missing, a styled text placeholder is rendered instead (see `src/components/branding/logo.tsx`).

## Required files

| File | Recommended size | Description |
|------|-----------------|-------------|
| `meru-district-council-logo.png` | 512×512, transparent | Primary council logo used in header, login and print card |
| `tanzania-coat-of-arms.png` | 512×512 | Coat of arms — header accent and printed card |
| `tanzania-flag.png` | 800×533 | Flag accent (optional) |
| `app-icon-192.png` | 192×192 | PWA icon (manifest) |
| `app-icon-512.png` | 512×512 | PWA icon (manifest) |
| `app-icon-maskable-512.png` | 512×512, safe zone 20% | Maskable PWA icon |

All paths are defined in `src/lib/constants.ts#BRANDING_ASSETS` — replace filenames there if the council supplies different names.

## How to add assets

1. Obtain the official files from the Meru District Council communications office.
2. Optimize PNGs (e.g. https://tinypng.com) — keep each under 300 KB.
3. Drop them into `public/branding/` with the exact filenames above.
4. No code change or rebuild is required — Vite serves `public/` statically.
5. Verify in the browser: hard-refresh (`Ctrl+Shift+R`) and check the header and login page.

## ID Card Template PDF (CRITICAL)

The original **ELIZABETH MGOMBELO ID.pdf** must be placed here as:

```
public/branding/meru-employee-id-template.pdf
```

This PDF is the **actual source of truth** — it is rendered via PDF.js and dynamic fields (name, check number, position, file number, photo) are overlaid with exact PDF coordinates. The system **does not** recreate the card with HTML/CSS; it uses the PDF directly for pixel-perfect print.

If the PDF is missing, the designer shows a placeholder and the print uses the browser fallback. Place the file and hard refresh (Ctrl+Shift+R).

## Placeholders

When a file is absent, the UI shows a text badge such as **“HALMASHAURI YA WILAYA YA MERU — Logo”** in council colours, so the system remains usable before official assets are provisioned.

## PWA

After adding the three app icons, the manifest in `vite.config.ts` will automatically use them for install prompts. Test with Chrome DevTools → Application → Manifest.
