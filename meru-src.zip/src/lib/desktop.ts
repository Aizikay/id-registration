/**
 * Desktop (Electron) bridge helpers.
 *
 * When the app runs inside the Electron shell, preload.ts exposes a typed,
 * minimal API on `window.meru`. In a plain browser `window.meru` is
 * undefined and every helper here degrades gracefully so the web build is
 * completely unaffected.
 */

import type { MeruDesktopBridge } from "@/types";

declare global {
  interface Window {
    meru?: MeruDesktopBridge;
  }
}

/** True when running inside the Electron desktop shell. */
export function isDesktop(): boolean {
  return typeof window !== "undefined" && window.meru?.isDesktop === true;
}

/** The desktop bridge, or null in a browser. */
export function desktop(): MeruDesktopBridge | null {
  return isDesktop() ? window.meru ?? null : null;
}

/** Path of the desktop's per-user data folder (null in browser). */
export async function getDataFolderPath(): Promise<string | null> {
  const d = desktop();
  if (!d) return null;
  try {
    return await d.getDataFolderPath();
  } catch {
    return null;
  }
}
