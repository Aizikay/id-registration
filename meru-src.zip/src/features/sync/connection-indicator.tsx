/**
 * Connection + sync status indicator.
 * Displays exactly: ONLINE / OFFLINE / SYNCING… / SYNC ERROR and
 * "Pending changes: N". Never pretends the system is synchronized.
 */

import { useSyncExternalStore } from "react";
import { SyncEngine } from "@/sync/engine";
import { db } from "@/db/database";
import { useLiveQuery } from "dexie-react-hooks";
import { cn } from "@/lib/cn";
import { Icon } from "@/components/icons/icon";

export function useSyncEngineState() {
  const state = useSyncExternalStore(
    (cb) => SyncEngine.subscribe(cb),
    () => SyncEngine.getState(),
    () => SyncEngine.getState()
  );
  const pending = useLiveQuery(
    () =>
      db.outbox
        .filter((e) => e.status === "pending" || e.status === "failed" || e.status === "in_flight")
        .count(),
    [],
    0
  );
  const conflicts = useLiveQuery(
    () => db.outbox.where("status").equals("conflict").count(),
    [],
    0
  );
  return { ...state, pending: pending ?? 0, conflicts: conflicts ?? 0 };
}

type Mode = "online" | "offline" | "syncing" | "sync-error";

const CONFIG: Record<Mode, { label: string; icon: "wifi" | "wifi-off" | "refresh" | "alert-circle"; classes: string; pulse?: boolean }> = {
  online: {
    label: "ONLINE",
    icon: "wifi",
    classes: "bg-emerald-50 text-emerald-700 border-emerald-200"
  },
  offline: {
    label: "OFFLINE",
    icon: "wifi-off",
    classes: "bg-slate-100 text-slate-600 border-slate-300"
  },
  syncing: {
    label: "SYNCING…",
    icon: "refresh",
    classes: "bg-sky-50 text-sky-700 border-sky-200",
    pulse: true
  },
  "sync-error": {
    label: "SYNC ERROR",
    icon: "alert-circle",
    classes: "bg-red-50 text-red-700 border-red-200"
  }
};

export function ConnectionBadge({ compact }: { compact?: boolean }) {
  const { online, running, lastError, pending, conflicts } = useSyncEngineState();

  let mode: Mode = online ? (running ? "syncing" : "online") : "offline";
  if (online && lastError) mode = "sync-error";

  // Offline with queued work is the most important state to surface honestly:
  if (!online && pending > 0 && mode === "offline") {
    return (
      <div className="flex items-center gap-2">
        <span
          className={cn(
            "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wide",
            CONFIG.offline.classes
          )}
          title={`Pending changes: ${pending}`}
        >
          <Icon name={CONFIG.offline.icon} className="h-3.5 w-3.5 animate-pulse-dot" />
          OFFLINE · {pending} pending
        </span>
      </div>
    );
  }

  if (conflicts > 0 && !compact) {
    return (
      <div className="flex items-center gap-2">
        <ModePill mode={mode} />
        <span className="inline-flex items-center gap-1.5 rounded-full border border-violet-200 bg-violet-50 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wide text-violet-700">
          <Icon name="alert-triangle" className="h-3.5 w-3.5" />
          {conflicts} conflict{conflicts === 1 ? "" : "s"}
        </span>
      </div>
    );
  }

  return <ModePill mode={mode} />;
}

function ModePill({ mode }: { mode: Mode }) {
  const cfg = CONFIG[mode];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wide",
        cfg.classes
      )}
      role="status"
    >
      <Icon
        name={cfg.icon}
        className={cn("h-3.5 w-3.5", cfg.pulse && (mode === "syncing" ? "animate-spin" : ""))}
      />
      {cfg.label}
    </span>
  );
}
