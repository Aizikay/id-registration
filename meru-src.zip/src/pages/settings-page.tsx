import { useState, useEffect, useCallback } from "react";
import Loader from "@/components/Loader";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Icon, type IconName } from "@/components/icons/icon";
import { useToast } from "@/components/ui/toast";
import { useAuth } from "@/features/auth/auth-context";
import { ORGANIZATION } from "@/lib/constants";
import { cn } from "@/lib/cn";
import { desktop } from "@/lib/desktop";

type ThemeMode = "light" | "dark" | "system";
type SettingsTab = "appearance" | "security" | "system";

const TABS: { id: SettingsTab; label: string; icon: IconName }[] = [
  { id: "appearance", label: "Appearance", icon: "eye" },
  { id: "security", label: "Security", icon: "shield-check" },
  { id: "system", label: "System Info", icon: "info" },
];

/* ── Helpers ─────────────────────────────────────────── */

function loadSetting<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw !== null ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function saveSetting(key: string, value: unknown) {
  localStorage.setItem(key, JSON.stringify(value));
}

/* ── Main Page ───────────────────────────────────────── */

export function SettingsPage() {
  const { profile, signOut } = useAuth();
  const navigate = useNavigate();
  const toast = useToast();

  // ── Tabs ──
  const [activeTab, setActiveTab] = useState<SettingsTab>("appearance");

  // ── Theme ──
  const [theme, setTheme] = useState<ThemeMode>(() => {
    return (localStorage.getItem("app-theme") as ThemeMode) || "system";
  });

  // ── Text size ──
  const [textSize, setTextSize] = useState<number>(() => {
    const saved = localStorage.getItem("app-text-size");
    return saved ? Number(saved) : 16;
  });

  // ── Animations ──
  const [animationsEnabled, setAnimationsEnabled] = useState<boolean>(() => loadSetting("meru-animations", true));

  // ── Edit Profile ──
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [editName, setEditName] = useState("");
  const [editRole, setEditRole] = useState("");

  // ── Change Password ──
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [changingPassword, setChangingPassword] = useState(false);

  // ── Sign Out ──
  const [showSignOutConfirm, setShowSignOutConfirm] = useState(false);

  // ── Accordions ──
  const [expandedAccordion, setExpandedAccordion] = useState<string | null>(null);

  // ── Update checker ──
  const [checkingUpdates, setCheckingUpdates] = useState(false);

  /* ── Theme effect: toggle .dark on <html> AND <body> ── */
  useEffect(() => {
    const root = document.documentElement;
    const body = document.body;
    localStorage.setItem("app-theme", theme);

    root.classList.remove("light", "dark");
    body.classList.remove("light", "dark");

    if (theme === "system") {
      const isDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
      root.classList.add(isDark ? "dark" : "light");
      body.classList.add(isDark ? "dark" : "light");
    } else {
      root.classList.add(theme);
      body.classList.add(theme);
    }
  }, [theme]);

  /* Listen for OS-level theme changes when in system mode */
  useEffect(() => {
    if (theme !== "system") return;
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const handler = (e: MediaQueryListEvent) => {
      const root = document.documentElement;
      const body = document.body;
      root.classList.remove("light", "dark");
      body.classList.remove("light", "dark");
      root.classList.add(e.matches ? "dark" : "light");
      body.classList.add(e.matches ? "dark" : "light");
    };
    mq.addEventListener("change", handler);
    return () => mq.removeEventListener("change", handler);
  }, [theme]);

  /* ── Text size effect ── */
  useEffect(() => {
    document.documentElement.style.fontSize = `${textSize}px`;
    document.documentElement.style.setProperty("--base-font-size", `${textSize}px`);
    localStorage.setItem("app-text-size", textSize.toString());
  }, [textSize]);

  /* ── Animations effect ── */
  useEffect(() => {
    document.body.classList.toggle("reduce-motion", !animationsEnabled);
    saveSetting("meru-animations", animationsEnabled);
  }, [animationsEnabled]);

  /* ── Handlers ── */

  const handleThemeChange = useCallback(
    (mode: ThemeMode) => {
      setTheme(mode);
      toast.success("Theme updated", `${mode.charAt(0).toUpperCase() + mode.slice(1)} mode applied`);
    },
    [toast],
  );

  const handleTextSizeChange = useCallback((size: number) => {
    setTextSize(size);
  }, []);

  const handleTextSizeCommit = useCallback(() => {
    toast.success("Text size saved", `Font size set to ${textSize}px`);
  }, [textSize, toast]);

  const handleAnimationsToggle = useCallback(() => {
    setAnimationsEnabled((prev) => {
      const next = !prev;
      saveSetting("meru-animations", next);
      document.body.classList.toggle("reduce-motion", !next);
      toast.info(next ? "Animations enabled" : "Animations disabled", next ? "Transitions active" : "Reduced motion applied");
      return next;
    });
  }, [toast]);

  const handleSignOut = async () => {
    setShowSignOutConfirm(false);
    await signOut();
    navigate("/login");
  };

  const toggleAccordion = (key: string) => {
    setExpandedAccordion(expandedAccordion === key ? null : key);
  };

  const handleCheckUpdates = () => {
    setCheckingUpdates(true);
    const native = desktop();
    if (native) {
      void native.checkForUpdates().then((r) => {
        setCheckingUpdates(false);
        if (r.ok) toast.success("Update check complete", r.message);
        else toast.warning("Update check", r.message);
      }).catch(() => {
        setCheckingUpdates(false);
        toast.error("Update check failed", "Could not reach the update service.");
      });
      return;
    }
    setTimeout(() => {
      setCheckingUpdates(false);
      toast.success("System Up to Date", `Running version 1.0.0 — ${ORGANIZATION.shortName}`);
    }, 1500);
  };

  const openEditProfile = () => {
    if (profile) {
      setEditName(profile.full_name);
      setEditRole("Administrator");
    }
    setIsEditingProfile(true);
  };

  const saveProfile = () => {
    if (!editName.trim()) {
      toast.error("Invalid name", "Name cannot be empty");
      return;
    }
    saveSetting("meru-profile-name", editName.trim());
    saveSetting("meru-profile-role", editRole.trim());
    setIsEditingProfile(false);
    toast.success("Profile updated", "Your changes have been saved");
  };

  const handleChangePassword = async () => {
    if (!currentPassword || !newPassword || !confirmPassword) {
      toast.error("Missing fields", "Please fill in all password fields");
      return;
    }
    if (newPassword.length < 6) {
      toast.error("Weak password", "New password must be at least 6 characters");
      return;
    }
    if (newPassword !== confirmPassword) {
      toast.error("Passwords don't match", "New password and confirmation must match");
      return;
    }
    setChangingPassword(true);
    await new Promise((r) => setTimeout(r, 1200));
    setChangingPassword(false);
    setShowChangePassword(false);
    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");
    toast.success("Password changed", "Your password has been updated successfully");
  };

  const displayName = loadSetting<string | null>("meru-profile-name", null) || profile?.full_name || "Meru Admin";
  const displayRole = loadSetting<string | null>("meru-profile-role", null) || "Administrator";

  return (
    <div className="animate-fade-in mx-auto max-w-5xl px-4 py-6 lg:px-8">
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold tracking-tight text-gray-900 dark:text-slate-100">Settings</h1>
        <p className="mt-1 text-sm text-gray-500 dark:text-slate-400">Manage your preferences, security, and system information</p>
      </div>

      {/* Tab Navigation */}
      <div className="mb-6 flex gap-1 rounded-xl border border-gray-200 bg-gray-50 p-1 shadow-sm dark:border-slate-700 dark:bg-slate-800">
        {TABS.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={cn(
              "relative flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-medium transition-all duration-200",
              activeTab === tab.id
                ? "bg-white text-emerald-700 shadow-sm dark:bg-slate-700 dark:text-emerald-400"
                : "text-gray-500 hover:text-gray-700 dark:text-slate-400 dark:hover:text-slate-200",
            )}
          >
            <Icon
              name={tab.icon}
              className={cn("h-4 w-4 transition-colors", activeTab === tab.id ? "text-emerald-600 dark:text-emerald-400" : "text-gray-400 dark:text-slate-500")}
            />
            {tab.label}
            {activeTab === tab.id && <div className="absolute inset-x-0 -bottom-1 h-0.5 rounded-full bg-emerald-500" />}
          </button>
        ))}
      </div>

      {/* ─── User Profile Card ─── */}
      {profile && (
        <div className="mb-6 overflow-hidden rounded-2xl border border-slate-200/80 bg-gradient-to-r from-white via-emerald-50/20 to-white shadow-sm transition-shadow hover:shadow-md dark:border-slate-700 dark:from-slate-800 dark:via-emerald-950/20 dark:to-slate-800">
          <div className="flex items-center gap-4 p-5">
            <div className="relative flex-shrink-0">
              <div className="h-14 w-14 overflow-hidden rounded-full border-2 border-emerald-500/30 bg-slate-100 shadow-md dark:bg-slate-700">
                <img src="/branding/admin-icon.jpeg" alt="Meru Admin Avatar" className="h-full w-full object-cover object-center" />
              </div>
              <div className="absolute -bottom-0.5 -right-0.5 h-4 w-4 rounded-full border-2 border-white bg-emerald-500 dark:border-slate-800" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-base font-semibold text-slate-900 dark:text-slate-100">{displayName}</p>
              <p className="text-sm font-medium text-slate-500 dark:text-slate-400">{displayRole}</p>
              {profile.phone && <p className="mt-0.5 text-xs text-slate-400 dark:text-slate-500">{profile.phone}</p>}
            </div>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-100 px-3 py-1 dark:border-emerald-800 dark:bg-emerald-900/50">
                <div className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-xs font-semibold text-emerald-800 dark:text-emerald-300">Active</span>
              </div>
              <Button variant="outline" size="sm" onClick={openEditProfile} icon={<Icon name="pencil" className="h-3.5 w-3.5" />}>
                Edit Profile
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* ─── Tab Content ─── */}
      {activeTab === "appearance" && (
        <AppearanceTab
          theme={theme}
          onThemeChange={handleThemeChange}
          textSize={textSize}
          onTextSizeChange={handleTextSizeChange}
          onTextSizeCommit={handleTextSizeCommit}
          animationsEnabled={animationsEnabled}
          onAnimationsToggle={handleAnimationsToggle}
        />
      )}
      {activeTab === "security" && <SecurityTab onChangePassword={() => setShowChangePassword(true)} />}
      {activeTab === "system" && (
        <SystemTab
          expandedAccordion={expandedAccordion}
          toggleAccordion={toggleAccordion}
          checkingUpdates={checkingUpdates}
          onCheckUpdates={handleCheckUpdates}
          onShowSignOut={() => setShowSignOutConfirm(true)}
        />
      )}

      {/* ─── Modals (dark mode supported) ─── */}
      {isEditingProfile && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm animate-fade-in">
          <div className="mx-4 w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl animate-slide-up dark:bg-slate-800">
            <div className="mb-5 flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-900/50">
                <Icon name="pencil" className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-slate-100">Edit Profile</h3>
                <p className="text-sm text-gray-500 dark:text-slate-400">Update your display information</p>
              </div>
            </div>
            <div className="space-y-4">
              <div>
                <label className="mb-1 block text-xs font-medium text-gray-600 dark:text-slate-400">Display Name</label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full rounded-xl border border-gray-200 bg-white px-4 py-2.5 text-sm text-gray-900 outline-none transition-all focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 dark:border-slate-600 dark:bg-slate-700 dark:text-slate-100 dark:focus:border-emerald-500"
                  placeholder="Enter your full name"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-medium text-gray-600 dark:text-slate-400">Role Title</label>
                <input
                  type="text"
                  value={editRole}
                  onChange={(e) => setEditRole(e.target.value)}
                  className="w-full rounded-xl border border-gray-200 bg-white px-4 py-2.5 text-sm text-gray-900 outline-none transition-all focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 dark:border-slate-600 dark:bg-slate-700 dark:text-slate-100 dark:focus:border-emerald-500"
                  placeholder="e.g. Administrator"
                />
              </div>
            </div>
            <div className="mt-6 flex justify-end gap-2">
              <Button variant="outline" size="sm" onClick={() => setIsEditingProfile(false)}>
                Cancel
              </Button>
              <Button variant="primary" size="sm" onClick={saveProfile} icon={<Icon name="check" className="h-4 w-4" />}>
                Save Changes
              </Button>
            </div>
          </div>
        </div>
      )}

      {showChangePassword && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm animate-fade-in">
          <div className="mx-4 w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl animate-slide-up dark:bg-slate-800">
            <div className="mb-5 flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-amber-100 dark:bg-amber-900/50">
                <Icon name="lock" className="h-5 w-5 text-amber-600 dark:text-amber-400" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-slate-100">Change Password</h3>
                <p className="text-sm text-gray-500 dark:text-slate-400">Update your account password</p>
              </div>
            </div>
            <div className="space-y-4">
              {[
                { label: "Current Password", value: currentPassword, setter: setCurrentPassword, placeholder: "Enter current password" },
                { label: "New Password", value: newPassword, setter: setNewPassword, placeholder: "Enter new password" },
                { label: "Confirm New Password", value: confirmPassword, setter: setConfirmPassword, placeholder: "Re-enter new password" },
              ].map((field) => (
                <div key={field.label}>
                  <label className="mb-1 block text-xs font-medium text-gray-600 dark:text-slate-400">{field.label}</label>
                  <input
                    type="password"
                    value={field.value}
                    onChange={(e) => field.setter(e.target.value)}
                    className="w-full rounded-xl border border-gray-200 bg-white px-4 py-2.5 text-sm text-gray-900 outline-none transition-all focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 dark:border-slate-600 dark:bg-slate-700 dark:text-slate-100 dark:focus:border-emerald-500"
                    placeholder={field.placeholder}
                  />
                </div>
              ))}
            </div>
            <div className="mt-6 flex justify-end gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setShowChangePassword(false);
                  setCurrentPassword("");
                  setNewPassword("");
                  setConfirmPassword("");
                }}
              >
                Cancel
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={handleChangePassword}
                disabled={changingPassword}
                icon={changingPassword ? <Loader /> : <Icon name="lock" className="h-4 w-4" />}
              >
                {changingPassword ? "Updating..." : "Update Password"}
              </Button>
            </div>
          </div>
        </div>
      )}

      {showSignOutConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm animate-fade-in">
          <div className="mx-4 w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl animate-slide-up dark:bg-slate-800">
            <div className="mb-4 flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-red-100 dark:bg-red-900/50">
                <Icon name="log-out" className="h-5 w-5 text-red-600 dark:text-red-400" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-slate-100">Sign Out?</h3>
                <p className="text-sm text-gray-500 dark:text-slate-400">You will need to sign in again.</p>
              </div>
            </div>
            <div className="mt-6 flex justify-end gap-2">
              <Button variant="outline" size="sm" onClick={() => setShowSignOutConfirm(false)}>
                Cancel
              </Button>
              <Button variant="danger" size="sm" onClick={handleSignOut} icon={<Icon name="log-out" className="h-4 w-4" />}>
                Sign Out
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ── APPEARANCE TAB ────────────────────────────────── */

function AppearanceTab({
  theme,
  onThemeChange,
  textSize,
  onTextSizeChange,
  onTextSizeCommit,
  animationsEnabled,
  onAnimationsToggle,
}: {
  theme: ThemeMode;
  onThemeChange: (mode: ThemeMode) => void;
  textSize: number;
  onTextSizeChange: (size: number) => void;
  onTextSizeCommit: () => void;
  animationsEnabled: boolean;
  onAnimationsToggle: () => void;
}) {
  const themes: { id: ThemeMode; label: string; desc: string; icon: IconName }[] = [
    { id: "light", label: "Light", desc: "Clean and bright", icon: "eye" },
    { id: "dark", label: "Dark", desc: "Easy on the eyes", icon: "eye-off" },
    { id: "system", label: "System", desc: "Auto-detect", icon: "monitor" },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h2 className="text-lg font-semibold text-gray-900 dark:text-slate-100">Appearance & Theme</h2>
        <p className="mt-1 text-sm text-gray-500 dark:text-slate-400">Customize how the application looks on your device</p>
      </div>

      {/* Theme Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        {themes.map((t) => (
          <button
            key={t.id}
            onClick={() => onThemeChange(t.id)}
            className={cn(
              "group relative overflow-hidden rounded-2xl border-2 p-1 transition-all duration-300",
              theme === t.id
                ? "border-emerald-500 shadow-lg shadow-emerald-500/10 dark:shadow-emerald-500/20"
                : "border-gray-200 hover:border-gray-300 hover:shadow-md dark:border-slate-600 dark:hover:border-slate-500",
            )}
          >
            <div className="relative h-36 w-full overflow-hidden rounded-xl border border-gray-200 dark:border-slate-600">
              <div className="flex items-center gap-1.5 border-b border-gray-200 bg-gray-50 px-3 py-1.5 dark:border-slate-600 dark:bg-slate-700">
                <div className="h-2 w-2 rounded-full bg-red-400" />
                <div className="h-2 w-2 rounded-full bg-amber-400" />
                <div className="h-2 w-2 rounded-full bg-emerald-400" />
                <div className="ml-2 h-1.5 flex-1 rounded bg-gray-200 dark:bg-slate-600" />
              </div>
              <div
                className={cn(
                  "flex h-full",
                  t.id === "dark" ? "bg-gray-900" : t.id === "system" ? "bg-gradient-to-r from-gray-50 to-gray-900 dark:from-slate-200 dark:to-slate-800" : "bg-white dark:bg-slate-200",
                )}
              >
                <div
                  className={cn(
                    "w-8 border-r",
                    t.id === "dark" ? "border-gray-700 bg-gray-800" : "border-gray-200 bg-gray-50 dark:border-slate-500 dark:bg-slate-300",
                  )}
                >
                  <div className="space-y-1 p-1">
                    <div className={cn("h-1.5 w-full rounded", t.id === "dark" ? "bg-gray-600" : "bg-gray-200 dark:bg-slate-400")} />
                    <div className={cn("h-1.5 w-3/4 rounded", t.id === "dark" ? "bg-emerald-500/30" : "bg-emerald-200 dark:bg-emerald-700/30")} />
                    <div className={cn("h-1.5 w-5/6 rounded", t.id === "dark" ? "bg-gray-700" : "bg-gray-200 dark:bg-slate-400")} />
                  </div>
                </div>
                <div className="flex-1 p-2">
                  <div className={cn("mb-2 h-1.5 w-1/2 rounded", t.id === "dark" ? "bg-gray-600" : "bg-gray-200 dark:bg-slate-400")} />
                  <div className="grid grid-cols-2 gap-1">
                    <div className={cn("h-6 rounded", t.id === "dark" ? "bg-gray-700" : "bg-gray-100 dark:bg-slate-300")} />
                    <div className={cn("h-6 rounded", t.id === "dark" ? "bg-gray-700" : "bg-gray-100 dark:bg-slate-300")} />
                  </div>
                  <div className={cn("mt-2 h-12 rounded", t.id === "dark" ? "bg-gray-800" : "bg-gray-50 dark:bg-slate-200")} />
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between px-3 py-3">
              <div className="flex items-center gap-2">
                <Icon name={t.icon} className={cn("h-4 w-4", theme === t.id ? "text-emerald-600 dark:text-emerald-400" : "text-gray-400 dark:text-slate-500")} />
                <div className="text-left">
                  <p className={cn("text-sm font-medium", theme === t.id ? "text-emerald-700 dark:text-emerald-400" : "text-gray-700 dark:text-slate-300")}>
                    {t.label}
                  </p>
                  <p className="text-xs text-gray-400 dark:text-slate-500">{t.desc}</p>
                </div>
              </div>
              {theme === t.id && (
                <div className="flex h-6 w-6 items-center justify-center rounded-full bg-emerald-500 transition-all duration-300 animate-scale-in">
                  <Icon name="check" className="h-3.5 w-3.5 text-white" />
                </div>
              )}
            </div>
          </button>
        ))}
      </div>

      {/* Text Size Slider */}
      <div className="rounded-2xl border border-gray-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-800">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-gray-900 dark:text-slate-100">Text Size</h3>
            <p className="mt-1 text-xs text-gray-500 dark:text-slate-400">Adjust the base text size for readability</p>
          </div>
          <span className="rounded-lg bg-emerald-50 px-2.5 py-1 text-xs font-bold text-emerald-700 tabular-nums dark:bg-emerald-900/30 dark:text-emerald-400">
            {textSize}px
          </span>
        </div>
        <div className="mt-4 flex items-center gap-4">
          <span className="w-4 text-right text-[11px] font-medium text-gray-400 dark:text-slate-500">A</span>
          <input
            type="range"
            min={11}
            max={22}
            step={1}
            value={textSize}
            onChange={(e) => onTextSizeChange(Number(e.target.value))}
            onMouseUp={onTextSizeCommit}
            onTouchEnd={onTextSizeCommit}
            style={{
              background: `linear-gradient(to right, #0c4b36 0%, #10b981 ${((textSize - 11) / 11) * 100}%, #e2e8f0 ${((textSize - 11) / 11) * 100}%, #e2e8f0 100%)`,
            }}
            className="h-2 flex-1 cursor-pointer appearance-none rounded-full transition-all [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-white [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-emerald-600 [&::-webkit-slider-thumb]:shadow-md [&::-webkit-slider-thumb]:transition-all [&::-webkit-slider-thumb]:duration-150 [&::-webkit-slider-thumb]:hover:scale-125 [&::-webkit-slider-thumb]:active:scale-110 [&::-moz-range-thumb]:h-4 [&::-moz-range-thumb]:w-4 [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:bg-white [&::-moz-range-thumb]:border-2 [&::-moz-range-thumb]:border-emerald-600 [&::-moz-range-thumb]:shadow-md"
          />
          <span className="w-6 text-lg font-bold text-gray-400 dark:text-slate-500">A</span>
        </div>
        <div className="mt-2 flex justify-between text-[10px] text-gray-300 dark:text-slate-600">
          <span>11px</span>
          <span>16px</span>
          <span>22px</span>
        </div>
      </div>

      {/* Animations Toggle */}
      <div className="rounded-2xl border border-gray-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-800">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-gray-900 dark:text-slate-100">Animations</h3>
            <p className="mt-0.5 text-xs text-gray-500 dark:text-slate-400">
              {animationsEnabled ? "Smooth transitions and micro-interactions are active" : "Reduced motion applied globally"}
            </p>
          </div>
          <button
            onClick={onAnimationsToggle}
            className={cn(
              "relative inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full transition-colors duration-200",
              animationsEnabled ? "bg-emerald-500" : "bg-gray-300 dark:bg-slate-600",
            )}
          >
            <span
              className={cn(
                "inline-block h-4 w-4 transform rounded-full bg-white shadow-sm transition-transform duration-200",
                animationsEnabled ? "translate-x-6" : "translate-x-1",
              )}
            />
          </button>
        </div>
      </div>
    </div>
  );
}

/* ── SECURITY TAB ──────────────────────────────────── */

function SecurityTab({ onChangePassword }: { onChangePassword: () => void }) {
  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h2 className="text-lg font-semibold text-gray-900 dark:text-slate-100">Security & Access</h2>
        <p className="mt-1 text-sm text-gray-500 dark:text-slate-400">Manage security features and data access policies</p>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <SecurityCard icon="shield-check" title="Row Level Security" description="All data access is protected at the database level via Supabase RLS policies" status="active" />
        <SecurityCard icon="lock" title="Session Management" description="Sessions refresh automatically and expire based on security policy" status="active" />
        <SecurityCard icon="shield-check" title="Duplicate Prevention" description="Duplicate ID issuance attempts are blocked and logged at the database level" status="active" />
        <SecurityCard icon="lock" title="Authentication" description="Secure email/password authentication via Supabase Auth with JWT tokens" status="active" />
      </div>

      <div className="rounded-2xl border border-gray-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-800">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-50 dark:bg-amber-900/30">
              <Icon name="lock" className="h-5 w-5 text-amber-600 dark:text-amber-400" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-gray-900 dark:text-slate-100">Password</h3>
              <p className="text-xs text-gray-500 dark:text-slate-400">Last changed 30 days ago</p>
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={onChangePassword}>
            Change Password
          </Button>
        </div>
      </div>

      <div className="rounded-2xl border border-gray-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-800">
        <h3 className="text-sm font-semibold text-gray-900 dark:text-slate-100">Active Sessions</h3>
        <p className="mt-1 text-xs text-gray-500 dark:text-slate-400">Devices currently signed in to your account</p>
        <div className="mt-4 space-y-3">
          <div className="flex items-center justify-between rounded-xl border border-gray-100 p-3 dark:border-slate-700">
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-50 dark:bg-emerald-900/30">
                <Icon name="monitor" className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
              </div>
              <div>
                <p className="text-sm font-medium text-gray-800 dark:text-slate-200">Current Session</p>
                <p className="text-xs text-gray-400 dark:text-slate-500">This device · {navigator.userAgent.includes("Chrome") ? "Chrome" : "Browser"} · Active now</p>
              </div>
            </div>
            <span className="rounded-full bg-emerald-50 px-2.5 py-1 text-[10px] font-bold text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400">Current</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function SecurityCard({ icon, title, description, status }: { icon: IconName; title: string; description: string; status: "active" | "inactive" | "warning" }) {
  const statusConfig = {
    active: { bg: "bg-emerald-50 dark:bg-emerald-900/30", text: "text-emerald-700 dark:text-emerald-400", dot: "bg-emerald-500", label: "Active", border: "border-emerald-200 dark:border-emerald-800" },
    inactive: { bg: "bg-gray-50 dark:bg-slate-700", text: "text-gray-500 dark:text-slate-400", dot: "bg-gray-400", label: "Inactive", border: "border-gray-200 dark:border-slate-600" },
    warning: { bg: "bg-amber-50 dark:bg-amber-900/30", text: "text-amber-700 dark:text-amber-400", dot: "bg-amber-500", label: "Warning", border: "border-amber-200 dark:border-amber-800" },
  };
  const s = statusConfig[status];

  return (
    <div className="group rounded-2xl border border-gray-200 bg-white p-5 shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md dark:border-slate-700 dark:bg-slate-800">
      <div className="flex items-start justify-between">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50 transition-colors group-hover:bg-emerald-100 dark:bg-emerald-900/30 dark:group-hover:bg-emerald-900/50">
          <Icon name={icon} className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
        </div>
        <div className={cn("flex items-center gap-1.5 rounded-full border px-2.5 py-1", s.bg, s.border)}>
          <div className={cn("h-1.5 w-1.5 rounded-full", s.dot, status === "active" && "animate-pulse")} />
          <span className={cn("text-[10px] font-bold uppercase tracking-wider", s.text)}>{s.label}</span>
        </div>
      </div>
      <h3 className="mt-3 text-sm font-semibold text-gray-900 dark:text-slate-100">{title}</h3>
      <p className="mt-1 text-xs leading-relaxed text-gray-500 dark:text-slate-400">{description}</p>
    </div>
  );
}

/* ── SYSTEM INFO TAB ───────────────────────────────── */

function SystemTab({ expandedAccordion, toggleAccordion, checkingUpdates, onCheckUpdates, onShowSignOut }: { expandedAccordion: string | null; toggleAccordion: (key: string) => void; checkingUpdates: boolean; onCheckUpdates: () => void; onShowSignOut: () => void }) {
  const native = desktop();

  const [dataPath, setDataPath] = useState<string | null>(null);
  useEffect(() => {
    if (!native) return;
    void native.getDataFolderPath().then(setDataPath).catch(() => undefined);
  }, [native]);

  const [busy, setBusy] = useState<"backup" | "restore" | null>(null);
  const handleBackup = async () => {
    if (!native) return;
    setBusy("backup");
    try {
      const r = await native.backupNow();
      if (r.ok && r.path) toast.success("Backup saved", r.path);
      else if (r.error !== "cancelled") toast.error("Backup failed", r.error ?? "Unknown error");
    } finally {
      setBusy(null);
    }
  };
  const handleRestore = async () => {
    if (!native) return;
    setBusy("restore");
    try {
      const r = await native.restoreBackup();
      if (!r.ok && r.error && r.error !== "cancelled") toast.error("Restore failed", r.error);
    } finally {
      setBusy(null);
    }
  };

  const toast = useToast();
  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h2 className="text-lg font-semibold text-gray-900 dark:text-slate-100">System Info & Support</h2>
        <p className="mt-1 text-sm text-gray-500 dark:text-slate-400">About the system, documentation, and support resources</p>
      </div>

      <div className="space-y-3">
        <AccordionItem key="about" icon="info" title="About" subtitle={`Version 1.0.0 — ${ORGANIZATION.shortName}`} isOpen={expandedAccordion === "about"} onToggle={() => toggleAccordion("about")}>
          <div className="space-y-3 text-sm text-gray-600 dark:text-slate-400">
            <div className="rounded-xl bg-gray-50 p-4 dark:bg-slate-700/50">
              <p className="font-semibold text-gray-800 dark:text-slate-200">{ORGANIZATION.systemNameEn}</p>
              <p className="mt-1">{ORGANIZATION.systemName}</p>
            </div>
            <p className="leading-relaxed">{ORGANIZATION.description}</p>
            <p className="text-xs text-gray-400 dark:text-slate-500">{ORGANIZATION.region}</p>
            <div className="grid grid-cols-2 gap-3">
              <InfoTile label="Version" value="1.0.0" />
              <InfoTile label="License" value="Government" />
              <InfoTile label="Framework" value="React + Vite" />
              <InfoTile label="Database" value="Supabase" />
            </div>
          </div>
        </AccordionItem>

        <AccordionItem key="terms" icon="external-link" title="Terms & Conditions" subtitle="Usage policies and terms of service" isOpen={expandedAccordion === "terms"} onToggle={() => toggleAccordion("terms")}>
          <div className="space-y-3 text-sm text-gray-600 dark:text-slate-400">
            <p className="font-medium text-gray-800 dark:text-slate-200">Terms of Service</p>
            <p>By using this system, you agree to the following terms:</p>
            <ul className="space-y-2">
              {["This system is for authorized personnel only", "All actions are tracked for accountability", "Do not share your login credentials", "Report any suspicious activity immediately", "Only issue identification documents through official procedures", "Data is stored securely and backed up regularly"].map((term, i) => (
                <li key={i} className="flex items-start gap-2">
                  <Icon name="check" className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-500" />
                  <span>{term}</span>
                </li>
              ))}
            </ul>
            <p className="text-xs text-gray-400 dark:text-slate-500">For full terms, contact the system administrator.</p>
          </div>
        </AccordionItem>

        <AccordionItem key="sysinfo" icon="settings" title="System Information" subtitle="Technical details about your account and environment" isOpen={expandedAccordion === "sysinfo"} onToggle={() => toggleAccordion("sysinfo")}>
          <div className="grid grid-cols-2 gap-3">
            <InfoTile label="Browser" value={navigator.userAgent.split(" ").slice(-1)[0] || "Chrome"} />
            <InfoTile label="Platform" value={native ? `Desktop (${native.platform})` : navigator.platform} />
            <InfoTile label="Screen" value={`${window.screen.width}×${window.screen.height}`} />
            <InfoTile label="Language" value={navigator.language} />
            <InfoTile label="Cookies" value={navigator.cookieEnabled ? "Enabled" : "Disabled"} />
            <InfoTile label="Online" value={navigator.onLine ? "Yes" : "No"} />
          </div>
        </AccordionItem>

        {native && (
          <div className="rounded-2xl border border-emerald-200 bg-emerald-50/40 p-5 dark:border-emerald-800 dark:bg-emerald-950/30">
            <div className="flex items-start gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-emerald-100 dark:bg-emerald-900/50">
                <Icon name="download" className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold text-gray-900 dark:text-slate-100">Local Data & Backups</p>
                <p className="mt-0.5 text-xs text-gray-500 dark:text-slate-400">
                  All records are stored on this computer and sync to the cloud when online.
                </p>
                {dataPath && (
                  <p className="mt-2 truncate rounded-lg bg-white/70 px-2 py-1 font-mono text-[10px] text-gray-500 dark:bg-slate-900/60 dark:text-slate-400" title={dataPath}>
                    {dataPath}
                  </p>
                )}
                <div className="mt-3 flex flex-wrap gap-2">
                  <Button size="sm" variant="outline" onClick={() => void native.openDataFolder()} icon={<Icon name="external-link" className="h-3.5 w-3.5" />}>
                    Open Data Folder
                  </Button>
                  <Button size="sm" variant="outline" loading={busy === "backup"} onClick={() => void handleBackup()} icon={<Icon name="download" className="h-3.5 w-3.5" />}>
                    Backup Now
                  </Button>
                  <Button size="sm" variant="outline" loading={busy === "restore"} onClick={() => void handleRestore()} icon={<Icon name="upload" className="h-3.5 w-3.5" />}>
                    Restore
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}

        <button
          onClick={onCheckUpdates}
          disabled={checkingUpdates}
          className="flex w-full items-center gap-4 rounded-2xl border border-gray-200 bg-white p-5 text-left shadow-sm transition-all duration-200 hover:border-emerald-200 hover:shadow-md disabled:opacity-60 dark:border-slate-700 dark:bg-slate-800 dark:hover:border-emerald-700"
        >
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50 dark:bg-emerald-900/30">
            {checkingUpdates ? (
              <Loader />
            ) : (
              <Icon name="refresh" className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
            )}
          </div>
          <div className="flex-1">
            <p className="text-sm font-semibold text-gray-900 dark:text-slate-100">{checkingUpdates ? "Checking..." : "Check for Updates"}</p>
            <p className="text-xs text-gray-500 dark:text-slate-400">Verify the system is running the latest version</p>
          </div>
          <Icon name="chevron-right" className="h-4 w-4 text-gray-400 dark:text-slate-500" />
        </button>
      </div>

      <div className="rounded-2xl border border-red-100 bg-red-50/50 p-5 dark:border-red-900/50 dark:bg-red-950/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-red-100 dark:bg-red-900/50">
              <Icon name="log-out" className="h-5 w-5 text-red-600 dark:text-red-400" />
            </div>
            <div>
              <p className="text-sm font-semibold text-gray-900 dark:text-slate-100">Sign Out</p>
              <p className="text-xs text-gray-500 dark:text-slate-400">Sign out of your account on this device</p>
            </div>
          </div>
          <Button variant="danger" size="sm" onClick={onShowSignOut} icon={<Icon name="log-out" className="h-4 w-4" />}>
            Sign Out
          </Button>
        </div>
      </div>
    </div>
  );
}

/* ── SHARED COMPONENTS ─────────────────────────────── */

function AccordionItem({ icon, title, subtitle, isOpen, onToggle, children }: { icon: IconName; title: string; subtitle: string; isOpen: boolean; onToggle: () => void; children: React.ReactNode }) {
  return (
    <div
      className={cn(
        "overflow-hidden rounded-2xl border bg-white shadow-sm transition-all duration-300 dark:bg-slate-800",
        isOpen ? "border-emerald-200 shadow-md dark:border-emerald-800" : "border-gray-200 hover:border-gray-300 hover:shadow-md dark:border-slate-700 dark:hover:border-slate-600",
      )}
    >
      <button onClick={onToggle} className="flex w-full items-center gap-4 p-5 text-left">
        <div className={cn("flex h-10 w-10 items-center justify-center rounded-xl transition-colors", isOpen ? "bg-emerald-100 dark:bg-emerald-900/40" : "bg-gray-100 dark:bg-slate-700")}>
          <Icon name={icon} className={cn("h-5 w-5 transition-colors", isOpen ? "text-emerald-600 dark:text-emerald-400" : "text-gray-500 dark:text-slate-400")} />
        </div>
        <div className="flex-1">
          <p className="text-sm font-semibold text-gray-900 dark:text-slate-100">{title}</p>
          <p className="text-xs text-gray-500 dark:text-slate-400">{subtitle}</p>
        </div>
        <Icon name="chevron-down" className={cn("h-5 w-5 shrink-0 text-gray-400 transition-transform duration-300 dark:text-slate-500", isOpen && "rotate-180 text-emerald-500")} />
      </button>
      <div className={cn("transition-all duration-300 ease-in-out", isOpen ? "max-h-[600px] opacity-100" : "max-h-0 opacity-0")}>
        <div className="border-t border-gray-100 px-5 pb-5 pt-4 dark:border-slate-700">{children}</div>
      </div>
    </div>
  );
}

function InfoTile({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-gray-100 bg-gray-50 p-3 dark:border-slate-700 dark:bg-slate-700/50">
      <p className="text-[10px] font-bold uppercase tracking-wider text-gray-400 dark:text-slate-500">{label}</p>
      <p className="mt-0.5 text-xs font-medium text-gray-700 dark:text-slate-300">{value}</p>
    </div>
  );
}
