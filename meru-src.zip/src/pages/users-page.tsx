import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, PageHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input, PasswordInput, Select } from "@/components/ui/form";
import {
  EmptyState,
  ErrorState,
  SkeletonRows,
  TBody,
  TD,
  TH,
  THead,
  TR,
  Table
} from "@/components/ui/data-table";
import { StatusBadge } from "@/components/ui/status-badge";
import { Modal } from "@/components/ui/modal";
import { Icon } from "@/components/icons/icon";
import { useToast } from "@/components/ui/toast";
import { mapSupabaseError } from "@/services/errors";
import {
  createStaffUser,
  listProfiles,
  sendPasswordReset,
  setUserStatus,
  updateUserRole
} from "@/services/users-service";
import type { Profile, UserRole } from "@/types";
import { ROLE_DESCRIPTIONS, ROLE_LABELS, STAFF_NUMBER_PATTERN } from "@/lib/constants";

const ROLE_OPTIONS: readonly { value: string; label: string }[] = [
  { value: "officer", label: "Officer" },
  { value: "supervisor", label: "Supervisor" },
  { value: "viewer", label: "Viewer" },
  { value: "admin", label: "Administrator" }
];

export function UsersPage() {
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [createOpen, setCreateOpen] = useState(false);
  const toast = useToast();
  const navigate = useNavigate();

  const load = (): void => {
    setLoading(true);
    listProfiles()
      .then(setProfiles)
      .catch((err) => setError(mapSupabaseError(err).userMessage))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="animate-fade-in">
      <PageHeader
        title="Staff Accounts"
        subtitle="Manage system users and their roles. Roles are enforced again at database level."
        actions={
          <Button icon={<Icon name="user-plus" className="h-4 w-4" />} onClick={() => setCreateOpen(true)}>
            New staff account
          </Button>
        }
      />

      <Card className="overflow-hidden">
        {error ? (
          <ErrorState message={error} onRetry={load} />
        ) : !loading && profiles.length === 0 ? (
          <EmptyState icon="users" title="No staff accounts" />
        ) : (
          <Table>
            <THead>
              <TR>
                <TH>Staff №</TH>
                <TH>Name</TH>
                <TH>Role</TH>
                <TH>Department</TH>
                <TH>Status</TH>
                <TH>Actions</TH>
              </TR>
            </THead>
            <TBody>
              {loading ? (
                <SkeletonRows rows={6} cols={6} />
              ) : (
                profiles.map((p) => (
                  <TR key={p.id}>
                    <TD className="font-mono text-xs font-semibold">{p.staff_number}</TD>
                    <TD className="font-medium">{p.full_name}</TD>
                    <TD>
                      <RoleSelect profile={p} onChange={(role) => void handleRoleChange(p, role)} onDone={load} />
                    </TD>
                    <TD className="text-xs text-slate-500">{p.department ?? "—"}</TD>
                    <TD>
                      <StatusBadge status={p.status} />
                    </TD>
                    <TD>
                      <div className="flex flex-wrap gap-1.5">
                        {p.status === "active" ? (
                          <ConfirmActionButton
                            label="Disable"
                            danger
                            title={`Disable ${p.full_name}?`}
                            message="The account will be blocked from signing in immediately."
                            confirmLabel="Disable account"
                            onConfirm={() =>
                              setUserStatus(p.id, "disabled").then(load).catch((err) => toast.error("Failed", mapSupabaseError(err).userMessage))
                            }
                          />
                        ) : (
                          <Button size="sm" variant="outline" onClick={() => void setUserStatus(p.id, "active").then(load)}>
                            Enable
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() =>
                            void sendPasswordReset(p.staff_number)
                              .then(() => toast.success("Reset email sent"))
                              .catch(() => toast.info(`Ask ${p.full_name} to use “Forgot password” with their email.`))
                          }
                        >
                          Reset password
                        </Button>
                      </div>
                    </TD>
                  </TR>
                ))
              )}
            </TBody>
          </Table>
        )}
      </Card>

      <CreateUserModal
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        onCreated={() => {
          setCreateOpen(false);
          load();
          toast.success("Staff account created");
        }}
      />
    </div>
  );

  async function handleRoleChange(p: Profile, role: UserRole): Promise<void> {
    try {
      await updateUserRole(p.id, role);
      toast.success(
        "Role updated",
        `${p.full_name} is now ${ROLE_LABELS[role]}. ${ROLE_DESCRIPTIONS[role]}`
      );
      load();
    } catch (err) {
      toast.error("Could not update role", mapSupabaseError(err).userMessage);
      navigate(0);
    }
  }
}

function RoleSelect({
  profile,
  onChange,
  onDone
}: {
  profile: Profile;
  onChange: (role: UserRole) => Promise<void> | void;
  onDone: () => void;
}) {
  const [saving, setSaving] = useState(false);
  return (
    <Select
      aria-label={`Role for ${profile.full_name}`}
      options={ROLE_OPTIONS}
      value={profile.role}
      disabled={saving}
      onChange={(e) => {
        setSaving(true);
        Promise.resolve(onChange(e.target.value as UserRole)).finally(() => {
          setSaving(false);
          onDone();
        });
      }}
      className="h-8 w-36 py-1 text-xs"
    />
  );
}

function ConfirmActionButton({
  label,
  title,
  message,
  confirmLabel,
  onConfirm,
  danger
}: {
  label: string;
  title: string;
  message: React.ReactNode;
  confirmLabel: string;
  onConfirm: () => Promise<unknown>;
  danger?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  return (
    <>
      <Button size="sm" variant={danger ? "danger" : "outline"} onClick={() => setOpen(true)}>
        {label}
      </Button>
      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title={title}
        tone={danger ? "danger" : "default"}
        size="sm"
        footer={
          <>
            <Button variant="outline" data-autofocus onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button
              variant={danger ? "danger" : "primary"}
              loading={busy}
              onClick={() => {
                setBusy(true);
                void onConfirm().finally(() => {
                  setBusy(false);
                  setOpen(false);
                });
              }}
            >
              {confirmLabel}
            </Button>
          </>
        }
      >
        <p className="text-sm text-slate-600">{message}</p>
      </Modal>
    </>
  );
}

function CreateUserModal({
  open,
  onClose,
  onCreated
}: {
  open: boolean;
  onClose: () => void;
  onCreated: () => void;
}) {
  const [form, setForm] = useState({
    fullName: "",
    staffNumber: "",
    email: "",
    password: "",
    role: "officer" as UserRole,
    department: ""
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const toast = useToast();

  const doCreate = async (): Promise<void> => {
    const errs: Record<string, string> = {};
    if (form.fullName.trim().length < 3) errs.fullName = "Full name required";
    if (!STAFF_NUMBER_PATTERN.test(form.staffNumber.trim().toUpperCase()))
      errs.staffNumber = "Format: STAFF-001 … STAFF-999999";
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(form.email)) errs.email = "Valid email required";
    if (form.password.length < 10) errs.password = "Minimum 10 characters";
    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }
    setSubmitting(true);
    try {
      await createStaffUser({
        email: form.email.trim(),
        password: form.password,
        fullName: form.fullName.trim(),
        staffNumber: form.staffNumber.trim().toUpperCase(),
        role: form.role,
        department: form.department.trim() || undefined
      });
      setForm({ fullName: "", staffNumber: "", email: "", password: "", role: "officer", department: "" });
      setErrors({});
      onCreated();
    } catch (err) {
      const message = err instanceof Error ? err.message : "Account creation failed";
      toast.error("Could not create account", message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="New staff account"
      description="Credentials are provisioned server-side; the service key never reaches the browser."
      footer={
        <>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button loading={submitting} onClick={() => void doCreate()} data-autofocus>
            Create account
          </Button>
        </>
      }
    >
      <form onSubmit={(e) => { e.preventDefault(); void doCreate(); }} className="grid gap-4 sm:grid-cols-2">
        <Input
          label="Full name"
          required
          value={form.fullName}
          onChange={(e) => setForm((f) => ({ ...f, fullName: e.target.value }))}
          error={errors.fullName}
        />
        <Input
          label="Staff number"
          required
          placeholder="STAFF-012"
          value={form.staffNumber}
          onChange={(e) => setForm((f) => ({ ...f, staffNumber: e.target.value.toUpperCase() }))}
          error={errors.staffNumber}
        />
        <Input
          label="Work email"
          required
          type="email"
          value={form.email}
          onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
          error={errors.email}
        />
        <PasswordInput
          label="Temporary password"
          required
          autoComplete="new-password"
          value={form.password}
          onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))}
          error={errors.password}
          hint="Min 10 characters"
        />
        <Select
          label="Role"
          options={ROLE_OPTIONS}
          value={form.role}
          onChange={(e) => setForm((f) => ({ ...f, role: e.target.value as UserRole }))}
          hint={ROLE_DESCRIPTIONS[form.role]}
        />
        <Input
          label="Department"
          value={form.department}
          onChange={(e) => setForm((f) => ({ ...f, department: e.target.value }))}
        />
        {/* Hidden submit so Enter works inside the modal */}
        <button type="submit" hidden aria-hidden="true" tabIndex={-1} />
      </form>
    </Modal>
  );
}
