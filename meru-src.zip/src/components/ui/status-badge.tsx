import { cn } from "@/lib/cn";
import { humanize } from "@/lib/format";
import { Icon, type IconName } from "@/components/icons/icon";

export type BadgeTone =
  | "green"
  | "amber"
  | "red"
  | "blue"
  | "slate"
  | "violet"
  | "gold";

const TONES: Record<BadgeTone, string> = {
  green:
    "bg-accent-50/80 dark:bg-emerald-950/60 text-accent-700 dark:text-emerald-400 border-accent-200/80 dark:border-emerald-800 shadow-[0_0_8px_rgb(34,197,94,0.08)]",
  amber:
    "bg-amber-50/80 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400 border-amber-200/80 dark:border-amber-800 shadow-[0_0_8px_rgb(245,158,11,0.08)]",
  red: "bg-danger-50/80 dark:bg-red-950/60 text-danger-700 dark:text-red-400 border-danger-200/80 dark:border-red-800 shadow-[0_0_8px_rgb(220,38,38,0.08)]",
  blue: "bg-primary-50/80 dark:bg-blue-950/60 text-primary-700 dark:text-blue-400 border-primary-200/80 dark:border-blue-800 shadow-[0_0_8px_rgb(51,128,255,0.08)]",
  slate: "bg-surface-100/80 dark:bg-slate-800 text-surface-600 dark:text-slate-400 border-surface-200/80 dark:border-slate-700",
  violet: "bg-purple-50/80 dark:bg-purple-950/60 text-purple-700 dark:text-purple-400 border-purple-200/80 dark:border-purple-800",
  gold: "bg-gold-50/80 dark:bg-amber-950/60 text-gold-700 dark:text-amber-400 border-gold-200/80 dark:border-amber-800 shadow-[0_0_8px_rgb(234,179,8,0.08)]",
};

const TONE_ICONS: Record<BadgeTone, IconName> = {
  green: "check-circle",
  amber: "clock",
  red: "alert-circle",
  blue: "info",
  slate: "info",
  violet: "alert-triangle",
  gold: "check-circle",
};

/**
 * Consistent status system with glassmorphic design.
 * Always icon + text — never color alone (accessibility requirement).
 */
export function StatusBadge({
  status,
  tone,
  label,
  pulse,
  className,
}: {
  status?: string;
  tone?: BadgeTone;
  label?: string;
  pulse?: boolean;
  className?: string;
}) {
  const resolvedTone = tone ?? toneForStatus(status ?? "");
  const text = label ?? humanize(status ?? "");
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 whitespace-nowrap rounded-full border px-2.5 py-1",
        "text-[11px] font-medium uppercase tracking-wide",
        "backdrop-blur-sm transition-all duration-200",
        "hover:shadow-md hover:scale-[1.02]",
        TONES[resolvedTone],
        className
      )}
    >
      <span className="relative flex h-3 w-3 items-center justify-center">
        {pulse ? (
          <span className="h-2 w-2 animate-pulse-dot rounded-full bg-current" />
        ) : (
          <Icon name={TONE_ICONS[resolvedTone]} className="h-3 w-3" />
        )}
      </span>
      {text}
    </span>
  );
}

function toneForStatus(status: string): BadgeTone {
  switch (status) {
    case "issued":
    case "online":
    case "active":
    case "registered":
    case "completed":
    case "synchronized":
      return "green";
    case "pending":
    case "printing":
    case "unknown":
    case "under_review":
    case "queued":
    case "reprint_requested":
      return "amber";
    case "failed":
    case "cancelled":
    case "revoked":
    case "error":
    case "disabled":
      return "red";
    case "offline":
      return "slate";
    case "conflict":
      return "violet";
    default:
      return "slate";
  }
}
