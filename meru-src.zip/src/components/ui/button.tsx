import { forwardRef, type ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/cn";
import { Spinner } from "./spinner";

type Variant = "primary" | "secondary" | "danger" | "ghost" | "outline" | "accent" | "gold";
type Size = "xs" | "sm" | "md" | "lg" | "xl";

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  loading?: boolean;
  icon?: React.ReactNode;
  shine?: boolean;
}

const VARIANTS: Record<Variant, string> = {
  primary: cn(
    "bg-gradient-to-r from-council-700 to-council-600 text-white",
    "border border-council-600/50 shadow-glass",
    "hover:from-council-800 hover:to-council-700 hover:shadow-glow",
    "active:from-council-900 active:to-council-800 active:shadow-none active:scale-[0.98]"
  ),
  secondary: cn(
    "bg-white/80 dark:bg-slate-800/80 text-council-700 dark:text-emerald-400 backdrop-blur-sm",
    "border border-council-200/80 dark:border-emerald-800/50 shadow-glass-sm",
    "hover:bg-council-50 dark:hover:bg-slate-700 hover:border-council-300 dark:hover:border-emerald-700 hover:shadow-glass",
    "active:bg-council-100 active:scale-[0.98]"
  ),
  danger: cn(
    "bg-gradient-to-r from-danger-600 to-danger-500 text-white",
    "border border-danger-500/50 shadow-glass",
    "hover:from-danger-700 hover:to-danger-600 hover:shadow-[0_0_20px_rgb(220,38,38,0.2)]",
    "active:from-danger-800 active:to-danger-700 active:scale-[0.98]"
  ),
  ghost: cn(
    "text-surface-600 dark:text-slate-400 bg-transparent",
    "hover:bg-surface-100/80 dark:hover:bg-slate-800 hover:text-surface-800 dark:hover:text-slate-200",
    "active:bg-surface-200/80 active:scale-[0.98]"
  ),
  outline: cn(
    "border border-surface-200/80 dark:border-slate-600 bg-white/60 dark:bg-slate-800/60 text-surface-600 dark:text-slate-300 backdrop-blur-sm",
    "shadow-glass-sm",
    "hover:bg-white dark:hover:bg-slate-700 hover:border-surface-300 dark:hover:border-slate-500 hover:shadow-glass",
    "active:bg-surface-50 active:scale-[0.98]"
  ),
  accent: cn(
    "bg-gradient-to-r from-accent-600 to-accent-500 text-white",
    "border border-accent-500/50 shadow-glass",
    "hover:from-accent-700 hover:to-accent-600 hover:shadow-[0_0_20px_rgb(34,197,94,0.2)]",
    "active:from-accent-800 active:to-accent-700 active:scale-[0.98]"
  ),
  gold: cn(
    "bg-gradient-to-r from-gold-500 to-gold-400 text-gold-900",
    "border border-gold-400/50 shadow-glass",
    "hover:from-gold-600 hover:to-gold-500 hover:shadow-[0_0_20px_rgb(234,179,8,0.2)]",
    "active:from-gold-700 active:to-gold-600 active:scale-[0.98]"
  ),
};

const SIZES: Record<Size, string> = {
  xs: "h-7 px-2.5 text-xs gap-1 rounded-lg",
  sm: "h-8 px-3 text-xs gap-1.5 rounded-lg",
  md: "h-10 px-4 text-sm gap-2 rounded-xl",
  lg: "h-11 px-5 text-sm gap-2 rounded-xl",
  xl: "h-12 px-6 text-base gap-2.5 rounded-xl",
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  function Button(
    {
      className,
      variant = "primary",
      size = "md",
      loading,
      icon,
      shine = false,
      children,
      disabled,
      type,
      ...props
    },
    ref
  ) {
    return (
      <button
        ref={ref}
        type={type ?? "button"}
        disabled={disabled || loading}
        aria-busy={loading || undefined}
        className={cn(
          "inline-flex select-none items-center justify-center",
          "transition-all duration-200 ease-[cubic-bezier(0.16,1,0.3,1)]",
          "focus-visible:ring-2 focus-visible:ring-council-500 focus-visible:ring-offset-2 focus-visible:outline-none",
          "disabled:pointer-events-none disabled:opacity-50",
          VARIANTS[variant],
          SIZES[size],
          shine && "btn-shine",
          className
        )}
        {...props}
      >
        {loading ? (
          <Spinner size="xs" className="text-current" />
        ) : icon ? (
          <span className="shrink-0 transition-transform duration-200 group-hover:scale-110">
            {icon}
          </span>
        ) : null}
        {children}
      </button>
    );
  }
);
