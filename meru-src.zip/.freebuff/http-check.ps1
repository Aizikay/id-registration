param([string]$Url = "http://localhost:5174/login")
try {
  $res = Invoke-WebRequest -Uri $Url -UseBasicParsing -TimeoutSec 20
  Write-Output ("HTTP " + $res.StatusCode)
} catch {
  Write-Output ("ERR " + $_.Exception.Message)
}
