-- Admin-only delete for persons. No DELETE policy existed before (intentionally append-only),
-- so even admins were blocked. Add a narrow policy + a helper RPC that enforces
-- the business rule: a person with an occupying issuance (pending/printing/issued/reprint_requested)
-- cannot be deleted — they must be corrected via UPDATE, not removal.

create or replace function public.can_delete_person(p_person_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select not exists (
    select 1 from public.issuance_records
    where person_id = p_person_id
      and status in ('pending','printing','issued','reprint_requested')
  );
$$;

grant execute on function public.can_delete_person(uuid) to authenticated;

-- Allow admins to delete persons when no occupying issuance exists.
-- The USING clause enforces both admin role and the business rule.
create policy persons_delete_admin on public.persons
  for delete to authenticated
  using (
    public.auth_profile_role() = 'admin'
    and public.can_delete_person(id)
  );

-- Also allow the service_role (used by the sync engine) to bypass for cleanup;
-- RLS is not applied to service_role by default, so no policy needed there,
-- but we keep the admin check for authenticated.
