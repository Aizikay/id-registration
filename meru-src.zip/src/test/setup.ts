import "@testing-library/jest-dom/vitest";

// IndexedDB for Dexie tests
import "fake-indexeddb/auto";
