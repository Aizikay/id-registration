$ErrorActionPreference = 'Stop'
$ws   = 'C:\Users\hp\Pictures\ID Registration & Issuance Management System.(MERU DC) - Copy'
$log  = Join-Path $ws '.freebuff\preview-185ab75d-b7ac-4e90-8d29-bbede45499ca.log'
$errF = "$log.err"
$vite = Join-Path $ws 'node_modules\vite\bin\vite.js'
$pidFile = Join-Path $ws '.freebuff\vite-pid.txt'

$p = Start-Process -FilePath 'C:\node.exe' `
  -ArgumentList "`"$vite`" --host 0.0.0.0 --port 5174" `
  -WorkingDirectory $ws `
  -RedirectStandardOutput $log `
  -RedirectStandardError $errF `
  -WindowStyle Hidden -PassThru

Set-Content -Path $pidFile -Value $p.Id -Encoding ascii
Write-Output "PID=$($p.Id)"
