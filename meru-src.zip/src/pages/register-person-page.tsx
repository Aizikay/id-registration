/**
 * Person registration form with full client-side validation, duplicate
 * identification detection and duplicate-person warnings.
 */

import { useCallback, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardBody, CardHeader, PageHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input, Select, Textarea } from "@/components/ui/form";
import { Modal } from "@/components/ui/modal";
import { useToast } from "@/components/ui/toast";
import { Icon } from "@/components/icons/icon";
import { StatusBadge } from "@/components/ui/status-badge";
import {
  validateAddress,
  validateDateOfBirth,
  validateFullName,
  validateGender,
  validateIdentificationNumber,
  validateNationality,
  validatePhone
} from "@/lib/validation";
import { registerPerson } from "@/services/people-service";
import { mapSupabaseError, AppError } from "@/services/errors";
import { v4 as uuidFallback } from "@/utils/uuid-fallback";
import type { Gender } from "@/types";

function newId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    try {
      return crypto.randomUUID();
    } catch {
      // fall through
    }
  }
  return uuidFallback();
}

interface FormState {
  identification_number: string;
  full_name: string;
  date_of_birth: string;
  gender: "" | Gender;
  nationality: string;
  address: string;
  phone: string;
}

const EMPTY_FORM: FormState = {
  identification_number: "",
  full_name: "",
  date_of_birth: "",
  gender: "",
  nationality: "Tanzanian",
  address: "",
  phone: ""
};

type Errors = Partial<Record<keyof FormState, string>>;

export function RegisterPersonPage() {
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [errors, setErrors] = useState<Errors>({});
  const [submitting, setSubmitting] = useState(false);
  const [duplicateId, setDuplicateId] = useState<{
    name: string;
    idNumber: string;
    created: string;
  } | null>(null);
  const [similarPeople, setSimilarPeople] = useState<
    { id: string; full_name: string; date_of_birth: string; identification_number: string }[]
  >([]);
  const toast = useToast();
  const navigate = useNavigate();

  const setField = (field: keyof FormState) => (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ): void => {
    let value = e.target.value;
    if (field === "identification_number") value = value.toUpperCase();
    if (field === "phone") value = value.replace(/[^\d+]/g, "").slice(0, 13);
    setForm((f) => ({ ...f, [field]: value }));
    setErrors((err) => ({ ...err, [field]: undefined }));
    setDuplicateId(null);
  };

  // Debounced duplicate-person warning (same name + DOB).
  useEffect(() => {
    const term = form.full_name.trim();
    if (term.length < 3 || !form.date_of_birth) {
      setSimilarPeople([]);
      return;
    }
    const timer = window.setTimeout(async () => {
      try {
        const { searchPersonsOffline } = await import("@/services/people-service");
        const local = await searchPersonsOffline(term, 10);
        setSimilarPeople(
          local
            .filter(
              (p) =>
                p.full_name.toLowerCase() === term.toLowerCase() &&
                p.date_of_birth === form.date_of_birth
            )
            .slice(0, 3)
            .map((p) => ({
              id: p.id,
              full_name: p.full_name,
              date_of_birth: p.date_of_birth,
              identification_number: p.identification_number
            }))
        );
      } catch {
        // Non-blocking suggestion only.
      }
    }, 500);
    return () => window.clearTimeout(timer);
  }, [form.full_name, form.date_of_birth]);

  const validateAll = (): Errors => {
    return {
      identification_number:
        validateIdentificationNumber(form.identification_number).message,
      full_name: validateFullName(form.full_name).message,
      date_of_birth: validateDateOfBirth(form.date_of_birth).message,
      gender: validateGender(form.gender).message,
      nationality: validateNationality(form.nationality).message,
      address: validateAddress(form.address).message,
      phone: form.phone ? validatePhone(form.phone).message : undefined
    };
  };

  const checkDuplicateBeforeSubmit = useCallback(async (): Promise<boolean> => {
    const { findDuplicateIdentification } = await import("@/services/people-service");
    try {
      const dup = await findDuplicateIdentification(form.identification_number);
      if (dup) {
        setDuplicateId({
          name: dup.full_name,
          idNumber: dup.identification_number,
          created: dup.created_at
        });
        return false;
      }
      return true;
    } catch {
      // If the check itself fails offline we proceed — the database UNIQUE
      // constraint remains the final guard at sync time.
      return true;
    }
  }, [form.identification_number]);

  const handleSubmit = async (e: React.FormEvent): Promise<void> => {
    e.preventDefault();
    const validation = validateAll();
    if (Object.values(validation).some(Boolean)) {
      setErrors(validation);
      toast.warning("Please correct the highlighted fields");
      return;
    }
    const okToContinue = await checkDuplicateBeforeSubmit();
    if (!okToContinue) return;

    setSubmitting(true);
    try {
      const result = await registerPerson({
        id: newId(),
        identification_number: form.identification_number.trim().toUpperCase(),
        full_name: form.full_name.trim(),
        date_of_birth: form.date_of_birth,
        gender: form.gender as Gender,
        nationality: form.nationality.trim() || "Tanzanian",
        address: form.address.trim(),
        phone: form.phone.trim() || null
      });
      if (result.offline) {
        toast.success(
          "Registered offline",
          `Saved on this device. Redirecting to ID Card Designer...`
        );
      } else {
        toast.success(
          "Person registered",
          `${result.person.full_name} saved — opening ID Card Designer...`
        );
      }
      // Redirect to ID Card Designer with the new person pre-loaded
      navigate(`/app/id-card?person=${result.person.id}`);
    } catch (err) {
      const mapped = err instanceof AppError ? err : mapSupabaseError(err);
      console.error("[RegisterPersonPage] failed:", mapped.code, mapped.detail, err);
      switch (mapped.code) {
        case "duplicate_identification":
        case "conflict_detected":
          setDuplicateId({
            name: "Existing record",
            idNumber: form.identification_number.toUpperCase(),
            created: ""
          });
          break;
        case "network_unavailable":
          // Should not happen (service falls back internally), but stay safe.
          toast.error("Saved locally", mapped.userMessage);
          break;
        default:
          toast.error("Registration failed", `${mapped.userMessage}${mapped.detail ? ` (${mapped.detail.slice(0,120)})` : ""}`);
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="mx-auto max-w-3xl animate-fade-in">
      <PageHeader
        title="Register Person"
        subtitle="Sajili Mtu Mpya — new citizen/resident record"
      />

      {similarPeople.length > 0 && !duplicateId && (
        <div
          role="status"
          className="mb-4 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800"
        >
          <p className="flex items-center gap-2 font-semibold">
            <Icon name="alert-triangle" className="h-4 w-4" />
            Possible duplicate person
          </p>
          <ul className="mt-2 space-y-1 text-xs">
            {similarPeople.map((p) => (
              <li key={p.id}>
                {p.full_name} · DOB {p.date_of_birth} ·{" "}
                <span className="font-mono">{p.identification_number}</span>
                {" — "}
                <button
                  type="button"
                  onClick={() => navigate(`/app/id-card?person=${p.id}`)}
                  className="font-semibold underline"
                >
                  open record
                </button>
              </li>
            ))}
          </ul>
          <p className="mt-2 text-[11px] opacity-80">
            Review carefully. Do not create a second record for the same person.
          </p>
        </div>
      )}

      <Card>
        <CardHeader
          title="Applicant details"
          subtitle="Fields marked * are required"
          icon={<Icon name="user-plus" className="h-4 w-4" />}
        />
        <CardBody>
          <form onSubmit={handleSubmit} noValidate className="space-y-5">
            <div className="grid gap-5 sm:grid-cols-2">
              <Input
                label="Full name"
                required
                placeholder="e.g. Anna Joseph Mwakalinga"
                value={form.full_name}
                onChange={setField("full_name")}
                error={errors.full_name}
                disabled={submitting}
                maxLength={120}
              />
              <Input
                label="Identification number"
                required
                placeholder="e.g. MRU2019001234"
                value={form.identification_number}
                onChange={setField("identification_number")}
                error={errors.identification_number}
                hint="8–20 uppercase letters/digits"
                disabled={submitting}
                maxLength={20}
              />
              <Input
                label="Date of birth"
                required
                type="date"
                value={form.date_of_birth}
                onChange={setField("date_of_birth")}
                error={errors.date_of_birth}
                disabled={submitting}
                max={new Date().toISOString().slice(0, 10)}
              />
              <Select
                label="Gender"
                required
                value={form.gender}
                onChange={setField("gender")}
                options={[
                  { value: "male", label: "Male / Mwanaume" },
                  { value: "female", label: "Female / Mwanamke" }
                ]}
                placeholder="Select gender…"
                error={errors.gender}
                disabled={submitting}
              />
              <Input
                label="Nationality"
                value={form.nationality}
                onChange={setField("nationality")}
                error={errors.nationality}
                disabled={submitting}
                maxLength={60}
              />
              <Input
                label="Phone number"
                type="tel"
                placeholder="0712345678"
                value={form.phone}
                onChange={setField("phone")}
                error={errors.phone}
                hint="Optional — Tanzanian format"
                disabled={submitting}
              />
            </div>

            <Textarea
              label="Physical address"
              required
              placeholder="Village/Streets, Ward, Division…"
              value={form.address}
              onChange={setField("address")}
              error={errors.address}
              disabled={submitting}
              rows={3}
              maxLength={300}
            />

            <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-4">
              <StatusBadge status={navigator.onLine ? "online" : "offline"} />
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => navigate("/app/people")}
                  disabled={submitting}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  loading={submitting}
                  icon={<Icon name="check" className="h-4 w-4" />}
                >
                  Register person
                </Button>
              </div>
            </div>
          </form>
        </CardBody>
      </Card>

      <Modal
        open={duplicateId !== null}
        onClose={() => setDuplicateId(null)}
        title="Duplicate identification number"
        tone="danger"
        size="sm"
        footer={
          <>
            <Button variant="outline" data-autofocus onClick={() => setDuplicateId(null)}>
              Edit entry
            </Button>
            {duplicateId?.created && (
              <Button variant="outline" onClick={() => navigate("/app/people")}>
                Search registry
              </Button>
            )}
          </>
        }
      >
        <div className="flex items-start gap-3 text-sm">
          <span className="mt-0.5 rounded-full bg-red-50 p-2 text-red-600">
            <Icon name="ban" className="h-5 w-5" />
          </span>
          <div className="text-slate-600">
            <p>
              Identification number{" "}
              <strong className="font-mono">{duplicateId?.idNumber}</strong> is
              already registered{duplicateId?.name && duplicateId.name !== "Existing record" ? ` to ${duplicateId.name}` : ""}.
            </p>
            <p className="mt-2 text-xs text-slate-500">
              Registration blocked by the system. Verify the applicant's
              identity before proceeding — never create duplicate records.
            </p>
          </div>
        </div>
      </Modal>
    </div>
  );
}
