import { useEffect, useState } from "react";
import { Card, PageHeader } from "@/components/ui/card";
import {
  EmptyState,
  ErrorState,
  SkeletonRows,
  TBody,
  TD,
  TH,
  THead,
  TR,
  Table
} from "@/components/ui/data-table";
import { StatusBadge } from "@/components/ui/status-badge";
import { listDevices } from "@/services/devices-service";
import type { WorkstationDevice } from "@/types";
import { formatDateTime, formatRelative } from "@/lib/format";

export function DevicesPage() {
  const [devices, setDevices] = useState<WorkstationDevice[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    listDevices()
      .then((d) => {
        if (!cancelled) setDevices(d);
      })
      .catch((err) => {
        if (!cancelled) setError(err.message ?? "Failed to load devices");
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div className="animate-fade-in">
      <PageHeader
        title="Workstation Devices"
        subtitle="Registered browsers/print-agent workstations. Revoked devices lose offline capability immediately."
      />
      <Card className="overflow-hidden">
        {error ? (
          <ErrorState message={error} onRetry={() => window.location.reload()} />
        ) : !loading && devices.length === 0 ? (
          <EmptyState
            icon="monitor"
            title="No registered devices"
            message="Devices register automatically the first time a staff member signs in."
          />
        ) : (
          <Table>
            <THead>
              <TR>
                <TH>Device</TH>
                <TH>Location</TH>
                <TH>Status</TH>
                <TH>Last online</TH>
                <TH>Last sync</TH>
              </TR>
            </THead>
            <TBody>
              {loading ? (
                <SkeletonRows rows={4} cols={5} />
              ) : (
                devices.map((d) => (
                  <TR key={d.id}>
                    <TD>
                      <p className="font-medium text-slate-800">{d.device_name}</p>
                      <p className="font-mono text-[11px] text-slate-400">{d.device_id}</p>
                    </TD>
                    <TD className="text-sm">{d.location ?? "—"}</TD>
                    <TD>
                      <StatusBadge status={d.status} />
                    </TD>
                    <TD className="text-xs" title={formatDateTime(d.last_online_at)}>
                      {d.last_online_at ? formatRelative(d.last_online_at) : "never"}
                    </TD>
                    <TD className="text-xs" title={formatDateTime(d.last_sync_at)}>
                      {d.last_sync_at ? formatRelative(d.last_sync_at) : "—"}
                    </TD>
                  </TR>
                ))
              )}
            </TBody>
          </Table>
        )}
      </Card>
    </div>
  );
}
