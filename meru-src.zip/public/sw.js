/**
 * Meru DC ID Registry — Service Worker
 *
 * Caches all static assets for offline use.
 * Strategy: Cache-First for static assets, Network-First for API calls.
 */

const CACHE_NAME = "meru-id-registry-v1";
const STATIC_ASSETS = [
  "/",
  "/index.html",
  "/login",
  "/app/dashboard",
  "/app/people",
  "/app/issuance",
  "/app/id-card",
  "/app/printers",
  "/app/reports",
  "/app/sync",
  "/app/settings",
];

// Assets to pre-cache on install
const PRECACHE_ASSETS = [
  "/branding/frontpageeditable.jpeg",
  "/branding/backpageid.jpeg",
  "/branding/merudc.jpeg",
  "/branding/court_of_arms-removebg-preview.png",
];

// Install: pre-cache critical assets
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log("[SW] Pre-caching static assets");
      return cache.addAll([...STATIC_ASSETS, ...PRECACHE_ASSETS]).catch((err) => {
        console.warn("[SW] Some assets failed to cache:", err);
        // Cache what we can
        return Promise.allSettled(
          [...STATIC_ASSETS, ...PRECACHE_ASSETS].map((url) =>
            cache.add(url).catch(() => console.warn(`[SW] Failed to cache: ${url}`))
          )
        );
      });
    })
  );
  // Activate immediately
  self.skipWaiting();
});

// Activate: clean up old caches
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((key) => key !== CACHE_NAME)
          .map((key) => {
            console.log("[SW] Removing old cache:", key);
            return caches.delete(key);
          })
      )
    )
  );
  // Take control of all pages immediately
  self.clients.claim();
});

// Fetch: serve from cache, fall back to network
self.addEventListener("fetch", (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Skip non-GET requests
  if (request.method !== "GET") return;

  // Skip Supabase API calls (let them go to network)
  if (url.hostname.includes("supabase")) return;

  // Skip Print Agent calls
  if (url.port === "8377") return;

  // Skip Vite dev server HMR
  if (url.pathname.startsWith("/@") || url.pathname.includes("__vite")) return;

  // For navigation requests, try network first, fall back to cache
  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request)
        .then((response) => {
          // Cache the response
          const responseClone = response.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(request, responseClone);
          });
          return response;
        })
        .catch(() => {
          return caches.match(request).then((cached) => {
            return cached || caches.match("/");
          });
        })
    );
    return;
  }

  // For static assets, try cache first, fall back to network
  event.respondWith(
    caches.match(request).then((cached) => {
      if (cached) return cached;

      return fetch(request)
        .then((response) => {
          // Don't cache non-success responses
          if (!response || response.status !== 200) return response;

          // Cache successful responses
          const responseClone = response.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(request, responseClone);
          });
          return response;
        })
        .catch(() => {
          // Return offline fallback for images
          if (request.destination === "image") {
            return new Response(
              '<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100"><rect fill="#e2e8f0" width="100" height="100"/><text fill="#94a3b8" font-family="sans-serif" font-size="12" x="50%" y="50%" text-anchor="middle" dy=".3em">Offline</text></svg>',
              { headers: { "Content-Type": "image/svg+xml" } }
            );
          }
          return new Response("Offline", { status: 503 });
        });
    })
  );
});

// Listen for messages from the main thread
self.addEventListener("message", (event) => {
  if (event.data && event.data.type === "SKIP_WAITING") {
    self.skipWaiting();
  }
});
