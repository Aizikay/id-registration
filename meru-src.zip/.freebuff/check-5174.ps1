$c = Get-NetTCPConnection -LocalPort 5174 -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
if ($c) {
  Write-Output "LISTENING pid=$($c.OwningProcess)"
} else {
  Write-Output "NOT_LISTENING"
}
$ws = 'C:\Users\hp\Pictures\ID Registration & Issuance Management System.(MERU DC) - Copy'
$log = Join-Path $ws '.freebuff\preview-185ab75d-b7ac-4e90-8d29-bbede45499ca.log'
Write-Output '--- LOG (tail) ---'
if (Test-Path $log) { Get-Content $log -Tail 15 } else { Write-Output '(no log file)' }
