import { useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { cn } from "@/lib/cn";
import { Icon } from "@/components/icons/icon";
import { Button } from "./button";

/**
 * Accessible modal dialog (focus trap + Escape + backdrop).
 * Glassmorphic design with smooth animations.
 */
export function Modal({
  open,
  onClose,
  title,
  description,
  children,
  footer,
  size = "md",
  tone = "default",
}: {
  open: boolean;
  onClose: () => void;
  title: React.ReactNode;
  description?: React.ReactNode;
  children?: React.ReactNode;
  footer?: React.ReactNode;
  size?: "sm" | "md" | "lg" | "xl";
  tone?: "default" | "danger";
}) {
  const dialogRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const previous = document.activeElement as HTMLElement | null;
    document.body.style.overflow = "hidden";

    const handleKey = (e: KeyboardEvent): void => {
      if (e.key === "Escape") {
        e.stopPropagation();
        onClose();
      }
      if (e.key === "Tab") {
        const focusables = dialogRef.current?.querySelectorAll<HTMLElement>(
          'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        if (!focusables || focusables.length === 0) return;
        const first = focusables[0]!;
        const last = focusables[focusables.length - 1]!;
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", handleKey);

    window.setTimeout(() => {
      const firstButton =
        dialogRef.current?.querySelector<HTMLElement>("[data-autofocus]");
      firstButton?.focus() ?? dialogRef.current?.focus();
    }, 50);

    return () => {
      document.removeEventListener("keydown", handleKey);
      document.body.style.overflow = "";
      previous?.focus?.();
    };
  }, [open, onClose]);

  if (!open) return null;

  const sizes = {
    sm: "max-w-sm",
    md: "max-w-lg",
    lg: "max-w-2xl",
    xl: "max-w-4xl",
  } as const;

  return createPortal(
    <div
      className="fixed inset-0 z-50 flex items-end justify-center p-4 sm:items-center"
      role="dialog"
      aria-modal="true"
      aria-label={typeof title === "string" ? title : undefined}
    >
      <button
        className={cn(
          "absolute inset-0 cursor-default",
          "bg-surface-900/40 backdrop-blur-md",
          "animate-fade-in"
        )}
        onClick={onClose}
        tabIndex={-1}
        aria-label="Close dialog"
      />
      <div
        ref={dialogRef}
        tabIndex={-1}
        className={cn(
          "relative w-full animate-scale-in",
          "rounded-2xl bg-white/90 dark:bg-slate-800/95 backdrop-blur-xl",
          "shadow-2xl outline-none border border-white/20 dark:border-slate-700/60",
          "overflow-hidden",
          sizes[size]
        )}
      >
        <div
          className={cn(
            "flex items-start justify-between gap-4 px-6 pt-5 pb-4",
            "bg-gradient-to-b from-surface-50/50 dark:from-slate-800/50 to-transparent",
            "border-b border-surface-100/60 dark:border-slate-700/60"
          )}
        >
          <div>
            <h2
              className={cn(
                "font-display text-base font-medium",
                tone === "danger" ? "text-danger-700 dark:text-red-400" : "text-surface-800 dark:text-slate-100"
              )}
            >
              {title}
            </h2>
            {description && (
              <p className="mt-1 text-sm text-surface-500 dark:text-slate-400">{description}</p>
            )}
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className={cn(
              "rounded-xl p-1.5 text-surface-400 dark:text-slate-500",
              "transition-all duration-200",
              "hover:bg-surface-100 dark:hover:bg-slate-700 hover:text-surface-600 dark:hover:text-slate-300",
              "active:scale-90"
            )}
          >
            <Icon name="x" className="h-5 w-5" />
          </button>
        </div>
        {children && <div className="px-6 py-5">{children}</div>}
        {footer && (
          <div
            className={cn(
              "flex flex-wrap justify-end gap-2.5 px-6 py-4",
              "border-t border-surface-100/60 dark:border-slate-700/60",
              "bg-surface-50/30 dark:bg-slate-900/30 backdrop-blur-sm"
            )}
          >
            {footer}
          </div>
        )}
      </div>
    </div>,
    document.body
  );
}

export interface ConfirmOptions {
  title: string;
  message: React.ReactNode;
  confirmLabel?: string;
  cancelLabel?: string;
  danger?: boolean;
  onConfirm: () => void;
  loading?: boolean;
}

export function ConfirmDialog({
  open,
  options,
  onCancel,
}: {
  open: boolean;
  options: ConfirmOptions | null;
  onCancel: () => void;
}) {
  if (!options) return null;
  return (
    <Modal
      open={open}
      onClose={onCancel}
      title={options.title}
      size="sm"
      tone={options.danger ? "danger" : "default"}
      footer={
        <>
          <Button variant="outline" onClick={onCancel} data-autofocus>
            {options.cancelLabel ?? "Cancel"}
          </Button>
          <Button
            variant={options.danger ? "danger" : "primary"}
            loading={options.loading}
            onClick={() => {
              options.onConfirm();
            }}
          >
            {options.confirmLabel ?? "Confirm"}
          </Button>
        </>
      }
    >
      <div className="flex items-start gap-3">
        <div
          className={cn(
            "mt-0.5 rounded-xl p-2.5",
            options.danger
              ? "bg-danger-50 dark:bg-red-950/60 text-danger-600 dark:text-red-400"
              : "bg-council-50 dark:bg-emerald-950/40 text-council-600 dark:text-emerald-400"
          )}
        >
          <Icon
            name={options.danger ? "alert-triangle" : "info"}
            className="h-5 w-5"
          />
        </div>
        <div className="text-sm leading-relaxed text-surface-600 dark:text-slate-400">
          {options.message}
        </div>
      </div>
    </Modal>
  );
}
