Set-Location 'C:\Users\hp\Pictures\ID Registration & Issuance Management System.(MERU DC) - Copy'
& C:\node.exe .\node_modules\typescript\bin\tsc -p electron/tsconfig.json 2>&1 | Select-Object -First 40
Write-Output "TSC_ELECTRON_EXIT=$LASTEXITCODE"
