/**
 * ID Card Editor Configuration — Meru District Council Employee ID
 *
 * Calibrated to match the existing constant text (MKURUGENZI, HW/MER/PF/17358)
 * on the original card template.
 *
 * Card: 502×325 px (85mm × 53.98mm, CR-80 standard)
 */

export interface FieldConfig {
  id: string;
  label: string;
  x: number;
  y: number;
  w: number;
  h: number;
  fontSize: number;
  fontWeight: number;
  fontFamily: string;
  color: string;
  textAlign: 'left' | 'center' | 'right';
  textTransform: 'none' | 'uppercase';
  lineHeight: number;
  letterSpacing: number;
}

export interface CalibrationPreset {
  id: string;
  name: string;
  timestamp: number;
  fields: Record<string, FieldConfig>;
}

export const CARD_CONFIG = {
  width: 502,
  height: 325,
  aspectRatio: 502 / 325,
  physicalWidth: 85.6,
  physicalHeight: 53.98,
  renderScale: 3,
  frontImage: '/branding/frontpage.jpeg',
  backImage: '/branding/backpage.jpeg',
};

/**
 * Calibrated font matching existing constant text on the card.
 */
const BASE_FONT: Omit<FieldConfig, 'id' | 'label'> = {
  x: 28.3,
  y: 44.5,
  w: 30,
  h: 4,
  fontSize: 15,
  textAlign: 'left',
  textTransform: 'uppercase',
  fontWeight: 700,
  fontFamily: '"Arial Narrow", Arial, Helvetica, sans-serif',
  color: '#000000',
  lineHeight: 1,
  letterSpacing: 0,
};

export const EDITABLE_FIELDS: Record<string, FieldConfig> = {
  cheki: {
    ...BASE_FONT,
    id: 'cheki',
    label: 'Cheki Namba',
    y: 44.5,
    textTransform: 'none',
  },
  jina: {
    ...BASE_FONT,
    id: 'jina',
    label: 'Jina (Full Name)',
    y: 52.5,
  },
  cheo: {
    ...BASE_FONT,
    id: 'cheo',
    label: 'Cheo (Position)',
    y: 59.5,
  },
};

/** Available fonts for card text */
export const FONT_OPTIONS: { label: string; value: string }[] = [
  { label: 'Arial Narrow Bold', value: '"Arial Narrow", Arial, Helvetica, sans-serif' },
  { label: 'Arial Bold', value: 'Arial, Helvetica, sans-serif' },
  { label: 'Arial Black', value: '"Arial Black", Arial, sans-serif' },
  { label: 'Helvetica Bold', value: '"Helvetica Neue", Helvetica, Arial, sans-serif' },
  { label: 'Times New Roman', value: '"Times New Roman", Times, serif' },
  { label: 'Georgia Bold', value: 'Georgia, "Times New Roman", serif' },
  { label: 'Verdana Bold', value: 'Verdana, Geneva, sans-serif' },
  { label: 'Trebuchet MS', value: '"Trebuchet MS", Helvetica, sans-serif' },
  { label: 'Impact', value: 'Impact, Haettenschweiler, sans-serif' },
  { label: 'Tahoma Bold', value: 'Tahoma, Geneva, sans-serif' },
  { label: 'Courier New Bold', value: '"Courier New", Courier, monospace' },
  { label: 'Segoe UI', value: '"Segoe UI", Tahoma, Geneva, sans-serif' },
  { label: 'Futura', value: 'Futura, "Trebuchet MS", Arial, sans-serif' },
  { label: 'Gill Sans', value: '"Gill Sans", "Gill Sans MT", Calibri, sans-serif' },
  { label: 'Roboto', value: 'Roboto, "Helvetica Neue", Arial, sans-serif' },
  { label: 'Open Sans', value: '"Open Sans", "Helvetica Neue", Arial, sans-serif' },
  { label: 'Lato', value: 'Lato, "Helvetica Neue", Arial, sans-serif' },
  { label: 'Montserrat', value: 'Montserrat, "Helvetica Neue", Arial, sans-serif' },
  { label: 'Nunito', value: 'Nunito, "Helvetica Neue", Arial, sans-serif' },
  { label: 'PT Sans', value: '"PT Sans", "Helvetica Neue", Arial, sans-serif' },
];

export const PHOTO_AREA = {
  x: 74.1,
  y: 40.3,
  w: 24.6,
  h: 52.0,
};

export const SIGNATURE_AREA = {
  x: 30.0,
  y: 61.0,
  w: 12,
  h: 8,
};

// Calibration presets storage
const PRESETS_KEY = 'meru-id-calibration-presets';

export function loadPresets(): CalibrationPreset[] {
  try {
    const raw = localStorage.getItem(PRESETS_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  return [];
}

export function savePreset(name: string): CalibrationPreset {
  const preset: CalibrationPreset = {
    id: `cal-${Date.now()}`,
    name,
    timestamp: Date.now(),
    fields: JSON.parse(JSON.stringify(EDITABLE_FIELDS)),
  };
  const presets = loadPresets();
  presets.push(preset);
  localStorage.setItem(PRESETS_KEY, JSON.stringify(presets));
  return preset;
}

export function deletePreset(id: string): void {
  const presets = loadPresets().filter((p) => p.id !== id);
  localStorage.setItem(PRESETS_KEY, JSON.stringify(presets));
}

export function loadPreset(id: string): boolean {
  const preset = loadPresets().find((p) => p.id === id);
  if (!preset) return false;
  Object.keys(preset.fields).forEach((key) => {
    if (EDITABLE_FIELDS[key] && preset.fields[key]) {
      Object.assign(EDITABLE_FIELDS[key], preset.fields[key]);
    }
  });
  return true;
}

export function resetToDefaults(): void {
  const defaults: Record<string, FieldConfig> = {
    cheki: {
      ...BASE_FONT, id: 'cheki', label: 'Cheki Namba', y: 44.5, textTransform: 'none',
    },
    jina: {
      ...BASE_FONT, id: 'jina', label: 'Jina (Full Name)', y: 52.5,
    },
    cheo: {
      ...BASE_FONT, id: 'cheo', label: 'Cheo (Position)', y: 59.5,
    },
  };
  Object.keys(defaults).forEach((key) => {
    if (EDITABLE_FIELDS[key]) {
      Object.assign(EDITABLE_FIELDS[key], defaults[key]);
    }
  });
}
