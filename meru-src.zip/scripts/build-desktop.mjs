#!/usr/bin/env node
/**
 * Desktop production build:
 *   1. Build the renderer (vite build) with relative base so file:// works.
 *   2. Bundle the electron main/preload (esbuild → dist-electron/*.cjs).
 *   3. Package with electron-builder (NSIS installer and/or portable exe).
 *
 * Usage:
 *   node scripts/build-desktop.mjs                  → installer + portable
 *   node scripts/build-desktop.mjs --win portable   → portable only
 */
import { spawnSync } from "node:child_process";
import { build } from "esbuild";
import { mkdirSync, cpSync, existsSync, readFileSync, writeFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const root = dirname(fileURLToPath(import.meta.url)) + "/..";
const node = "C:/node.exe";
const isWin = process.platform === "win32";

function run(cmd, args, opts = {}) {
  const r = spawnSync(cmd, args, { stdio: "inherit", shell: false, ...opts });
  if (r.status !== 0) {
    console.error(`[desktop] step failed: ${cmd} ${args.join(" ")}`);
    process.exit(r.status ?? 1);
  }
}

/* ─── 1. Renderer build (relative base for file://) ─── */
console.log("[desktop] building renderer (vite)...");
run(node, [join(root, "node_modules/vite/bin/vite.js"), "build"], {
  env: { ...process.env, VITE_BASE: "./" },
});

/* ─── 2. Main + preload bundle ─── */
console.log("[desktop] bundling electron main + preload...");
mkdirSync(join(root, "dist-electron"), { recursive: true });
await build({
  bundle: true,
  platform: "node",
  format: "cjs",
  target: "node20",
  external: ["electron", "electron-updater"],
  entryPoints: [join(root, "electron/main.ts")],
  outfile: join(root, "dist-electron/main.cjs"),
  logLevel: "warning",
});
await build({
  bundle: true,
  platform: "node",
  format: "cjs",
  target: "node20",
  external: ["electron"],
  entryPoints: [join(root, "electron/preload.ts")],
  outfile: join(root, "dist-electron/preload.cjs"),
  logLevel: "warning",
});

/* ─── 3. electron-builder ─── */
console.log("[desktop] packaging with electron-builder...");
const targets = process.argv.includes("--win")
  ? process.argv[process.argv.indexOf("--win") + 1] ?? "nsis,portable"
  : "nsis,portable";

run(isWin ? "C:/npm.cmd" : "npm", ["exec", "--yes", "--", "electron-builder", `--win ${targets}`], {
  cwd: root,
  env: process.env,
});

console.log("[desktop] done → dist-desktop/");
