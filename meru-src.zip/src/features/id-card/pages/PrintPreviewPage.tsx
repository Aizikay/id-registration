import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardBody, CardHeader, PageHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Icon } from "@/components/icons/icon";
import { useToast } from "@/components/ui/toast";
import { PdfIdCardPreview } from "../components/PdfIdCardPreview";
import { loadTemplate, type EmployeeData } from "../template";
import { searchPersonsOnline, searchPersonsOffline } from "@/services/people-service";
import { issueId } from "@/services/issuance-service";
import { printAgentClient } from "@/printing/agent-client";
import { createPrintHistory } from "@/services/print-history-service";
import type { Person } from "@/types";

function usePrintStyles() {
  useEffect(() => {
    const style = document.createElement("style");
    style.id = "id-card-print-styles";
    style.textContent = `
      @media print {
        @page { size: 86mm 54mm; margin: 0; }
        html, body { margin: 0 !important; padding: 0 !important; background: white !important; }
        body * { visibility: hidden !important; }
        #id-card-print-area, #id-card-print-area * { visibility: visible !important; }
        #id-card-print-area { position: absolute !important; left: 50% !important; top: 50% !important; transform: translate(-50%, -50%) !important; box-shadow: none !important; }
        .no-print { display: none !important; }
      }
    `;
    document.head.appendChild(style);
    return () => { document.getElementById("id-card-print-styles")?.remove(); };
  }, []);
}

export function PrintPreviewPage() {
  usePrintStyles();
  const navigate = useNavigate();
  const toast = useToast();
  const [template] = useState(() => loadTemplate());
  const [search, setSearch] = useState("");
  const [results, setResults] = useState<Person[]>([]);
  const [data, setData] = useState<EmployeeData>({
    fullName: "ELIZABETH R. MGOMBELO",
    checkNumber: "8973229",
    position: "AFISA ELIMU KATA",
    fileNumber: "HW/MER/PF/17358",
    identificationNumber: "MRU2019000001",
    photoUrl: null,
    photoCroppedUrl: null
  });
  const [selectedPerson, setSelectedPerson] = useState<Person | null>(null);
  const [printer, setPrinter] = useState("OFFICE-PRINTER-01");
  const [copies, setCopies] = useState(1);
  const [issuing, setIssuing] = useState(false);
  const [printState, setPrintState] = useState<"draft" | "ready" | "printing" | "issued" | "failed">("draft");

  useEffect(() => {
    if (search.trim().length < 2) { setResults([]); return; }
    const t = window.setTimeout(async () => {
      const online = navigator.onLine;
      const res = online ? await searchPersonsOnline({ search: search.trim(), pageSize: 6 }) : { rows: (await searchPersonsOffline(search.trim(), 6)) as unknown as Person[] };
      setResults((res.rows as Person[]).slice(0, 6));
    }, 300);
    return () => window.clearTimeout(t);
  }, [search]);

  const selectPerson = (p: Person) => {
    setSelectedPerson(p);
    setData({
      fullName: p.full_name.toUpperCase(),
      checkNumber: (p as unknown as { staff_number?: string }).staff_number ?? p.identification_number.slice(-7),
      position: (p as unknown as { position?: string }).position ?? "MTUMISHI",
      fileNumber: `HW/MER/PF/${p.identification_number.slice(-5)}`,
      identificationNumber: p.identification_number,
      photoUrl: null,
      photoCroppedUrl: null
    });
    setPrintState("ready");
    setSearch("");
    setResults([]);
  };

  const handlePrint = async () => {
    if (!selectedPerson) { toast.warning("Select employee first"); return; }
    setPrintState("printing");
    setIssuing(true);
    try {
      // First try to send to Print Agent
      let sentToAgent = false;
      try {
        const status = await printAgentClient.status();
        if (status.printers.length > 0) {
          const printer = status.printers.find((p) => p.is_default) ?? status.printers[0];
          if (!printer) return;
          
          // Create print history record
          const historyRecord = await createPrintHistory({
            document_name: `ID Card — ${data.fullName}`,
            printer_name: printer.name,
            printer_connection_type: 'unknown',
            person_name: data.fullName,
            identification_number: data.identificationNumber,
            status: 'printing',
          });

          // Send to Print Agent with dual-page images
          const idempotencyKey = `PRINT-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 8)}`;
          const result = await printAgentClient.submitPrintJob({
            document_reference: historyRecord.id,
            issuance_reference: `PH-${historyRecord.id.slice(0, 8)}`,
            idempotency_key: idempotencyKey,
            printer_id: printer.id,
            person_name: data.fullName,
            identification_number: data.identificationNumber,
            issued_by_staff_number: null,
            issued_at_iso: new Date().toISOString(),
            council_name_sw: 'HALMASHAURI YA WILAYA YA MERU',
            council_name_en: 'MERU DISTRICT COUNCIL',
            front_image_src: '/branding/frontpageeditable.jpeg',
            back_image_src: '/branding/backpageid.jpeg',
          });

          if (result.ok) {
            sentToAgent = true;
            toast.success(`Print sent to ${printer.name}`, `Job ID: ${result.job_id}`);
          }
        }
      } catch {
        // Print Agent not available, fall through to legacy print
      }

      // Legacy issuance flow
      if (!sentToAgent) {
        const result = await issueId({
          person: selectedPerson,
          printerId: null,
          workstationDeviceId: null,
          printJobReference: `PRT-${Date.now().toString(36).toUpperCase()}`
        });
        if (result.outcome === "blocked") {
          setPrintState("failed");
          toast.error("ID already issued", `Ref ${result.existing?.issuance_reference ?? ""}`);
          return;
        }
      }

      setPrintState("issued");
      if (!sentToAgent) {
        toast.success("Issued", "ID card issued — Print Agent offline, use Printers page to print");
      }
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      if (msg.includes("insertBefore")) {
        setPrintState("issued");
        return;
      }
      setPrintState("failed");
      toast.error("Issuance failed", (e as Error).message?.slice(0, 200) ?? "Database error");
    } finally {
      setIssuing(false);
    }
  };

  const handleDownloadPdf = async () => {
    try {
      const { PDFDocument } = await import("pdf-lib");
      const existingPdfBytes = await fetch(template.pdfSrc).then((r) => r.arrayBuffer());
      const pdfDoc = await PDFDocument.load(existingPdfBytes);
      const pdfBytes = await pdfDoc.save();
      const blob = new Blob([pdfBytes as unknown as BlobPart], { type: "application/pdf" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${data.fullName.replace(/\s+/g, "_")}_ID_${template.version}.pdf`;
      a.click();
      URL.revokeObjectURL(url);
    } catch {
      window.print();
    }
  };

  const handleFullscreenPrint = () => {
    const win = window.open("", "_blank", "width=960,height=680");
    if (!win) return;

    const cardHtml = `
      <div id="id-card-print-area" style="
        width: 86mm; height: 54mm; position: relative; overflow: hidden;
        background: #fef3c7; border-radius: 2mm;
        box-shadow: 0 0 60px rgba(16,185,129,0.3);
      ">
        <img src="${template.pdfSrc}" style="width: 100%; height: 100%; object-fit: cover; display: block;" crossorigin="anonymous" />
      </div>
    `;

    win.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Meru DC — Print ID Card</title>
        <style>
          @page { size: 86mm 54mm; margin: 0; }
          * { margin: 0; padding: 0; box-sizing: border-box; }
          html, body {
            width: 100%; height: 100%;
            display: flex; align-items: center; justify-content: center;
            background: #0f172a;
            font-family: system-ui, -apple-system, sans-serif;
          }
          .print-card { width: 86mm; height: 54mm; background: white; overflow: hidden; }
          @media print {
            html, body { background: white !important; }
            .print-card { box-shadow: none !important; }
            .controls { display: none !important; }
          }
        </style>
      </head>
      <body>
        <div class="controls" style="
          position: fixed; top: 0; left: 0; right: 0; z-index: 1000;
          display: flex; align-items: center; justify-content: center; gap: 12px;
          padding: 14px 20px;
          background: linear-gradient(135deg, #065f46, #064e3b);
          box-shadow: 0 4px 20px rgba(0,0,0,0.4);
        ">
          <span style="color: #6ee7b7; font-weight: 700; font-size: 14px;">🖨️ Print Preview — ${data.fullName}</span>
          <span style="color: rgba(255,255,255,0.5); margin: 0 8px;">|</span>
          <span style="color: #a7f3d0; font-size: 12px;">86 × 54 mm</span>
          <div style="flex: 1;" />
          <button onclick="window.print()" style="
            background: #10b981; color: white; border: none;
            padding: 8px 24px; border-radius: 8px; font-weight: 600;
            cursor: pointer; font-size: 13px;
          " onmouseover="this.style.background='#34d399'" onmouseout="this.style.background='#10b981'">🖨️ Print</button>
          <button onclick="window.close()" style="
            background: rgba(255,255,255,0.15); color: white; border: none;
            padding: 8px 16px; border-radius: 8px; cursor: pointer; font-size: 13px;
          ">✕ Close</button>
        </div>
        <div class="print-card" style="margin-top: 50px;">
          ${cardHtml}
        </div>
        <script>
          document.addEventListener('keydown', (e) => {
            if (e.key === 'p' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); window.print(); }
            if (e.key === 'Escape') window.close();
          });
        </script>
      </body>
      </html>
    `);
    win.document.close();
  };

  return (
    <div className="mx-auto max-w-6xl animate-fade-in">
      <PageHeader
        title="Print Preview"
        subtitle={`${template.dimensions.width} × ${template.dimensions.height} ${template.dimensions.unit} • exact print • no browser scaling`}
        actions={
          <Button variant="outline" size="sm" onClick={() => navigate("/app/id-card")}>
            Back to designer
          </Button>
        }
      />

      <div className="grid gap-6 lg:grid-cols-[1fr_380px]">
        <Card>
          <CardHeader title="PRINT PREVIEW" subtitle="Screen = Print (same template engine)" icon={<Icon name="printer" className="h-4 w-4" />} />
          <CardBody className="flex flex-col items-center gap-4 bg-slate-100 py-8">
            <div className={`rounded-full px-3 py-1 text-xs font-bold uppercase tracking-widest ${printState === "draft" ? "bg-slate-200 text-slate-600" : printState === "ready" ? "bg-council-800 text-white" : printState === "printing" ? "bg-amber-500 text-white animate-pulse" : printState === "issued" ? "bg-emerald-600 text-white" : "bg-red-600 text-white"}`}>
              {printState === "draft" ? "DRAFT" : printState === "ready" ? "READY TO PRINT" : printState === "printing" ? "PRINTING…" : printState === "issued" ? "ISSUED" : "PRINT FAILED"}
            </div>
            <PdfIdCardPreview template={template} data={data} scale={2.2} printMode />
            <p className="text-center font-mono text-xs text-slate-500">Template v{template.version} • {template.name}</p>
          </CardBody>
        </Card>

        <div className="space-y-4 no-print">
          <Card>
            <CardHeader title="Employee" icon={<Icon name="search" className="h-4 w-4" />} />
            <CardBody className="space-y-3">
              <input
                type="text"
                placeholder="Search name or Cheki Namba…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 placeholder-slate-400 outline-none transition-all focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
              />
              {results.length > 0 && (
                <div className="max-h-48 overflow-auto rounded-lg border border-slate-200">
                  {results.map((p) => (
                    <button key={p.id} onClick={() => selectPerson(p)} className="flex w-full items-center justify-between px-3 py-2 text-left hover:bg-slate-50">
                      <span className="text-sm font-medium">{p.full_name}</span>
                      <span className="font-mono text-xs text-slate-500">{(p as unknown as { staff_number?: string }).staff_number ?? p.identification_number}</span>
                    </button>
                  ))}
                </div>
              )}
              {selectedPerson && <p className="rounded-lg bg-emerald-50 px-3 py-2 text-sm text-emerald-800">Selected: <strong>{selectedPerson.full_name}</strong></p>}
            </CardBody>
          </Card>

          <Card>
            <CardHeader title="Print options" icon={<Icon name="settings" className="h-4 w-4" />} />
            <CardBody className="space-y-3">
              <label className="block text-xs font-medium uppercase tracking-wide text-slate-500">Printer</label>
              <select value={printer} onChange={(e) => setPrinter(e.target.value)} className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm">
                <option>OFFICE-PRINTER-01</option>
                <option>REGISTRY-PRINTER</option>
                <option>Save as PDF</option>
              </select>
              <label className="block text-xs font-medium uppercase tracking-wide text-slate-500">Copies</label>
              <input type="number" min={1} max={5} value={copies} onChange={(e) => setCopies(Math.max(1, Math.min(5, Number(e.target.value))))} className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm" />
              <div className="grid grid-cols-2 gap-2 pt-2">
                <Button variant="outline" onClick={() => window.print()} icon={<Icon name="eye" className="h-4 w-4" />}>
                  Quick Print
                </Button>
                <Button variant="outline" onClick={handleDownloadPdf} icon={<Icon name="download" className="h-4 w-4" />}>
                  Save PDF
                </Button>
              </div>
              <Button
                className="w-full mt-2"
                variant="outline"
                onClick={handleFullscreenPrint}
                icon={<span className="text-base">⛶</span>}
              >
                Fullscreen Print
              </Button>
              <div className="flex gap-2 pt-2">
                <Button variant="outline" className="flex-1" onClick={() => setPrintState("draft")}>
                  Cancel
                </Button>
                <Button className="flex-1" loading={issuing} onClick={handlePrint} icon={<Icon name="printer" className="h-4 w-4" />}>
                  Print ID
                </Button>
              </div>
              <p className="text-xs text-slate-500">Issuance is duplicate-blocked. Reprints require a reason and supervisor approval.</p>
            </CardBody>
          </Card>
        </div>
      </div>
    </div>
  );
}
