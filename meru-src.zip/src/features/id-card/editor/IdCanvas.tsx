/**
 * IdCanvas — High-resolution DPI-aware canvas renderer for the ID card.
 * Renders at 2x internal resolution so text and photos stay crisp at all zoom levels.
 * The export functions render at 3x for print-quality output.
 */

import { useRef, useEffect, useCallback } from "react";
import {
  CARD_CONFIG,
  EDITABLE_FIELDS,
  PHOTO_AREA,
  SIGNATURE_AREA,
} from "./editorConfig";

export interface EditorData {
  cheki: string;
  jina: string;
  cheo: string;
  photo: HTMLImageElement | null;
  photoTransform: { zoom: number; rotation: number; x: number; y: number } | null;
  signature: HTMLImageElement | null;
  sigTransform: { zoom: number; rotation: number; x: number; y: number } | null;
}

interface AreaOverride {
  x: number;
  y: number;
  w: number;
  h: number;
}

interface Props {
  frontBg: HTMLImageElement | null;
  backBg: HTMLImageElement | null;
  data: EditorData;
  zoom: number;
  page: "front" | "back";
  calVersion?: number;
  photoArea?: AreaOverride;
  sigArea?: AreaOverride;
  posVersion?: number;
}

const W = CARD_CONFIG.width;
const H = CARD_CONFIG.height;
// 2x DPI for crisp display — buffer is 2× card size, CSS displays at logical size
const DISPLAY_SCALE = 2;

export function IdCanvas({
  frontBg,
  backBg,
  data,
  zoom,
  page,
  calVersion = 0,
  photoArea,
  sigArea,
  posVersion = 0,
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mountedRef = useRef(false);

  useEffect(() => {
    mountedRef.current = true;
    return () => { mountedRef.current = false; };
  }, []);

  const renderCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || !mountedRef.current) return;
    const ctx = canvas.getContext("2d", { alpha: false });
    if (!ctx) return;

    // Set canvas buffer to 2× card dimensions for HiDPI rendering
    canvas.width = W * DISPLAY_SCALE;
    canvas.height = H * DISPLAY_SCALE;

    // Scale all drawing operations by 2 — coordinates stay in logical W×H space
    ctx.scale(DISPLAY_SCALE, DISPLAY_SCALE);

    // Enable high-quality image smoothing
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";

    // Clear the full buffer
    ctx.clearRect(0, 0, W, H);

    if (page === "front") {
      renderFront(ctx, frontBg, data, photoArea, sigArea);
    } else {
      renderBack(ctx, backBg);
    }
  }, [frontBg, backBg, data, page, photoArea, sigArea]);

  useEffect(() => {
    renderCanvas();
  }, [renderCanvas, calVersion, posVersion]);

  useEffect(() => {
    const h = () => renderCanvas();
    window.addEventListener("resize", h);
    return () => window.removeEventListener("resize", h);
  }, [renderCanvas]);

  // CSS displays the 2× buffer at logical W×H then ×zoom, so the browser downscales
  // from 1004→502px (2:1) at zoom=1, and 1:1 at zoom=2 — always crisp.
  return (
    <canvas
      ref={canvasRef}
      width={W * DISPLAY_SCALE}
      height={H * DISPLAY_SCALE}
      style={{
        display: "block",
        width: W * zoom,
        height: H * zoom,
        imageRendering: "auto",
      }}
    />
  );
}

/* ───────────────────────── Front page renderer ───────────────────────── */

function renderFront(
  ctx: CanvasRenderingContext2D,
  bg: HTMLImageElement | null,
  data: EditorData,
  photoOverride?: AreaOverride,
  sigOverride?: AreaOverride
) {
  // Layer 1: Background image
  if (bg && bg.complete && bg.naturalWidth > 0) {
    try {
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = "high";
      ctx.drawImage(bg, 0, 0, W, H);
    } catch { /* ignore */ }
  } else {
    ctx.fillStyle = "#f9e005";
    ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = "#1e293b";
    ctx.font = "bold 12px Arial, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("Loading template...", W / 2, H / 2);
  }

  // Layer 2: User Photo
  const area = photoOverride || PHOTO_AREA;
  const bx = (area.x / 100) * W;
  const by = (area.y / 100) * H;
  const bw = (area.w / 100) * W;
  const bh = (area.h / 100) * H;

  if (data.photo && data.photo.complete && data.photo.naturalWidth > 0) {
    // Overscan bleed so the cover-fit photo overlaps the frame edge completely —
    // no white margin, stroke, or background layer can ever show around the image.
    const bleedX = bw * 0.025;
    const bleedY = bh * 0.025;
    const px = bx - bleedX;
    const py = by - bleedY;
    const pw = bw + bleedX * 2;
    const ph = bh + bleedY * 2;

    ctx.save();
    ctx.beginPath();
    roundRect(ctx, px, py, pw, ph, 0);
    ctx.clip();

    const t = data.photoTransform || { zoom: 1, rotation: 0, x: 0, y: 0 };
    const natW = data.photo.naturalWidth || 1;
    const natH = data.photo.naturalHeight || 1;

    // Use cover-fit (max) for best quality — photo fills area edge-to-edge
    const fitScale = Math.max(pw / natW, ph / natH) * t.zoom;
    const dw = natW * fitScale;
    const dh = natH * fitScale;
    const dx = px + (pw - dw) / 2 + t.x;
    const dy = py + (ph - dh) / 2 + t.y;

    if (t.rotation !== 0) {
      ctx.translate(px + pw / 2, py + ph / 2);
      ctx.rotate((t.rotation * Math.PI) / 180);
      ctx.translate(-(px + pw / 2), -(py + ph / 2));
    }

    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(data.photo, dx, dy, dw, dh);
    ctx.restore();
    // No border or background layer when a photo is present — image is seamless
  } else {
    // Placeholder — white bounding box frame as a position guide (empty state only)
    ctx.save();
    ctx.strokeStyle = "rgba(255,255,255,0.8)";
    ctx.lineWidth = 1.5;
    ctx.lineJoin = "round";
    roundRect(ctx, bx, by, bw, bh, 4);
    ctx.stroke();
    ctx.restore();
  }

  // Layer 3: Editable text fields
  // Rendered to match existing constant text ("MKURUGENZI", "HW/MER/PF/17358")
  renderEditableText(ctx, data);

  // Layer 4: Employee Signature
  if (data.signature && data.signature.complete && data.signature.naturalWidth > 0) {
    const s = sigOverride || SIGNATURE_AREA;
    const sx = (s.x / 100) * W;
    const sy = (s.y / 100) * H;
    const sw = (s.w / 100) * W;
    const sh = (s.h / 100) * H;

    ctx.save();
    ctx.beginPath();
    ctx.rect(sx, sy, sw, sh);
    ctx.clip();

    const t = data.sigTransform || { zoom: 1, rotation: 0, x: 0, y: 0 };
    const sNatW = data.signature.naturalWidth || 1;
    const sNatH = data.signature.naturalHeight || 1;
    const fitScale = Math.min(sw / sNatW, sh / sNatH) * 0.85 * t.zoom;
    const dw = sNatW * fitScale;
    const dh = sNatH * fitScale;
    const dx = sx + (sw - dw) / 2 + t.x;
    const dy = sy + (sh - dh) / 2 + t.y;

    if (t.rotation !== 0) {
      ctx.translate(sx + sw / 2, sy + sh / 2);
      ctx.rotate((t.rotation * Math.PI) / 180);
      ctx.translate(-(sx + sw / 2), -(sy + sh / 2));
    }

    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(data.signature, dx, dy, dw, dh);
    ctx.restore();
  }
}

/* ───────────────── Editable text rendering ───────────────── */

function renderEditableText(ctx: CanvasRenderingContext2D, data: EditorData) {
  const fieldKeys = Object.keys(EDITABLE_FIELDS);

  for (let i = 0; i < fieldKeys.length; i++) {
    const f = EDITABLE_FIELDS[fieldKeys[i]!];
    if (!f) continue;

    const rawVal = (data as unknown as Record<string, unknown>)[f.id];
    const val = rawVal != null ? String(rawVal) : "";
    if (val.trim() === "") continue;

    // Calculate position from percentage coordinates
    const fx = (f.x / 100) * W;
    const fy = (f.y / 100) * H;

    ctx.save();

    // Font — match existing constant text exactly
    const fontStr = `${f.fontWeight} ${f.fontSize}px ${f.fontFamily}`;
    ctx.font = fontStr;
    ctx.fillStyle = f.color || "#000000";
    ctx.textBaseline = "alphabetic";
    ctx.textAlign = f.textAlign || "left";

    // Crisp text rendering — disable smoothing for text to keep it sharp
    ctx.imageSmoothingEnabled = true;

    // Text transform
    let displayVal = val;
    if (f.textTransform === "uppercase") {
      displayVal = displayVal.toUpperCase();
    }

    // Letter spacing via character-by-character rendering
    if (f.letterSpacing && f.letterSpacing !== 0) {
      ctx.textAlign = "left";
      let xPos = fx;
      for (let c = 0; c < displayVal.length; c++) {
        const char = displayVal[c]!;
        ctx.fillText(char, xPos, fy);
        xPos += ctx.measureText(char).width + f.letterSpacing;
      }
    } else {
      ctx.fillText(displayVal, fx, fy);
    }

    ctx.restore();
  }
}

/* ───────────────────────── Back page renderer ───────────────────────── */

function renderBack(ctx: CanvasRenderingContext2D, bg: HTMLImageElement | null) {
  ctx.clearRect(0, 0, W, H);

  if (bg && bg.complete && bg.naturalWidth > 0) {
    try {
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = "high";
      ctx.drawImage(bg, 0, 0, W, H);
    } catch { /* ignore */ }
  } else {
    // Fallback back page
    const grad = ctx.createLinearGradient(0, 0, W, H);
    grad.addColorStop(0, "#0c2d6b");
    grad.addColorStop(1, "#0a4b36");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    ctx.strokeStyle = "rgba(255,255,255,0.06)";
    ctx.lineWidth = 1;
    for (let i = 0; i < W; i += 24) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, H);
      ctx.stroke();
    }

    ctx.fillStyle = "rgba(255,255,255,0.15)";
    ctx.font = `bold ${H * 0.08}px Arial, sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("HALMASHAURI YA WILAYA YA MERU", W / 2, H * 0.35);

    ctx.fillStyle = "rgba(255,255,255,0.10)";
    ctx.font = `${H * 0.04}px Arial, sans-serif`;
    ctx.fillText("ID Registration & Issuance Management System", W / 2, H * 0.50);
    ctx.fillText("Arusha, Tanzania", W / 2, H * 0.60);

    ctx.fillStyle = "rgba(255,255,255,0.06)";
    ctx.font = `italic ${H * 0.03}px Arial, sans-serif`;
    ctx.fillText("Back of Card — Fixed", W / 2, H * 0.75);
  }
}

/* ───────────────────────── Utilities ───────────────────────── */

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

/* ───────────── High-resolution export (3× scale for print) ───────────── */

export function renderHighResFront(
  bg: HTMLImageElement | null,
  data: EditorData,
  photoOverride?: AreaOverride,
  sigOverride?: AreaOverride
): HTMLCanvasElement {
  const scale = CARD_CONFIG.renderScale; // 3x
  const c = document.createElement("canvas");
  c.width = W * scale;
  c.height = H * scale;
  const ctx = c.getContext("2d", { alpha: false })!;
  ctx.scale(scale, scale);
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  renderFront(ctx, bg, data, photoOverride, sigOverride);
  return c;
}

export function renderHighResBack(bg: HTMLImageElement | null): HTMLCanvasElement {
  const scale = CARD_CONFIG.renderScale; // 3x
  const c = document.createElement("canvas");
  c.width = W * scale;
  c.height = H * scale;
  const ctx = c.getContext("2d", { alpha: false })!;
  ctx.scale(scale, scale);
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  renderBack(ctx, bg);
  return c;
}
