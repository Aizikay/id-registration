/**
 * Domain-level status transition rules for issuance records.
 * Mirrors the database CHECK/trigger logic so both layers agree.
 */

import type { IssuanceStatus } from "@/types";

const TRANSITIONS: Record<IssuanceStatus, readonly IssuanceStatus[]> = {
  pending: ["printing", "issued", "failed", "cancelled"],
  printing: ["issued", "failed", "cancelled"],
  issued: [], // terminal — reprints create a NEW record, never mutate this
  failed: ["pending", "reprint_requested", "cancelled"],
  cancelled: [],
  reprint_requested: ["printing", "failed", "cancelled"]
};

export function canTransition(
  from: IssuanceStatus,
  to: IssuanceStatus
): boolean {
  return TRANSITIONS[from]?.includes(to) ?? false;
}

export function allowedNextStatuses(status: IssuanceStatus): readonly IssuanceStatus[] {
  return TRANSITIONS[status] ?? [];
}

/** Only these roles may mark a failed print as successfully issued. */
export const ISSUED_OVERRIDE_ROLES: readonly string[] = ["admin", "supervisor"];
