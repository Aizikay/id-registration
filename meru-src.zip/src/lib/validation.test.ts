import { describe, it, expect } from "vitest";
import {
  validateFullName,
  validateIdentificationNumber,
  validateDateOfBirth,
  validateGender,
  validateAddress,
  validatePhone,
  validateNationality
} from "./validation";

describe("validateFullName", () => {
  it("rejects empty", () => expect(validateFullName("").valid).toBe(false));
  it("rejects too short", () => expect(validateFullName("Ab").valid).toBe(false));
  it("rejects numeric names", () => expect(validateFullName("12345").valid).toBe(false));
  it("accepts Swahili/English names with apostrophe and hyphen", () => {
    expect(validateFullName("Asha Mohamed").valid).toBe(true);
    expect(validateFullName("Jean-Pierre O'Neil").valid).toBe(true);
    expect(validateFullName("Juma Hassan").valid).toBe(true);
  });
  it("rejects >120 chars", () => expect(validateFullName("A".repeat(121)).valid).toBe(false));
});

describe("validateIdentificationNumber", () => {
  it("accepts 1-30 uppercase alnum", () => {
    expect(validateIdentificationNumber("AB123456").valid).toBe(true);
    expect(validateIdentificationNumber("ab123456").valid).toBe(true); // uppercased internally
    expect(validateIdentificationNumber("A1B2C3D4E5F6G7H8I9J0").valid).toBe(true);
    expect(validateIdentificationNumber("1234567").valid).toBe(true); // short numeric OK
    expect(validateIdentificationNumber("MRU-1234").valid).toBe(true);
  });
  it("rejects too long", () => expect(validateIdentificationNumber("A".repeat(31)).valid).toBe(false));
  it("rejects spaces and special chars", () => expect(validateIdentificationNumber("AB 123456").valid).toBe(false));
  it("rejects at-sign and others", () => expect(validateIdentificationNumber("AB@1234").valid).toBe(false));
  it("rejects empty", () => expect(validateIdentificationNumber("").valid).toBe(false));
});

describe("validateDateOfBirth", () => {
  it("rejects empty", () => expect(validateDateOfBirth("").valid).toBe(false));
  it("rejects future date", () => {
    const future = new Date(Date.now() + 86400000).toISOString().slice(0, 10);
    expect(validateDateOfBirth(future).valid).toBe(false);
  });
  it("rejects under-18", () => {
    const d = new Date();
    d.setFullYear(d.getFullYear() - 10);
    expect(validateDateOfBirth(d.toISOString().slice(0, 10)).valid).toBe(false);
  });
  it("accepts 30-year-old", () => {
    const d = new Date();
    d.setFullYear(d.getFullYear() - 30);
    expect(validateDateOfBirth(d.toISOString().slice(0, 10)).valid).toBe(true);
  });
  it("rejects implausible >130 years", () => {
    expect(validateDateOfBirth("1800-01-01").valid).toBe(false);
  });
});

describe("validateGender", () => {
  it("accepts male/female", () => {
    expect(validateGender("male").valid).toBe(true);
    expect(validateGender("female").valid).toBe(true);
  });
  it("rejects other", () => expect(validateGender("other").valid).toBe(false));
});

describe("validateAddress", () => {
  it("rejects empty", () => expect(validateAddress("").valid).toBe(false));
  it("rejects too short", () => expect(validateAddress("Ab").valid).toBe(false));
  it("accepts normal address", () => expect(validateAddress("P.O. Box 123, Meru, Arusha").valid).toBe(true));
});

describe("validatePhone", () => {
  it("accepts empty (optional)", () => expect(validatePhone("").valid).toBe(true));
  it("accepts TZ mobile 07…", () => expect(validatePhone("0712345678").valid).toBe(true));
  it("accepts +255", () => expect(validatePhone("+255712345678").valid).toBe(true));
  it("rejects invalid", () => expect(validatePhone("12345").valid).toBe(false));
});

describe("validateNationality", () => {
  it("accepts empty (defaults upstream)", () => expect(validateNationality("").valid).toBe(true));
  it("accepts Tanzanian", () => expect(validateNationality("Tanzanian").valid).toBe(true));
  it("rejects numeric", () => expect(validateNationality("123").valid).toBe(false));
});
