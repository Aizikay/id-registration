#!/usr/bin/env node
/**
 * Desktop development orchestrator.
 *
 * Starts the Vite dev server (renderer) and launches Electron pointed at it.
 * Re-bundles the main process when electron/ sources change.
 */
import { spawn } from "node:child_process";
import { build } from "esbuild";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { existsSync } from "node:fs";

const root = dirname(fileURLToPath(import.meta.url)) + "/..";
const isWin = process.platform === "win32";
const node = "C:/node.exe";

/* ─── Bundle main + preload once up front ─── */
async function bundleMain() {
  await build({
    bundle: true,
    platform: "node",
    format: "cjs",
    target: "node20",
    external: ["electron", "electron-updater"],
    entryPoints: [join(root, "electron/main.ts")],
    outfile: join(root, "dist-electron/main.cjs"),
    logLevel: "silent",
  });
  await build({
    bundle: true,
    platform: "node",
    format: "cjs",
    target: "node20",
    external: ["electron"],
    entryPoints: [join(root, "electron/preload.ts")],
    outfile: join(root, "dist-electron/preload.cjs"),
    logLevel: "silent",
  });
}

await bundleMain();
console.log("[desktop] main + preload bundled");

/* ─── Start Vite dev server ─── */
const vite = spawn(
  node,
  [join(root, "node_modules/vite/bin/vite.js"), "--host", "127.0.0.1", "--port", "5174", "--strictPort"],
  { cwd: root, stdio: "inherit", shell: false }
);

// Wait for the dev server to answer, then launch Electron.
const electronExe = join(root, "node_modules/electron/dist/electron.exe");
if (!existsSync(electronExe)) {
  console.error("[desktop] electron binary missing — run: node node_modules/electron/install.js");
  vite.kill();
  process.exit(1);
}

async function waitForVite() {
  for (let i = 0; i < 60; i++) {
    try {
      const res = await fetch("http://127.0.0.1:5174/login");
      if (res.ok) return true;
    } catch {
      // not ready yet
    }
    await new Promise((r) => setTimeout(r, 500));
  }
  return false;
}

const ok = await waitForVite();
if (!ok) {
  console.error("[desktop] Vite dev server did not become ready in time");
  vite.kill();
  process.exit(1);
}

const electronProc = spawn(
  electronExe,
  [join(root, "dist-electron/main.cjs")],
  {
    cwd: root,
    stdio: "inherit",
    env: {
      ...process.env,
      ELECTRON_DISABLE_SECURITY_WARNINGS: "true",
      MERU_DESKTOP_DEV: "1",
      VITE_DEV_SERVER_URL: "http://127.0.0.1:5174",
    },
  }
);

electronProc.on("exit", (code) => {
  console.log(`[desktop] electron exited (${code}) — stopping vite`);
  vite.kill();
  process.exit(code ?? 0);
});

/* ─── Re-bundle main process on change ─── */
const { watch } = await import("node:fs");
let rebuildTimer = null;
watch(join(root, "electron"), { recursive: true }, () => {
  if (rebuildTimer) clearTimeout(rebuildTimer);
  rebuildTimer = setTimeout(async () => {
    await bundleMain();
    console.log("[desktop] main re-bundled — restart the app (Ctrl+R in Electron reloads renderer only)");
  }, 300);
});

const shutdown = () => {
  vite.kill();
  electronProc.kill();
  process.exit(0);
};
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
