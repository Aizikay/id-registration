/**
 * Staff/user administration service (admin only).
 * Account creation goes through the `create-user` Edge Function so the
 * service-role key never touches the frontend.
 */

import { supabase } from "./supabase-client";
import { env } from "@/lib/env";
import { mapSupabaseError } from "./errors";
import type { Profile, UserRole } from "@/types";

export async function listProfiles(): Promise<Profile[]> {
  const { data, error } = await supabase
    .from("profiles")
    .select("*")
    .order("staff_number");
  if (error) throw mapSupabaseError(error);
  return data as Profile[];
}

export interface CreateStaffInput {
  email: string;
  password: string;
  fullName: string;
  staffNumber: string;
  role: UserRole;
  department?: string;
  phone?: string;
}

export async function createStaffUser(input: CreateStaffInput): Promise<void> {
  const { data: sessionData } = await supabase.auth.getSession();
  const accessToken = sessionData.session?.access_token;
  if (!accessToken) throw mapSupabaseError(new Error("session_expired"));

  const response = await fetch(
    `${env.supabaseUrl}/functions/v1/create-user`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
        apikey: env.supabaseAnonKey
      },
      body: JSON.stringify({
        email: input.email,
        password: input.password,
        full_name: input.fullName,
        staff_number: input.staffNumber,
        role: input.role,
        department: input.department,
        phone: input.phone
      })
    }
  );

  if (!response.ok) {
    const body = (await response.json().catch(() => ({}))) as { error?: string };
    if (response.status === 403) {
      throw mapSupabaseError({ code: "42501", message: body.error });
    }
    throw new Error(body.error ?? "Failed to create staff account");
  }


}

export async function updateUserRole(profileId: string, role: UserRole): Promise<void> {
  const { error } = await supabase
    .from("profiles")
    .update({ role })
    .eq("id", profileId);
  if (error) throw mapSupabaseError(error);

}

export async function setUserStatus(
  profileId: string,
  status: "active" | "disabled"
): Promise<void> {
  // NOTE: full auth-layer ban requires the service-role key; the profile row
  // is disabled here (blocking all app access via RLS + auth-context checks),
  // and an administrator can additionally ban the user from the Supabase
  // dashboard for immediate session termination.
  const { error } = await supabase
    .from("profiles")
    .update({ status })
    .eq("id", profileId);
  if (error) throw mapSupabaseError(error);


}

export async function sendPasswordReset(email: string): Promise<void> {
  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${window.location.origin}/reset-password`
  });
  if (error) throw mapSupabaseError(error);
}
