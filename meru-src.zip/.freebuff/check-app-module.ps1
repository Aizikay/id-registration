$res = Invoke-WebRequest -Uri "http://localhost:5174/src/App.tsx" -UseBasicParsing -TimeoutSec 15
$c = $res.Content
$dyn = [regex]::Matches($c, "import\(").Count
Write-Output ("dynamic import count: " + $dyn)
Write-Output ("has lazy dashboard import: " + $c.Contains("dashboard-page"))
Write-Output ("has lazy IdEditor import: " + $c.Contains("editor/IdEditorPage"))
Write-Output ("has static IdEditorPage ref (should be only in lazy): " + $c.Contains("features/id-card/editor/IdEditorPage"))
