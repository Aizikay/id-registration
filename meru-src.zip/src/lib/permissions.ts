/**
 * Centralized permission matrix.
 *
 * Frontend checks use this for UI affordances only — authorization is
 * always enforced again at the database (RLS) level. Never trust the
 * frontend role check alone.
 */

import type { UserRole } from "@/types";

export type Permission =
  | "people.view"
  | "people.create"
  | "people.update"
  | "people.delete"
  | "issuance.view"
  | "issuance.create"
  | "issuance.cancel"
  | "print.request"
  | "print.reprint"
  | "users.view"
  | "users.manage"
  | "reports.view"
  | "reports.export"
  | "printers.view"
  | "printers.manage"
  | "departments.view"
  | "departments.manage"
  | "devices.view"
  | "devices.manage"
  | "settings.manage"
  | "sync.view"
  | "sync.retry"
  | "conflicts.resolve";

const PERMISSIONS: Record<UserRole, readonly Permission[]> = {
  admin: [
    "people.view",
    "people.create",
    "people.update",
    "people.delete",
    "issuance.view",
    "issuance.create",
    "issuance.cancel",
    "print.request",
    "print.reprint",
    "users.view",
    "users.manage",
    "reports.view",
    "reports.export",
    "printers.view",
    "printers.manage",
    "departments.view",
    "departments.manage",
    "devices.view",
    "devices.manage",
    "settings.manage",
    "sync.view",
    "sync.retry",
    "conflicts.resolve"
  ],
  officer: [
    "people.view",
    "people.create",
    "people.update",
    "issuance.view",
    "issuance.create",
    "print.request",
    "reports.view",
    "departments.view"
  ],
  supervisor: [
    "people.view",
    "people.delete",
    "issuance.view",
    "print.reprint",
    "users.view",
    "reports.view",
    "reports.export",
    "printers.view",
    "departments.view",
    "devices.view",
    "sync.view",
    "conflicts.resolve"
  ],
  viewer: ["people.view", "issuance.view"]
};

export function can(role: UserRole | null | undefined, permission: Permission): boolean {
  if (!role) return false;
  return PERMISSIONS[role].includes(permission);
}

export function permissionsFor(role: UserRole): readonly Permission[] {
  return PERMISSIONS[role];
}
