Set-Location 'C:\Users\hp\Pictures\ID Registration & Issuance Management System.(MERU DC) - Copy'
node_modules\.bin\tsc --noEmit 2>&1
exit $LASTEXITCODE
