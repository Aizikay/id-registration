import { lazy, Suspense } from "react";
import { BrowserRouter, HashRouter, Navigate, Route, Routes } from "react-router-dom";
import { isDesktop } from "@/lib/desktop";
import { AuthProvider } from "@/features/auth/auth-context";
import { ThemeProvider } from "@/contexts/ThemeContext";
import { ProtectedRoute } from "@/features/auth/protected-route";
import { ToastProvider } from "@/components/ui/toast";
import { AppShell } from "@/components/layout/app-shell";
import Loader from "@/components/Loader";

/*
 * Route-level code splitting: each page is its own lazy chunk, so the first
 * paint only waits for the code of the route you actually opened instead of
 * the whole application (dashboard, ID editor, PDF libs, printers, …).
 */
const LoginPage = lazy(() =>
  import("@/pages/login-page").then((m) => ({ default: m.LoginPage }))
);
const ForgotPasswordPage = lazy(() =>
  import("@/pages/forgot-password-page").then((m) => ({
    default: m.ForgotPasswordPage,
  }))
);
const DashboardPage = lazy(() =>
  import("@/pages/dashboard-page").then((m) => ({ default: m.DashboardPage }))
);
const PeopleListPage = lazy(() =>
  import("@/pages/people-list-page").then((m) => ({
    default: m.PeopleListPage,
  }))
);
const IssuanceListPage = lazy(() =>
  import("@/pages/issuance-list-page").then((m) => ({
    default: m.IssuanceListPage,
  }))
);
const ReportsPage = lazy(() =>
  import("@/pages/reports-page").then((m) => ({ default: m.ReportsPage }))
);
const PrintersPage = lazy(() =>
  import("@/pages/printers-page").then((m) => ({ default: m.PrintersPage }))
);
const SyncPage = lazy(() =>
  import("@/pages/sync-page").then((m) => ({ default: m.SyncPage }))
);
const SettingsPage = lazy(() =>
  import("@/pages/settings-page").then((m) => ({ default: m.SettingsPage }))
);
const DepartmentsPage = lazy(() =>
  import("@/pages/departments-page").then((m) => ({ default: m.DepartmentsPage }))
);
const PrintPreviewPage = lazy(() =>
  import("@/features/id-card/pages/PrintPreviewPage").then((m) => ({
    default: m.PrintPreviewPage,
  }))
);
const IdEditorPage = lazy(() =>
  import("@/features/id-card/editor/IdEditorPage")
);
const NotFoundPage = lazy(() =>
  import("@/pages/not-found-page").then((m) => ({ default: m.NotFoundPage }))
);

/** Full-screen loader shown while a route chunk loads. */
function RouteFallback() {
  return (
    <div
      className="flex min-h-screen items-center justify-center bg-slate-50 dark:bg-slate-950"
      role="status"
      aria-label="Loading page"
    >
      <Loader />
    </div>
  );
}

export default function App() {
  /*
   * Desktop (Electron production) loads the renderer from file://, where the
   * History API cannot work — use a hash router there. The web build keeps
   * clean browser URLs.
   */
  const Router = isDesktop() ? HashRouter : BrowserRouter;
  return (
    <Router>
      <AuthProvider>
        <ThemeProvider>
          <ToastProvider>
            <Suspense fallback={<RouteFallback />}>
              <Routes>
                <Route path="/login" element={<LoginPage />} />
                <Route path="/forgot-password" element={<ForgotPasswordPage />} />
                <Route path="/reset-password" element={<ForgotPasswordPage />} />

                <Route
                  path="/app"
                  element={
                    <ProtectedRoute>
                      <AppShell />
                    </ProtectedRoute>
                  }
                >
                  <Route index element={<DashboardPage />} />
                  <Route
                    path="people"
                    element={
                      <ProtectedRoute permission="people.view">
                        <PeopleListPage />
                      </ProtectedRoute>
                    }
                  />
                  <Route
                    path="people/register"
                    element={<Navigate to="/app/id-card?new=true" replace />}
                  />

                  <Route
                    path="issuance"
                    element={
                      <ProtectedRoute permission="issuance.view">
                        <IssuanceListPage />
                      </ProtectedRoute>
                    }
                  />

                  <Route
                    path="reports"
                    element={
                      <ProtectedRoute permission="reports.view">
                        <ReportsPage />
                      </ProtectedRoute>
                    }
                  />

                  <Route
                    path="printers"
                    element={
                      <ProtectedRoute permission="printers.view">
                        <PrintersPage />
                      </ProtectedRoute>
                    }
                  />

                  <Route
                    path="departments"
                    element={
                      <ProtectedRoute permission="departments.view">
                        <DepartmentsPage />
                      </ProtectedRoute>
                    }
                  />

                  <Route
                    path="sync"
                    element={
                      <ProtectedRoute>
                        <SyncPage />
                      </ProtectedRoute>
                    }
                  />
                  <Route
                    path="settings"
                    element={
                      <ProtectedRoute permission="settings.manage">
                        <SettingsPage />
                      </ProtectedRoute>
                    }
                  />
                  <Route
                    path="id-card"
                    element={
                      <ProtectedRoute permission="issuance.view">
                        <IdEditorPage />
                      </ProtectedRoute>
                    }
                  />
                  <Route
                    path="id-card/preview"
                    element={
                      <ProtectedRoute permission="issuance.view">
                        <PrintPreviewPage />
                      </ProtectedRoute>
                    }
                  />
                </Route>

                <Route path="/" element={<Navigate to="/app" replace />} />
                <Route path="*" element={<NotFoundPage />} />
              </Routes>
            </Suspense>
          </ToastProvider>
        </ThemeProvider>
      </AuthProvider>
    </Router>
  );
}
