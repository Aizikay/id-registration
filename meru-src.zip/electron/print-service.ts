import { app, BrowserWindow } from "electron";
import { createLogger } from "./logger";
import { listPrinters } from "./printer-discovery";
import type { NativePrintJob, NativePrintResult } from "../src/types";
import { writeFile, unlink, mkdtemp } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { randomUUID } from "node:crypto";

const exec = promisify(execFile);
const log = createLogger("print-service");

/**
 * Native print pipeline (main process).
 *
 *   Renderer (data-URI images)
 *     → hidden BrowserWindow prints via Electron's printToPDF (or silent
 *       SumatraPDF spooling for duplex/copies control)
 *     → OS print spooler → real printer
 *
 * Real results only: any spooler failure is returned as { ok:false } with the
 * actual error. Nothing is ever simulated.
 */

/** Map data URI / file:// / http(s):// image srcs to file paths readable by the print pipeline. */
async function materializeImage(src: string, dir: string, name: string): Promise<string> {
  if (src.startsWith("data:")) {
    const base64 = src.slice(src.indexOf(",") + 1);
    const filePath = join(dir, `${name}.png`);
    await writeFile(filePath, Buffer.from(base64, "base64"));
    return filePath;
  }
  if (src.startsWith("file://")) {
    return decodeURIComponent(src.replace(/^file:\/\/\//, "").replace(/\//g, "\\"));
  }
  if (/^https?:\/\//.test(src)) {
    const res = await fetch(src);
    if (!res.ok) throw new Error(`Failed to download image: HTTP ${res.status}`);
    const filePath = join(dir, `${name}.png`);
    await writeFile(filePath, Buffer.from(await res.arrayBuffer()));
    return filePath;
  }
  // Plain absolute path
  return src;
}

/** Build a two-sided (front+back) HTML document sized for the card. */
function buildCardHtml(frontPath: string, backPath: string | null, landscape: boolean): string {
  const page = landscape ? "width:101.6mm;height:63.5mm" : "width:63.5mm;height:101.6mm";
  return `<!doctype html>
<html><head><meta charset="utf-8"><style>
  @page { size: ${landscape ? "101.6mm 63.5mm" : "63.5mm 101.6mm"}; margin: 0; }
  html,body { margin:0; padding:0; }
  .page { ${page}; page-break-after: always; }
  .page img { width:100%; height:100%; object-fit:contain; }
  .last { page-break-after: auto; }
</style></head><body>
  <div class="page"><img src="file:///${frontPath.replace(/\\/g, "/")}"></div>
  ${backPath ? `<div class="page last"><img src="file:///${backPath.replace(/\\/g, "/")}"></div>` : ""}
</body></html>`;
}

/**
 * Locate a silent print helper (SumatraPDF portable) shipped with the app.
 * Users can drop SumatraPDF.exe next to the app executable to enable
 * advanced options (duplex, tray selection). Without it we fall back to
 * Electron's printToPDF + ShellExecute printto verb.
 */
function findSumatra(): string | null {
  const candidates = [
    join(process.resourcesPath ?? "", "SumatraPDF.exe"),
    join(app.getPath("exe"), "..", "SumatraPDF.exe"),
    join(app.getAppPath(), "SumatraPDF.exe"),
  ];
  for (const c of candidates) {
    try {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const { existsSync } = require("node:fs") as typeof import("node:fs");
      if (existsSync(c)) return c;
    } catch {
      // ignore
    }
  }
  return null;
}

async function printViaSumatra(
  sumatraExe: string,
  pdfPath: string,
  printerName: string,
  opts: { copies: number; duplex: boolean }
): Promise<NativePrintResult> {
  const args = [
    "-print-to", printerName,
    "-silent",
    "-print-settings",
    `${opts.copies}x${opts.duplex ? ",duplex" : ""}`,
    "-exit-when-done",
    pdfPath,
  ];
  await exec(sumatraExe, args, { timeout: 120_000, windowsHide: true });
  return { ok: true, job_id: randomUUID(), status: "completed", pages_printed: opts.copies * 2 };
}

/** Print a rendered PDF via the Windows shell "printto" verb (no dialog). */
async function printViaShellVerb(
  pdfPath: string,
  printerName: string
): Promise<NativePrintResult> {
  // PDFs registered with a default handler (usually Edge/Acrobat) respond to
  // the printto verb. We spawn the handler invisibly.
  const script = `
$ErrorActionPreference = 'Stop'
Start-Process -FilePath '${pdfPath.replace(/'/g, "''")}' -Verb PrintTo -ArgumentList '\"${printerName.replace(/'/g, "''")}\"' -WindowStyle Hidden -PassThru | Out-Null
`;
  await exec("powershell.exe", [
    "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", script,
  ], { timeout: 60_000, windowsHide: true });
  return { ok: true, job_id: randomUUID(), status: "completed" };
}

/** Render HTML → PDF via a hidden BrowserWindow using Electron's printToPDF. */
async function renderHtmlToPdf(
  html: string,
  opts: { landscape: boolean; marginsIn: number; paperWidthIn?: number; paperHeightIn?: number }
): Promise<{ pdf: Buffer; pages: number }> {
  const win = new BrowserWindow({
    show: false,
    webPreferences: { sandbox: true, nodeIntegration: false, contextIsolation: true },
  });
  try {
    await win.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(html)}`);
    const pdf = await win.webContents.printToPDF({
      landscape: opts.landscape,
      margins: {
        top: opts.marginsIn,
        bottom: opts.marginsIn,
        left: opts.marginsIn,
        right: opts.marginsIn,
      },
      pageSize: opts.paperWidthIn && opts.paperHeightIn
        ? { width: opts.paperWidthIn * 25400, height: opts.paperHeightIn * 25400 } // microns
        : undefined,
      printBackground: true,
      preferCSSPageSize: opts.paperWidthIn === undefined,
    });
    // pages unknown from printToPDF; approximate via form feeds in pdf — not critical
    return { pdf, pages: 1 };
  } finally {
    win.destroy();
  }
}

export async function printJob(job: NativePrintJob): Promise<NativePrintResult> {
  const started = Date.now();
  log.info(`Job ${job.job_ref}: printer="${job.printer_name}" duplex=${!!job.duplex} copies=${job.copies ?? 1}`);
  try {
    // Validate the printer exists right now.
    const printers = await listPrinters();
    const target = printers.find((p) => p.name === job.printer_name);
    if (!target) {
      return {
        ok: false,
        job_id: randomUUID(),
        status: "failed",
        error_message: `Printer "${job.printer_name}" is not installed or is disconnected.`,
      };
    }

    const tmp = await mkdtemp(join(tmpdir(), "meru-print-"));
    const frontPath = await materializeImage(job.front_image_src, tmp, "front");
    const backPath = job.back_image_src ? await materializeImage(job.back_image_src, tmp, "back") : null;
    const landscape = job.orientation !== "portrait";

    // 1. Compose the card HTML (front + optional back pages).
    const html = buildCardHtml(frontPath, backPath, landscape);

    // 2. Render to PDF.
    const { pdf } = await renderHtmlToPdf(html, {
      landscape,
      marginsIn: 0,
    });
    const pdfPath = join(tmp, "job.pdf");
    await writeFile(pdfPath, pdf);

    // 3. Spool to the real printer.
    let result: NativePrintResult;
    const sumatra = findSumatra();
    if (sumatra) {
      result = await printViaSumatra(sumatra, pdfPath, job.printer_name, {
        copies: job.copies ?? 1,
        duplex: job.duplex === true,
      });
    } else {
      result = await printViaShellVerb(pdfPath, job.printer_name);
    }

    // Cleanup temp (best effort; keep on failure for debugging).
    await unlink(pdfPath).catch(() => undefined);
    await unlink(frontPath).catch(() => undefined);
    if (backPath) await unlink(backPath).catch(() => undefined);

    log.info(`Job ${job.job_ref} completed in ${Date.now() - started}ms`);
    return result;
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    log.error(`Job ${job.job_ref} failed: ${msg}`);
    return { ok: false, job_id: randomUUID(), status: "failed", error_message: msg };
  }
}

/** Print an arbitrary PDF (already rendered by the renderer) directly. */
export async function printPdf(job: {
  job_ref: string;
  printer_name: string;
  pdf_base64: string;
  copies?: number;
  duplex?: boolean;
}): Promise<NativePrintResult> {
  try {
    const tmp = await mkdtemp(join(tmpdir(), "meru-print-"));
    const pdfPath = join(tmp, "doc.pdf");
    await writeFile(pdfPath, Buffer.from(job.pdf_base64, "base64"));
    const sumatra = findSumatra();
    if (sumatra) {
      const r = await printViaSumatra(sumatra, pdfPath, job.printer_name, {
        copies: job.copies ?? 1,
        duplex: job.duplex === true,
      });
      await unlink(pdfPath).catch(() => undefined);
      return r;
    }
    const r = await printViaShellVerb(pdfPath, job.printer_name);
    await unlink(pdfPath).catch(() => undefined);
    return r;
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    log.error(`PDF job ${job.job_ref} failed: ${msg}`);
    return { ok: false, job_id: randomUUID(), status: "failed", error_message: msg };
  }
}

/** Render HTML to PDF without printing (export flows). */
export async function renderPdfFromHtml(payload: {
  html: string;
  paper_width_in?: number;
  paper_height_in?: number;
  landscape?: boolean;
  margins_in?: number;
}): Promise<{ pdf_base64: string; pages: number }> {
  const { pdf, pages } = await renderHtmlToPdf(payload.html, {
    landscape: payload.landscape ?? false,
    marginsIn: payload.margins_in ?? 0,
    paperWidthIn: payload.paper_width_in,
    paperHeightIn: payload.paper_height_in,
  });
  return { pdf_base64: pdf.toString("base64"), pages };
}
