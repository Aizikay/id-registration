---
name: ui-ux-pro-max
description: "UI/UX design intelligence for web, mobile, and desktop. This skill should be used when designing, building, reviewing, or fixing interfaces, including pages, components, design systems, accessibility, interaction, responsive layout, typography, color, charts, and stack-specific UI implementation. Searchable local data: 79 searchable styles (50 active), 192 product palettes and reasoning profiles, 74 font pairs, 119 UX guidelines, 105 icons, 17 GSAP presets, 25 chart types, and 22 stacks."
metadata:
  author: nextlevelbuilder
  version: "2.0.0"
  source: https://github.com/nextlevelbuilder/ui-ux-pro-max-skill
---

# UI/UX Pro Max

## When to Use

Use this skill when the user wants to:
- Design or build any UI component, page, or layout
- Choose color schemes, typography, or visual styles
- Create landing pages, dashboards, or app interfaces
- Improve UX, accessibility, or responsive design
- Implement specific UI stacks (React, Vue, Tailwind, etc.)

## Quick Start

For new projects or pages, generate a complete design system:

```bash
python3 .agents/skills/ui-ux-pro-max/scripts/search.py "YOUR PROJECT DESCRIPTION" --design-system
```

Example:
```bash
python3 .agents/skills/ui-ux-pro-max/scripts/search.py "ID registration system government dashboard" --design-system -p "Meru Council"
```

## Available Commands

### Generate Design System
```bash
python3 .agents/skills/ui-ux-pro-max/scripts/search.py "<keywords>" --design-system
python3 .agents/skills/ui-ux-pro-max/scripts/search.py "<keywords>" --design-system -f markdown -p "Project Name"
```

### Search Specific Domains
```bash
# UI Styles (glassmorphism, brutalism, minimalism, etc.)
python3 .agents/skills/ui-ux-pro-max/scripts/search.py "glassmorphism modern" --domain style

# Color Palettes
python3 .agents/skills/ui-ux-pro-max/scripts/search.py "professional corporate" --domain color

# Typography
python3 .agents/skills/ui-ux-pro-max/scripts/search.py "clean modern" --domain typography

# UX Guidelines
python3 .agents/skills/ui-ux-pro-max/scripts/search.py "form validation accessibility" --domain ux

# Landing Pages
python3 .agents/skills/ui-ux-pro-max/scripts/search.py "hero sections" --domain landing
```

### Stack-Specific Guidelines
```bash
# React/Next.js
python3 .agents/skills/ui-ux-pro-max/scripts/search.py "components responsive" --stack react

# Vue/Nuxt
python3 .agents/skills/ui-ux-pro-max/scripts/search.py "forms validation" --stack vue

# Tailwind CSS
python3 .agents/skills/ui-ux-pro-max/scripts/search.py "dark mode" --domain html-tailwind
```

### Save Design System to Project
```bash
python3 .agents/skills/ui-ux-pro-max/scripts/search.py "<query>" --design-system --persist --output-dir "."
```

## Data Files

All searchable data is in `.agents/skills/ui-ux-pro-max/data/`:
- `styles.csv` - 79 UI styles (glassmorphism, neumorphism, brutalism, etc.)
- `colors.csv` - Color palettes
- `typography.csv` - Font pairings
- `products.csv` - 192 product types
- `landing.csv` - Landing page patterns
- `ux-guidelines.csv` - UX best practices
- `icons.csv` - Icon recommendations
- `charts.csv` - Chart types for dashboards
- `stacks/` - Stack-specific guidelines for React, Vue, Angular, etc.

## Tips

1. **Be specific**: "dark glassmorphism dashboard" > "nice looking UI"
2. **Mention your stack**: The skill adapts recommendations to React, Vue, Tailwind, etc.
3. **Use `--domain`** for targeted searches
4. **Use `--design-system`** for complete project styling
5. **Save your design system** with `--persist` for consistency across sessions
