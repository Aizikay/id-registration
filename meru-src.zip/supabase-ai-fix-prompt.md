# Supabase AI — Database Fix Prompt

Copy everything below (the `<<<` fences included) into Supabase AI (Dashboard → SQL Editor → AI) and send.

---

<<<

I need you to apply a database fix to this project. Diagnosis is already complete; do not change table structures or policies beyond what is specified below. Apply both SQL blocks exactly, then run the verification queries at the end and report results.

## Context / symptoms
- The app is an ID Registration & Issuance system. The hosted DB is missing some schema from its migrations.
- Symptom: the dashboard shows 2 registered people, but the People Registry/GitHub-style list shows "No registered people yet".
- Root cause: the `persons` table is missing the `signature_path` column, so every REST SELECT that includes that column fails with `HTTP 400 code 42703: column persons.signature_path does not exist`. The app swallows the error, so the list renders as empty.
- Secondary issues to fix in this same pass:
  1. `get_dashboard_stats()` is currently executable by the `anon` role (a security leak). It must be `revoke`d from `anon` and granted only to `authenticated`.
  2. `get_dashboard_stats()` currently returns a daily series key named `issued`; the app expects `issued_count`. Replace the function with the canonical definition below.
- All statements are idempotent (safe to re-run).

## Block 1 — Add `signature_path` + Supervisor/Admin DELETE policy

Run:

```sql
-- 1. Add signature_path column to persons table
ALTER TABLE public.persons
  ADD COLUMN IF NOT EXISTS signature_path text;

-- 2. Enable Row Level Security (if not already enabled)
ALTER TABLE public.persons ENABLE ROW LEVEL SECURITY;

-- 3. Replace the DELETE policy so admin AND supervisor can delete.
DROP POLICY IF EXISTS "Allow only Supervisors to delete people" ON public.persons;
DROP POLICY IF EXISTS "delete_people_supervisor_only" ON public.persons;
DROP POLICY IF EXISTS "persons_delete_admin" ON public.persons;
DROP POLICY IF EXISTS "person_delete_supervisor_admin" ON public.persons;

CREATE POLICY "person_delete_supervisor_admin" ON public.persons
  FOR DELETE TO authenticated
  USING (public.auth_profile_role() IN ('supervisor', 'admin'));

-- 4. Recreate the canonical read/write policies to make re-runs safe.
DROP POLICY IF EXISTS "Allow authenticated users to view people" ON public.persons;
CREATE POLICY "Allow authenticated users to view people"
  ON public.persons FOR SELECT
  TO authenticated
  USING (true);

DROP POLICY IF EXISTS "Allow authenticated users to insert people" ON public.persons;
CREATE POLICY "Allow authenticated users to insert people"
  ON public.persons FOR INSERT
  TO authenticated
  WITH CHECK (true);

DROP POLICY IF EXISTS "Allow authenticated users to update people" ON public.persons;
CREATE POLICY "Allow authenticated users to update people"
  ON public.persons FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);
```

## Block 2 — Harden `get_dashboard_stats` (fix key mismatch + anon leak)

Run:

```sql
create or replace function public.get_dashboard_stats()
returns jsonb
language sql
stable
security definer
set search_path = public
as $$
  select jsonb_build_object(
    'total_registered', (select count(*) from public.persons),
    'total_issued', (select count(*) from public.issuance_records where status = 'issued'),
    'total_pending', (select count(*) from public.issuance_records where status in ('pending','printing','reprint_requested')),
    'total_failed_prints', (select count(*) from public.issuance_records where status = 'failed'),
    'today_issued', (select count(*) from public.issuance_records where status='issued' and issued_at >= date_trunc('day', now())),
    'online_devices', (select count(*) from public.workstation_devices where status='active' and last_online_at > now() - interval '15 minutes'),
    'printers_online', (select count(*) from public.printers where status='online' and enabled),
    'printers_total', (select count(*) from public.printers where enabled),
    'recent_issuances', (
      select coalesce(jsonb_agg(x), '[]'::jsonb) from (
        select i.issuance_reference, i.issued_at, i.status, pr.full_name as person_name,
               pr.identification_number, pf.staff_number as issued_by_staff
        from public.issuance_records i
        join public.persons pr on pr.id = i.person_id
        left join public.profiles pf on pf.id = i.issued_by
        order by coalesce(i.issued_at, i.created_at) desc
        limit 10
      ) x
    ),
    'daily_last_7_days', (
      select coalesce(jsonb_agg(x order by x.day), '[]'::jsonb) from (
        select d::date as day,
               (select count(*) from public.issuance_records
                 where status='issued' and issued_at >= d and issued_at < d + interval '1 day') as issued_count
        from generate_series(date_trunc('day', now()) - interval '6 days', date_trunc('day', now()), interval '1 day') d
      ) x
    )
  );
$$;

-- Only authenticated staff may read the aggregate; no anon access.
revoke execute on function public.get_dashboard_stats() from anon;
grant execute on function public.get_dashboard_stats() to authenticated;
```

## Verify and report back
After applying, run these and confirm each passes:

```sql
-- 1. Column now exists
select column_name, data_type from information_schema.columns
where table_schema = 'public' and table_name = 'persons' and column_name = 'signature_path';

-- 2. Function not executable by anon anymore
select has_function_privilege('anon', 'public.get_dashboard_stats()', 'EXECUTE') as anon_can_execute;

-- 3. Function returns the expected shape (daily key must be issued_count, not issued)
select public.get_dashboard_stats() as stats;

-- 4. RLS policies present
select policyname, cmd from pg_policies
where schemaname = 'public' and tablename = 'persons'
order by cmd;
```

<<<