/**
 * Inactivity auto-lock. After `env.idleLockMinutes` without interaction the
 * user is signed out (secure logout) per government security policy.
 */

import { useEffect, useRef } from "react";
import { env } from "@/lib/env";

const EVENTS: readonly (keyof DocumentEventMap)[] = [
  "mousemove",
  "mousedown",
  "keydown",
  "touchstart",
  "scroll"
];

export function useIdleLock(onLock: () => void): void {
  const callbackRef = useRef(onLock);
  callbackRef.current = onLock;

  useEffect(() => {
    if (!env.idleLockMinutes || env.idleLockMinutes <= 0) return;

    let timer: number | null = null;
    const reset = (): void => {
      if (timer !== null) window.clearTimeout(timer);
      timer = window.setTimeout(
        () => callbackRef.current(),
        env.idleLockMinutes * 60_000
      );
    };

    for (const evt of EVENTS) {
      document.addEventListener(evt, reset, { passive: true });
    }
    reset();

    return () => {
      if (timer !== null) window.clearTimeout(timer);
      for (const evt of EVENTS) {
        document.removeEventListener(evt, reset);
      }
    };
  }, []);
}
