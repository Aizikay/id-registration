import { useCallback, useEffect, useRef, useState } from "react";
import { printAgentClient, type AgentPrinterInfo } from "@/printing/agent-client";

export interface DiscoveredPrinter extends AgentPrinterInfo {
  connection_type: "usb" | "network" | "wireless" | "unknown";
  registered: boolean; // whether this printer is also in the Supabase DB
}

interface UsePrinterDiscoveryOptions {
  /** Poll interval in ms. Set 0 to disable polling. Default 15000 (15s). */
  pollInterval?: number;
}

interface UsePrinterDiscoveryResult {
  printers: DiscoveredPrinter[];
  agentOnline: boolean;
  loading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
}

/**
 * Auto-discovers printers via the local Print Agent.
 * The agent runs on the workstation and uses PowerShell `Get-Printer` /
 * WMIC to enumerate USB, network, and wireless printers.
 */
export function usePrinterDiscovery(
  registeredIdentifiers: Set<string>,
  opts: UsePrinterDiscoveryOptions = {}
): UsePrinterDiscoveryResult {
  const { pollInterval = 15_000 } = opts;
  const [printers, setPrinters] = useState<DiscoveredPrinter[]>([]);
  const [agentOnline, setAgentOnline] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const mountedRef = useRef(true);

  const fetchPrinters = useCallback(async () => {
    try {
      setError(null);
      const status = await printAgentClient.status();
      if (!mountedRef.current) return;
      setAgentOnline(true);

      const discovered: DiscoveredPrinter[] = status.printers.map((p) => ({
        ...p,
        connection_type: classifyConnection(p),
        registered: registeredIdentifiers.has(p.id) || registeredIdentifiers.has(p.name),
      }));
      setPrinters(discovered);
    } catch (err) {
      if (!mountedRef.current) return;
      const msg = err instanceof Error ? err.message : String(err);
      if (msg === "agent_unreachable" || msg.includes("fetch")) {
        setAgentOnline(false);
        setError("Print Agent not reachable. Start the agent on this workstation.");
      } else {
        setError(msg);
      }
    } finally {
      if (mountedRef.current) setLoading(false);
    }
  }, [registeredIdentifiers]);

  useEffect(() => {
    mountedRef.current = true;
    void fetchPrinters();

    let interval: ReturnType<typeof setInterval> | undefined;
    if (pollInterval > 0) {
      interval = setInterval(() => {
        void fetchPrinters();
      }, pollInterval);
    }

    return () => {
      mountedRef.current = false;
      if (interval) clearInterval(interval);
    };
  }, [fetchPrinters, pollInterval]);

  return { printers, agentOnline, loading, error, refresh: fetchPrinters };
}

/**
 * Classify a printer's connection type based on its name and properties.
 * This is heuristic — Windows doesn't expose connection type via Get-Printer
 * in a simple field, but we can infer from common patterns.
 */
function classifyConnection(p: AgentPrinterInfo): DiscoveredPrinter["connection_type"] {
  const name = p.name.toLowerCase();

  // USB printers often have "USB" in name, or brand names like "HP DeskJet"
  if (name.includes("usb")) return "usb";

  // Network printers often have IP patterns or "network" in name
  if (name.includes("network") || /\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/.test(name)) {
    return "network";
  }

  // Wireless printers
  if (name.includes("wireless") || name.includes("wifi") || name.includes("airprint")) {
    return "wireless";
  }

  // Shared printers on the network
  if (name.includes("shared") || name.includes("\\\\")) return "network";

  // Default heuristic: if status is online and no identifying marks, assume USB
  return "unknown";
}
