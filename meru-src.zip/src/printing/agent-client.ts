/**
 * Local Print Agent client (browser side).
 *
 * The agent is a small authenticated service running on the officer's Windows
 * workstation (see /print-agent). It exposes a localhost-only HTTP API.
 *
 * Security model:
 *   - Agent listens on 127.0.0.1 ONLY (never exposed to the LAN).
 *   - Agent validates request `Origin` against an allowlist of authorized
 *     deployments, so arbitrary websites cannot drive the printer.
 *   - Every print job carries: issuance reference, actor identity, device id,
 *     printer identity and an idempotency key. The agent refuses jobs missing
 *     these or replaying an already-printed idempotency key.
 */

import { env } from "@/lib/env";
import { AppError } from "@/services/errors";
import { authProfileCache } from "@/services/audit-service";

export interface AgentStatus {
  ok: true;
  agent_version: string;
  device_id: string;
  printers: AgentPrinterInfo[];
}

export interface AgentPrinterInfo {
  id: string; // agent-local identifier
  name: string;
  is_default: boolean;
  status: "online" | "offline" | "unknown" | "error";
  location?: string;
}

export interface PrintJobRequest {
  /** Server-issued or locally generated unique print reference. */
  document_reference: string;
  issuance_reference: string;
  idempotency_key: string;
  printer_id: string;
  person_name: string;
  identification_number: string;
  issued_by_staff_number: string | null;
  issued_at_iso: string;
  council_name_sw: string;
  council_name_en: string;
  /** Front page image (data URI or URL) for dual-page printing. */
  front_image_src?: string;
  /** Back page image (data URI or URL) for dual-page printing. */
  back_image_src?: string;
  /** Optional text overlays for the front page. */
  front_overlays?: {
    chekiNamba?: string;
    jina?: string;
    cheo?: string;
    photoSrc?: string;
    signatureSrc?: string;
  };
}

export interface PrintJobResult {
  ok: boolean;
  job_id: string;
  status: "completed" | "failed" | "queued" | "printing";
  error_message?: string;
  pages_printed?: number;
}

async function agentFetch<T>(
  path: string,
  init?: RequestInit
): Promise<T> {
  const url = `${env.printAgentUrl}${path}`;
  let response: Response;
  try {
    response = await fetch(url, {
      ...init,
      headers: {
        "Content-Type": "application/json",
        ...(init?.headers ?? {})
      }
    });
  } catch {
    throw new AppError("agent_unreachable", "Print Agent at " + env.printAgentUrl + " is not reachable");
  }
  if (!response.ok) {
    const body = (await response.json().catch(() => ({}))) as {
      error?: string;
    };
    throw new AppErrorLike(body.error ?? `agent_error_${response.status}`);
  }
  return (await response.json()) as T;
}

class AppErrorLike extends Error {}

export const printAgentClient = {
  async status(): Promise<AgentStatus> {
    return agentFetch<AgentStatus>("/status");
  },

  async printers(): Promise<AgentPrinterInfo[]> {
    const s = await this.status();
    return s.printers;
  },

  async testPrinter(printerId: string): Promise<{ ok: boolean; message: string }> {
    try {
      const result = await agentFetch<{ ok: boolean; job_id: string }>(
        "/test",
        {
          method: "POST",
          body: JSON.stringify({
            printer_id: printerId,
            requested_by: authProfileCache.staffNumber
          })
        }
      );
      return { ok: result.ok, message: "Test page sent to printer." };
    } catch (err) {
      const message =
        err instanceof Error && err.message === "agent_unreachable"
          ? "Print Agent is not reachable. Start it on this workstation."
          : "Printer test failed.";
      return { ok: false, message };
    }
  },

  async submitPrintJob(request: PrintJobRequest): Promise<PrintJobResult> {
    return agentFetch<PrintJobResult>("/print", {
      method: "POST",
      body: JSON.stringify({
        ...request,
        requested_by: authProfileCache.staffNumber
      })
    });
  },

  async jobStatus(jobId: string): Promise<PrintJobResult> {
    return agentFetch<PrintJobResult>(`/jobs/${encodeURIComponent(jobId)}`);
  }
};
