import { BrowserWindow, dialog } from "electron";
import { createLogger } from "./logger";
import { resolveElectronUpdater } from "./package";

const log = createLogger("updater");

/**
 * Update checking. electron-updater is only active in packaged builds where
 * the module is bundled into app.asar; in dev it reports "not available".
 * Publish configuration (GitHub / generic server) can be added later in
 * electron-builder.yml without touching this file.
 */
export async function checkForUpdates(win: BrowserWindow | null): Promise<{
  ok: boolean;
  message: string;
}> {
  const updater = resolveElectronUpdater() as {
    autoUpdater?: {
      checkForUpdatesAndNotify: () => Promise<unknown>;
      on: (event: string, cb: (info: unknown) => void) => void;
    };
  } | null;

  if (!updater?.autoUpdater) {
    return {
      ok: false,
      message: "Update checking is unavailable in this build (development mode or no update feed configured).",
    };
  }

  try {
    updater.autoUpdater.on("update-downloaded", (info) => {
      log.info("Update downloaded");
      void dialog.showMessageBox(win ?? undefined!, {
        type: "info",
        title: "Update Ready",
        message: "A new version has been downloaded.",
        detail: `Restart the app to apply the update. ${
          typeof info === "object" && info && "version" in info ? `Version ${(info as { version: string }).version}.` : ""
        }`,
        buttons: ["Restart", "Later"],
        defaultId: 0,
      }).then(({ response }) => {
        if (response === 0) {
          (updater.autoUpdater as unknown as { quitAndInstall: () => void }).quitAndInstall();
        }
      });
    });

    await updater.autoUpdater.checkForUpdatesAndNotify();
    return { ok: true, message: "You are up to date. Checking for updates in the background." };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    log.error(`Update check failed: ${msg}`);
    return { ok: false, message: `Could not check for updates: ${msg}` };
  }
}
