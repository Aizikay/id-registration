# Meru ID Registry — Dev Server Run Doc

## Reproduce Uncommitted Artifacts

No special artifacts needed. Dependencies are pre-installed in `node_modules/`.

## Start the Dev Server

The project path contains spaces and parentheses, which break npm `.cmd` shims when invoked via PowerShell `Start-Process`. Use `C:\node.exe` directly to invoke Vite.

**Detach command (PowerShell):**

```powershell
Start-Process -FilePath 'C:\node.exe' -ArgumentList '"<WORKSPACE>\node_modules\vite\bin\vite.js"','--host','0.0.0.0','--port','5174' -WorkingDirectory '<WORKSPACE>' -RedirectStandardOutput '<LOG>' -RedirectStandardError '<LOG>.err' -WindowStyle Hidden -PassThru | Select-Object -ExpandProperty Id
```

Where:
- `<WORKSPACE>` = `C:\Users\hp\Pictures\ID Registration & Issuance Management System.(MERU DC) - Copy`
- `<LOG>` = `<WORKSPACE>\.freebuff\preview-185ab75d-b7ac-4e90-8d29-bbede45499ca.log`

Note: Port 5173 is occupied by a previous server. Use port 5174.

## Verify

```powershell
Get-Process -Id <PID>
(Invoke-WebRequest -Uri 'http://localhost:5174' -TimeoutSec 5 -UseBasicParsing).StatusCode
```

Expected: `200`

## Access

`http://localhost:5174/login` (app routes live under `/app/*`, e.g. `/app/departments`)

## Desktop app (Electron)

The repo also builds a native Windows desktop app. See `README-DESKTOP.md`.

- Dev: `C:\node.exe scripts/dev-desktop.mjs` (starts Vite on 5174 + Electron window)
- Build installer: `npm run desktop:build` (electron-builder → `dist-desktop/`)
- Main/preload bundling: `C:\node.exe scripts/build-electron.mjs` → `dist-electron/*.cjs`
- Note: Electron's binary postinstall may be blocked by npm allow-scripts;
  run `node node_modules/electron/install.js` once if `node_modules/electron/dist/electron.exe` is missing.
- When the desktop dev test runs it occupies port 5174 — stop the web preview
  first, or the Vite strictPort start will fail.

Note: the PWA service worker can serve a stale bundle after route changes. If a new
route 404s in the preview, unregister service workers + clear caches, then reload:

```js
const regs = await navigator.serviceWorker.getRegistrations();
for (const r of regs) await r.unregister();
for (const k of await caches.keys()) await caches.delete(k);
```
